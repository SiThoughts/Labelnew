"""
One-Click Training Launcher for Anomaly-based Defect Detection

Usage:
    python train_one_click.py --image-type EV
    python train_one_click.py --image-type BV
    python train_one_click.py --image-type TV
"""
import os
import sys
import argparse
import shutil
import numpy as np
from tqdm import tqdm

# Add src to path
sys.path.insert(0, os.path.dirname(__file__))

from src.train import Trainer
from src.export_onnx import main as export_onnx_main


def print_banner():
    """Print welcome banner"""
    banner = """
    ╔═══════════════════════════════════════════════════════════════╗
    ║                                                               ║
    ║     Anomaly-based Defect Detection System                    ║
    ║     One-Click Training Launcher                              ║
    ║                                                               ║
    ║     Detecting: Chip & Check Defects                          ║
    ║     Architecture: SimpleNet + Two-Stage Classification       ║
    ║                                                               ║
    ╚═══════════════════════════════════════════════════════════════╝
    """
    print(banner)


def check_environment():
    """Check if environment is properly set up"""
    print("\n[1/6] Checking environment...")
    
    # Check Python version
    python_version = sys.version_info
    if python_version.major < 3 or (python_version.major == 3 and python_version.minor < 8):
        print("✗ Python 3.8 or higher is required")
        return False
    print(f"✓ Python {python_version.major}.{python_version.minor}.{python_version.micro}")
    
    # Check PyTorch
    try:
        import torch
        print(f"✓ PyTorch {torch.__version__}")
        
        if torch.cuda.is_available():
            print(f"✓ CUDA available: {torch.cuda.get_device_name(0)}")
        else:
            print("⚠ CUDA not available - training will use CPU (slower)")
    except ImportError:
        print("✗ PyTorch not installed")
        print("  Please run: pip install torch torchvision")
        return False
    
    # Check other dependencies
    required_packages = ['torchvision', 'numpy', 'opencv-python', 'pillow', 'tqdm', 'matplotlib']
    missing_packages = []
    
    for package in required_packages:
        pkg_name = package.replace('-', '_')
        try:
            __import__(pkg_name)
            print(f"✓ {package}")
        except ImportError:
            missing_packages.append(package)
            print(f"✗ {package} not installed")
    
    if missing_packages:
        print(f"\n✗ Missing packages: {', '.join(missing_packages)}")
        print("  Please run: pip install " + " ".join(missing_packages))
        return False
    
    return True


def check_data(data_root, image_type):
    """Check if data directory exists and contains images"""
    print(f"\n[2/6] Checking data for {image_type} images...")
    
    data_dir = os.path.join(data_root, image_type)
    
    if not os.path.exists(data_dir):
        print(f"✗ Data directory not found: {data_dir}")
        return False
    
    # Count images and XMLs
    img_exts = ['.png', '.jpg', '.bmp', '..png']
    total_images = 0
    total_xmls = 0
    
    for root, dirs, files in os.walk(data_dir):
        for f in files:
            if any(f.lower().endswith(ext) for ext in img_exts):
                if image_type.lower() in f.lower():
                    total_images += 1
            if f.endswith('.xml'):
                total_xmls += 1
    
    if total_images == 0:
        print(f"✗ No {image_type} images found in {data_dir}")
        return False
    
    if total_xmls == 0:
        print(f"✗ No XML annotation files found")
        return False
    
    print(f"✓ Found {total_images} {image_type} images")
    print(f"✓ Found {total_xmls} XML annotation files")
    
    return True


def split_data(data_root, image_type, results_dir, ratio=0.85):
    """Split data into train and validation sets"""
    print(f"\n[3/6] Splitting data into train/validation sets...")
    
    train_dir = os.path.join(results_dir, "train")
    valid_dir = os.path.join(results_dir, "valid")
    
    # Check if already split
    if os.path.exists(train_dir) and os.path.exists(valid_dir):
        print("✓ Data already split")
        return train_dir, valid_dir
    
    os.makedirs(train_dir, exist_ok=True)
    os.makedirs(valid_dir, exist_ok=True)
    
    # Collect all image files
    data_dir = os.path.join(data_root, image_type)
    img_exts = ['.png', '.jpg', '.bmp', '..png']
    img_files = []
    xml_files = []
    
    for root, dirs, files in os.walk(data_dir):
        for f in files:
            if any(f.lower().endswith(ext) for ext in img_exts):
                if image_type.lower() in f.lower():
                    img_path = os.path.join(root, f)
                    xml_path = img_path.rsplit('.', 1)[0] + '.xml'
                    xml_path = xml_path.replace('..', '.')
                    
                    if os.path.exists(xml_path):
                        img_files.append(img_path)
                        xml_files.append(xml_path)
    
    # Shuffle and split
    indices = list(range(len(img_files)))
    np.random.seed(42)
    np.random.shuffle(indices)
    
    split = int(np.floor(ratio * len(img_files)))
    train_indices = indices[:split]
    val_indices = indices[split:]
    
    # Copy files
    print(f"Copying {len(train_indices)} images to train directory...")
    for idx in tqdm(train_indices):
        shutil.copy(img_files[idx], os.path.join(train_dir, os.path.basename(img_files[idx])))
        shutil.copy(xml_files[idx], os.path.join(train_dir, os.path.basename(xml_files[idx])))
    
    print(f"Copying {len(val_indices)} images to validation directory...")
    for idx in tqdm(val_indices):
        shutil.copy(img_files[idx], os.path.join(valid_dir, os.path.basename(img_files[idx])))
        shutil.copy(xml_files[idx], os.path.join(valid_dir, os.path.basename(xml_files[idx])))
    
    print(f"✓ Data split complete: {len(train_indices)} train, {len(val_indices)} val")
    
    return train_dir, valid_dir


def train_model(train_dir, valid_dir, results_dir, image_type, config):
    """Train the model (two-phase training)"""
    print(f"\n[4/6] Training model for {image_type} images...")
    
    # Create trainer
    trainer = Trainer(config)
    
    # Phase 1: Train anomaly heatmap generator
    print("\nStarting Phase 1: Anomaly Heatmap Training...")
    trainer.train_phase1_anomaly(
        train_dir=train_dir,
        val_dir=valid_dir,
        image_type=image_type,
        epochs=config.get('phase1_epochs', 50),
        batch_size=config.get('batch_size', 8),
        lr=config.get('phase1_lr', 0.0001)
    )
    
    # Phase 2: Train two-stage classifiers
    print("\nStarting Phase 2: Classifier Training...")
    trainer.train_phase2_classifiers(
        train_dir=train_dir,
        val_dir=valid_dir,
        image_type=image_type,
        epochs=config.get('phase2_epochs', 100),
        batch_size=config.get('batch_size', 4),
        lr=config.get('phase2_lr', 0.005)
    )
    
    print(f"\n✓ Training completed")
    print(f"✓ Results saved to: {results_dir}")


def export_model(results_dir, image_type):
    """Export model to ONNX"""
    print(f"\n[5/6] Exporting model to ONNX format...")
    
    model_path = os.path.join(results_dir, 'best_model.pt')
    
    if not os.path.exists(model_path):
        print(f"✗ Model file not found: {model_path}")
        return None
    
    try:
        onnx_path = export_onnx_main(model_path, results_dir, image_type)
        print(f"✓ ONNX model exported to: {onnx_path}")
        return onnx_path
    except Exception as e:
        print(f"✗ ONNX export failed: {e}")
        import traceback
        traceback.print_exc()
        return None


def generate_report(results_dir, image_type):
    """Generate summary report"""
    print(f"\n[6/6] Generating summary report...")
    
    report_path = os.path.join(results_dir, 'training_report.txt')
    
    try:
        from datetime import datetime
        
        with open(report_path, 'w') as f:
            f.write("="*60 + "\n")
            f.write("Anomaly-based Defect Detection Training Report\n")
            f.write("="*60 + "\n\n")
            
            f.write(f"Training Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Image Type: {image_type}\n")
            f.write(f"Results Directory: {results_dir}\n\n")
            
            f.write("Architecture:\n")
            f.write("  - Anomaly Heatmap: SimpleNet-inspired (WideResNet50 backbone)\n")
            f.write("  - Box Generation: Connected components from heatmap\n")
            f.write("  - Classification: Two-stage (defect/non-defect → chip/check)\n\n")
            
            f.write("Training Phases:\n")
            f.write("  - Phase 1: Anomaly heatmap on normal images\n")
            f.write("  - Phase 2: Two-stage classifiers on defect images\n\n")
            
            f.write("Files Generated:\n")
            f.write("-" * 60 + "\n")
            
            for filename in os.listdir(results_dir):
                filepath = os.path.join(results_dir, filename)
                if os.path.isfile(filepath):
                    size = os.path.getsize(filepath) / (1024 * 1024)  # MB
                    f.write(f"  - {filename} ({size:.2f} MB)\n")
            
            f.write("\n" + "="*60 + "\n")
            f.write("Training Complete!\n")
            f.write("="*60 + "\n")
        
        print(f"✓ Report saved to: {report_path}")
        
    except Exception as e:
        print(f"⚠ Could not generate report: {e}")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='One-Click Training for Anomaly-based Defect Detection'
    )
    parser.add_argument(
        '--image-type',
        type=str,
        default='EV',
        choices=['EV', 'BV', 'TV'],
        help='Type of images to train on (default: EV)'
    )
    parser.add_argument(
        '--data-root',
        type=str,
        default='D:/Photomask/merlin',
        help='Root directory containing EV/BV/TV subdirectories'
    )
    parser.add_argument(
        '--results-dir',
        type=str,
        default=None,
        help='Directory to save results (default: ./results/<image_type>)'
    )
    parser.add_argument(
        '--skip-checks',
        action='store_true',
        help='Skip environment and data checks'
    )
    
    args = parser.parse_args()
    
    # Print banner
    print_banner()
    
    # Set results directory
    if args.results_dir is None:
        args.results_dir = os.path.join('./results', args.image_type)
    
    # Run checks
    if not args.skip_checks:
        if not check_environment():
            print("\n✗ Environment check failed. Please fix the issues and try again.")
            sys.exit(1)
        
        if not check_data(args.data_root, args.image_type):
            print("\n✗ Data check failed. Please ensure your data is properly set up.")
            sys.exit(1)
    
    print("\n" + "="*60)
    print("All checks passed! Starting training...")
    print("="*60)
    
    # Split data
    train_dir, valid_dir = split_data(args.data_root, args.image_type, args.results_dir)
    
    # Configuration
    config = {
        'class_mapping': {'chip': 1, 'check': 2},
        'results_dir': args.results_dir,
        'phase1_epochs': 50,
        'phase2_epochs': 100,
        'batch_size': 8 if args.image_type == 'EV' else 16,  # Smaller images = larger batch
        'phase1_lr': 0.0001,
        'phase2_lr': 0.005,
        'score_threshold': 0.5
    }
    
    # Train model
    train_model(train_dir, valid_dir, args.results_dir, args.image_type, config)
    
    # Export to ONNX
    onnx_path = export_model(args.results_dir, args.image_type)
    
    # Generate report
    generate_report(args.results_dir, args.image_type)
    
    # Final summary
    print("\n" + "="*60)
    print("🎉 ONE-CLICK TRAINING COMPLETE! 🎉")
    print("="*60)
    print(f"\nResults Location: {args.results_dir}")
    print("\nGenerated Files:")
    print(f"  • best_model.pt           - Best PyTorch model")
    print(f"  • best_model.onnx         - ONNX model for deployment")
    print(f"  • best_phase1_model.pt    - Phase 1 checkpoint")
    print(f"  • training_report.txt     - Detailed training report")
    print("\nNext Steps:")
    print("  1. Review the training loss plots")
    print("  2. Use best_model.onnx for inference on your device")
    print("  3. The ONNX model outputs: boxes, labels, scores")
    print("  4. Labels: 1=chip, 2=check")
    print("\n" + "="*60 + "\n")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n✗ Training interrupted by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n✗ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
