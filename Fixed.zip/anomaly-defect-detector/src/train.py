"""
Training script for Anomaly-based Defect Detection
Two-phase training:
  Phase 1: Train anomaly heatmap generator on normal images
  Phase 2: Train two-stage classifiers on defect images
"""
import os
import sys
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt

from src.model import AnomalyDefectDetector
from src.dataset import DefectDataset, NormalDataset, collate_fn, collate_fn_normal
from src.loss import AnomalyLoss, match_boxes_to_gt
import torch.nn.functional as F


class Trainer:
    """
    Trainer for anomaly-based defect detection
    """
    def __init__(self, config):
        """
        Args:
            config: dict with training configuration
        """
        self.config = config
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Class mapping
        self.class_mapping = config['class_mapping']  # {'chip': 1, 'check': 2}
        
        # Results directory
        self.results_dir = config['results_dir']
        os.makedirs(self.results_dir, exist_ok=True)
        
        # Initialize model
        self.model = AnomalyDefectDetector(
            pretrained=True,
            roi_output_size=7,
            score_threshold=config.get('score_threshold', 0.5)
        ).to(self.device)
        
        print(f"Model initialized on {self.device}")
        print(f"Results will be saved to: {self.results_dir}")
    
    def train_phase1_anomaly(self, train_dir, val_dir, image_type='EV', 
                             epochs=50, batch_size=8, lr=0.0001):
        """
        Phase 1: Train anomaly heatmap generator on normal images only
        """
        print("\n" + "="*60)
        print("PHASE 1: Training Anomaly Heatmap Generator")
        print("="*60)
        
        # Create datasets (normal images only)
        train_dataset = NormalDataset(train_dir, image_type=image_type)
        val_dataset = NormalDataset(val_dir, image_type=image_type)
        
        if len(train_dataset) == 0:
            print("Warning: No normal training images found. Skipping Phase 1.")
            return
        
        train_loader = DataLoader(train_dataset, batch_size=batch_size, 
                                 shuffle=True, num_workers=4, 
                                 collate_fn=collate_fn_normal)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, 
                               shuffle=False, num_workers=4,
                               collate_fn=collate_fn_normal)
        
        # Optimizer (only for feature adaptor and discriminator)
        params = list(self.model.feature_adaptor.parameters()) + \
                list(self.model.anomaly_discriminator.parameters())
        optimizer = optim.Adam(params, lr=lr, weight_decay=0.00001)
        
        # Loss
        criterion = AnomalyLoss()
        
        # Training loop
        best_val_loss = float('inf')
        train_losses = []
        val_losses = []
        
        for epoch in range(epochs):
            # Train
            self.model.train()
            train_loss = 0
            
            for images in tqdm(train_loader, desc=f'Phase 1 Epoch {epoch+1}/{epochs}'):
                images = images.to(self.device)
                
                # Forward pass
                anomaly_map, adapted_features = self.model(images, training_phase='anomaly')
                
                # Generate synthetic anomalous features
                anomalous_features = []
                for feat in adapted_features:
                    # Add Gaussian noise
                    noise = torch.randn_like(feat) * 0.015  # σ=0.015 as in SimpleNet
                    anomalous_feat = feat + noise
                    anomalous_features.append(anomalous_feat)
                
                # Get anomaly scores for synthetic anomalous features
                anomaly_map_anomalous = self.model.anomaly_discriminator(anomalous_features)
                
                # Compute loss
                loss = criterion(anomaly_map, anomaly_map_anomalous)
                
                # Backward
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                
                train_loss += loss.item()
            
            train_loss /= len(train_loader)
            train_losses.append(train_loss)
            
            # Validation
            val_loss = self._validate_phase1(val_loader, criterion)
            val_losses.append(val_loss)
            
            print(f"Epoch {epoch+1}/{epochs} - Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}")
            
            # Save best model
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                torch.save(self.model.state_dict(), 
                          os.path.join(self.results_dir, 'best_phase1_model.pt'))
                print(f"  → Saved best Phase 1 model (val_loss: {val_loss:.4f})")
        
        # Plot losses
        self._plot_losses(train_losses, val_losses, 'Phase 1: Anomaly Detection')
        
        print(f"\nPhase 1 training completed. Best val loss: {best_val_loss:.4f}")
    
    def _validate_phase1(self, val_loader, criterion):
        """Validate Phase 1 (anomaly detection)"""
        self.model.eval()
        val_loss = 0
        
        with torch.no_grad():
            for images in val_loader:
                images = images.to(self.device)
                
                anomaly_map, adapted_features = self.model(images, training_phase='anomaly')
                
                # Generate synthetic anomalous features
                anomalous_features = []
                for feat in adapted_features:
                    noise = torch.randn_like(feat) * 0.015
                    anomalous_feat = feat + noise
                    anomalous_features.append(anomalous_feat)
                
                anomaly_map_anomalous = self.model.anomaly_discriminator(anomalous_features)
                
                loss = criterion(anomaly_map, anomaly_map_anomalous)
                val_loss += loss.item()
        
        return val_loss / len(val_loader)
    
    def train_phase2_classifiers(self, train_dir, val_dir, image_type='EV',
                                 epochs=100, batch_size=4, lr=0.005):
        """
        Phase 2: Train two-stage classifiers on defect images
        """
        print("\n" + "="*60)
        print("PHASE 2: Training Two-Stage Classifiers")
        print("="*60)
        
        # Load best Phase 1 model
        phase1_model_path = os.path.join(self.results_dir, 'best_phase1_model.pt')
        if os.path.exists(phase1_model_path):
            self.model.load_state_dict(torch.load(phase1_model_path))
            print("Loaded Phase 1 model weights")
        
        # Create datasets (all images, including defects)
        train_dataset = DefectDataset(train_dir, self.class_mapping, image_type=image_type)
        val_dataset = DefectDataset(val_dir, self.class_mapping, image_type=image_type)
        
        train_loader = DataLoader(train_dataset, batch_size=batch_size,
                                 shuffle=True, num_workers=4,
                                 collate_fn=collate_fn, drop_last=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size,
                               shuffle=False, num_workers=4,
                               collate_fn=collate_fn, drop_last=True)
        
        # Optimizer (only for classifiers)
        params = self.model.classifier.parameters()
        optimizer = optim.SGD(params, lr=lr, momentum=0.9, weight_decay=0.0005)
        lr_scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=30, gamma=0.1)
        
        # Training loop
        best_val_loss = float('inf')
        train_losses = []
        val_losses = []
        
        for epoch in range(epochs):
            # Train
            train_loss = self._train_epoch_phase2(train_loader, optimizer)
            train_losses.append(train_loss)
            
            # Validation
            val_loss, metrics = self._validate_phase2(val_loader)
            val_losses.append(val_loss)
            
            print(f"Epoch {epoch+1}/{epochs} - Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}")
            print(f"  Precision: {metrics['precision']:.3f}, Recall: {metrics['recall']:.3f}, F1: {metrics['f1']:.3f}")
            
            # Save best model
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                torch.save(self.model.state_dict(),
                          os.path.join(self.results_dir, 'best_model.pt'))
                print(f"  → Saved best model (val_loss: {val_loss:.4f})")
            
            # Step scheduler
            lr_scheduler.step()
            
            # Save latest
            torch.save(self.model.state_dict(),
                      os.path.join(self.results_dir, 'latest_model.pt'))
        
        # Plot losses
        self._plot_losses(train_losses, val_losses, 'Phase 2: Classification')
        
        print(f"\nPhase 2 training completed. Best val loss: {best_val_loss:.4f}")
    
    def _train_epoch_phase2(self, train_loader, optimizer):
        """Train one epoch for Phase 2"""
        self.model.train()
        # Freeze anomaly detection components
        for param in self.model.feature_extractor.parameters():
            param.requires_grad = False
        for param in self.model.feature_adaptor.parameters():
            param.requires_grad = False
        for param in self.model.anomaly_discriminator.parameters():
            param.requires_grad = False
        
        epoch_loss = 0
        num_processed_batches = 0
        
        for images, targets in tqdm(train_loader, desc='Training Phase 2'):
            images = images.to(self.device)
            targets = [{k: v.to(self.device) for k, v in t.items()} for t in targets]
            
            # Generate boxes from anomaly heatmap
            with torch.no_grad():
                anomaly_map, adapted_features = self.model(images, training_phase='anomaly')
                pred_boxes_list = self.model.heatmap_to_boxes(anomaly_map, images.shape[2:])
            
            # Skip if no boxes generated
            total_boxes = sum(len(boxes) for boxes in pred_boxes_list)
            if total_boxes == 0:
                continue
            
            # Prepare ROI boxes
            roi_boxes = []
            gt_labels_list = []
            gt_is_defect_list = []
            
            for batch_idx, (pred_boxes, target) in enumerate(zip(pred_boxes_list, targets)):
                if len(pred_boxes) == 0:
                    continue
                
                pred_boxes_tensor = torch.tensor(pred_boxes, dtype=torch.float32, device=self.device)
                gt_boxes = target['boxes']
                gt_labels = target['labels']
                
                # Match predicted boxes to ground truth
                matched_labels, is_defect = match_boxes_to_gt(pred_boxes_tensor, gt_boxes, gt_labels)
                
                # Add to ROI list
                for box in pred_boxes:
                    roi_boxes.append([batch_idx] + box)
                
                gt_labels_list.append(matched_labels)
                gt_is_defect_list.append(is_defect)
            
            if len(roi_boxes) == 0:
                continue
            
            roi_boxes_tensor = torch.tensor(roi_boxes, dtype=torch.float32, device=self.device)
            gt_labels_all = torch.cat(gt_labels_list, dim=0)
            gt_is_defect_all = torch.cat(gt_is_defect_list, dim=0)
            
            # ROI pooling
            feature_dict = {str(i): feat for i, feat in enumerate(adapted_features)}
            image_shapes = [images.shape[2:] for _ in range(images.shape[0])]
            roi_features = self.model.roi_pool(feature_dict, roi_boxes_tensor, image_shapes)
            
            # Classification
            defect_scores, type_scores = self.model.classifier(roi_features)
            
            # Compute losses
            loss_defect = F.cross_entropy(defect_scores, gt_is_defect_all)
            
            # Type loss only for defect boxes
            defect_mask = gt_is_defect_all == 1
            if defect_mask.sum() > 0:
                type_labels = gt_labels_all[defect_mask] - 1  # Convert to 0-indexed
                loss_type = F.cross_entropy(type_scores[defect_mask], type_labels)
            else:
                loss_type = torch.tensor(0.0, device=self.device)
            
            loss = loss_defect + loss_type
            
            # Backward
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            epoch_loss += loss.item()
            num_processed_batches += 1
        
        # Return average loss (handle case where no batches were processed)
        if num_processed_batches == 0:
            return 0.0
        return epoch_loss / num_processed_batches
    
    def _validate_phase2(self, val_loader):
        """Validate Phase 2 (classification)"""
        self.model.eval()
        val_loss = 0
        num_batches = 0
        
        # Metrics
        tp, fp, fn = 0, 0, 0
        
        with torch.no_grad():
            for images, targets in val_loader:
                images = images.to(self.device)
                targets = [{k: v.to(self.device) for k, v in t.items()} for t in targets]
                
                # Forward pass
                outputs = self.model(images, boxes=None, training_phase='full')
                
                # Simple loss approximation (for monitoring only)
                # In validation, we just track metrics, not actual loss
                num_batches += 1
                
                # Compute metrics
                # Note: outputs contains all detections from the batch
                # We need to match them to ground truth boxes from all images
                pred_boxes = outputs['boxes']
                pred_labels = outputs['labels']
                
                # Collect all GT boxes and labels from batch
                all_gt_boxes = []
                all_gt_labels = []
                for target in targets:
                    if len(target['boxes']) > 0:
                        all_gt_boxes.append(target['boxes'])
                        all_gt_labels.append(target['labels'])
                
                if len(all_gt_boxes) > 0:
                    gt_boxes = torch.cat(all_gt_boxes, dim=0)
                    gt_labels = torch.cat(all_gt_labels, dim=0)
                else:
                    gt_boxes = torch.zeros((0, 4), device=self.device)
                    gt_labels = torch.zeros((0,), dtype=torch.long, device=self.device)
                
                if len(gt_boxes) > 0 and len(pred_boxes) > 0:
                    # Compute IoU
                    from src.loss import compute_iou
                    iou = compute_iou(pred_boxes, gt_boxes)
                    max_iou, max_idx = iou.max(dim=1)
                    
                    # Count TP, FP
                    for i, (iou_val, pred_label) in enumerate(zip(max_iou, pred_labels)):
                        if iou_val >= 0.5:
                            if pred_label == gt_labels[max_idx[i]]:
                                tp += 1
                            else:
                                fp += 1
                        else:
                            fp += 1
                    
                    # Count FN
                    matched_gt = torch.zeros(len(gt_boxes), dtype=torch.bool, device=self.device)
                    for i, iou_val in enumerate(max_iou):
                        if iou_val >= 0.5:
                            matched_gt[max_idx[i]] = True
                    fn += (~matched_gt).sum().item()
                elif len(gt_boxes) > 0:
                    fn += len(gt_boxes)
                elif len(pred_boxes) > 0:
                    fp += len(pred_boxes)
        
        # Compute metrics
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
        
        metrics = {
            'precision': precision,
            'recall': recall,
            'f1': f1
        }
        
        # Use negative F1 as validation "loss" (lower is better)
        val_loss = 1.0 - f1
        
        return val_loss, metrics
    
    def _plot_losses(self, train_losses, val_losses, title):
        """Plot training and validation losses"""
        plt.figure(figsize=(10, 6))
        plt.plot(train_losses, label='Train Loss')
        plt.plot(val_losses, label='Val Loss')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.title(title)
        plt.legend()
        plt.grid(True)
        plt.savefig(os.path.join(self.results_dir, f'{title.replace(" ", "_").replace(":", "")}_losses.png'))
        plt.close()
