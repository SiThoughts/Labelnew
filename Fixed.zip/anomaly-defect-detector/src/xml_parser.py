"""
XML Parser for Pascal VOC format annotations
Handles both defect and non-defect images
"""
import xml.etree.ElementTree as ET
import os


def parse_xml(xml_path):
    """
    Parse Pascal VOC XML annotation file
    
    Args:
        xml_path: Path to XML file
    
    Returns:
        dict with keys:
            - filename: Image filename
            - size: (width, height, depth)
            - objects: List of dicts with 'name' and 'bbox' (xmin, ymin, xmax, ymax)
            - has_defects: Boolean indicating if image has defects
    """
    if not os.path.exists(xml_path):
        raise FileNotFoundError(f"XML file not found: {xml_path}")
    
    tree = ET.parse(xml_path)
    root = tree.getroot()
    
    # Parse filename
    filename = root.find('filename')
    filename = filename.text if filename is not None else None
    
    # Parse size
    size_elem = root.find('size')
    if size_elem is not None:
        width = int(size_elem.find('width').text)
        height = int(size_elem.find('height').text)
        depth_elem = size_elem.find('depth')
        depth = int(depth_elem.text) if depth_elem is not None else 3
        size = (width, height, depth)
    else:
        size = None
    
    # Parse objects
    objects = []
    for obj in root.findall('object'):
        name_elem = obj.find('name')
        name = name_elem.text if name_elem is not None else None
        
        bbox_elem = obj.find('bndbox')
        if bbox_elem is not None:
            xmin = int(float(bbox_elem.find('xmin').text))
            ymin = int(float(bbox_elem.find('ymin').text))
            xmax = int(float(bbox_elem.find('xmax').text))
            ymax = int(float(bbox_elem.find('ymax').text))
            bbox = (xmin, ymin, xmax, ymax)
        else:
            bbox = None
        
        if name and bbox:
            objects.append({
                'name': name.lower(),  # Normalize to lowercase
                'bbox': bbox
            })
    
    # Determine if image has defects
    has_defects = len(objects) > 0
    
    return {
        'filename': filename,
        'size': size,
        'objects': objects,
        'has_defects': has_defects
    }


def get_class_id(class_name, class_mapping):
    """
    Get class ID from class name
    
    Args:
        class_name: Name of the class (e.g., 'chip', 'check')
        class_mapping: Dict mapping class names to IDs
    
    Returns:
        Class ID (int)
    """
    class_name = class_name.lower()
    if class_name in class_mapping:
        return class_mapping[class_name]
    else:
        raise ValueError(f"Unknown class name: {class_name}")


def filter_objects_by_class(objects, valid_classes):
    """
    Filter objects to only include valid classes
    
    Args:
        objects: List of object dicts
        valid_classes: List of valid class names
    
    Returns:
        Filtered list of objects
    """
    valid_classes_lower = [c.lower() for c in valid_classes]
    return [obj for obj in objects if obj['name'] in valid_classes_lower]
