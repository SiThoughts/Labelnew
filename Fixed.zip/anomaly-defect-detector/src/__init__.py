"""
Anomaly-based Defect Detection System
Source package
"""

__version__ = "1.0.0"
