"""
Anomaly-based Defect Detection Model
Combines SimpleNet-style anomaly heatmap with two-stage classification
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from torchvision.models import wide_resnet50_2
from typing import List, Tuple, Dict
import cv2
import numpy as np


class FeatureExtractor(nn.Module):
    """
    Extract multi-scale features from pretrained WideResNet50
    """
    def __init__(self, pretrained=True):
        super().__init__()
        # Load pretrained WideResNet50
        backbone = wide_resnet50_2(pretrained=pretrained)
        
        # Extract layers for multi-scale features
        self.layer1 = nn.Sequential(*list(backbone.children())[:5])  # Output: C=256
        self.layer2 = backbone.layer2  # Output: C=512
        self.layer3 = backbone.layer3  # Output: C=1024
        
        # Channel counts for each level
        self.out_channels = [256, 512, 1024]
        
    def forward(self, x):
        """
        Extract multi-scale features
        Returns: List of feature maps at different scales
        """
        features = []
        
        x = self.layer1(x)
        features.append(x)
        
        x = self.layer2(x)
        features.append(x)
        
        x = self.layer3(x)
        features.append(x)
        
        return features


class FeatureAdaptor(nn.Module):
    """
    Adapt pretrained features to target domain
    """
    def __init__(self, in_channels_list):
        super().__init__()
        # Single FC layer for each scale
        self.adaptors = nn.ModuleList([
            nn.Linear(c, c) for c in in_channels_list
        ])
        
    def forward(self, features):
        """
        Adapt features from each scale
        """
        adapted = []
        for feat, adaptor in zip(features, self.adaptors):
            # feat: [B, C, H, W]
            B, C, H, W = feat.shape
            feat_flat = feat.permute(0, 2, 3, 1).reshape(-1, C)  # [B*H*W, C]
            adapted_flat = adaptor(feat_flat)  # [B*H*W, C]
            adapted_feat = adapted_flat.reshape(B, H, W, C).permute(0, 3, 1, 2)  # [B, C, H, W]
            adapted.append(adapted_feat)
        return adapted


class AnomalyDiscriminator(nn.Module):
    """
    Discriminator to generate pixel-wise anomaly scores
    """
    def __init__(self, in_channels_list):
        super().__init__()
        total_channels = sum(in_channels_list)
        
        # Simple 2-layer MLP
        self.discriminator = nn.Sequential(
            nn.Linear(total_channels, 512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(512, 1)
        )
        
    def forward(self, features):
        """
        Generate anomaly score map
        features: List of [B, C, H, W] tensors
        Returns: [B, H, W] anomaly score map
        """
        # Upsample all features to the same size (largest)
        target_size = features[0].shape[2:]  # Use first scale size
        
        upsampled = []
        for feat in features:
            if feat.shape[2:] != target_size:
                feat = F.interpolate(feat, size=target_size, mode='bilinear', align_corners=False)
            upsampled.append(feat)
        
        # Concatenate along channel dimension
        concat_feat = torch.cat(upsampled, dim=1)  # [B, total_C, H, W]
        
        # Apply discriminator per pixel
        B, C, H, W = concat_feat.shape
        feat_flat = concat_feat.permute(0, 2, 3, 1).reshape(-1, C)  # [B*H*W, C]
        scores_flat = self.discriminator(feat_flat)  # [B*H*W, 1]
        scores = scores_flat.reshape(B, H, W)  # [B, H, W]
        
        return scores


class DefectClassifier(nn.Module):
    """
    Two-stage classifier: 
    1. Defect vs Non-Defect
    2. Chip vs Check
    """
    def __init__(self, roi_output_size=7):
        super().__init__()
        
        # ROI feature dimension after pooling
        roi_feature_dim = 1024 * roi_output_size * roi_output_size
        
        # Stage 1: Defect vs Non-Defect
        self.defect_classifier = nn.Sequential(
            nn.Linear(roi_feature_dim, 512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(512, 2)  # [non-defect, defect]
        )
        
        # Stage 2: Chip vs Check
        self.type_classifier = nn.Sequential(
            nn.Linear(roi_feature_dim, 512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(512, 2)  # [chip, check]
        )
        
    def forward(self, roi_features):
        """
        roi_features: [N, C, H, W] ROI pooled features
        Returns: defect_scores [N, 2], type_scores [N, 2]
        """
        # Flatten ROI features
        roi_flat = roi_features.flatten(1)  # [N, C*H*W]
        
        # Stage 1: Defect classification
        defect_scores = self.defect_classifier(roi_flat)  # [N, 2]
        
        # Stage 2: Type classification
        type_scores = self.type_classifier(roi_flat)  # [N, 2]
        
        return defect_scores, type_scores


class AnomalyDefectDetector(nn.Module):
    """
    Complete model: Anomaly heatmap → Boxes → Two-stage classification
    """
    def __init__(self, pretrained=True, roi_output_size=7, score_threshold=0.5):
        super().__init__()
        
        # Stage 1: Anomaly heatmap generation
        self.feature_extractor = FeatureExtractor(pretrained=pretrained)
        in_channels_list = self.feature_extractor.out_channels
        self.feature_adaptor = FeatureAdaptor(in_channels_list)
        self.anomaly_discriminator = AnomalyDiscriminator(in_channels_list)
        
        # Stage 2: ROI pooling for box features
        self.roi_pool = torchvision.ops.MultiScaleRoIAlign(
            featmap_names=['0', '1', '2'],
            output_size=roi_output_size,
            sampling_ratio=2
        )
        
        # Stage 3: Two-stage classification
        self.classifier = DefectClassifier(roi_output_size)
        
        self.score_threshold = score_threshold
        
    def forward(self, images, boxes=None, training_phase='full'):
        """
        Forward pass with different modes
        
        Args:
            images: [B, 3, H, W] input images
            boxes: Optional list of boxes for training
            training_phase: 'anomaly', 'classifier', or 'full'
        
        Returns:
            Depends on training_phase
        """
        # Extract features
        features = self.feature_extractor(images)
        
        # Adapt features
        adapted_features = self.feature_adaptor(features)
        
        # Generate anomaly heatmap
        anomaly_map = self.anomaly_discriminator(adapted_features)  # [B, H, W]
        
        if training_phase == 'anomaly':
            # Only return anomaly map for Phase 1 training
            return anomaly_map, adapted_features
        
        # Generate boxes from heatmap (if not provided)
        if boxes is None:
            boxes = self.heatmap_to_boxes(anomaly_map, images.shape[2:])
        
        if len(boxes) == 0:
            # No boxes detected, return empty results
            return {
                'boxes': torch.zeros((0, 4), device=images.device),
                'labels': torch.zeros((0,), dtype=torch.long, device=images.device),
                'scores': torch.zeros((0,), device=images.device),
                'anomaly_map': anomaly_map
            }
        
        # ROI pooling
        # Convert boxes to ROI format: [batch_idx, x1, y1, x2, y2]
        roi_boxes = self._prepare_roi_boxes(boxes, images.shape[0], images.device)
        
        # Create feature dict for ROI pooling
        feature_dict = {str(i): feat for i, feat in enumerate(adapted_features)}
        
        # Pool features (need list of image shapes for each image in batch)
        image_shapes = [images.shape[2:] for _ in range(images.shape[0])]
        roi_features = self.roi_pool(feature_dict, roi_boxes, image_shapes)  # [N, C, 7, 7]
        
        # Two-stage classification
        defect_scores, type_scores = self.classifier(roi_features)
        
        # Process outputs
        defect_probs = F.softmax(defect_scores, dim=1)  # [N, 2]
        type_probs = F.softmax(type_scores, dim=1)  # [N, 2]
        
        # Filter: Keep only defects
        is_defect = defect_probs[:, 1] > self.score_threshold
        
        if is_defect.sum() == 0:
            # No defects detected
            return {
                'boxes': torch.zeros((0, 4), device=images.device),
                'labels': torch.zeros((0,), dtype=torch.long, device=images.device),
                'scores': torch.zeros((0,), device=images.device),
                'anomaly_map': anomaly_map
            }
        
        # Get final boxes, labels, scores
        final_boxes = self._extract_boxes_from_list(boxes, is_defect, images.device)
        final_labels = torch.argmax(type_probs[is_defect], dim=1) + 1  # 1=chip, 2=check
        final_scores = defect_probs[is_defect, 1] * torch.max(type_probs[is_defect], dim=1)[0]
        
        return {
            'boxes': final_boxes,
            'labels': final_labels,
            'scores': final_scores,
            'anomaly_map': anomaly_map,
            'all_defect_scores': defect_scores,
            'all_type_scores': type_scores
        }
    
    def heatmap_to_boxes(self, anomaly_map, image_size, threshold=0.3, min_area=100):
        """
        Convert anomaly heatmap to bounding boxes
        
        Args:
            anomaly_map: [B, H, W] anomaly scores
            image_size: (H, W) original image size
            threshold: Threshold for binarization
            min_area: Minimum box area
        
        Returns:
            List of boxes for each image in batch
        """
        batch_boxes = []
        
        for b in range(anomaly_map.shape[0]):
            heatmap = anomaly_map[b].detach().cpu().numpy()
            
            # Upsample heatmap to image size
            # Note: cv2.resize expects (width, height), image_size is (height, width)
            heatmap_resized = cv2.resize(heatmap, (image_size[1], image_size[0]))
            
            # Apply Gaussian smoothing
            heatmap_smooth = cv2.GaussianBlur(heatmap_resized, (5, 5), 4)
            
            # Threshold
            binary_mask = (heatmap_smooth > threshold).astype(np.uint8)
            
            # Find connected components
            num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(binary_mask, connectivity=8)
            
            boxes = []
            for i in range(1, num_labels):  # Skip background (0)
                x, y, w, h, area = stats[i]
                
                if area < min_area:
                    continue
                
                # Convert to [x1, y1, x2, y2]
                box = [x, y, x + w, y + h]
                boxes.append(box)
            
            batch_boxes.append(boxes)
        
        return batch_boxes
    
    def _prepare_roi_boxes(self, boxes_list, batch_size, device):
        """
        Prepare boxes for ROI pooling
        
        Args:
            boxes_list: List of boxes for each image in batch
            batch_size: Batch size
            device: Device to create tensor on
        """
        roi_boxes = []
        for batch_idx, boxes in enumerate(boxes_list):
            for box in boxes:
                # Format: [batch_idx, x1, y1, x2, y2]
                roi_box = [batch_idx] + box
                roi_boxes.append(roi_box)
        
        if len(roi_boxes) == 0:
            return torch.zeros((0, 5), device=device)
        
        return torch.tensor(roi_boxes, dtype=torch.float32, device=device)
    
    def _extract_boxes_from_list(self, boxes_list, mask, device):
        """
        Extract boxes based on mask
        
        Args:
            boxes_list: List of boxes
            mask: Boolean mask for filtering
            device: Device to create tensor on
        """
        all_boxes = []
        for boxes in boxes_list:
            all_boxes.extend(boxes)
        
        if len(all_boxes) == 0:
            return torch.zeros((0, 4), device=device)
        
        all_boxes_tensor = torch.tensor(all_boxes, dtype=torch.float32, device=device)
        return all_boxes_tensor[mask]


class AnomalyDefectDetectorONNX(nn.Module):
    """
    ONNX-compatible wrapper for inference
    Outputs: boxes, labels, scores (matching Faster R-CNN format from train.py)
    """
    def __init__(self, model):
        super().__init__()
        self.model = model
        self.model.eval()
        
    def forward(self, images):
        """
        ONNX-compatible forward pass
        Matches the output format of Faster R-CNN in train.py
        
        Args:
            images: [1, 3, H, W] input images (batch size 1 for ONNX)
        
        Returns:
            boxes: [N, 4] bounding boxes [x1, y1, x2, y2]
            labels: [N] class labels (1=chip, 2=check)
            scores: [N] confidence scores [0, 1]
        """
        with torch.no_grad():
            # Get model predictions
            outputs = self.model(images, boxes=None, training_phase='full')
            
            boxes = outputs['boxes']
            labels = outputs['labels']
            scores = outputs['scores']
            
            # ONNX export requires at least one detection
            # If no detections, return a dummy box with score 0
            if boxes.shape[0] == 0:
                boxes = torch.zeros((1, 4), dtype=torch.float32, device=images.device)
                labels = torch.ones((1,), dtype=torch.int64, device=images.device)
                scores = torch.zeros((1,), dtype=torch.float32, device=images.device)
            
            # Ensure correct dtypes for ONNX
            boxes = boxes.float()
            labels = labels.long()
            scores = scores.float()
            
            return boxes, labels, scores
