"""
Dataset classes for anomaly-based defect detection
Handles both normal (no defect) and defect images
"""
import os
import torch
from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as transforms
from src.xml_parser import parse_xml, get_class_id, filter_objects_by_class


class DefectDataset(Dataset):
    """
    Dataset for defect detection
    Loads images and XML annotations from directory
    """
    def __init__(self, data_dir, class_mapping, image_type='EV', 
                 transform=None, defect_only=False, normal_only=False):
        """
        Args:
            data_dir: Directory containing images and XML files
            class_mapping: Dict mapping class names to IDs {'chip': 1, 'check': 2}
            image_type: Type of images to load ('EV', 'BV', 'TV')
            transform: Optional transform to apply
            defect_only: If True, only load images with defects
            normal_only: If True, only load images without defects
        """
        self.data_dir = data_dir
        self.class_mapping = class_mapping
        self.image_type = image_type.lower()
        self.transform = transform
        self.defect_only = defect_only
        self.normal_only = normal_only
        
        # Get all image files
        self.samples = self._load_samples()
        
        print(f"Loaded {len(self.samples)} {image_type} images from {data_dir}")
        if defect_only:
            print(f"  - Defect images only")
        elif normal_only:
            print(f"  - Normal images only")
    
    def _load_samples(self):
        """Load all valid image-xml pairs"""
        samples = []
        
        # Supported image extensions
        img_exts = ['.png', '.jpg', '.bmp', '..png']
        
        # Walk through directory
        for root, dirs, files in os.walk(self.data_dir):
            for filename in files:
                # Check if it's an image file with correct type
                if any(filename.lower().endswith(ext) for ext in img_exts):
                    if self.image_type in filename.lower():
                        img_path = os.path.join(root, filename)
                        
                        # Find corresponding XML
                        xml_filename = filename.rsplit('.', 1)[0] + '.xml'
                        xml_filename = xml_filename.replace('..', '.')
                        xml_path = os.path.join(root, xml_filename)
                        
                        if os.path.exists(xml_path):
                            # Parse XML to check if it has defects
                            try:
                                annotation = parse_xml(xml_path)
                                has_defects = annotation['has_defects']
                                
                                # Filter based on defect_only/normal_only
                                if self.defect_only and not has_defects:
                                    continue
                                if self.normal_only and has_defects:
                                    continue
                                
                                samples.append({
                                    'image_path': img_path,
                                    'xml_path': xml_path,
                                    'has_defects': has_defects,
                                    'annotation': annotation
                                })
                            except Exception as e:
                                print(f"Warning: Failed to parse {xml_path}: {e}")
        
        return samples
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        """
        Returns:
            image: [3, H, W] tensor
            target: dict with keys:
                - boxes: [N, 4] tensor (x1, y1, x2, y2)
                - labels: [N] tensor (class IDs)
                - has_defects: bool
                - image_id: int
        """
        sample = self.samples[idx]
        
        # Load image
        image = Image.open(sample['image_path']).convert('RGB')
        
        # Parse annotation
        annotation = sample['annotation']
        
        # Extract boxes and labels
        boxes = []
        labels = []
        
        if annotation['has_defects']:
            # Filter objects to only include valid classes
            valid_classes = list(self.class_mapping.keys())
            objects = filter_objects_by_class(annotation['objects'], valid_classes)
            
            for obj in objects:
                bbox = obj['bbox']  # (xmin, ymin, xmax, ymax)
                boxes.append(bbox)
                
                class_id = get_class_id(obj['name'], self.class_mapping)
                labels.append(class_id)
        
        # Convert to tensors
        if len(boxes) > 0:
            boxes = torch.tensor(boxes, dtype=torch.float32)
            labels = torch.tensor(labels, dtype=torch.int64)
        else:
            boxes = torch.zeros((0, 4), dtype=torch.float32)
            labels = torch.zeros((0,), dtype=torch.int64)
        
        # Create target dict
        target = {
            'boxes': boxes,
            'labels': labels,
            'has_defects': torch.tensor([1.0 if annotation['has_defects'] else 0.0], dtype=torch.float32),
            'image_id': torch.tensor([idx], dtype=torch.int64)
        }
        
        # Apply transforms
        if self.transform:
            image, target = self.transform(image, target)
        else:
            # Default: convert to tensor
            image = transforms.ToTensor()(image)
        
        return image, target


class NormalDataset(Dataset):
    """
    Dataset for normal (no defect) images only
    Used for Phase 1 training (anomaly detector)
    """
    def __init__(self, data_dir, image_type='EV', transform=None):
        """
        Args:
            data_dir: Directory containing images and XML files
            image_type: Type of images to load ('EV', 'BV', 'TV')
            transform: Optional transform to apply
        """
        self.data_dir = data_dir
        self.image_type = image_type.lower()
        self.transform = transform
        
        # Get all normal images
        self.samples = self._load_normal_samples()
        
        print(f"Loaded {len(self.samples)} normal {image_type} images from {data_dir}")
    
    def _load_normal_samples(self):
        """Load all normal (no defect) images"""
        samples = []
        
        img_exts = ['.png', '.jpg', '.bmp', '..png']
        
        for root, dirs, files in os.walk(self.data_dir):
            for filename in files:
                if any(filename.lower().endswith(ext) for ext in img_exts):
                    if self.image_type in filename.lower():
                        img_path = os.path.join(root, filename)
                        
                        # Find corresponding XML
                        xml_filename = filename.rsplit('.', 1)[0] + '.xml'
                        xml_filename = xml_filename.replace('..', '.')
                        xml_path = os.path.join(root, xml_filename)
                        
                        if os.path.exists(xml_path):
                            try:
                                annotation = parse_xml(xml_path)
                                
                                # Only include images without defects
                                if not annotation['has_defects']:
                                    samples.append({
                                        'image_path': img_path,
                                        'xml_path': xml_path
                                    })
                            except Exception as e:
                                print(f"Warning: Failed to parse {xml_path}: {e}")
        
        return samples
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        """
        Returns:
            image: [3, H, W] tensor
        """
        sample = self.samples[idx]
        
        # Load image
        image = Image.open(sample['image_path']).convert('RGB')
        
        # Apply transforms
        if self.transform:
            image = self.transform(image)
        else:
            image = transforms.ToTensor()(image)
        
        return image


def collate_fn(batch):
    """
    Custom collate function for DataLoader
    Handles variable number of boxes per image
    """
    images = []
    targets = []
    
    for image, target in batch:
        images.append(image)
        targets.append(target)
    
    # Stack images
    images = torch.stack(images, dim=0)
    
    return images, targets


def collate_fn_normal(batch):
    """
    Collate function for normal images (no targets)
    """
    return torch.stack(batch, dim=0)
