"""
Loss functions for anomaly-based defect detection
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class AnomalyLoss(nn.Module):
    """
    Loss for anomaly heatmap training (SimpleNet-style)
    Truncated L1 loss for discriminating normal vs anomalous features
    """
    def __init__(self, th_plus=0.5, th_minus=-0.5):
        super().__init__()
        self.th_plus = th_plus
        self.th_minus = th_minus
    
    def forward(self, anomaly_scores_normal, anomaly_scores_anomalous):
        """
        Args:
            anomaly_scores_normal: [B, H, W] scores for normal features
            anomaly_scores_anomalous: [B, H, W] scores for synthetic anomalous features
        
        Returns:
            loss: scalar
        """
        # Loss for normal samples (should be positive)
        loss_normal = torch.clamp(self.th_plus - anomaly_scores_normal, min=0)
        
        # Loss for anomalous samples (should be negative)
        loss_anomalous = torch.clamp(-self.th_minus + anomaly_scores_anomalous, min=0)
        
        # Combine losses
        loss = loss_normal.mean() + loss_anomalous.mean()
        
        return loss


class DefectClassificationLoss(nn.Module):
    """
    Loss for two-stage classification
    """
    def __init__(self, defect_weight=1.0, type_weight=1.0):
        super().__init__()
        self.defect_weight = defect_weight
        self.type_weight = type_weight
        self.ce_loss = nn.CrossEntropyLoss()
    
    def forward(self, defect_scores, type_scores, targets):
        """
        Args:
            defect_scores: [N, 2] defect vs non-defect scores
            type_scores: [N, 2] chip vs check scores
            targets: List of target dicts with 'boxes', 'labels', 'has_defects'
        
        Returns:
            loss_dict: dict with 'loss_defect', 'loss_type', 'loss_total'
        """
        # Extract ground truth labels
        # For defect classification: 0=non-defect, 1=defect
        # For type classification: 0=chip, 1=check (only for defect boxes)
        
        # This will be implemented during training based on box matching
        # For now, return placeholder
        loss_defect = self.ce_loss(defect_scores, torch.zeros(defect_scores.shape[0], dtype=torch.long, device=defect_scores.device))
        loss_type = self.ce_loss(type_scores, torch.zeros(type_scores.shape[0], dtype=torch.long, device=type_scores.device))
        
        loss_total = self.defect_weight * loss_defect + self.type_weight * loss_type
        
        return {
            'loss_defect': loss_defect,
            'loss_type': loss_type,
            'loss_total': loss_total
        }


class CombinedLoss(nn.Module):
    """
    Combined loss for end-to-end training
    """
    def __init__(self, anomaly_weight=0.5, defect_weight=1.0, type_weight=1.0):
        super().__init__()
        self.anomaly_weight = anomaly_weight
        self.anomaly_loss = AnomalyLoss()
        self.classification_loss = DefectClassificationLoss(defect_weight, type_weight)
    
    def forward(self, anomaly_scores_normal, anomaly_scores_anomalous, 
                defect_scores, type_scores, targets):
        """
        Combined loss for all components
        """
        loss_anomaly = self.anomaly_loss(anomaly_scores_normal, anomaly_scores_anomalous)
        loss_dict = self.classification_loss(defect_scores, type_scores, targets)
        
        loss_total = (self.anomaly_weight * loss_anomaly + 
                     loss_dict['loss_total'])
        
        return {
            'loss_anomaly': loss_anomaly,
            'loss_defect': loss_dict['loss_defect'],
            'loss_type': loss_dict['loss_type'],
            'loss_total': loss_total
        }


def compute_iou(boxes1, boxes2):
    """
    Compute IoU between two sets of boxes
    
    Args:
        boxes1: [N, 4] tensor (x1, y1, x2, y2)
        boxes2: [M, 4] tensor (x1, y1, x2, y2)
    
    Returns:
        iou: [N, M] tensor of IoU values
    """
    # Expand dimensions for broadcasting
    boxes1 = boxes1.unsqueeze(1)  # [N, 1, 4]
    boxes2 = boxes2.unsqueeze(0)  # [1, M, 4]
    
    # Compute intersection
    x1 = torch.max(boxes1[..., 0], boxes2[..., 0])
    y1 = torch.max(boxes1[..., 1], boxes2[..., 1])
    x2 = torch.min(boxes1[..., 2], boxes2[..., 2])
    y2 = torch.min(boxes1[..., 3], boxes2[..., 3])
    
    intersection = torch.clamp(x2 - x1, min=0) * torch.clamp(y2 - y1, min=0)
    
    # Compute areas
    area1 = (boxes1[..., 2] - boxes1[..., 0]) * (boxes1[..., 3] - boxes1[..., 1])
    area2 = (boxes2[..., 2] - boxes2[..., 0]) * (boxes2[..., 3] - boxes2[..., 1])
    
    # Compute union
    union = area1 + area2 - intersection
    
    # Compute IoU
    iou = intersection / (union + 1e-6)
    
    return iou


def match_boxes_to_gt(pred_boxes, gt_boxes, gt_labels, iou_threshold=0.5):
    """
    Match predicted boxes to ground truth boxes
    
    Args:
        pred_boxes: [N, 4] predicted boxes
        gt_boxes: [M, 4] ground truth boxes
        gt_labels: [M] ground truth labels
        iou_threshold: IoU threshold for positive match
    
    Returns:
        matched_labels: [N] labels for each predicted box
            - 0 for background (non-defect)
            - 1, 2, ... for defect classes
        is_defect: [N] binary labels (0=non-defect, 1=defect)
    """
    if len(gt_boxes) == 0:
        # No ground truth boxes, all predictions are background
        matched_labels = torch.zeros(len(pred_boxes), dtype=torch.long, device=pred_boxes.device)
        is_defect = torch.zeros(len(pred_boxes), dtype=torch.long, device=pred_boxes.device)
        return matched_labels, is_defect
    
    # Compute IoU
    iou = compute_iou(pred_boxes, gt_boxes)  # [N, M]
    
    # Find best matching GT for each prediction
    max_iou, max_idx = iou.max(dim=1)  # [N]
    
    # Assign labels based on IoU threshold
    matched_labels = torch.zeros(len(pred_boxes), dtype=torch.long, device=pred_boxes.device)
    is_defect = torch.zeros(len(pred_boxes), dtype=torch.long, device=pred_boxes.device)
    
    positive_mask = max_iou >= iou_threshold
    matched_labels[positive_mask] = gt_labels[max_idx[positive_mask]]
    is_defect[positive_mask] = 1
    
    return matched_labels, is_defect
