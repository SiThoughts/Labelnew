"""
ONNX Export for Anomaly-based Defect Detection
Exports model to ONNX format matching Faster R-CNN output format
"""
import os
import torch
import torch.onnx
from PIL import Image
import torchvision.transforms as transforms

from src.model import AnomalyDefectDetector, AnomalyDefectDetectorONNX


def export_to_onnx(model_path, image_size, output_path, opset_version=11):
    """
    Export trained model to ONNX format
    
    Args:
        model_path: Path to trained PyTorch model (.pt file)
        image_size: Tuple (height, width) for input image
        output_path: Path to save ONNX model
        opset_version: ONNX opset version
    """
    device = torch.device('cpu')
    
    # Load model
    print(f"Loading model from {model_path}...")
    model = AnomalyDefectDetector(pretrained=False)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.eval()
    
    # Wrap for ONNX export
    onnx_model = AnomalyDefectDetectorONNX(model)
    onnx_model.eval()
    
    # Create dummy input
    height, width = image_size
    dummy_input = torch.randn(1, 3, height, width, device=device)
    
    print(f"Exporting to ONNX with input size: {height}x{width}...")
    
    # Test forward pass
    with torch.no_grad():
        test_output = onnx_model(dummy_input)
        print(f"Test output shapes:")
        print(f"  boxes: {test_output[0].shape}")
        print(f"  labels: {test_output[1].shape}")
        print(f"  scores: {test_output[2].shape}")
    
    # Export to ONNX
    torch.onnx.export(
        onnx_model,
        dummy_input,
        output_path,
        export_params=True,
        opset_version=opset_version,
        do_constant_folding=True,
        input_names=['input'],
        output_names=['boxes', 'labels', 'scores'],
        dynamic_axes={
            'input': {0: 'batch_size'},  # Allow variable batch size
            'boxes': {0: 'num_boxes'},
            'labels': {0: 'num_labels'},
            'scores': {0: 'num_scores'}
        }
    )
    
    print(f"ONNX model saved to: {output_path}")
    
    # Verify ONNX model
    verify_onnx(output_path, dummy_input)
    
    return output_path


def verify_onnx(onnx_path, dummy_input):
    """
    Verify ONNX model can be loaded and run
    """
    try:
        import onnx
        import onnxruntime as ort
        
        # Check ONNX model
        print("\nVerifying ONNX model...")
        onnx_model = onnx.load(onnx_path)
        onnx.checker.check_model(onnx_model)
        print("  ✓ ONNX model is valid")
        
        # Test with ONNX Runtime
        print("\nTesting with ONNX Runtime...")
        ort_session = ort.InferenceSession(onnx_path)
        
        # Get input/output names
        input_name = ort_session.get_inputs()[0].name
        output_names = [output.name for output in ort_session.get_outputs()]
        print(f"  Input: {input_name}")
        print(f"  Outputs: {output_names}")
        
        # Run inference
        ort_inputs = {input_name: dummy_input.numpy()}
        ort_outputs = ort_session.run(None, ort_inputs)
        
        print(f"  ✓ ONNX Runtime inference successful")
        print(f"  Output shapes:")
        for name, output in zip(output_names, ort_outputs):
            print(f"    {name}: {output.shape}")
        
    except ImportError as e:
        print(f"  Warning: Could not verify ONNX model: {e}")
        print(f"  Please install onnx and onnxruntime to verify")
    except Exception as e:
        print(f"  Error during ONNX verification: {e}")


def export_for_image_type(model_path, image_type, results_dir, opset_version=11):
    """
    Export ONNX model for specific image type with correct input size
    
    Args:
        model_path: Path to trained PyTorch model
        image_type: 'EV', 'BV', or 'TV'
        results_dir: Directory to save ONNX model
        opset_version: ONNX opset version
    """
    # Determine image size based on type
    if image_type.upper() == 'EV':
        image_size = (1460, 2048)  # height, width
    elif image_type.upper() in ['BV', 'TV']:
        image_size = (500, 1024)
    else:
        raise ValueError(f"Unknown image type: {image_type}")
    
    output_path = os.path.join(results_dir, 'best_model.onnx')
    
    return export_to_onnx(model_path, image_size, output_path, opset_version)


def main(model_path, results_dir, image_type='EV'):
    """
    Main function for ONNX export
    """
    print("="*60)
    print("ONNX Export")
    print("="*60)
    
    onnx_path = export_for_image_type(model_path, image_type, results_dir)
    
    print("\n" + "="*60)
    print("ONNX Export Completed Successfully!")
    print("="*60)
    print(f"\nONNX model saved to: {onnx_path}")
    print(f"Image type: {image_type}")
    
    if image_type.upper() == 'EV':
        print(f"Input size: 1460 x 2048")
    else:
        print(f"Input size: 500 x 1024")
    
    print("\nOutput format:")
    print("  - boxes: [N, 4] - Bounding boxes [x1, y1, x2, y2]")
    print("  - labels: [N] - Class labels (1=chip, 2=check)")
    print("  - scores: [N] - Confidence scores [0, 1]")
    
    return onnx_path


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 3:
        print("Usage: python export_onnx.py <model_path> <results_dir> [image_type]")
        sys.exit(1)
    
    model_path = sys.argv[1]
    results_dir = sys.argv[2]
    image_type = sys.argv[3] if len(sys.argv) > 3 else 'EV'
    
    main(model_path, results_dir, image_type)
