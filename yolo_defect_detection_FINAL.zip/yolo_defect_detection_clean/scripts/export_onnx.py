#!/usr/bin/env python3
"""
ONNX Export Script for YOLOv8 Defect Detection Models
Creates ONNX models with internal padding functionality for 2048x1460 images.
"""

import os
import sys
import argparse
import torch
import onnx
import numpy as np
from pathlib import Path
from ultralytics import YOLO
from typing import Optional, Dict, List

def export_baseline_onnx(model_path: str, output_path: str, 
                        input_size: tuple = (1460, 2048),
                        include_nms: bool = True) -> str:
    """
    Export baseline ONNX model without modifications.
    
    Args:
        model_path: Path to YOLOv8 model weights
        output_path: Path to save ONNX model
        input_size: Input image size (height, width)
        include_nms: Whether to include NMS in the model
    
    Returns:
        Path to exported ONNX model
    """
    print(f"🔧 Exporting baseline ONNX model...")
    print(f"   Source: {model_path}")
    print(f"   Target: {output_path}")
    print(f"   Input size: {input_size}")
    
    # Load model
    model = YOLO(model_path)
    
    # Export to ONNX with specific parameters from your image
    model.export(
        format='onnx',
        imgsz=list(input_size),
        optimize=False,
        half=False,
        int8=False,
        dynamic=False,
        simplify=True,
        opset=11,
        workspace=4,
        nms=include_nms,
        # Parameters from your image
        export_params=True,
        do_constant_folding=True,
        input_names=['input'],
        output_names=['boxes', 'labels', 'scores'],
        dynamic_axes={
            'boxes': {0: 'num_boxes'},
            'labels': {0: 'num_labels'}, 
            'scores': {0: 'num_scores'}
        }
    )
    
    # Move the exported file to the desired location
    model_dir = Path(model_path).parent
    exported_onnx = model_dir / f"{Path(model_path).stem}.onnx"
    
    if exported_onnx.exists():
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        if str(exported_onnx) != output_path:
            import shutil
            shutil.move(str(exported_onnx), output_path)
    
    print(f"✅ Baseline ONNX model exported: {output_path}")
    return output_path

def add_internal_padding(input_onnx: str, output_onnx: str,
                        original_size: tuple = (1460, 2048),
                        target_multiple: int = 32) -> str:
    """
    Add internal padding to ONNX model for NCHW float32 input.
    
    Args:
        input_onnx: Path to source ONNX model
        output_onnx: Path to save modified model
        original_size: Original image size (height, width)
        target_multiple: Target multiple for padding
    
    Returns:
        Path to modified model
    """
    print(f"🔧 Adding internal padding to ONNX model...")
    print(f"   Source: {input_onnx}")
    print(f"   Target: {output_onnx}")
    
    # Load model
    model = onnx.load(input_onnx)
    graph = model.graph
    
    # Calculate padding
    orig_h, orig_w = original_size
    pad_h = (target_multiple - orig_h % target_multiple) % target_multiple
    pad_w = (target_multiple - orig_w % target_multiple) % target_multiple
    
    print(f"   Original size: {orig_h}x{orig_w}")
    print(f"   Padding: bottom={pad_h}, right={pad_w}")
    print(f"   Final size: {orig_h + pad_h}x{orig_w + pad_w}")
    
    if pad_h == 0 and pad_w == 0:
        print("   No padding needed, copying original model")
        import shutil
        shutil.copy2(input_onnx, output_onnx)
        return output_onnx
    
    # Get original input name
    original_input = graph.input[0].name
    
    # Create pads initializer: [N,C,H,W | N,C,H,W] -> begin pads then end pads
    pads_name = "pads_const"
    pads_vals = [0, 0, 0, 0, 0, 0, pad_h, pad_w]  # pad bottom and right only
    pads_init = onnx.numpy_helper.from_array(
        np.array(pads_vals, dtype=np.int64),
        name=pads_name
    )
    graph.initializer.append(pads_init)
    
    # Create Pad node
    pad_out = "x_padded"
    pad_node = onnx.helper.make_node(
        "Pad",
        inputs=[original_input, pads_name],
        outputs=[pad_out],
        mode="constant",
        name="Pad_to_mult32"
    )
    
    # Insert pad node at the beginning
    graph.node.insert(0, pad_node)
    
    # Redirect all consumers of original input to pad_out
    for node in graph.node[1:]:  # Skip the pad node we just added
        for i, input_name in enumerate(node.input):
            if input_name == original_input:
                node.input[i] = pad_out
    
    # Update input shape to original size (padding happens internally)
    for value_info in graph.input:
        if value_info.name == original_input and value_info.type.tensor_type.shape.dim:
            dims = value_info.type.tensor_type.shape.dim
            if len(dims) == 4:
                dims[0].dim_value = 1
                dims[1].dim_value = 3
                dims[2].dim_value = orig_h
                dims[3].dim_value = orig_w
    
    # Validate and save
    try:
        onnx.checker.check_model(model)
    except Exception as e:
        print(f"⚠️  Model validation warning: {e}")
    
    os.makedirs(os.path.dirname(output_onnx), exist_ok=True)
    onnx.save(model, output_onnx)
    
    print(f"✅ Padded ONNX model saved: {output_onnx}")
    return output_onnx

def add_uint8_preprocessing(input_onnx: str, output_onnx: str,
                           original_size: tuple = (1460, 2048),
                           target_multiple: int = 32,
                           normalization: str = 'div255') -> str:
    """
    Add uint8 HWC frontend with full preprocessing pipeline.
    
    Args:
        input_onnx: Path to source ONNX model (NCHW float32)
        output_onnx: Path to save modified model
        original_size: Original image size (height, width)
        target_multiple: Target multiple for padding
        normalization: Normalization method ('div255' or 'imagenet')
    
    Returns:
        Path to modified model
    """
    print(f"🔧 Adding uint8 HWC preprocessing to ONNX model...")
    print(f"   Source: {input_onnx}")
    print(f"   Target: {output_onnx}")
    print(f"   Normalization: {normalization}")
    
    # Load model
    model = onnx.load(input_onnx)
    graph = model.graph
    
    # Get original input name
    original_input = graph.input[0].name
    
    # Create new uint8 HWC input
    orig_h, orig_w = original_size
    new_input_name = "input_uint8_hwc"
    new_input = onnx.helper.make_tensor_value_info(
        new_input_name,
        onnx.TensorProto.UINT8,
        [1, orig_h, orig_w, 3]  # NHWC format
    )
    
    # Replace original input
    graph.input[0] = new_input
    
    # Build preprocessing pipeline
    preprocessing_nodes = []
    current_output = new_input_name
    
    # Step 1: Cast uint8 to float32
    cast_out = "x_f32_hwc"
    cast_node = onnx.helper.make_node(
        "Cast",
        inputs=[current_output],
        outputs=[cast_out],
        to=onnx.TensorProto.FLOAT,
        name="CastUint8ToFloat"
    )
    preprocessing_nodes.append(cast_node)
    current_output = cast_out
    
    # Step 2: Normalization
    if normalization == 'div255':
        # Simple division by 255
        div_const_name = "div255"
        div_const_init = onnx.numpy_helper.from_array(
            np.array([255.0], dtype=np.float32),
            name=div_const_name
        )
        graph.initializer.append(div_const_init)
        
        div_out = "x_norm_hwc"
        div_node = onnx.helper.make_node(
            "Div",
            inputs=[current_output, div_const_name],
            outputs=[div_out],
            name="Div255"
        )
        preprocessing_nodes.append(div_node)
        current_output = div_out
        
    elif normalization == 'imagenet':
        # ImageNet normalization: (x/255 - mean) / std
        # First divide by 255
        div_const_name = "div255"
        div_const_init = onnx.numpy_helper.from_array(
            np.array([255.0], dtype=np.float32),
            name=div_const_name
        )
        graph.initializer.append(div_const_init)
        
        div_out = "x_div255_hwc"
        div_node = onnx.helper.make_node(
            "Div",
            inputs=[current_output, div_const_name],
            outputs=[div_out],
            name="Div255"
        )
        preprocessing_nodes.append(div_node)
        current_output = div_out
        
        # Subtract ImageNet mean
        mean_init = onnx.numpy_helper.from_array(
            np.array([0.485, 0.456, 0.406], dtype=np.float32).reshape(1, 1, 1, 3),
            name="mean_hwc"
        )
        graph.initializer.append(mean_init)
        
        sub_out = "x_zm_hwc"
        sub_node = onnx.helper.make_node(
            "Sub",
            inputs=[current_output, "mean_hwc"],
            outputs=[sub_out],
            name="SubMean"
        )
        preprocessing_nodes.append(sub_node)
        current_output = sub_out
        
        # Divide by ImageNet std
        std_init = onnx.numpy_helper.from_array(
            np.array([0.229, 0.224, 0.225], dtype=np.float32).reshape(1, 1, 1, 3),
            name="std_hwc"
        )
        graph.initializer.append(std_init)
        
        div2_out = "x_std_hwc"
        div2_node = onnx.helper.make_node(
            "Div",
            inputs=[current_output, "std_hwc"],
            outputs=[div2_out],
            name="DivStd"
        )
        preprocessing_nodes.append(div2_node)
        current_output = div2_out
    
    # Step 3: Transpose HWC -> NCHW
    nchw_out = "x_nchw"
    transpose_node = onnx.helper.make_node(
        "Transpose",
        inputs=[current_output],
        outputs=[nchw_out],
        perm=[0, 3, 1, 2],  # NHWC -> NCHW
        name="HWC_to_NCHW"
    )
    preprocessing_nodes.append(transpose_node)
    current_output = nchw_out
    
    # Step 4: Pad to multiple of 32
    pad_h = (target_multiple - orig_h % target_multiple) % target_multiple
    pad_w = (target_multiple - orig_w % target_multiple) % target_multiple
    
    if pad_h > 0 or pad_w > 0:
        pads_vals = [0, 0, 0, 0, 0, 0, pad_h, pad_w]
        pads_init = onnx.numpy_helper.from_array(
            np.array(pads_vals, dtype=np.int64),
            name="pads_const"
        )
        graph.initializer.append(pads_init)
        
        pad_out = "x_padded"
        pad_node = onnx.helper.make_node(
            "Pad",
            inputs=[current_output, "pads_const"],
            outputs=[pad_out],
            mode="constant",
            name="PadToMult32"
        )
        preprocessing_nodes.append(pad_node)
        current_output = pad_out
    
    # Insert all preprocessing nodes at the beginning
    for i, node in enumerate(preprocessing_nodes):
        graph.node.insert(i, node)
    
    # Update all nodes that used the original input
    for node in graph.node[len(preprocessing_nodes):]:
        for i, input_name in enumerate(node.input):
            if input_name == original_input:
                node.input[i] = current_output
    
    # Validate and save
    try:
        onnx.checker.check_model(model)
    except Exception as e:
        print(f"⚠️  Model validation warning: {e}")
    
    os.makedirs(os.path.dirname(output_onnx), exist_ok=True)
    onnx.save(model, output_onnx)
    
    print(f"✅ uint8 HWC model saved: {output_onnx}")
    return output_onnx

def create_all_variants(model_path: str, output_dir: str,
                       input_size: tuple = (1460, 2048),
                       target_multiple: int = 32) -> Dict[str, str]:
    """
    Create all ONNX variants from a trained model.
    
    Args:
        model_path: Path to trained YOLOv8 model
        output_dir: Directory to save all variants
        input_size: Original image size (height, width)
        target_multiple: Target multiple for padding
    
    Returns:
        Dictionary mapping variant names to file paths
    """
    print(f"🚀 Creating all ONNX variants from: {model_path}")
    
    os.makedirs(output_dir, exist_ok=True)
    variants = {}
    
    # Step 1: Export baseline ONNX model
    baseline_path = os.path.join(output_dir, "baseline_model.onnx")
    variants['baseline'] = export_baseline_onnx(
        model_path, baseline_path, input_size, include_nms=True
    )
    
    # Step 2: Create NCHW float32 variant with internal padding
    nchw_path = os.path.join(output_dir, "model_nchw_float32_padded.onnx")
    variants['nchw_float32_padded'] = add_internal_padding(
        baseline_path, nchw_path, input_size, target_multiple
    )
    
    # Step 3: Create uint8 HWC variant with div255 normalization
    hwc_div255_path = os.path.join(output_dir, "model_hwc_uint8_div255.onnx")
    variants['hwc_uint8_div255'] = add_uint8_preprocessing(
        baseline_path, hwc_div255_path, input_size, target_multiple, 'div255'
    )
    
    # Step 4: Create uint8 HWC variant with ImageNet normalization
    hwc_imagenet_path = os.path.join(output_dir, "model_hwc_uint8_imagenet.onnx")
    variants['hwc_uint8_imagenet'] = add_uint8_preprocessing(
        baseline_path, hwc_imagenet_path, input_size, target_multiple, 'imagenet'
    )
    
    # Save variant information
    import json
    variant_info = {
        'source_model': model_path,
        'input_size': input_size,
        'target_multiple': target_multiple,
        'variants': variants,
        'descriptions': {
            'baseline': 'Standard ONNX export without modifications',
            'nchw_float32_padded': 'NCHW float32 input with internal padding',
            'hwc_uint8_div255': 'HWC uint8 input with div255 normalization and padding',
            'hwc_uint8_imagenet': 'HWC uint8 input with ImageNet normalization and padding'
        },
        'usage': {
            'baseline': 'Standard ONNX model, requires external preprocessing',
            'nchw_float32_padded': 'Feed (1,3,1460,2048) float32 tensor in [0,1] range',
            'hwc_uint8_div255': 'Feed (1,1460,2048,3) uint8 tensor (raw RGB/BGR)',
            'hwc_uint8_imagenet': 'Feed (1,1460,2048,3) uint8 tensor (raw RGB)'
        }
    }
    
    info_path = os.path.join(output_dir, "variant_info.json")
    with open(info_path, 'w') as f:
        json.dump(variant_info, f, indent=2)
    
    print(f"✅ All variants created successfully!")
    print(f"📁 Output directory: {output_dir}")
    print(f"📄 Variant info: {info_path}")
    
    return variants

def main():
    """Main function for command-line usage."""
    parser = argparse.ArgumentParser(
        description='Export YOLOv8 models to ONNX with internal padding',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Create all ONNX variants
  python export_onnx.py --model best.pt --output-dir ./models
  
  # Create only baseline ONNX
  python export_onnx.py --model best.pt --output baseline.onnx --variant baseline
  
  # Create NCHW padded variant
  python export_onnx.py --model best.pt --output padded.onnx --variant nchw_padded
        """
    )
    
    parser.add_argument('--model', required=True, help='Path to trained YOLOv8 model (.pt)')
    parser.add_argument('--output', help='Output path for single variant')
    parser.add_argument('--output-dir', help='Output directory for all variants')
    parser.add_argument('--variant', choices=['baseline', 'nchw_padded', 'hwc_div255', 'hwc_imagenet', 'all'],
                       default='all', help='Specific variant to create')
    parser.add_argument('--input-size', nargs=2, type=int, default=[1460, 2048],
                       help='Input image size (height width)')
    parser.add_argument('--target-multiple', type=int, default=32,
                       help='Target multiple for padding')
    parser.add_argument('--include-nms', action='store_true', default=True,
                       help='Include NMS in baseline export')
    
    args = parser.parse_args()
    
    # Validate arguments
    if not os.path.exists(args.model):
        print(f"❌ Model file not found: {args.model}")
        sys.exit(1)
    
    if args.variant == 'all' and not args.output_dir:
        print("❌ --output-dir required when creating all variants")
        sys.exit(1)
    
    if args.variant != 'all' and not args.output:
        print("❌ --output required when creating single variant")
        sys.exit(1)
    
    try:
        input_size = tuple(args.input_size)
        
        if args.variant == 'all':
            # Create all variants
            create_all_variants(
                args.model, args.output_dir,
                input_size, args.target_multiple
            )
        else:
            # Create specific variant
            if args.variant == 'baseline':
                export_baseline_onnx(
                    args.model, args.output, input_size, args.include_nms
                )
            elif args.variant == 'nchw_padded':
                # First create baseline, then add padding
                baseline_path = args.output.replace('.onnx', '_baseline.onnx')
                export_baseline_onnx(
                    args.model, baseline_path, input_size, args.include_nms
                )
                add_internal_padding(
                    baseline_path, args.output, input_size, args.target_multiple
                )
                os.remove(baseline_path)  # Clean up temporary file
            elif args.variant == 'hwc_div255':
                # First create baseline, then add preprocessing
                baseline_path = args.output.replace('.onnx', '_baseline.onnx')
                export_baseline_onnx(
                    args.model, baseline_path, input_size, args.include_nms
                )
                add_uint8_preprocessing(
                    baseline_path, args.output, input_size, args.target_multiple, 'div255'
                )
                os.remove(baseline_path)  # Clean up temporary file
            elif args.variant == 'hwc_imagenet':
                # First create baseline, then add preprocessing
                baseline_path = args.output.replace('.onnx', '_baseline.onnx')
                export_baseline_onnx(
                    args.model, baseline_path, input_size, args.include_nms
                )
                add_uint8_preprocessing(
                    baseline_path, args.output, input_size, args.target_multiple, 'imagenet'
                )
                os.remove(baseline_path)  # Clean up temporary file
        
        print("🎉 ONNX export completed successfully!")
        
    except Exception as e:
        print(f"❌ ONNX export failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()

