#!/usr/bin/env python3
"""
ONNX Model Inference Demonstration
Shows how to use the exported ONNX models with internal padding for defect detection.
"""

import os
import sys
import cv2
import numpy as np
import onnxruntime as ort
import argparse
import json
import time
from pathlib import Path
from typing import List, Tuple, Dict, Optional

class DefectDetectionInference:
    """Inference class for defect detection using ONNX models with internal padding."""
    
    def __init__(self, model_path: str, providers: Optional[List[str]] = None):
        """Initialize inference engine."""
        self.model_path = model_path
        self.providers = providers or ['CUDAExecutionProvider', 'CPUExecutionProvider']
        
        # Load ONNX session
        try:
            self.session = ort.InferenceSession(model_path, providers=self.providers)
            print(f"✅ Loaded model: {model_path}")
            print(f"   Provider: {self.session.get_providers()[0]}")
        except Exception as e:
            raise ValueError(f"Failed to load ONNX model: {e}")
        
        # Get model info
        self.input_info = self.session.get_inputs()[0]
        self.output_info = self.session.get_outputs()
        
        # Determine input format
        self.input_format = self._determine_input_format()
        
        print(f"📊 Model Information:")
        print(f"   Input: {self.input_info.name}, shape: {self.input_info.shape}")
        print(f"   Input format: {self.input_format}")
        print(f"   Outputs: {[out.name for out in self.output_info]}")
    
    def _determine_input_format(self) -> str:
        """Determine input format from model metadata."""
        shape = self.input_info.shape
        dtype = self.input_info.type
        
        if dtype == 'tensor(uint8)' and len(shape) == 4 and shape[-1] == 3:
            return 'hwc_uint8'  # HWC uint8 format
        elif dtype == 'tensor(float)' and len(shape) == 4 and shape[1] == 3:
            return 'nchw_float32'  # NCHW float32 format
        else:
            return 'unknown'
    
    def preprocess_image(self, image_path: str) -> np.ndarray:
        """Preprocess image for inference."""
        # Load image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")
        
        # Convert BGR to RGB
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Ensure correct size (2048x1460)
        expected_size = (2048, 1460)  # (width, height)
        if image.shape[:2][::-1] != expected_size:
            print(f"⚠️  Image size {image.shape[:2][::-1]} != expected {expected_size}, resizing...")
            image = cv2.resize(image, expected_size)
        
        # Prepare input based on model format
        if self.input_format == 'hwc_uint8':
            # Model expects HWC uint8 - no preprocessing needed!
            # The model handles cast, normalization, transpose, and padding internally
            input_tensor = image[np.newaxis, ...]  # Add batch dimension: (1, H, W, 3)
            
        elif self.input_format == 'nchw_float32':
            # Model expects NCHW float32 - normalize and transpose
            # The model handles padding internally (1460 -> 1472)
            image = image.astype(np.float32) / 255.0  # Normalize to [0, 1]
            input_tensor = np.transpose(image, (2, 0, 1))[np.newaxis, ...]  # HWC -> NCHW + batch
            
        else:
            raise ValueError(f"Unsupported input format: {self.input_format}")
        
        return input_tensor
    
    def run_inference(self, input_tensor: np.ndarray) -> List[np.ndarray]:
        """Run inference on preprocessed input."""
        try:
            outputs = self.session.run(None, {self.input_info.name: input_tensor})
            return outputs
        except Exception as e:
            raise RuntimeError(f"Inference failed: {e}")
    
    def postprocess_outputs(self, outputs: List[np.ndarray], 
                          confidence_threshold: float = 0.3) -> Dict:
        """Postprocess model outputs to extract detections."""
        detections = {
            'boxes': [],
            'scores': [],
            'labels': [],
            'num_detections': 0
        }
        
        # Handle different output formats
        if len(outputs) == 1:
            # Single output (e.g., YOLOv8 format)
            output = outputs[0]
            
            if len(output.shape) == 3 and output.shape[0] == 1:
                # Format: [1, num_detections, 6] where 6 = [x1, y1, x2, y2, conf, class]
                detections_array = output[0]  # Remove batch dimension
                
                # Filter by confidence
                if detections_array.shape[1] >= 5:  # Has confidence scores
                    conf_scores = detections_array[:, 4]
                    valid_indices = conf_scores > confidence_threshold
                    
                    if np.any(valid_indices):
                        valid_detections = detections_array[valid_indices]
                        
                        detections['boxes'] = valid_detections[:, :4].tolist()  # x1, y1, x2, y2
                        detections['scores'] = valid_detections[:, 4].tolist()   # confidence
                        
                        if valid_detections.shape[1] > 5:
                            detections['labels'] = valid_detections[:, 5].tolist()  # class
                        else:
                            detections['labels'] = [0] * len(detections['boxes'])  # Default class
                        
                        detections['num_detections'] = len(detections['boxes'])
        
        elif len(outputs) == 3:
            # Separate outputs for boxes, scores, labels
            boxes, scores, labels = outputs
            
            if len(boxes.shape) == 3:  # [batch, num_detections, 4]
                boxes = boxes[0]  # Remove batch dimension
                scores = scores[0] if len(scores.shape) == 2 else scores
                labels = labels[0] if len(labels.shape) == 2 else labels
            
            # Filter by confidence
            valid_indices = scores > confidence_threshold
            
            if np.any(valid_indices):
                detections['boxes'] = boxes[valid_indices].tolist()
                detections['scores'] = scores[valid_indices].tolist()
                detections['labels'] = labels[valid_indices].tolist()
                detections['num_detections'] = len(detections['boxes'])
        
        return detections
    
    def visualize_detections(self, image_path: str, detections: Dict, 
                           output_path: Optional[str] = None) -> np.ndarray:
        """Visualize detections on the original image."""
        # Load original image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")
        
        h, w = image.shape[:2]
        
        # Draw detections
        for i in range(detections['num_detections']):
            box = detections['boxes'][i]
            score = detections['scores'][i]
            label = detections['labels'][i] if i < len(detections['labels']) else 0
            
            x1, y1, x2, y2 = box
            
            # Convert normalized coordinates to pixel coordinates if needed
            if max(box) <= 1.0:
                x1, x2 = x1 * w, x2 * w
                y1, y2 = y1 * h, y2 * h
            
            # Ensure coordinates are within image bounds
            x1 = max(0, min(w, int(x1)))
            y1 = max(0, min(h, int(y1)))
            x2 = max(0, min(w, int(x2)))
            y2 = max(0, min(h, int(y2)))
            
            # Draw bounding box
            color = (0, 255, 0)  # Green for defects
            thickness = 2
            cv2.rectangle(image, (x1, y1), (x2, y2), color, thickness)
            
            # Draw label and confidence
            label_text = f"Defect {score:.2f}"
            if len(detections['labels']) > i:
                label_text = f"Class {int(label)} {score:.2f}"
            
            # Calculate text size and background
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 0.6
            text_thickness = 1
            (text_w, text_h), _ = cv2.getTextSize(label_text, font, font_scale, text_thickness)
            
            # Draw text background
            cv2.rectangle(image, (x1, y1 - text_h - 10), (x1 + text_w, y1), color, -1)
            
            # Draw text
            cv2.putText(image, label_text, (x1, y1 - 5), font, font_scale, (255, 255, 255), text_thickness)
        
        # Add summary text
        summary_text = f"Detections: {detections['num_detections']}"
        cv2.putText(image, summary_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        # Save if output path provided
        if output_path:
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            cv2.imwrite(output_path, image)
            print(f"💾 Visualization saved: {output_path}")
        
        return image
    
    def detect_defects(self, image_path: str, 
                      confidence_threshold: float = 0.3,
                      save_visualization: bool = True,
                      output_dir: Optional[str] = None) -> Dict:
        """Complete defect detection pipeline."""
        print(f"🔍 Detecting defects in: {image_path}")
        
        # Preprocess
        start_time = time.time()
        input_tensor = self.preprocess_image(image_path)
        preprocess_time = time.time() - start_time
        
        # Inference
        start_time = time.time()
        outputs = self.run_inference(input_tensor)
        inference_time = time.time() - start_time
        
        # Postprocess
        start_time = time.time()
        detections = self.postprocess_outputs(outputs, confidence_threshold)
        postprocess_time = time.time() - start_time
        
        # Create results
        results = {
            'image_path': image_path,
            'model_path': self.model_path,
            'input_format': self.input_format,
            'detections': detections,
            'timing': {
                'preprocess_time': preprocess_time,
                'inference_time': inference_time,
                'postprocess_time': postprocess_time,
                'total_time': preprocess_time + inference_time + postprocess_time
            },
            'model_info': {
                'input_shape': input_tensor.shape,
                'input_dtype': str(input_tensor.dtype),
                'output_shapes': [output.shape for output in outputs]
            }
        }
        
        # Save visualization
        if save_visualization and output_dir:
            base_name = Path(image_path).stem
            vis_path = os.path.join(output_dir, f"{base_name}_detections.png")
            self.visualize_detections(image_path, detections, vis_path)
        
        # Print results
        print(f"   ✅ Found {detections['num_detections']} defects")
        print(f"   ⏱️  Total time: {results['timing']['total_time']:.4f}s")
        print(f"      Preprocess: {preprocess_time:.4f}s")
        print(f"      Inference: {inference_time:.4f}s")
        print(f"      Postprocess: {postprocess_time:.4f}s")
        
        if detections['num_detections'] > 0:
            avg_confidence = np.mean(detections['scores'])
            print(f"   📊 Average confidence: {avg_confidence:.3f}")
        
        return results

def main():
    """Main function for command-line usage."""
    parser = argparse.ArgumentParser(
        description='Defect Detection Inference with ONNX Models',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Detect defects in a single image
  python inference_demo.py --model model.onnx --image test.png --output ./results
  
  # Adjust confidence threshold
  python inference_demo.py --model model.onnx --image test.png --confidence 0.5
        """
    )
    
    parser.add_argument('--model', required=True, help='Path to ONNX model')
    parser.add_argument('--image', required=True, help='Path to input image')
    parser.add_argument('--output', default='./inference_results', help='Output directory for results')
    parser.add_argument('--confidence', type=float, default=0.3, help='Confidence threshold')
    parser.add_argument('--no-visualization', action='store_true', help='Skip saving visualizations')
    parser.add_argument('--providers', nargs='+', default=['CUDAExecutionProvider', 'CPUExecutionProvider'],
                       help='ONNX Runtime execution providers')
    
    args = parser.parse_args()
    
    # Validate arguments
    if not os.path.exists(args.model):
        print(f"❌ Model file not found: {args.model}")
        sys.exit(1)
    
    if not os.path.exists(args.image):
        print(f"❌ Image file not found: {args.image}")
        sys.exit(1)
    
    try:
        # Initialize inference engine
        detector = DefectDetectionInference(args.model, args.providers)
        
        # Run detection
        results = detector.detect_defects(
            args.image, 
            confidence_threshold=args.confidence,
            save_visualization=not args.no_visualization,
            output_dir=args.output
        )
        
        # Save results
        os.makedirs(args.output, exist_ok=True)
        results_path = os.path.join(args.output, 'detection_results.json')
        with open(results_path, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        print(f"📄 Results saved: {results_path}")
        
        print("🎉 Detection completed successfully!")
        
    except Exception as e:
        print(f"❌ Detection failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()

