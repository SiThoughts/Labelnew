#!/usr/bin/env python3
"""
YOLOv8 Training Script for Tiny Defect Detection
Optimized for 2048x1460 images with defects as small as 0.1% of image area.
"""

import os
import sys
import yaml
import json
import argparse
from pathlib import Path
from typing import Dict, Optional, List
import torch
import numpy as np
from ultralytics import YOLO
from ultralytics.utils import LOGGER
import matplotlib.pyplot as plt

class TinyDefectTrainer:
    """Trainer class optimized for tiny defect detection."""
    
    def __init__(self, config_path: str, hyperparams_path: str):
        """Initialize trainer with configuration files."""
        self.config_path = config_path
        self.hyperparams_path = hyperparams_path
        self.config = self._load_yaml(config_path)
        self.hyperparams = self._load_yaml(hyperparams_path)
        
        # Set up paths
        self.dataset_path = Path(self.config['path'])
        self.project_dir = Path('runs/detect')
        
        # Training state
        self.model = None
        self.training_results = {}
        
    def _load_yaml(self, path: str) -> Dict:
        """Load YAML configuration file."""
        with open(path, 'r') as f:
            return yaml.safe_load(f)
    
    def validate_dataset(self) -> bool:
        """Validate dataset structure and paths."""
        print("🔍 Validating dataset structure...")
        
        if not self.dataset_path.exists():
            print(f"❌ Dataset path does not exist: {self.dataset_path}")
            return False
        
        # Check required directories
        required_dirs = ['images/train', 'images/val', 'labels/train', 'labels/val']
        for dir_path in required_dirs:
            full_path = self.dataset_path / dir_path
            if not full_path.exists():
                print(f"❌ Required directory missing: {full_path}")
                return False
            
            # Count files
            files = list(full_path.glob('*'))
            print(f"✅ {dir_path}: {len(files)} files")
        
        print("✅ Dataset validation completed successfully!")
        return True
    
    def setup_model(self, model_size: str = 'x', pretrained: bool = True) -> YOLO:
        """Setup YOLOv8 model optimized for tiny defect detection."""
        print(f"🚀 Setting up YOLOv8{model_size} model...")
        
        model_name = f'yolov8{model_size}.pt' if pretrained else f'yolov8{model_size}.yaml'
        self.model = YOLO(model_name)
        
        print(f"✅ Model initialized: {model_name}")
        print(f"   Pretrained: {pretrained}")
        print(f"   Parameters: {sum(p.numel() for p in self.model.model.parameters()):,}")
        
        return self.model
    
    def prepare_training_args(self, phase: str, custom_args: Optional[Dict] = None) -> Dict:
        """Prepare training arguments for specified phase."""
        hyp = self.hyperparams
        
        # Base arguments
        args = {
            'data': self.config_path,
            'imgsz': hyp.get('imgsz', [1460, 2048]),
            'batch': hyp.get('batch', 1),
            'device': hyp.get('device', 0),
            'workers': hyp.get('workers', 4),
            'project': hyp.get('project', 'runs/detect'),
            'name': f"tiny_defect_{phase}",
            'exist_ok': True,
            'pretrained': True,
            'optimizer': hyp.get('optimizer', 'AdamW'),
            'verbose': hyp.get('verbose', True),
            'seed': hyp.get('seed', 0),
            'deterministic': hyp.get('deterministic', True),
            'single_cls': hyp.get('single_cls', False),
            'rect': hyp.get('rect', False),
            'cos_lr': hyp.get('cos_lr', False),
            'close_mosaic': hyp.get('close_mosaic', 10),
            'resume': hyp.get('resume', False),
            'amp': hyp.get('amp', True),
            'fraction': hyp.get('fraction', 1.0),
            'profile': hyp.get('profile', False),
            'freeze': hyp.get('freeze', None),
            'multi_scale': hyp.get('multi_scale', False),
            'overlap_mask': hyp.get('overlap_mask', True),
            'mask_ratio': hyp.get('mask_ratio', 4),
            'dropout': hyp.get('dropout', 0.0),
            'val': hyp.get('val', True),
            'plots': hyp.get('plots', True),
            'save_json': hyp.get('save_json', True),
            'save_hybrid': hyp.get('save_hybrid', True),
            'save_txt': hyp.get('save_txt', False),
            'save_conf': hyp.get('save_conf', False),
            'save_crop': hyp.get('save_crop', False),
            'val_period': hyp.get('val_period', 1),
        }
        
        # Learning rate settings
        args.update({
            'lr0': hyp.get('lr0', 0.002),
            'lrf': hyp.get('lrf', 0.01),
            'momentum': hyp.get('momentum', 0.937),
            'weight_decay': hyp.get('weight_decay', 0.0005),
            'warmup_epochs': hyp.get('warmup_epochs', 3.0),
            'warmup_momentum': hyp.get('warmup_momentum', 0.8),
            'warmup_bias_lr': hyp.get('warmup_bias_lr', 0.1),
        })
        
        # Loss weights
        args.update({
            'box': hyp.get('box', 8.0),
            'cls': hyp.get('cls', 0.8),
            'dfl': hyp.get('dfl', 1.8),
        })
        
        # Augmentation settings based on phase
        if phase == 'phase1':
            # Full augmentations for initial training
            phase_hyp = hyp.get('training_phases', {}).get('phase1', {})
            args.update({
                'hsv_h': hyp.get('hsv_h', 0.015),
                'hsv_s': hyp.get('hsv_s', 0.60),
                'hsv_v': hyp.get('hsv_v', 0.40),
                'degrees': hyp.get('degrees', 5.0),
                'translate': hyp.get('translate', 0.02),
                'scale': hyp.get('scale', 0.15),
                'shear': hyp.get('shear', 0.0),
                'perspective': hyp.get('perspective', 0.0),
                'flipud': hyp.get('flipud', 0.0),
                'fliplr': hyp.get('fliplr', 0.5),
                'mosaic': phase_hyp.get('mosaic', 1.0),
                'mixup': phase_hyp.get('mixup', 0.10),
                'copy_paste': phase_hyp.get('copy_paste', 0.40),
                'epochs': phase_hyp.get('epochs', 250),
            })
        
        elif phase == 'phase2':
            # Reduced augmentations for fine-tuning
            phase_hyp = hyp.get('training_phases', {}).get('phase2', {})
            args.update({
                'mosaic': phase_hyp.get('mosaic', 0.0),
                'mixup': phase_hyp.get('mixup', 0.0),
                'copy_paste': phase_hyp.get('copy_paste', 0.0),
                'epochs': phase_hyp.get('epochs', 50),
                'resume': True,
            })
        
        # NMS settings
        args.update({
            'conf': hyp.get('conf_thres', 0.20),
            'iou': hyp.get('iou_thres', 0.55),
            'max_det': hyp.get('max_det', 1000),
        })
        
        # Apply custom arguments
        if custom_args:
            args.update(custom_args)
        
        return args
    
    def train_phase1(self, custom_args: Optional[Dict] = None) -> Dict:
        """Execute Phase 1 training: Initial training with full augmentations."""
        print("🚀 Starting Phase 1 Training (Initial training with full augmentations)...")
        
        if self.model is None:
            raise ValueError("Model not initialized. Call setup_model() first.")
        
        # Prepare training arguments
        train_args = self.prepare_training_args('phase1', custom_args)
        
        print(f"📋 Training arguments:")
        for key, value in train_args.items():
            print(f"   {key}: {value}")
        
        # Start training
        try:
            results = self.model.train(**train_args)
            
            # Store results
            self.training_results['phase1'] = {
                'results': results,
                'best_weights': str(self.model.trainer.best),
                'last_weights': str(self.model.trainer.last),
                'args': train_args
            }
            
            print("✅ Phase 1 training completed successfully!")
            print(f"📁 Best weights saved to: {self.model.trainer.best}")
            
            return self.training_results['phase1']
            
        except Exception as e:
            print(f"❌ Phase 1 training failed: {e}")
            raise
    
    def train_phase2(self, phase1_weights: Optional[str] = None, custom_args: Optional[Dict] = None) -> Dict:
        """Execute Phase 2 training: Fine-tuning with reduced augmentations."""
        print("🎯 Starting Phase 2 Training (Fine-tuning with reduced augmentations)...")
        
        # Load best weights from phase 1 if not provided
        if phase1_weights is None:
            if 'phase1' in self.training_results:
                phase1_weights = self.training_results['phase1']['best_weights']
            else:
                # Try to find the latest phase1 weights
                phase1_dir = self.project_dir / 'tiny_defect_phase1'
                if phase1_dir.exists():
                    weights_dir = phase1_dir / 'weights'
                    if (weights_dir / 'best.pt').exists():
                        phase1_weights = str(weights_dir / 'best.pt')
        
        if phase1_weights is None or not Path(phase1_weights).exists():
            raise ValueError(f"Phase 1 weights not found: {phase1_weights}")
        
        print(f"📂 Loading Phase 1 weights: {phase1_weights}")
        
        # Load model with phase1 weights
        self.model = YOLO(phase1_weights)
        
        # Prepare training arguments for phase 2
        train_args = self.prepare_training_args('phase2', custom_args)
        train_args['resume'] = False  # Don't resume, start fresh with new settings
        
        print(f"📋 Phase 2 training arguments:")
        for key, value in train_args.items():
            print(f"   {key}: {value}")
        
        # Start phase 2 training
        try:
            results = self.model.train(**train_args)
            
            # Store results
            self.training_results['phase2'] = {
                'results': results,
                'best_weights': str(self.model.trainer.best),
                'last_weights': str(self.model.trainer.last),
                'args': train_args,
                'phase1_weights': phase1_weights
            }
            
            print("✅ Phase 2 training completed successfully!")
            print(f"📁 Final best weights saved to: {self.model.trainer.best}")
            
            return self.training_results['phase2']
            
        except Exception as e:
            print(f"❌ Phase 2 training failed: {e}")
            raise
    
    def validate_model(self, weights_path: Optional[str] = None, split: str = 'val') -> Dict:
        """Validate trained model on specified dataset split."""
        print(f"🔍 Validating model on {split} split...")
        
        if weights_path:
            model = YOLO(weights_path)
        elif self.model:
            model = self.model
        else:
            raise ValueError("No model or weights specified for validation")
        
        # Run validation
        try:
            val_results = model.val(
                data=self.config_path,
                split=split,
                imgsz=[1460, 2048],
                batch=1,
                conf=0.001,  # Very low threshold for comprehensive analysis
                iou=0.6,
                max_det=1000,
                save_json=True,
                save_hybrid=True,
                plots=True,
                verbose=True
            )
            
            print("✅ Validation completed successfully!")
            return val_results
            
        except Exception as e:
            print(f"❌ Validation failed: {e}")
            raise
    
    def save_training_summary(self, output_path: str):
        """Save comprehensive training summary to JSON file."""
        summary = {
            'config_path': self.config_path,
            'hyperparams_path': self.hyperparams_path,
            'dataset_config': self.config,
            'hyperparameters': self.hyperparams,
            'training_results': {}
        }
        
        # Add training results (excluding non-serializable objects)
        for phase, results in self.training_results.items():
            summary['training_results'][phase] = {
                'best_weights': results.get('best_weights'),
                'last_weights': results.get('last_weights'),
                'args': results.get('args'),
                'phase1_weights': results.get('phase1_weights')
            }
        
        # Save to file
        with open(output_path, 'w') as f:
            json.dump(summary, f, indent=2, default=str)
        
        print(f"📄 Training summary saved to: {output_path}")
    
    def run_full_training(self, model_size: str = 'x', custom_args: Optional[Dict] = None) -> Dict:
        """Run complete two-phase training pipeline."""
        print("🎯 Starting complete two-phase training pipeline...")
        
        # Validate dataset first
        if not self.validate_dataset():
            raise ValueError("Dataset validation failed")
        
        # Setup model
        self.setup_model(model_size=model_size, pretrained=True)
        
        # Phase 1: Initial training
        phase1_results = self.train_phase1(custom_args)
        
        # Phase 2: Fine-tuning
        phase2_results = self.train_phase2()
        
        # Final validation
        print("🔍 Running final validation...")
        final_validation = self.validate_model(phase2_results['best_weights'])
        
        # Save training summary
        summary_path = self.project_dir / 'tiny_defect_phase2' / 'training_summary.json'
        self.save_training_summary(str(summary_path))
        
        print("🎉 Complete training pipeline finished successfully!")
        print(f"📁 Final model weights: {phase2_results['best_weights']}")
        
        return {
            'phase1': phase1_results,
            'phase2': phase2_results,
            'final_validation': final_validation,
            'summary_path': str(summary_path)
        }

def main():
    """Main function for command-line usage."""
    parser = argparse.ArgumentParser(description='Train YOLOv8 for tiny defect detection')
    parser.add_argument('--config', required=True, help='Path to dataset configuration YAML')
    parser.add_argument('--hyperparams', required=True, help='Path to hyperparameters YAML')
    parser.add_argument('--model-size', default='x', choices=['n', 's', 'm', 'l', 'x'], 
                       help='YOLOv8 model size')
    parser.add_argument('--phase', choices=['phase1', 'phase2', 'full'], default='full',
                       help='Training phase to run')
    parser.add_argument('--weights', help='Path to weights for phase2 or validation')
    parser.add_argument('--validate-only', action='store_true', help='Only run validation')
    parser.add_argument('--epochs', type=int, help='Override number of epochs')
    parser.add_argument('--batch', type=int, help='Override batch size')
    parser.add_argument('--device', help='Training device (0, 1, cpu, etc.)')
    
    args = parser.parse_args()
    
    # Initialize trainer
    trainer = TinyDefectTrainer(args.config, args.hyperparams)
    
    # Prepare custom arguments
    custom_args = {}
    if args.epochs:
        custom_args['epochs'] = args.epochs
    if args.batch:
        custom_args['batch'] = args.batch
    if args.device:
        custom_args['device'] = args.device
    
    try:
        if args.validate_only:
            # Only run validation
            if not args.weights:
                raise ValueError("Weights path required for validation-only mode")
            trainer.validate_model(args.weights)
            
        elif args.phase == 'phase1':
            # Run only phase 1
            trainer.setup_model(model_size=args.model_size)
            trainer.train_phase1(custom_args)
            
        elif args.phase == 'phase2':
            # Run only phase 2
            if not args.weights:
                raise ValueError("Phase 1 weights required for phase 2 training")
            trainer.train_phase2(args.weights, custom_args)
            
        else:
            # Run full training pipeline
            trainer.run_full_training(model_size=args.model_size, custom_args=custom_args)
            
    except Exception as e:
        print(f"❌ Training failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()

