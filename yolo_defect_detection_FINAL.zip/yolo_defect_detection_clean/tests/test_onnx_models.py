#!/usr/bin/env python3
"""
ONNX Model Testing and Validation Suite
Comprehensive testing for exported ONNX models with internal padding.
"""

import os
import sys
import cv2
import numpy as np
import onnxruntime as ort
import argparse
import json
import time
from pathlib import Path
from typing import List, Dict, Tuple, Optional

class ONNXModelTester:
    """Comprehensive tester for ONNX defect detection models."""
    
    def __init__(self, model_path: str, providers: Optional[List[str]] = None):
        """Initialize ONNX model tester."""
        self.model_path = model_path
        self.providers = providers or ['CUDAExecutionProvider', 'CPUExecutionProvider']
        
        # Load model
        try:
            self.session = ort.InferenceSession(model_path, providers=self.providers)
            print(f"✅ Loaded model: {model_path}")
            print(f"   Provider: {self.session.get_providers()[0]}")
        except Exception as e:
            raise ValueError(f"Failed to load ONNX model: {e}")
        
        # Get model metadata
        self.input_info = self.session.get_inputs()[0]
        self.output_info = self.session.get_outputs()
        
        print(f"📊 Model Information:")
        print(f"   Input: {self.input_info.name}")
        print(f"   Input shape: {self.input_info.shape}")
        print(f"   Input type: {self.input_info.type}")
        print(f"   Outputs: {[(out.name, out.shape, out.type) for out in self.output_info]}")
    
    def test_input_shapes(self) -> Dict:
        """Test various input shapes and validate model behavior."""
        print("🧪 Testing input shapes...")
        
        results = {
            'expected_shape': self.input_info.shape,
            'tests': []
        }
        
        # Determine input format
        input_shape = self.input_info.shape
        input_type = self.input_info.type
        
        if input_type == 'tensor(uint8)' and len(input_shape) == 4 and input_shape[-1] == 3:
            # HWC uint8 format
            test_shapes = [
                (1, 1460, 2048, 3),  # Expected shape
                (1, 1460, 2048, 3),  # Same shape
            ]
            dtype = np.uint8
            value_range = (0, 255)
        elif input_type == 'tensor(float)' and len(input_shape) == 4 and input_shape[1] == 3:
            # NCHW float32 format
            test_shapes = [
                (1, 3, 1460, 2048),  # Expected shape
                (1, 3, 1460, 2048),  # Same shape
            ]
            dtype = np.float32
            value_range = (0.0, 1.0)
        else:
            print(f"   ⚠️  Unknown input format: {input_type} with shape {input_shape}")
            return results
        
        for test_shape in test_shapes:
            test_result = {
                'shape': test_shape,
                'success': False,
                'error': None,
                'output_shapes': [],
                'inference_time': 0
            }
            
            try:
                # Create test input
                if dtype == np.uint8:
                    test_input = np.random.randint(
                        value_range[0], value_range[1] + 1, 
                        size=test_shape, dtype=dtype
                    )
                else:
                    test_input = np.random.uniform(
                        value_range[0], value_range[1], 
                        size=test_shape
                    ).astype(dtype)
                
                # Run inference
                start_time = time.time()
                outputs = self.session.run(None, {self.input_info.name: test_input})
                inference_time = time.time() - start_time
                
                test_result['success'] = True
                test_result['output_shapes'] = [output.shape for output in outputs]
                test_result['inference_time'] = inference_time
                
                print(f"   ✅ Shape {test_shape}: {inference_time:.4f}s")
                
            except Exception as e:
                test_result['error'] = str(e)
                print(f"   ❌ Shape {test_shape}: {e}")
            
            results['tests'].append(test_result)
        
        return results
    
    def test_padding_functionality(self) -> Dict:
        """Test internal padding functionality."""
        print("📏 Testing internal padding functionality...")
        
        results = {
            'padding_tests': [],
            'expected_behavior': 'Model should handle 1460x2048 input and pad to 1472x2048 internally'
        }
        
        input_shape = self.input_info.shape
        input_type = self.input_info.type
        
        # Create test input with exact expected size
        if input_type == 'tensor(uint8)' and len(input_shape) == 4 and input_shape[-1] == 3:
            # HWC uint8 format
            test_input = np.random.randint(0, 256, size=(1, 1460, 2048, 3), dtype=np.uint8)
        elif input_type == 'tensor(float)' and len(input_shape) == 4 and input_shape[1] == 3:
            # NCHW float32 format  
            test_input = np.random.uniform(0.0, 1.0, size=(1, 3, 1460, 2048)).astype(np.float32)
        else:
            print(f"   ⚠️  Cannot test padding for input format: {input_type}")
            return results
        
        padding_test = {
            'input_shape': test_input.shape,
            'success': False,
            'error': None,
            'outputs': [],
            'inference_time': 0,
            'padding_verified': False
        }
        
        try:
            # Run inference
            start_time = time.time()
            outputs = self.session.run(None, {self.input_info.name: test_input})
            inference_time = time.time() - start_time
            
            padding_test['success'] = True
            padding_test['outputs'] = [{'shape': output.shape, 'dtype': str(output.dtype)} for output in outputs]
            padding_test['inference_time'] = inference_time
            
            # Check if model produces reasonable outputs
            if outputs and len(outputs) > 0:
                # For YOLO models, expect detection outputs
                if len(outputs[0].shape) >= 2:
                    padding_test['padding_verified'] = True
                    print(f"   ✅ Padding test passed: {inference_time:.4f}s")
                    print(f"      Input: {test_input.shape}")
                    print(f"      Output shapes: {[output.shape for output in outputs]}")
                else:
                    print(f"   ⚠️  Unexpected output format")
            
        except Exception as e:
            padding_test['error'] = str(e)
            print(f"   ❌ Padding test failed: {e}")
        
        results['padding_tests'].append(padding_test)
        return results
    
    def test_inference_consistency(self, num_runs: int = 5) -> Dict:
        """Test inference consistency across multiple runs."""
        print(f"🔄 Testing inference consistency ({num_runs} runs)...")
        
        results = {
            'num_runs': num_runs,
            'runs': [],
            'consistency_check': {
                'all_runs_successful': True,
                'output_shapes_consistent': True,
                'timing_stats': {}
            }
        }
        
        # Create test input
        input_shape = self.input_info.shape
        input_type = self.input_info.type
        
        if input_type == 'tensor(uint8)' and len(input_shape) == 4 and input_shape[-1] == 3:
            test_input = np.random.randint(0, 256, size=(1, 1460, 2048, 3), dtype=np.uint8)
        elif input_type == 'tensor(float)' and len(input_shape) == 4 and input_shape[1] == 3:
            test_input = np.random.uniform(0.0, 1.0, size=(1, 3, 1460, 2048)).astype(np.float32)
        else:
            print(f"   ⚠️  Cannot test consistency for input format: {input_type}")
            return results
        
        inference_times = []
        output_shapes_list = []
        
        for run_idx in range(num_runs):
            run_result = {
                'run_id': run_idx + 1,
                'success': False,
                'inference_time': 0,
                'output_shapes': [],
                'error': None
            }
            
            try:
                start_time = time.time()
                outputs = self.session.run(None, {self.input_info.name: test_input})
                inference_time = time.time() - start_time
                
                run_result['success'] = True
                run_result['inference_time'] = inference_time
                run_result['output_shapes'] = [output.shape for output in outputs]
                
                inference_times.append(inference_time)
                output_shapes_list.append(run_result['output_shapes'])
                
            except Exception as e:
                run_result['error'] = str(e)
                results['consistency_check']['all_runs_successful'] = False
                print(f"   ❌ Run {run_idx + 1} failed: {e}")
            
            results['runs'].append(run_result)
        
        # Analyze consistency
        if inference_times:
            results['consistency_check']['timing_stats'] = {
                'mean': np.mean(inference_times),
                'std': np.std(inference_times),
                'min': min(inference_times),
                'max': max(inference_times)
            }
            
            # Check output shape consistency
            if len(set(str(shapes) for shapes in output_shapes_list)) > 1:
                results['consistency_check']['output_shapes_consistent'] = False
                print(f"   ⚠️  Output shapes inconsistent across runs")
            
            print(f"   ✅ Consistency test completed:")
            print(f"      Successful runs: {len(inference_times)}/{num_runs}")
            print(f"      Average time: {results['consistency_check']['timing_stats']['mean']:.4f}s")
            print(f"      Time std: {results['consistency_check']['timing_stats']['std']:.4f}s")
        
        return results
    
    def test_edge_cases(self) -> Dict:
        """Test edge cases and boundary conditions."""
        print("⚠️  Testing edge cases...")
        
        results = {
            'edge_cases': []
        }
        
        input_shape = self.input_info.shape
        input_type = self.input_info.type
        
        # Test cases based on input format
        if input_type == 'tensor(uint8)' and len(input_shape) == 4 and input_shape[-1] == 3:
            # HWC uint8 format
            test_cases = [
                ('all_zeros', np.zeros((1, 1460, 2048, 3), dtype=np.uint8)),
                ('all_max', np.full((1, 1460, 2048, 3), 255, dtype=np.uint8)),
                ('random_pattern', np.random.randint(0, 256, size=(1, 1460, 2048, 3), dtype=np.uint8))
            ]
        elif input_type == 'tensor(float)' and len(input_shape) == 4 and input_shape[1] == 3:
            # NCHW float32 format
            test_cases = [
                ('all_zeros', np.zeros((1, 3, 1460, 2048), dtype=np.float32)),
                ('all_ones', np.ones((1, 3, 1460, 2048), dtype=np.float32)),
                ('random_pattern', np.random.uniform(0.0, 1.0, size=(1, 3, 1460, 2048)).astype(np.float32))
            ]
        else:
            print(f"   ⚠️  Cannot test edge cases for input format: {input_type}")
            return results
        
        for case_name, test_input in test_cases:
            case_result = {
                'case_name': case_name,
                'input_shape': test_input.shape,
                'input_dtype': str(test_input.dtype),
                'success': False,
                'inference_time': 0,
                'output_info': [],
                'error': None
            }
            
            try:
                start_time = time.time()
                outputs = self.session.run(None, {self.input_info.name: test_input})
                inference_time = time.time() - start_time
                
                case_result['success'] = True
                case_result['inference_time'] = inference_time
                case_result['output_info'] = [
                    {
                        'shape': output.shape,
                        'dtype': str(output.dtype),
                        'has_nan': bool(np.isnan(output).any()),
                        'has_inf': bool(np.isinf(output).any()),
                        'min_val': float(np.min(output)),
                        'max_val': float(np.max(output))
                    }
                    for output in outputs
                ]
                
                print(f"   ✅ {case_name}: {inference_time:.4f}s")
                
            except Exception as e:
                case_result['error'] = str(e)
                print(f"   ❌ {case_name}: {e}")
            
            results['edge_cases'].append(case_result)
        
        return results
    
    def benchmark_performance(self, num_warmup: int = 5, num_benchmark: int = 20) -> Dict:
        """Benchmark model performance."""
        print(f"⚡ Benchmarking performance ({num_warmup} warmup + {num_benchmark} benchmark runs)...")
        
        results = {
            'warmup_runs': num_warmup,
            'benchmark_runs': num_benchmark,
            'performance_stats': {}
        }
        
        # Create test input
        input_shape = self.input_info.shape
        input_type = self.input_info.type
        
        if input_type == 'tensor(uint8)' and len(input_shape) == 4 and input_shape[-1] == 3:
            test_input = np.random.randint(0, 256, size=(1, 1460, 2048, 3), dtype=np.uint8)
        elif input_type == 'tensor(float)' and len(input_shape) == 4 and input_shape[1] == 3:
            test_input = np.random.uniform(0.0, 1.0, size=(1, 3, 1460, 2048)).astype(np.float32)
        else:
            print(f"   ⚠️  Cannot benchmark input format: {input_type}")
            return results
        
        # Warmup runs
        print(f"   🔥 Warming up...")
        for i in range(num_warmup):
            try:
                self.session.run(None, {self.input_info.name: test_input})
            except Exception as e:
                print(f"   ❌ Warmup run {i+1} failed: {e}")
                return results
        
        # Benchmark runs
        print(f"   📊 Benchmarking...")
        benchmark_times = []
        
        for i in range(num_benchmark):
            try:
                start_time = time.time()
                outputs = self.session.run(None, {self.input_info.name: test_input})
                inference_time = time.time() - start_time
                benchmark_times.append(inference_time)
            except Exception as e:
                print(f"   ❌ Benchmark run {i+1} failed: {e}")
                continue
        
        if benchmark_times:
            results['performance_stats'] = {
                'mean_time': np.mean(benchmark_times),
                'std_time': np.std(benchmark_times),
                'min_time': min(benchmark_times),
                'max_time': max(benchmark_times),
                'median_time': np.median(benchmark_times),
                'fps': 1.0 / np.mean(benchmark_times),
                'all_times': benchmark_times
            }
            
            stats = results['performance_stats']
            print(f"   ✅ Performance benchmark completed:")
            print(f"      Mean time: {stats['mean_time']:.4f}s ± {stats['std_time']:.4f}s")
            print(f"      Min/Max time: {stats['min_time']:.4f}s / {stats['max_time']:.4f}s")
            print(f"      FPS: {stats['fps']:.2f}")
        
        return results
    
    def run_comprehensive_test(self, output_dir: str) -> Dict:
        """Run comprehensive test suite."""
        print("🚀 Running comprehensive ONNX model test suite...")
        
        os.makedirs(output_dir, exist_ok=True)
        
        test_results = {
            'model_path': self.model_path,
            'test_timestamp': str(np.datetime64('now')),
            'model_info': {
                'input_name': self.input_info.name,
                'input_shape': self.input_info.shape,
                'input_type': self.input_info.type,
                'outputs': [(out.name, out.shape, out.type) for out in self.output_info],
                'providers': self.session.get_providers()
            },
            'tests': {}
        }
        
        # Run all tests
        test_results['tests']['input_shapes'] = self.test_input_shapes()
        test_results['tests']['padding_functionality'] = self.test_padding_functionality()
        test_results['tests']['inference_consistency'] = self.test_inference_consistency()
        test_results['tests']['edge_cases'] = self.test_edge_cases()
        test_results['tests']['performance_benchmark'] = self.benchmark_performance()
        
        # Generate summary
        test_results['summary'] = self._generate_test_summary(test_results['tests'])
        
        # Save results
        results_path = os.path.join(output_dir, 'onnx_test_results.json')
        with open(results_path, 'w') as f:
            json.dump(test_results, f, indent=2, default=str)
        
        print(f"📄 Test results saved: {results_path}")
        print("✅ Comprehensive testing completed!")
        
        return test_results
    
    def _generate_test_summary(self, tests: Dict) -> Dict:
        """Generate summary of test results."""
        summary = {
            'overall_status': 'PASS',
            'issues': [],
            'warnings': [],
            'performance_summary': {}
        }
        
        # Check input shape tests
        if 'input_shapes' in tests:
            failed_tests = [t for t in tests['input_shapes']['tests'] if not t['success']]
            if failed_tests:
                summary['overall_status'] = 'FAIL'
                summary['issues'].append(f"Input shape tests failed: {len(failed_tests)} failures")
        
        # Check padding functionality
        if 'padding_functionality' in tests:
            padding_tests = tests['padding_functionality']['padding_tests']
            failed_padding = [t for t in padding_tests if not t['success']]
            if failed_padding:
                summary['overall_status'] = 'FAIL'
                summary['issues'].append("Padding functionality test failed")
        
        # Check consistency
        if 'inference_consistency' in tests:
            consistency = tests['inference_consistency']['consistency_check']
            if not consistency['all_runs_successful']:
                summary['overall_status'] = 'FAIL'
                summary['issues'].append("Inference consistency test failed")
            if not consistency['output_shapes_consistent']:
                summary['warnings'].append("Output shapes inconsistent across runs")
        
        # Performance summary
        if 'performance_benchmark' in tests and 'performance_stats' in tests['performance_benchmark']:
            perf_stats = tests['performance_benchmark']['performance_stats']
            summary['performance_summary'] = {
                'average_fps': perf_stats['fps'],
                'average_inference_time': perf_stats['mean_time'],
                'performance_rating': 'Good' if perf_stats['fps'] > 10 else 'Moderate' if perf_stats['fps'] > 1 else 'Slow'
            }
        
        return summary

def main():
    """Main function for command-line usage."""
    parser = argparse.ArgumentParser(
        description='Comprehensive ONNX model testing suite',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Test single ONNX model
  python test_onnx_models.py --model model.onnx --output ./test_results
  
  # Test with CPU only
  python test_onnx_models.py --model model.onnx --providers CPUExecutionProvider
        """
    )
    
    parser.add_argument('--model', required=True, help='Path to ONNX model')
    parser.add_argument('--output', default='./onnx_test_results', help='Output directory for test results')
    parser.add_argument('--providers', nargs='+', default=['CUDAExecutionProvider', 'CPUExecutionProvider'],
                       help='ONNX Runtime execution providers')
    parser.add_argument('--warmup', type=int, default=5, help='Number of warmup runs for benchmarking')
    parser.add_argument('--benchmark', type=int, default=20, help='Number of benchmark runs')
    parser.add_argument('--consistency-runs', type=int, default=5, help='Number of consistency test runs')
    
    args = parser.parse_args()
    
    if not os.path.exists(args.model):
        print(f"❌ Model file not found: {args.model}")
        sys.exit(1)
    
    try:
        # Initialize tester
        tester = ONNXModelTester(args.model, args.providers)
        
        # Run comprehensive tests
        results = tester.run_comprehensive_test(args.output)
        
        # Print summary
        summary = results['summary']
        print(f"\n📋 Test Summary:")
        print(f"   Overall Status: {summary['overall_status']}")
        
        if summary['issues']:
            print(f"   Issues: {len(summary['issues'])}")
            for issue in summary['issues']:
                print(f"      - {issue}")
        
        if summary['warnings']:
            print(f"   Warnings: {len(summary['warnings'])}")
            for warning in summary['warnings']:
                print(f"      - {warning}")
        
        if 'performance_summary' in summary:
            perf = summary['performance_summary']
            print(f"   Performance: {perf['performance_rating']}")
            print(f"      FPS: {perf['average_fps']:.2f}")
            print(f"      Avg time: {perf['average_inference_time']:.4f}s")
        
        if summary['overall_status'] == 'PASS':
            print("🎉 All tests passed!")
        else:
            print("⚠️  Some tests failed - check detailed results")
            sys.exit(1)
        
    except Exception as e:
        print(f"❌ Testing failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()

