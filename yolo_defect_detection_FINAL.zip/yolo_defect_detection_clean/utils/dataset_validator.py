#!/usr/bin/env python3
"""
Dataset Validator for YOLOv8 Defect Detection
Validates dataset structure and provides comprehensive analysis.
"""

import os
import sys
import yaml
import json
import argparse
import cv2
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from collections import defaultdict, Counter

class DatasetValidator:
    """Comprehensive dataset validator for YOLO format datasets."""
    
    def __init__(self, config_path: str):
        """Initialize validator with dataset configuration."""
        self.config_path = config_path
        self.config = self._load_config()
        self.dataset_path = Path(self.config['path'])
        self.stats = defaultdict(dict)
        
    def _load_config(self) -> Dict:
        """Load dataset configuration from YAML file."""
        with open(self.config_path, 'r') as f:
            return yaml.safe_load(f)
    
    def validate_structure(self) -> bool:
        """Validate basic dataset directory structure."""
        print("🔍 Validating dataset structure...")
        
        if not self.dataset_path.exists():
            print(f"❌ Dataset root path does not exist: {self.dataset_path}")
            return False
        
        # Check required directories
        required_dirs = {
            'images_train': self.dataset_path / self.config['train'],
            'images_val': self.dataset_path / self.config['val'],
            'labels_train': self.dataset_path / self.config['train'].replace('images', 'labels'),
            'labels_val': self.dataset_path / self.config['val'].replace('images', 'labels'),
        }
        
        # Check if test split exists
        if 'test' in self.config:
            required_dirs['images_test'] = self.dataset_path / self.config['test']
            required_dirs['labels_test'] = self.dataset_path / self.config['test'].replace('images', 'labels')
        
        all_exist = True
        for name, path in required_dirs.items():
            if path.exists():
                file_count = len(list(path.glob('*')))
                print(f"✅ {name}: {path} ({file_count} files)")
                self.stats['structure'][name] = {'path': str(path), 'file_count': file_count}
            else:
                print(f"❌ {name}: {path} (missing)")
                self.stats['structure'][name] = {'path': str(path), 'file_count': 0, 'missing': True}
                all_exist = False
        
        return all_exist
    
    def analyze_images(self, split: str = 'train') -> Dict:
        """Analyze images in specified split."""
        print(f"📊 Analyzing images in {split} split...")
        
        images_dir = self.dataset_path / self.config[split]
        if not images_dir.exists():
            print(f"❌ Images directory not found: {images_dir}")
            return {}
        
        image_files = list(images_dir.glob('*.png')) + list(images_dir.glob('*.jpg')) + list(images_dir.glob('*.jpeg'))
        
        if not image_files:
            print(f"❌ No image files found in {images_dir}")
            return {}
        
        print(f"   Found {len(image_files)} images")
        
        # Analyze image properties
        widths, heights, channels = [], [], []
        corrupted_images = []
        
        for i, img_path in enumerate(image_files):
            try:
                img = cv2.imread(str(img_path))
                if img is None:
                    corrupted_images.append(str(img_path))
                    continue
                
                h, w, c = img.shape
                heights.append(h)
                widths.append(w)
                channels.append(c)
                
                if (i + 1) % 100 == 0:
                    print(f"   Processed {i + 1}/{len(image_files)} images")
                    
            except Exception as e:
                corrupted_images.append(str(img_path))
                print(f"   ⚠️  Error reading {img_path}: {e}")
        
        if not widths:
            print(f"❌ No valid images found in {split} split")
            return {}
        
        # Calculate statistics
        stats = {
            'total_images': len(image_files),
            'valid_images': len(widths),
            'corrupted_images': len(corrupted_images),
            'width': {
                'min': min(widths),
                'max': max(widths),
                'mean': np.mean(widths),
                'std': np.std(widths)
            },
            'height': {
                'min': min(heights),
                'max': max(heights),
                'mean': np.mean(heights),
                'std': np.std(heights)
            },
            'channels': {
                'unique': list(set(channels)),
                'most_common': Counter(channels).most_common(1)[0] if channels else None
            },
            'corrupted_files': corrupted_images
        }
        
        # Check for expected resolution
        expected_w, expected_h = 2048, 1460
        matching_resolution = sum(1 for w, h in zip(widths, heights) if w == expected_w and h == expected_h)
        stats['resolution_match'] = {
            'expected': f"{expected_w}x{expected_h}",
            'matching_count': matching_resolution,
            'matching_percentage': (matching_resolution / len(widths)) * 100 if widths else 0
        }
        
        print(f"   ✅ Image analysis completed:")
        print(f"      Valid images: {stats['valid_images']}/{stats['total_images']}")
        print(f"      Resolution range: {stats['width']['min']}-{stats['width']['max']} x {stats['height']['min']}-{stats['height']['max']}")
        print(f"      Expected resolution ({expected_w}x{expected_h}): {matching_resolution}/{len(widths)} ({stats['resolution_match']['matching_percentage']:.1f}%)")
        
        self.stats['images'][split] = stats
        return stats
    
    def analyze_labels(self, split: str = 'train') -> Dict:
        """Analyze labels in specified split."""
        print(f"🏷️  Analyzing labels in {split} split...")
        
        labels_dir = self.dataset_path / self.config[split].replace('images', 'labels')
        if not labels_dir.exists():
            print(f"❌ Labels directory not found: {labels_dir}")
            return {}
        
        label_files = list(labels_dir.glob('*.txt'))
        
        if not label_files:
            print(f"❌ No label files found in {labels_dir}")
            return {}
        
        print(f"   Found {label_files} label files")
        
        # Analyze label properties
        all_boxes = []
        class_counts = Counter()
        images_without_labels = 0
        labels_per_image = []
        corrupted_labels = []
        
        for label_path in label_files:
            try:
                with open(label_path, 'r') as f:
                    lines = f.read().strip().split('\n')
                
                if not lines or lines == ['']:
                    images_without_labels += 1
                    labels_per_image.append(0)
                    continue
                
                image_boxes = []
                for line in lines:
                    parts = line.strip().split()
                    if len(parts) >= 5:
                        class_id = int(parts[0])
                        x_center, y_center, width, height = map(float, parts[1:5])
                        
                        # Validate coordinates
                        if not (0 <= x_center <= 1 and 0 <= y_center <= 1 and 
                               0 < width <= 1 and 0 < height <= 1):
                            print(f"   ⚠️  Invalid coordinates in {label_path}: {line}")
                        
                        class_counts[class_id] += 1
                        image_boxes.append([x_center, y_center, width, height])
                        all_boxes.append([x_center, y_center, width, height])
                
                labels_per_image.append(len(image_boxes))
                
            except Exception as e:
                corrupted_labels.append(str(label_path))
                print(f"   ⚠️  Error reading {label_path}: {e}")
        
        if not all_boxes:
            print(f"❌ No valid labels found in {split} split")
            return {}
        
        # Calculate box area statistics
        box_areas = []
        for box in all_boxes:
            x_center, y_center, width, height = box
            area = width * height  # Normalized area
            box_areas.append(area)
        
        # Analyze tiny defects (< 0.1% of image)
        tiny_threshold = 0.001  # 0.1% of normalized image area
        tiny_defects = [area for area in box_areas if area < tiny_threshold]
        
        stats = {
            'total_labels': len(label_files),
            'total_defects': len(all_boxes),
            'images_without_labels': images_without_labels,
            'defects_per_image': {
                'min': min(labels_per_image) if labels_per_image else 0,
                'max': max(labels_per_image) if labels_per_image else 0,
                'mean': np.mean(labels_per_image) if labels_per_image else 0,
                'std': np.std(labels_per_image) if labels_per_image else 0
            },
            'class_distribution': dict(class_counts),
            'defect_areas': {
                'min': min(box_areas) if box_areas else 0,
                'max': max(box_areas) if box_areas else 0,
                'mean': np.mean(box_areas) if box_areas else 0,
                'median': np.median(box_areas) if box_areas else 0,
                'std': np.std(box_areas) if box_areas else 0
            },
            'tiny_defects': {
                'count': len(tiny_defects),
                'percentage': (len(tiny_defects) / len(all_boxes)) * 100 if all_boxes else 0,
                'threshold': tiny_threshold
            },
            'corrupted_files': corrupted_labels
        }
        
        print(f"   ✅ Label analysis completed:")
        print(f"      Total defects: {stats['total_defects']}")
        print(f"      Defects per image: {stats['defects_per_image']['mean']:.2f} ± {stats['defects_per_image']['std']:.2f}")
        print(f"      Tiny defects (< 0.1%): {stats['tiny_defects']['count']}/{stats['total_defects']} ({stats['tiny_defects']['percentage']:.1f}%)")
        print(f"      Average defect area: {stats['defect_areas']['mean']:.4f} ({stats['defect_areas']['mean']*100:.2f}% of image)")
        
        self.stats['labels'][split] = stats
        return stats
    
    def check_image_label_correspondence(self, split: str = 'train') -> Dict:
        """Check correspondence between images and labels."""
        print(f"🔗 Checking image-label correspondence for {split} split...")
        
        images_dir = self.dataset_path / self.config[split]
        labels_dir = self.dataset_path / self.config[split].replace('images', 'labels')
        
        if not images_dir.exists() or not labels_dir.exists():
            print(f"❌ Missing directories for {split} split")
            return {}
        
        # Get image and label files
        image_files = set()
        for ext in ['*.png', '*.jpg', '*.jpeg']:
            image_files.update(Path(f).stem for f in images_dir.glob(ext))
        
        label_files = set(Path(f).stem for f in labels_dir.glob('*.txt'))
        
        # Find mismatches
        images_without_labels = image_files - label_files
        labels_without_images = label_files - image_files
        matched_pairs = image_files & label_files
        
        stats = {
            'total_images': len(image_files),
            'total_labels': len(label_files),
            'matched_pairs': len(matched_pairs),
            'images_without_labels': len(images_without_labels),
            'labels_without_images': len(labels_without_images),
            'correspondence_rate': (len(matched_pairs) / len(image_files)) * 100 if image_files else 0
        }
        
        print(f"   ✅ Correspondence check completed:")
        print(f"      Matched pairs: {stats['matched_pairs']}")
        print(f"      Images without labels: {stats['images_without_labels']}")
        print(f"      Labels without images: {stats['labels_without_images']}")
        print(f"      Correspondence rate: {stats['correspondence_rate']:.1f}%")
        
        if images_without_labels:
            print(f"   ⚠️  Some images don't have corresponding labels")
        if labels_without_images:
            print(f"   ⚠️  Some labels don't have corresponding images")
        
        self.stats['correspondence'][split] = stats
        return stats
    
    def generate_visualizations(self, output_dir: str, split: str = 'train'):
        """Generate visualization plots for the dataset."""
        print(f"📈 Generating visualizations for {split} split...")
        
        os.makedirs(output_dir, exist_ok=True)
        
        if split not in self.stats.get('labels', {}):
            print(f"   ⚠️  No label statistics available for {split} split")
            return
        
        label_stats = self.stats['labels'][split]
        
        # Plot 1: Defect area distribution
        if 'defect_areas' in label_stats:
            plt.figure(figsize=(10, 6))
            
            # Get all box areas for histogram
            labels_dir = self.dataset_path / self.config[split].replace('images', 'labels')
            all_areas = []
            
            for label_path in labels_dir.glob('*.txt'):
                try:
                    with open(label_path, 'r') as f:
                        lines = f.read().strip().split('\n')
                    
                    for line in lines:
                        if line.strip():
                            parts = line.strip().split()
                            if len(parts) >= 5:
                                width, height = float(parts[3]), float(parts[4])
                                area = width * height
                                all_areas.append(area)
                except:
                    continue
            
            if all_areas:
                plt.hist(all_areas, bins=50, alpha=0.7, edgecolor='black')
                plt.axvline(x=0.001, color='red', linestyle='--', label='Tiny defect threshold (0.1%)')
                plt.xlabel('Defect Area (normalized)')
                plt.ylabel('Frequency')
                plt.title(f'Defect Area Distribution - {split.title()} Split')
                plt.legend()
                plt.grid(True, alpha=0.3)
                plt.savefig(os.path.join(output_dir, f'{split}_defect_areas.png'), dpi=300, bbox_inches='tight')
                plt.close()
                print(f"   💾 Saved: {split}_defect_areas.png")
        
        # Plot 2: Class distribution
        if 'class_distribution' in label_stats:
            class_dist = label_stats['class_distribution']
            if class_dist:
                plt.figure(figsize=(8, 6))
                classes = list(class_dist.keys())
                counts = list(class_dist.values())
                
                plt.bar(classes, counts, alpha=0.7, edgecolor='black')
                plt.xlabel('Class ID')
                plt.ylabel('Number of Defects')
                plt.title(f'Class Distribution - {split.title()} Split')
                plt.grid(True, alpha=0.3)
                plt.savefig(os.path.join(output_dir, f'{split}_class_distribution.png'), dpi=300, bbox_inches='tight')
                plt.close()
                print(f"   💾 Saved: {split}_class_distribution.png")
    
    def save_report(self, output_path: str):
        """Save comprehensive validation report."""
        print(f"📄 Saving validation report...")
        
        report = {
            'dataset_config': self.config,
            'validation_timestamp': str(np.datetime64('now')),
            'statistics': dict(self.stats),
            'summary': self._generate_summary()
        }
        
        with open(output_path, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        print(f"   💾 Report saved: {output_path}")
    
    def _generate_summary(self) -> Dict:
        """Generate summary of validation results."""
        summary = {
            'dataset_valid': True,
            'issues': [],
            'recommendations': []
        }
        
        # Check for major issues
        for split in ['train', 'val']:
            if split in self.stats.get('correspondence', {}):
                corr_stats = self.stats['correspondence'][split]
                if corr_stats['correspondence_rate'] < 95:
                    summary['dataset_valid'] = False
                    summary['issues'].append(f"Low correspondence rate in {split} split: {corr_stats['correspondence_rate']:.1f}%")
        
        # Check for tiny defects
        for split in self.stats.get('labels', {}):
            label_stats = self.stats['labels'][split]
            if 'tiny_defects' in label_stats:
                tiny_pct = label_stats['tiny_defects']['percentage']
                if tiny_pct > 50:
                    summary['recommendations'].append(f"High percentage of tiny defects in {split} split ({tiny_pct:.1f}%) - consider specialized training techniques")
        
        return summary
    
    def run_full_validation(self, output_dir: str) -> bool:
        """Run complete dataset validation pipeline."""
        print("🚀 Starting comprehensive dataset validation...")
        
        os.makedirs(output_dir, exist_ok=True)
        
        # Step 1: Validate structure
        structure_valid = self.validate_structure()
        
        if not structure_valid:
            print("❌ Dataset structure validation failed")
            return False
        
        # Step 2: Analyze each split
        splits_to_check = ['train', 'val']
        if 'test' in self.config:
            splits_to_check.append('test')
        
        for split in splits_to_check:
            if split in self.config:
                print(f"\n📊 Analyzing {split} split...")
                self.analyze_images(split)
                self.analyze_labels(split)
                self.check_image_label_correspondence(split)
                self.generate_visualizations(output_dir, split)
        
        # Step 3: Save comprehensive report
        report_path = os.path.join(output_dir, 'dataset_validation_report.json')
        self.save_report(report_path)
        
        print("\n✅ Dataset validation completed successfully!")
        print(f"📁 Results saved to: {output_dir}")
        
        return True

def main():
    """Main function for command-line usage."""
    parser = argparse.ArgumentParser(description='Validate YOLO dataset for defect detection')
    parser.add_argument('--config', required=True, help='Path to dataset configuration YAML')
    parser.add_argument('--output', default='./dataset_analysis', help='Output directory for analysis results')
    parser.add_argument('--split', choices=['train', 'val', 'test'], help='Analyze specific split only')
    
    args = parser.parse_args()
    
    if not os.path.exists(args.config):
        print(f"❌ Configuration file not found: {args.config}")
        sys.exit(1)
    
    try:
        validator = DatasetValidator(args.config)
        
        if args.split:
            # Analyze specific split only
            print(f"🔍 Analyzing {args.split} split only...")
            os.makedirs(args.output, exist_ok=True)
            
            validator.analyze_images(args.split)
            validator.analyze_labels(args.split)
            validator.check_image_label_correspondence(args.split)
            validator.generate_visualizations(args.output, args.split)
            
            report_path = os.path.join(args.output, f'{args.split}_analysis_report.json')
            validator.save_report(report_path)
        else:
            # Run full validation
            validator.run_full_validation(args.output)
        
        print("🎉 Validation completed successfully!")
        
    except Exception as e:
        print(f"❌ Validation failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()

