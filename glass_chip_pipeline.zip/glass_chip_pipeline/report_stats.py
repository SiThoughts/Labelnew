#!/usr/bin/env python3
"""
Statistics reporting utility for glass chip detection pipeline.

This script analyzes processed feature data and generates comprehensive
statistical reports including histograms, SNR analysis, and quality metrics.
"""

import os
import sys
import argparse
import logging
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import cv2

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class GlassStatisticsReporter:
    """
    Comprehensive statistics reporter for glass chip detection pipeline.
    
    Analyzes processed feature data and generates detailed reports including
    channel statistics, SNR analysis, and quality metrics.
    """
    
    def __init__(self):
        """Initialize the statistics reporter."""
        self.channel_names = ['L_CLAHE', 'DoG_s2_4', 'DoG_s4_8', 'Entropy11', 'EdgeBandMask', 'ConcavityMap']
        self.channel_descriptions = {
            'L_CLAHE': 'Enhanced L channel with CLAHE + Retinex',
            'DoG_s2_4': 'Difference of Gaussians (σ=2,4)',
            'DoG_s4_8': 'Difference of Gaussians (σ=4,8)',
            'Entropy11': 'Local entropy (11×11 window)',
            'EdgeBandMask': 'Edge band mask (15-30px)',
            'ConcavityMap': 'Edge concavity/deviation map'
        }
    
    def analyze_dataset(self, feature_dir: str, annotation_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze a complete dataset of processed features.
        
        Args:
            feature_dir: Directory containing .npy feature files
            annotation_path: Optional path to annotation file for SNR analysis
            
        Returns:
            Dictionary containing comprehensive statistics
        """
        feature_path = Path(feature_dir)
        
        # Find all feature files
        feature_files = list(feature_path.glob("*.npy"))
        
        if not feature_files:
            raise ValueError(f"No .npy files found in {feature_dir}")
        
        logger.info(f"Analyzing {len(feature_files)} feature files")
        
        # Load all features
        all_features = []
        file_names = []
        
        for feature_file in feature_files:
            try:
                features = np.load(feature_file)
                if features.shape[2] != 6:
                    logger.warning(f"Skipping {feature_file}: expected 6 channels, got {features.shape[2]}")
                    continue
                
                all_features.append(features)
                file_names.append(feature_file.stem)
                
            except Exception as e:
                logger.warning(f"Failed to load {feature_file}: {e}")
        
        if not all_features:
            raise ValueError("No valid feature files found")
        
        # Compute statistics
        stats_dict = {
            'dataset_info': {
                'num_images': len(all_features),
                'image_names': file_names,
                'feature_shapes': [f.shape for f in all_features]
            },
            'channel_statistics': self._compute_channel_statistics(all_features),
            'correlation_analysis': self._compute_channel_correlations(all_features),
            'quality_metrics': self._compute_quality_metrics(all_features),
            'distribution_analysis': self._analyze_distributions(all_features)
        }
        
        # Add SNR analysis if annotations are available
        if annotation_path and os.path.exists(annotation_path):
            stats_dict['snr_analysis'] = self._compute_snr_analysis(
                all_features, file_names, annotation_path
            )
        
        return stats_dict
    
    def _compute_channel_statistics(self, all_features: List[np.ndarray]) -> Dict[str, Any]:
        """Compute comprehensive statistics for each channel."""
        stats = {}
        
        for channel_idx, channel_name in enumerate(self.channel_names):
            channel_data = []
            
            # Collect all pixel values for this channel across all images
            for features in all_features:
                channel = features[:, :, channel_idx]
                channel_data.append(channel.flatten())
            
            # Combine all data
            all_channel_data = np.concatenate(channel_data)
            
            # Compute statistics
            stats[channel_name] = {
                'mean': float(np.mean(all_channel_data)),
                'std': float(np.std(all_channel_data)),
                'min': float(np.min(all_channel_data)),
                'max': float(np.max(all_channel_data)),
                'median': float(np.median(all_channel_data)),
                'q25': float(np.percentile(all_channel_data, 25)),
                'q75': float(np.percentile(all_channel_data, 75)),
                'skewness': float(stats.skew(all_channel_data)),
                'kurtosis': float(stats.kurtosis(all_channel_data)),
                'non_zero_ratio': float(np.mean(all_channel_data > 0)),
                'entropy': float(self._compute_entropy(all_channel_data)),
                'dynamic_range': float(np.max(all_channel_data) - np.min(all_channel_data))
            }
            
            # Per-image statistics
            per_image_means = [np.mean(f[:, :, channel_idx]) for f in all_features]
            per_image_stds = [np.std(f[:, :, channel_idx]) for f in all_features]
            
            stats[channel_name]['per_image'] = {
                'mean_consistency': float(np.std(per_image_means)),
                'std_consistency': float(np.std(per_image_stds)),
                'mean_range': [float(np.min(per_image_means)), float(np.max(per_image_means))],
                'std_range': [float(np.min(per_image_stds)), float(np.max(per_image_stds))]
            }
        
        return stats
    
    def _compute_channel_correlations(self, all_features: List[np.ndarray]) -> Dict[str, Any]:
        """Compute correlations between channels."""
        # Sample pixels from all images for correlation analysis
        sample_size = min(10000, sum(f.size // 6 for f in all_features))
        
        sampled_data = np.zeros((sample_size, 6))
        idx = 0
        
        for features in all_features:
            h, w, c = features.shape
            flat_features = features.reshape(-1, c)
            
            # Sample random pixels
            n_samples = min(sample_size - idx, len(flat_features))
            if n_samples <= 0:
                break
            
            sample_indices = np.random.choice(len(flat_features), n_samples, replace=False)
            sampled_data[idx:idx+n_samples] = flat_features[sample_indices]
            idx += n_samples
        
        # Compute correlation matrix
        correlation_matrix = np.corrcoef(sampled_data[:idx].T)
        
        # Create correlation dictionary
        correlations = {}
        for i, name1 in enumerate(self.channel_names):
            correlations[name1] = {}
            for j, name2 in enumerate(self.channel_names):
                correlations[name1][name2] = float(correlation_matrix[i, j])
        
        return {
            'correlation_matrix': correlation_matrix.tolist(),
            'correlations': correlations,
            'sample_size': idx
        }
    
    def _compute_quality_metrics(self, all_features: List[np.ndarray]) -> Dict[str, Any]:
        """Compute quality metrics for the feature extraction."""
        metrics = {}
        
        for channel_idx, channel_name in enumerate(self.channel_names):
            channel_metrics = {
                'contrast_ratio': [],
                'information_content': [],
                'spatial_coherence': []
            }
            
            for features in all_features:
                channel = features[:, :, channel_idx]
                
                # Contrast ratio (std/mean)
                if np.mean(channel) > 0:
                    contrast = np.std(channel) / np.mean(channel)
                else:
                    contrast = 0
                channel_metrics['contrast_ratio'].append(contrast)
                
                # Information content (entropy)
                info_content = self._compute_entropy(channel.flatten())
                channel_metrics['information_content'].append(info_content)
                
                # Spatial coherence (local correlation)
                spatial_coherence = self._compute_spatial_coherence(channel)
                channel_metrics['spatial_coherence'].append(spatial_coherence)
            
            # Aggregate metrics
            metrics[channel_name] = {
                'avg_contrast_ratio': float(np.mean(channel_metrics['contrast_ratio'])),
                'avg_information_content': float(np.mean(channel_metrics['information_content'])),
                'avg_spatial_coherence': float(np.mean(channel_metrics['spatial_coherence'])),
                'contrast_consistency': float(np.std(channel_metrics['contrast_ratio'])),
                'info_consistency': float(np.std(channel_metrics['information_content']))
            }
        
        return metrics
    
    def _analyze_distributions(self, all_features: List[np.ndarray]) -> Dict[str, Any]:
        """Analyze value distributions for each channel."""
        distributions = {}
        
        for channel_idx, channel_name in enumerate(self.channel_names):
            # Collect sample data
            sample_data = []
            for features in all_features[:10]:  # Sample from first 10 images
                channel = features[:, :, channel_idx]
                sample_indices = np.random.choice(channel.size, min(1000, channel.size), replace=False)
                sample_data.extend(channel.flat[sample_indices])
            
            sample_data = np.array(sample_data)
            
            # Fit common distributions
            distributions[channel_name] = {
                'histogram_bins': 50,
                'histogram_counts': np.histogram(sample_data, bins=50)[0].tolist(),
                'histogram_edges': np.histogram(sample_data, bins=50)[1].tolist(),
                'normality_test': float(stats.normaltest(sample_data)[1]),  # p-value
                'zero_fraction': float(np.mean(sample_data == 0)),
                'outlier_fraction': self._compute_outlier_fraction(sample_data)
            }
        
        return distributions
    
    def _compute_snr_analysis(self, all_features: List[np.ndarray], 
                            file_names: List[str], annotation_path: str) -> Dict[str, Any]:
        """Compute Signal-to-Noise Ratio analysis using annotations."""
        # This is a placeholder for SNR analysis
        # In practice, you would load annotations and compute SNR for defect vs background regions
        logger.info("SNR analysis not fully implemented - placeholder")
        
        return {
            'note': 'SNR analysis requires implementation based on annotation format',
            'defect_snr': {},
            'background_snr': {}
        }
    
    def _compute_entropy(self, data: np.ndarray, bins: int = 256) -> float:
        """Compute entropy of data."""
        hist, _ = np.histogram(data, bins=bins, density=True)
        hist = hist[hist > 0]  # Remove zero bins
        return float(-np.sum(hist * np.log2(hist + 1e-10)))
    
    def _compute_spatial_coherence(self, channel: np.ndarray) -> float:
        """Compute spatial coherence using local correlation."""
        if channel.size < 4:
            return 0.0
        
        # Compute correlation with shifted versions
        h, w = channel.shape
        if h < 2 or w < 2:
            return 0.0
        
        # Horizontal correlation
        h_corr = np.corrcoef(channel[:, :-1].flatten(), channel[:, 1:].flatten())[0, 1]
        
        # Vertical correlation
        v_corr = np.corrcoef(channel[:-1, :].flatten(), channel[1:, :].flatten())[0, 1]
        
        # Average correlation (handle NaN)
        correlations = [h_corr, v_corr]
        valid_correlations = [c for c in correlations if not np.isnan(c)]
        
        if valid_correlations:
            return float(np.mean(valid_correlations))
        else:
            return 0.0
    
    def _compute_outlier_fraction(self, data: np.ndarray) -> float:
        """Compute fraction of outliers using IQR method."""
        q25, q75 = np.percentile(data, [25, 75])
        iqr = q75 - q25
        
        if iqr == 0:
            return 0.0
        
        lower_bound = q25 - 1.5 * iqr
        upper_bound = q75 + 1.5 * iqr
        
        outliers = (data < lower_bound) | (data > upper_bound)
        return float(np.mean(outliers))
    
    def generate_report(self, stats_dict: Dict[str, Any], output_dir: str):
        """Generate comprehensive statistical report."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Generate plots
        self._plot_channel_distributions(stats_dict, output_path)
        self._plot_correlation_matrix(stats_dict, output_path)
        self._plot_quality_metrics(stats_dict, output_path)
        self._plot_per_image_consistency(stats_dict, output_path)
        
        # Generate text report
        self._generate_text_report(stats_dict, output_path)
        
        # Generate CSV summary
        self._generate_csv_summary(stats_dict, output_path)
        
        logger.info(f"Complete statistical report generated in {output_path}")
    
    def _plot_channel_distributions(self, stats_dict: Dict[str, Any], output_path: Path):
        """Plot distribution histograms for all channels."""
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        fig.suptitle('Channel Value Distributions', fontsize=16, fontweight='bold')
        
        for i, channel_name in enumerate(self.channel_names):
            row = i // 3
            col = i % 3
            ax = axes[row, col]
            
            # Get distribution data
            dist_data = stats_dict['distribution_analysis'][channel_name]
            bin_edges = np.array(dist_data['histogram_edges'])
            bin_counts = np.array(dist_data['histogram_counts'])
            
            # Plot histogram
            bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
            ax.bar(bin_centers, bin_counts, width=np.diff(bin_edges), alpha=0.7)
            
            ax.set_title(f'{channel_name} Distribution')
            ax.set_xlabel('Value')
            ax.set_ylabel('Count')
            ax.grid(True, alpha=0.3)
            
            # Add statistics text
            channel_stats = stats_dict['channel_statistics'][channel_name]
            stats_text = f"Mean: {channel_stats['mean']:.3f}\n"
            stats_text += f"Std: {channel_stats['std']:.3f}\n"
            stats_text += f"Skew: {channel_stats['skewness']:.3f}"
            
            ax.text(0.02, 0.98, stats_text, transform=ax.transAxes,
                   verticalalignment='top', fontsize=8,
                   bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        plt.tight_layout()
        plt.savefig(output_path / 'channel_distributions.png', dpi=150, bbox_inches='tight')
        plt.close()
    
    def _plot_correlation_matrix(self, stats_dict: Dict[str, Any], output_path: Path):
        """Plot correlation matrix between channels."""
        correlation_matrix = np.array(stats_dict['correlation_analysis']['correlation_matrix'])
        
        plt.figure(figsize=(10, 8))
        sns.heatmap(correlation_matrix, 
                   xticklabels=self.channel_names,
                   yticklabels=self.channel_names,
                   annot=True, fmt='.3f', cmap='coolwarm', center=0,
                   square=True, cbar_kws={'label': 'Correlation Coefficient'})
        
        plt.title('Channel Correlation Matrix', fontsize=14, fontweight='bold')
        plt.tight_layout()
        plt.savefig(output_path / 'correlation_matrix.png', dpi=150, bbox_inches='tight')
        plt.close()
    
    def _plot_quality_metrics(self, stats_dict: Dict[str, Any], output_path: Path):
        """Plot quality metrics for all channels."""
        quality_data = stats_dict['quality_metrics']
        
        metrics = ['avg_contrast_ratio', 'avg_information_content', 'avg_spatial_coherence']
        metric_labels = ['Contrast Ratio', 'Information Content', 'Spatial Coherence']
        
        fig, axes = plt.subplots(1, 3, figsize=(18, 6))
        fig.suptitle('Quality Metrics by Channel', fontsize=16, fontweight='bold')
        
        for i, (metric, label) in enumerate(zip(metrics, metric_labels)):
            ax = axes[i]
            
            values = [quality_data[channel][metric] for channel in self.channel_names]
            
            bars = ax.bar(self.channel_names, values, alpha=0.7)
            ax.set_title(label)
            ax.set_ylabel('Value')
            ax.tick_params(axis='x', rotation=45)
            ax.grid(True, alpha=0.3)
            
            # Color bars based on value
            for bar, value in zip(bars, values):
                if value > np.mean(values):
                    bar.set_color('green')
                else:
                    bar.set_color('orange')
        
        plt.tight_layout()
        plt.savefig(output_path / 'quality_metrics.png', dpi=150, bbox_inches='tight')
        plt.close()
    
    def _plot_per_image_consistency(self, stats_dict: Dict[str, Any], output_path: Path):
        """Plot per-image consistency metrics."""
        fig, axes = plt.subplots(1, 2, figsize=(15, 6))
        fig.suptitle('Per-Image Consistency', fontsize=16, fontweight='bold')
        
        # Mean consistency
        ax1 = axes[0]
        mean_consistency = [stats_dict['channel_statistics'][ch]['per_image']['mean_consistency'] 
                          for ch in self.channel_names]
        
        bars1 = ax1.bar(self.channel_names, mean_consistency, alpha=0.7, color='skyblue')
        ax1.set_title('Mean Value Consistency')
        ax1.set_ylabel('Standard Deviation of Means')
        ax1.tick_params(axis='x', rotation=45)
        ax1.grid(True, alpha=0.3)
        
        # Std consistency
        ax2 = axes[1]
        std_consistency = [stats_dict['channel_statistics'][ch]['per_image']['std_consistency'] 
                         for ch in self.channel_names]
        
        bars2 = ax2.bar(self.channel_names, std_consistency, alpha=0.7, color='lightcoral')
        ax2.set_title('Standard Deviation Consistency')
        ax2.set_ylabel('Standard Deviation of Stds')
        ax2.tick_params(axis='x', rotation=45)
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_path / 'consistency_metrics.png', dpi=150, bbox_inches='tight')
        plt.close()
    
    def _generate_text_report(self, stats_dict: Dict[str, Any], output_path: Path):
        """Generate comprehensive text report."""
        report_path = output_path / 'statistical_report.txt'
        
        with open(report_path, 'w') as f:
            f.write("Glass Chip Detection Pipeline - Statistical Analysis Report\n")
            f.write("=" * 70 + "\n\n")
            
            # Dataset info
            dataset_info = stats_dict['dataset_info']
            f.write(f"Dataset Information:\n")
            f.write(f"  Number of images: {dataset_info['num_images']}\n")
            f.write(f"  Image shapes: {set(tuple(s) for s in dataset_info['feature_shapes'])}\n\n")
            
            # Channel statistics
            f.write("Channel Statistics:\n")
            f.write("-" * 30 + "\n")
            
            for channel_name in self.channel_names:
                stats = stats_dict['channel_statistics'][channel_name]
                f.write(f"\n{channel_name} ({self.channel_descriptions[channel_name]}):\n")
                f.write(f"  Mean: {stats['mean']:.4f} ± {stats['std']:.4f}\n")
                f.write(f"  Range: [{stats['min']:.4f}, {stats['max']:.4f}]\n")
                f.write(f"  Median: {stats['median']:.4f}\n")
                f.write(f"  Q25-Q75: [{stats['q25']:.4f}, {stats['q75']:.4f}]\n")
                f.write(f"  Skewness: {stats['skewness']:.4f}\n")
                f.write(f"  Kurtosis: {stats['kurtosis']:.4f}\n")
                f.write(f"  Non-zero ratio: {stats['non_zero_ratio']:.4f}\n")
                f.write(f"  Entropy: {stats['entropy']:.4f}\n")
                f.write(f"  Dynamic range: {stats['dynamic_range']:.4f}\n")
                
                # Per-image consistency
                per_img = stats['per_image']
                f.write(f"  Mean consistency: {per_img['mean_consistency']:.4f}\n")
                f.write(f"  Std consistency: {per_img['std_consistency']:.4f}\n")
            
            # Quality metrics
            f.write("\n\nQuality Metrics:\n")
            f.write("-" * 20 + "\n")
            
            for channel_name in self.channel_names:
                quality = stats_dict['quality_metrics'][channel_name]
                f.write(f"\n{channel_name}:\n")
                f.write(f"  Contrast ratio: {quality['avg_contrast_ratio']:.4f}\n")
                f.write(f"  Information content: {quality['avg_information_content']:.4f}\n")
                f.write(f"  Spatial coherence: {quality['avg_spatial_coherence']:.4f}\n")
            
            # Correlation analysis
            f.write("\n\nChannel Correlations:\n")
            f.write("-" * 25 + "\n")
            
            correlations = stats_dict['correlation_analysis']['correlations']
            for i, ch1 in enumerate(self.channel_names):
                for j, ch2 in enumerate(self.channel_names):
                    if i < j:  # Only upper triangle
                        corr = correlations[ch1][ch2]
                        f.write(f"  {ch1} - {ch2}: {corr:.3f}\n")
    
    def _generate_csv_summary(self, stats_dict: Dict[str, Any], output_path: Path):
        """Generate CSV summary of key statistics."""
        csv_path = output_path / 'channel_summary.csv'
        
        # Prepare data for CSV
        rows = []
        for channel_name in self.channel_names:
            stats = stats_dict['channel_statistics'][channel_name]
            quality = stats_dict['quality_metrics'][channel_name]
            
            row = {
                'Channel': channel_name,
                'Description': self.channel_descriptions[channel_name],
                'Mean': stats['mean'],
                'Std': stats['std'],
                'Min': stats['min'],
                'Max': stats['max'],
                'Median': stats['median'],
                'Skewness': stats['skewness'],
                'Kurtosis': stats['kurtosis'],
                'NonZeroRatio': stats['non_zero_ratio'],
                'Entropy': stats['entropy'],
                'DynamicRange': stats['dynamic_range'],
                'ContrastRatio': quality['avg_contrast_ratio'],
                'InformationContent': quality['avg_information_content'],
                'SpatialCoherence': quality['avg_spatial_coherence'],
                'MeanConsistency': stats['per_image']['mean_consistency'],
                'StdConsistency': stats['per_image']['std_consistency']
            }
            rows.append(row)
        
        # Save to CSV
        df = pd.DataFrame(rows)
        df.to_csv(csv_path, index=False, float_format='%.4f')


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Generate statistical analysis report for glass chip detection features"
    )
    
    parser.add_argument(
        '--feature_dir', required=True,
        help='Directory containing .npy feature files'
    )
    parser.add_argument(
        '--output_dir', required=True,
        help='Output directory for reports and plots'
    )
    parser.add_argument(
        '--annotations', type=str,
        help='Path to annotation file for SNR analysis'
    )
    
    args = parser.parse_args()
    
    # Validate input directory
    if not os.path.exists(args.feature_dir):
        logger.error(f"Feature directory does not exist: {args.feature_dir}")
        sys.exit(1)
    
    # Create reporter and analyze
    reporter = GlassStatisticsReporter()
    
    logger.info("Starting statistical analysis...")
    
    try:
        stats_dict = reporter.analyze_dataset(args.feature_dir, args.annotations)
        reporter.generate_report(stats_dict, args.output_dir)
        
        logger.info("Statistical analysis completed successfully")
        
    except Exception as e:
        logger.error(f"Analysis failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

