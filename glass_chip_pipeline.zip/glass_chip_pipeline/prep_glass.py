#!/usr/bin/env python3
"""
Main CLI tool for glass chip preprocessing pipeline.

This script processes a directory of glass images and generates 6-channel feature tensors
optimized for chip/check detection with maximum recall.
"""

import os
import sys
import argparse
import logging
import yaml
import csv
from pathlib import Path
from typing import Dict, Any, List, Tuple
import multiprocessing as mp
from functools import partial
import time

import cv2
import numpy as np
from tqdm import tqdm

# Import our modules
from preproc_glass import GlassPreprocessor
from features_glass import GlassFeatureExtractor

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class GlassPreprocessingPipeline:
    """
    Complete preprocessing pipeline for glass chip detection.
    
    Handles batch processing of images with multiprocessing support,
    configuration management, and comprehensive logging.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the preprocessing pipeline.
        
        Args:
            config: Configuration dictionary with all parameters
        """
        self.config = config
        self.preprocessor = GlassPreprocessor(config)
        self.feature_extractor = GlassFeatureExtractor(config)
        
        # Statistics tracking
        self.stats = {
            'processed_images': 0,
            'failed_images': 0,
            'total_processing_time': 0,
            'channel_stats': []
        }
    
    def process_directory(self, input_dir: str, output_dir: str, num_workers: int = 1) -> Dict[str, Any]:
        """
        Process all images in a directory.
        
        Args:
            input_dir: Input directory containing images
            output_dir: Output directory for processed features
            num_workers: Number of worker processes
            
        Returns:
            Processing statistics
        """
        input_path = Path(input_dir)
        output_path = Path(output_dir)
        
        # Create output directories
        output_path.mkdir(parents=True, exist_ok=True)
        (output_path / 'features').mkdir(exist_ok=True)
        (output_path / 'previews').mkdir(exist_ok=True)
        
        # Find all image files
        image_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif'}
        image_paths = []
        
        for ext in image_extensions:
            image_paths.extend(input_path.glob(f"*{ext}"))
            image_paths.extend(input_path.glob(f"*{ext.upper()}"))
        
        image_paths = sorted(image_paths)
        
        if not image_paths:
            logger.warning(f"No images found in {input_dir}")
            return self.stats
        
        logger.info(f"Found {len(image_paths)} images to process")
        
        # Save configuration
        config_path = output_path / 'config.yaml'
        with open(config_path, 'w') as f:
            yaml.dump(self.config, f, default_flow_style=False)
        logger.info(f"Configuration saved to {config_path}")
        
        # Process images
        start_time = time.time()
        
        if num_workers > 1:
            self._process_parallel(image_paths, output_path, num_workers)
        else:
            self._process_sequential(image_paths, output_path)
        
        self.stats['total_processing_time'] = time.time() - start_time
        
        # Save statistics
        self._save_statistics(output_path)
        
        # Generate summary report
        self._generate_summary_report(output_path)
        
        return self.stats
    
    def _process_sequential(self, image_paths: List[Path], output_path: Path):
        """Process images sequentially."""
        for image_path in tqdm(image_paths, desc="Processing images"):
            try:
                self._process_single_image(image_path, output_path)
                self.stats['processed_images'] += 1
            except Exception as e:
                logger.error(f"Failed to process {image_path}: {e}")
                self.stats['failed_images'] += 1
    
    def _process_parallel(self, image_paths: List[Path], output_path: Path, num_workers: int):
        """Process images in parallel."""
        process_func = partial(self._process_single_image_wrapper, output_path=output_path)
        
        with mp.Pool(num_workers) as pool:
            results = list(tqdm(
                pool.imap(process_func, image_paths),
                total=len(image_paths),
                desc="Processing images"
            ))
        
        # Aggregate results
        for success, stats in results:
            if success:
                self.stats['processed_images'] += 1
                if stats:
                    self.stats['channel_stats'].append(stats)
            else:
                self.stats['failed_images'] += 1
    
    def _process_single_image_wrapper(self, image_path: Path, output_path: Path) -> Tuple[bool, Dict[str, Any]]:
        """Wrapper for single image processing for multiprocessing."""
        try:
            stats = self._process_single_image(image_path, output_path)
            return True, stats
        except Exception as e:
            logger.error(f"Failed to process {image_path}: {e}")
            return False, {}
    
    def _process_single_image(self, image_path: Path, output_path: Path) -> Dict[str, Any]:
        """
        Process a single image through the complete pipeline.
        
        Args:
            image_path: Path to input image
            output_path: Base output directory
            
        Returns:
            Processing statistics for this image
        """
        # Load image
        image = cv2.imread(str(image_path))
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")
        
        # Convert BGR to RGB and normalize
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        
        # Preprocess image
        processed_image, preproc_metadata = self.preprocessor.preprocess_image(image)
        
        # Extract features
        features = self.feature_extractor.extract_features(processed_image)
        
        # Save features as .npy file
        feature_path = output_path / 'features' / f"{image_path.stem}.npy"
        np.save(feature_path, features)
        
        # Generate and save preview
        if self.config.get('generate_previews', True):
            preview_path = output_path / 'previews' / f"{image_path.stem}_preview.png"
            self._generate_preview(features, processed_image, preview_path)
        
        # Compute statistics
        stats = self._compute_image_statistics(image_path.name, features, preproc_metadata)
        
        return stats
    
    def _generate_preview(self, features: np.ndarray, processed_image: np.ndarray, preview_path: Path):
        """Generate a preview image showing all channels."""
        # Create 2x3 grid showing all 6 channels plus original
        fig_height, fig_width = 800, 1200
        preview = np.zeros((fig_height, fig_width, 3), dtype=np.uint8)
        
        # Channel names
        channel_names = ['L_CLAHE', 'DoG_s2_4', 'DoG_s4_8', 'Entropy11', 'EdgeBandMask', 'ConcavityMap']
        
        # Grid layout: 2 rows, 3 columns
        cell_height = fig_height // 2
        cell_width = fig_width // 3
        
        for i in range(6):
            row = i // 3
            col = i % 3
            
            # Extract and normalize channel
            channel = features[:, :, i]
            channel_uint8 = (channel * 255).astype(np.uint8)
            
            # Resize to fit cell
            channel_resized = cv2.resize(channel_uint8, (cell_width - 20, cell_height - 40))
            
            # Convert to RGB
            if len(channel_resized.shape) == 2:
                channel_rgb = cv2.cvtColor(channel_resized, cv2.COLOR_GRAY2RGB)
            else:
                channel_rgb = channel_resized
            
            # Place in grid
            y_start = row * cell_height + 20
            y_end = y_start + channel_resized.shape[0]
            x_start = col * cell_width + 10
            x_end = x_start + channel_resized.shape[1]
            
            preview[y_start:y_end, x_start:x_end] = channel_rgb
            
            # Add title
            cv2.putText(
                preview, channel_names[i],
                (x_start, y_start - 5),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1
            )
        
        # Save preview
        cv2.imwrite(str(preview_path), cv2.cvtColor(preview, cv2.COLOR_RGB2BGR))
    
    def _compute_image_statistics(self, image_name: str, features: np.ndarray, 
                                metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Compute statistics for a single image."""
        channel_names = ['L_CLAHE', 'DoG_s2_4', 'DoG_s4_8', 'Entropy11', 'EdgeBandMask', 'ConcavityMap']
        
        stats = {
            'image_name': image_name,
            'shape': features.shape,
            'preprocessing_metadata': metadata
        }
        
        for i, name in enumerate(channel_names):
            channel = features[:, :, i]
            stats[f'{name}_mean'] = float(np.mean(channel))
            stats[f'{name}_std'] = float(np.std(channel))
            stats[f'{name}_min'] = float(np.min(channel))
            stats[f'{name}_max'] = float(np.max(channel))
            stats[f'{name}_nonzero_ratio'] = float(np.mean(channel > 0))
        
        return stats
    
    def _save_statistics(self, output_path: Path):
        """Save processing statistics to CSV."""
        if not self.stats['channel_stats']:
            return
        
        csv_path = output_path / 'processing_stats.csv'
        
        # Get all field names from the first entry
        fieldnames = list(self.stats['channel_stats'][0].keys())
        
        with open(csv_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(self.stats['channel_stats'])
        
        logger.info(f"Statistics saved to {csv_path}")
    
    def _generate_summary_report(self, output_path: Path):
        """Generate a summary report."""
        report_path = output_path / 'summary_report.txt'
        
        with open(report_path, 'w') as f:
            f.write("Glass Chip Preprocessing Pipeline - Summary Report\n")
            f.write("=" * 60 + "\n\n")
            
            f.write(f"Total images processed: {self.stats['processed_images']}\n")
            f.write(f"Failed images: {self.stats['failed_images']}\n")
            f.write(f"Total processing time: {self.stats['total_processing_time']:.2f} seconds\n")
            
            if self.stats['processed_images'] > 0:
                avg_time = self.stats['total_processing_time'] / self.stats['processed_images']
                f.write(f"Average time per image: {avg_time:.2f} seconds\n")
            
            f.write("\nConfiguration:\n")
            f.write("-" * 20 + "\n")
            for key, value in self.config.items():
                f.write(f"{key}: {value}\n")
            
            # Channel statistics summary
            if self.stats['channel_stats']:
                f.write("\nChannel Statistics Summary:\n")
                f.write("-" * 30 + "\n")
                
                channel_names = ['L_CLAHE', 'DoG_s2_4', 'DoG_s4_8', 'Entropy11', 'EdgeBandMask', 'ConcavityMap']
                
                for channel in channel_names:
                    means = [stat[f'{channel}_mean'] for stat in self.stats['channel_stats']]
                    stds = [stat[f'{channel}_std'] for stat in self.stats['channel_stats']]
                    nonzero_ratios = [stat[f'{channel}_nonzero_ratio'] for stat in self.stats['channel_stats']]
                    
                    f.write(f"\n{channel}:\n")
                    f.write(f"  Mean value: {np.mean(means):.4f} ± {np.std(means):.4f}\n")
                    f.write(f"  Std deviation: {np.mean(stds):.4f} ± {np.std(stds):.4f}\n")
                    f.write(f"  Non-zero ratio: {np.mean(nonzero_ratios):.4f} ± {np.std(nonzero_ratios):.4f}\n")
        
        logger.info(f"Summary report saved to {report_path}")


def create_default_config() -> Dict[str, Any]:
    """Create default configuration."""
    return {
        # Preprocessing parameters
        'pose_normalize': True,
        'illumination_method': 'divide',
        'texture_suppress': True,
        'retinex_sigma': 60,
        'margin_px': 10,
        'min_part_area': 1000,
        
        # Feature extraction parameters
        'clahe_clip_limit': 3.0,
        'clahe_tile_grid_size': [40, 40],
        'dog_sigmas': [[2, 4], [4, 8]],
        'entropy_window_size': 11,
        'edge_band_width': 25,
        'concavity_smooth_sigma': 5,
        
        # Output parameters
        'generate_previews': True,
        'save_intermediate': False
    }


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Glass chip preprocessing pipeline",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    # Required arguments
    parser.add_argument(
        '--input_dir', required=True,
        help='Input directory containing images'
    )
    parser.add_argument(
        '--output_dir', required=True,
        help='Output directory for processed features'
    )
    
    # Preprocessing parameters
    parser.add_argument(
        '--band_px', type=int, default=25,
        help='Edge band width in pixels'
    )
    parser.add_argument(
        '--clahe_clip', type=float, default=3.0,
        help='CLAHE clip limit'
    )
    parser.add_argument(
        '--clahe_grid', type=int, default=40,
        help='CLAHE tile grid size'
    )
    parser.add_argument(
        '--retinex_sigma', type=float, default=60,
        help='Retinex Gaussian sigma'
    )
    parser.add_argument(
        '--dog_sigmas', nargs=4, type=float, default=[2, 4, 4, 8],
        help='DoG sigma values: sigma1_1 sigma2_1 sigma1_2 sigma2_2'
    )
    parser.add_argument(
        '--entropy_win', type=int, default=11,
        help='Entropy window size'
    )
    
    # Processing options
    parser.add_argument(
        '--texture_suppress', choices=['on', 'off'], default='on',
        help='Enable/disable texture suppression'
    )
    parser.add_argument(
        '--pose_normalize', choices=['on', 'off'], default='on',
        help='Enable/disable pose normalization'
    )
    parser.add_argument(
        '--num_workers', type=int, default=8,
        help='Number of worker processes'
    )
    parser.add_argument(
        '--no_previews', action='store_true',
        help='Disable preview generation'
    )
    
    # Configuration file
    parser.add_argument(
        '--config', type=str,
        help='Path to configuration YAML file'
    )
    
    return parser.parse_args()


def main():
    """Main entry point."""
    args = parse_arguments()
    
    # Create configuration
    if args.config and os.path.exists(args.config):
        with open(args.config, 'r') as f:
            config = yaml.safe_load(f)
        logger.info(f"Loaded configuration from {args.config}")
    else:
        config = create_default_config()
    
    # Override config with command line arguments
    config.update({
        'edge_band_width': args.band_px,
        'clahe_clip_limit': args.clahe_clip,
        'clahe_tile_grid_size': [args.clahe_grid, args.clahe_grid],
        'retinex_sigma': args.retinex_sigma,
        'dog_sigmas': [[args.dog_sigmas[0], args.dog_sigmas[1]], 
                       [args.dog_sigmas[2], args.dog_sigmas[3]]],
        'entropy_window_size': args.entropy_win,
        'texture_suppress': args.texture_suppress == 'on',
        'pose_normalize': args.pose_normalize == 'on',
        'generate_previews': not args.no_previews
    })
    
    # Validate input directory
    if not os.path.exists(args.input_dir):
        logger.error(f"Input directory does not exist: {args.input_dir}")
        sys.exit(1)
    
    # Create pipeline and process
    pipeline = GlassPreprocessingPipeline(config)
    
    logger.info("Starting glass chip preprocessing pipeline")
    logger.info(f"Input directory: {args.input_dir}")
    logger.info(f"Output directory: {args.output_dir}")
    logger.info(f"Number of workers: {args.num_workers}")
    
    try:
        stats = pipeline.process_directory(
            args.input_dir, 
            args.output_dir, 
            args.num_workers
        )
        
        logger.info("Processing completed successfully")
        logger.info(f"Processed: {stats['processed_images']} images")
        logger.info(f"Failed: {stats['failed_images']} images")
        logger.info(f"Total time: {stats['total_processing_time']:.2f} seconds")
        
    except Exception as e:
        logger.error(f"Processing failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

