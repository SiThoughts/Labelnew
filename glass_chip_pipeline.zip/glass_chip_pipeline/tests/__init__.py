# Test package for glass chip detection pipeline

