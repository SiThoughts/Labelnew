"""
Augmentation module for glass chip detection with defect-preserving transformations.

This module implements data augmentations specifically designed to preserve
defect characteristics while providing variation for robust model training.
"""

import cv2
import numpy as np
from typing import Tuple, Dict, Any, Optional, List
import logging
import albumentations as A
from albumentations.pytorch import ToTensorV2
import torch

logger = logging.getLogger(__name__)


class GlassDefectAugmentations:
    """
    Augmentation pipeline specifically designed for glass defect detection.
    
    Focuses on preserving defect characteristics while providing sufficient
    variation for robust model training.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize augmentation pipeline.
        
        Args:
            config: Configuration dictionary for augmentation parameters
        """
        self.config = config or self._default_config()
        self.transform = self._create_transform_pipeline()
        
    def _default_config(self) -> Dict[str, Any]:
        """Default augmentation configuration."""
        return {
            # Geometric augmentations
            'horizontal_flip_prob': 0.5,
            'vertical_flip_prob': 0.5,
            'rotation_limit': 5,  # Small rotations to preserve edge characteristics
            'rotation_prob': 0.3,
            
            # Photometric augmentations (applied to L_CLAHE channel)
            'brightness_limit': 0.15,
            'contrast_limit': 0.15,
            'brightness_contrast_prob': 0.3,
            
            # Noise and blur (minimal to preserve defect details)
            'blur_limit': (1, 3),
            'blur_prob': 0.2,
            'noise_var_limit': (0.0, 0.01),
            'noise_prob': 0.1,
            
            # Elastic deformation (very mild)
            'elastic_alpha': 1,
            'elastic_sigma': 50,
            'elastic_prob': 0.1,
            
            # Channel-specific augmentations
            'channel_shuffle_prob': 0.1,
            'channel_dropout_prob': 0.05,
            
            # Test-time augmentation
            'tta_scales': [0.8, 1.0, 1.2],
            'tta_flips': [False, True],
        }
    
    def _create_transform_pipeline(self) -> A.Compose:
        """Create the main augmentation pipeline."""
        transforms = []
        
        # Geometric transformations
        if self.config['horizontal_flip_prob'] > 0:
            transforms.append(A.HorizontalFlip(p=self.config['horizontal_flip_prob']))
        
        if self.config['vertical_flip_prob'] > 0:
            transforms.append(A.VerticalFlip(p=self.config['vertical_flip_prob']))
        
        if self.config['rotation_prob'] > 0:
            transforms.append(A.Rotate(
                limit=self.config['rotation_limit'],
                p=self.config['rotation_prob'],
                border_mode=cv2.BORDER_REFLECT,
                interpolation=cv2.INTER_CUBIC
            ))
        
        # Photometric transformations (mild to preserve defect contrast)
        if self.config['brightness_contrast_prob'] > 0:
            transforms.append(A.RandomBrightnessContrast(
                brightness_limit=self.config['brightness_limit'],
                contrast_limit=self.config['contrast_limit'],
                p=self.config['brightness_contrast_prob']
            ))
        
        # Mild blur (preserve defect edges)
        if self.config['blur_prob'] > 0:
            transforms.append(A.GaussianBlur(
                blur_limit=self.config['blur_limit'],
                p=self.config['blur_prob']
            ))
        
        # Very mild elastic deformation
        if self.config['elastic_prob'] > 0:
            transforms.append(A.ElasticTransform(
                alpha=self.config['elastic_alpha'],
                sigma=self.config['elastic_sigma'],
                alpha_affine=0,  # No affine component
                p=self.config['elastic_prob'],
                border_mode=cv2.BORDER_REFLECT
            ))
        
        return A.Compose(
            transforms,
            bbox_params=A.BboxParams(
                format='coco',
                label_fields=['class_labels'],
                min_visibility=0.3
            ),
            additional_targets={f'mask_{i}': 'mask' for i in range(10)}  # Support up to 10 masks
        )
    
    def augment_features(self, features: np.ndarray, 
                        masks: Optional[np.ndarray] = None,
                        bboxes: Optional[np.ndarray] = None,
                        labels: Optional[np.ndarray] = None) -> Tuple[np.ndarray, Optional[np.ndarray], Optional[np.ndarray], Optional[np.ndarray]]:
        """
        Apply augmentations to 6-channel features and annotations.
        
        Args:
            features: 6-channel feature array (H, W, 6)
            masks: Binary masks (N, H, W)
            bboxes: Bounding boxes (N, 4) in COCO format
            labels: Class labels (N,)
            
        Returns:
            Tuple of (augmented_features, augmented_masks, augmented_bboxes, augmented_labels)
        """
        try:
            # Use L_CLAHE channel (first channel) as the primary image for augmentation
            primary_image = features[:, :, 0]
            
            # Prepare augmentation data
            aug_data = {
                'image': primary_image,
                'bboxes': bboxes.tolist() if bboxes is not None else [],
                'class_labels': labels.tolist() if labels is not None else []
            }
            
            # Add masks as additional targets
            if masks is not None:
                for i, mask in enumerate(masks):
                    aug_data[f'mask_{i}'] = mask
            
            # Apply augmentations
            augmented = self.transform(**aug_data)
            
            # Extract augmented primary image
            aug_primary = augmented['image']
            
            # Apply the same geometric transformation to all channels
            aug_features = self._apply_geometric_to_all_channels(
                features, primary_image, aug_primary
            )
            
            # Apply channel-specific augmentations
            aug_features = self._apply_channel_specific_augmentations(aug_features)
            
            # Extract augmented annotations
            aug_bboxes = np.array(augmented['bboxes']) if augmented['bboxes'] else bboxes
            aug_labels = np.array(augmented['class_labels']) if augmented['class_labels'] else labels
            
            # Extract augmented masks
            aug_masks = None
            if masks is not None:
                aug_masks = []
                for i in range(len(masks)):
                    if f'mask_{i}' in augmented:
                        aug_masks.append(augmented[f'mask_{i}'])
                    else:
                        aug_masks.append(masks[i])  # Fallback to original
                aug_masks = np.stack(aug_masks, axis=0)
            
            return aug_features, aug_masks, aug_bboxes, aug_labels
            
        except Exception as e:
            logger.warning(f"Augmentation failed: {e}, returning original data")
            return features, masks, bboxes, labels
    
    def _apply_geometric_to_all_channels(self, features: np.ndarray, 
                                       original_primary: np.ndarray,
                                       augmented_primary: np.ndarray) -> np.ndarray:
        """
        Apply the same geometric transformation to all feature channels.
        
        This is a simplified approach that assumes the transformation can be
        estimated from the change in the primary channel.
        """
        aug_features = features.copy()
        aug_features[:, :, 0] = augmented_primary
        
        # For other channels, we need to apply the same transformation
        # This is a simplified approach - in practice, you might want to
        # extract the transformation matrix and apply it directly
        
        # Check if the image was flipped or rotated by comparing shapes and content
        if features.shape[:2] == augmented_primary.shape:
            # Same shape, likely flip or small rotation
            # Apply the same transformation to other channels
            for i in range(1, features.shape[2]):
                # Use the same transformation pipeline on each channel
                try:
                    # This is a simplified approach - you might want to implement
                    # more sophisticated transformation tracking
                    channel_data = {'image': features[:, :, i]}
                    aug_channel = self.transform(**channel_data)
                    aug_features[:, :, i] = aug_channel['image']
                except:
                    # Fallback: keep original channel
                    aug_features[:, :, i] = features[:, :, i]
        
        return aug_features
    
    def _apply_channel_specific_augmentations(self, features: np.ndarray) -> np.ndarray:
        """Apply channel-specific augmentations."""
        aug_features = features.copy()
        
        # Channel dropout (randomly zero out a channel)
        if np.random.random() < self.config['channel_dropout_prob']:
            # Don't drop the L_CLAHE channel (most important)
            channel_to_drop = np.random.randint(1, features.shape[2])
            aug_features[:, :, channel_to_drop] = 0
        
        # Channel shuffle (swap similar channels)
        if np.random.random() < self.config['channel_shuffle_prob']:
            # Swap DoG channels (1 and 2) or keep them as is
            if np.random.random() < 0.5:
                aug_features[:, :, [1, 2]] = aug_features[:, :, [2, 1]]
        
        # Add mild noise to some channels (preserve defect channels)
        if self.config['noise_prob'] > 0:
            for i in [1, 2, 3]:  # DoG and Entropy channels
                if np.random.random() < self.config['noise_prob']:
                    noise_var = np.random.uniform(0, self.config['noise_var_limit'][1])
                    noise = np.random.normal(0, noise_var, aug_features[:, :, i].shape)
                    aug_features[:, :, i] = np.clip(
                        aug_features[:, :, i] + noise, 0, 1
                    )
        
        return aug_features
    
    def create_tta_variants(self, features: np.ndarray) -> List[np.ndarray]:
        """
        Create test-time augmentation variants.
        
        Args:
            features: Original 6-channel features (H, W, 6)
            
        Returns:
            List of augmented feature variants
        """
        variants = [features]  # Include original
        
        # Scale variants
        for scale in self.config['tta_scales']:
            if scale != 1.0:
                h, w = features.shape[:2]
                new_h, new_w = int(h * scale), int(w * scale)
                
                scaled_features = np.zeros((new_h, new_w, 6), dtype=features.dtype)
                for i in range(6):
                    scaled_features[:, :, i] = cv2.resize(
                        features[:, :, i], (new_w, new_h), 
                        interpolation=cv2.INTER_CUBIC
                    )
                variants.append(scaled_features)
        
        # Flip variants
        for flip in self.config['tta_flips']:
            if flip:
                flipped_features = np.flip(features, axis=1).copy()
                variants.append(flipped_features)
        
        return variants
    
    def merge_tta_predictions(self, predictions: List[Dict[str, Any]], 
                            original_shape: Tuple[int, int]) -> Dict[str, Any]:
        """
        Merge predictions from test-time augmentation variants.
        
        Args:
            predictions: List of prediction dictionaries from different variants
            original_shape: Original image shape (H, W)
            
        Returns:
            Merged prediction dictionary
        """
        if not predictions:
            return {}
        
        # Simple approach: take union of all detections and apply NMS
        all_boxes = []
        all_scores = []
        all_labels = []
        
        for pred in predictions:
            if 'boxes' in pred and len(pred['boxes']) > 0:
                # Scale boxes back to original size if needed
                boxes = pred['boxes'].copy()
                # Add scaling logic here if needed
                
                all_boxes.append(boxes)
                all_scores.append(pred.get('scores', np.ones(len(boxes))))
                all_labels.append(pred.get('labels', np.zeros(len(boxes))))
        
        if all_boxes:
            all_boxes = np.vstack(all_boxes)
            all_scores = np.concatenate(all_scores)
            all_labels = np.concatenate(all_labels)
            
            # Apply NMS to remove duplicates
            keep_indices = self._apply_nms(all_boxes, all_scores, iou_threshold=0.5)
            
            return {
                'boxes': all_boxes[keep_indices],
                'scores': all_scores[keep_indices],
                'labels': all_labels[keep_indices]
            }
        
        return {}
    
    def _apply_nms(self, boxes: np.ndarray, scores: np.ndarray, 
                   iou_threshold: float = 0.5) -> np.ndarray:
        """Apply Non-Maximum Suppression."""
        if len(boxes) == 0:
            return np.array([], dtype=int)
        
        # Convert to format expected by cv2.dnn.NMSBoxes
        boxes_list = [box.tolist() for box in boxes]
        scores_list = scores.tolist()
        
        indices = cv2.dnn.NMSBoxes(
            boxes_list, scores_list, 
            score_threshold=0.1, 
            nms_threshold=iou_threshold
        )
        
        if len(indices) > 0:
            return indices.flatten()
        else:
            return np.array([], dtype=int)


class DefectPreservingAugmentations:
    """
    Specialized augmentations that preserve defect characteristics.
    
    This class implements augmentations specifically designed to maintain
    the visual characteristics of chips and checks while providing variation.
    """
    
    def __init__(self):
        """Initialize defect-preserving augmentations."""
        pass
    
    def preserve_edge_contrast(self, features: np.ndarray, 
                             edge_mask: np.ndarray) -> np.ndarray:
        """
        Apply augmentations while preserving edge contrast in defect regions.
        
        Args:
            features: 6-channel features
            edge_mask: Binary mask of edge regions
            
        Returns:
            Augmented features with preserved edge contrast
        """
        aug_features = features.copy()
        
        # Apply stronger contrast enhancement in edge regions
        edge_regions = edge_mask > 0
        
        if np.any(edge_regions):
            # Enhance contrast in L_CLAHE channel within edge regions
            l_channel = aug_features[:, :, 0]
            edge_pixels = l_channel[edge_regions]
            
            if len(edge_pixels) > 0:
                # Apply histogram equalization to edge regions
                edge_pixels_uint8 = (edge_pixels * 255).astype(np.uint8)
                eq_pixels = cv2.equalizeHist(edge_pixels_uint8.reshape(-1, 1))
                eq_pixels = eq_pixels.flatten().astype(np.float32) / 255.0
                
                # Blend with original
                alpha = 0.3
                l_channel[edge_regions] = (
                    alpha * eq_pixels + (1 - alpha) * edge_pixels
                )
                
                aug_features[:, :, 0] = l_channel
        
        return aug_features
    
    def enhance_defect_visibility(self, features: np.ndarray,
                                defect_masks: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Enhance defect visibility through targeted augmentations.
        
        Args:
            features: 6-channel features
            defect_masks: Binary masks of known defects
            
        Returns:
            Features with enhanced defect visibility
        """
        aug_features = features.copy()
        
        if defect_masks is not None and len(defect_masks) > 0:
            # Combine all defect masks
            combined_mask = np.any(defect_masks, axis=0)
            
            # Enhance DoG responses in defect regions
            for dog_channel in [1, 2]:  # DoG channels
                channel = aug_features[:, :, dog_channel]
                defect_pixels = channel[combined_mask]
                
                if len(defect_pixels) > 0:
                    # Amplify DoG response in defect regions
                    amplification = 1.2
                    channel[combined_mask] = np.clip(
                        defect_pixels * amplification, 0, 1
                    )
                    aug_features[:, :, dog_channel] = channel
        
        return aug_features


def create_augmentation_pipeline(config: Optional[Dict[str, Any]] = None) -> GlassDefectAugmentations:
    """
    Create a complete augmentation pipeline for glass defect detection.
    
    Args:
        config: Optional configuration dictionary
        
    Returns:
        Configured augmentation pipeline
    """
    return GlassDefectAugmentations(config)


if __name__ == "__main__":
    # Example usage and testing
    import sys
    
    # Create test data
    test_features = np.random.rand(256, 256, 6).astype(np.float32)
    test_masks = np.random.randint(0, 2, (2, 256, 256)).astype(np.uint8)
    test_bboxes = np.array([[10, 10, 50, 50], [100, 100, 30, 30]], dtype=np.float32)
    test_labels = np.array([0, 0], dtype=int)
    
    # Create augmentation pipeline
    aug_pipeline = create_augmentation_pipeline()
    
    # Test augmentation
    aug_features, aug_masks, aug_bboxes, aug_labels = aug_pipeline.augment_features(
        test_features, test_masks, test_bboxes, test_labels
    )
    
    print("Augmentation test completed:")
    print(f"Original features shape: {test_features.shape}")
    print(f"Augmented features shape: {aug_features.shape}")
    print(f"Original masks shape: {test_masks.shape}")
    print(f"Augmented masks shape: {aug_masks.shape if aug_masks is not None else None}")
    print(f"Original bboxes: {test_bboxes}")
    print(f"Augmented bboxes: {aug_bboxes}")
    
    # Test TTA
    tta_variants = aug_pipeline.create_tta_variants(test_features)
    print(f"Created {len(tta_variants)} TTA variants")
    
    print("All tests passed!")

