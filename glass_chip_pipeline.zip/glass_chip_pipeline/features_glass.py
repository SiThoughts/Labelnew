"""
Glass feature extraction module implementing 6-channel feature maps for chip/check detection.

This module generates specialized feature channels that highlight defects while suppressing
background textures, incorporating classical computer vision techniques optimized for
maximum recall in glass defect detection.
"""

import cv2
import numpy as np
from typing import Tuple, Dict, Any, Optional
import logging
from scipy import ndimage, interpolate
from skimage import filters, morphology, measure, feature
from skimage.filters.rank import entropy
from skimage.morphology import disk
import warnings

warnings.filterwarnings('ignore', category=UserWarning)

logger = logging.getLogger(__name__)


class GlassFeatureExtractor:
    """
    Feature extractor for glass chip detection implementing 6 specialized channels.
    
    Channels:
    1. L_CLAHE - Enhanced L channel with CLAHE and Retinex
    2. DoG_s2_4 - Difference of Gaussians (σ1=2, σ2=4)
    3. DoG_s4_8 - Difference of Gaussians (σ1=4, σ2=8)
    4. Entropy11 - Local entropy (11x11 window)
    5. EdgeBandMask - Binary mask for edge band region
    6. ConcavityMap - Edge deviation/concavity detection
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize feature extractor with configuration.
        
        Args:
            config: Dictionary containing feature extraction parameters
        """
        self.config = config or self._default_config()
        
    def _default_config(self) -> Dict[str, Any]:
        """Default configuration parameters."""
        return {
            'clahe_clip_limit': 3.0,
            'clahe_tile_grid_size': (40, 40),
            'retinex_sigma': 60,
            'dog_sigmas': [(2, 4), (4, 8)],
            'entropy_window_size': 11,
            'edge_band_width': 25,
            'edge_band_min_width': 15,
            'edge_band_max_width': 30,
            'concavity_smooth_sigma': 5,
            'concavity_spline_points': 100,
            'min_contour_area': 1000,
            'canny_low': 50,
            'canny_high': 150
        }
    
    def extract_features(self, image: np.ndarray, part_mask: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Extract all 6 feature channels from preprocessed image.
        
        Args:
            image: Preprocessed RGB image [0,1] float32
            part_mask: Optional binary mask of the part region
            
        Returns:
            Feature tensor of shape (H, W, 6) with channels in order:
            [L_CLAHE, DoG_s2_4, DoG_s4_8, Entropy11, EdgeBandMask, ConcavityMap]
        """
        h, w = image.shape[:2]
        features = np.zeros((h, w, 6), dtype=np.float32)
        
        # Convert to Lab and extract L channel
        lab_image = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)
        l_channel = lab_image[:, :, 0] / 100.0  # Normalize to [0,1]
        
        # If no part mask provided, create one using simple thresholding
        if part_mask is None:
            part_mask = self._create_simple_mask(l_channel)
        
        # Channel 1: L_CLAHE
        features[:, :, 0] = self._compute_l_clahe(l_channel)
        
        # Channel 2: DoG_s2_4
        features[:, :, 1] = self._compute_dog(features[:, :, 0], self.config['dog_sigmas'][0])
        
        # Channel 3: DoG_s4_8
        features[:, :, 2] = self._compute_dog(features[:, :, 0], self.config['dog_sigmas'][1])
        
        # Channel 4: Entropy11
        features[:, :, 3] = self._compute_local_entropy(features[:, :, 0])
        
        # Channel 5: EdgeBandMask
        features[:, :, 4] = self._compute_edge_band_mask(l_channel, part_mask)
        
        # Channel 6: ConcavityMap
        features[:, :, 5] = self._compute_concavity_map(l_channel, part_mask)
        
        return features
    
    def _create_simple_mask(self, l_channel: np.ndarray) -> np.ndarray:
        """Create a simple part mask if none provided."""
        # Convert to uint8
        l_uint8 = (l_channel * 255).astype(np.uint8)
        
        # Apply Otsu thresholding
        _, binary = cv2.threshold(l_uint8, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        # Clean up with morphological operations
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
        
        return binary.astype(bool)
    
    def _compute_l_clahe(self, l_channel: np.ndarray) -> np.ndarray:
        """
        Compute enhanced L channel with CLAHE and Retinex normalization.
        
        Args:
            l_channel: L channel from Lab [0,1]
            
        Returns:
            Enhanced L channel [0,1]
        """
        # Convert to uint8 for CLAHE
        l_uint8 = (l_channel * 255).astype(np.uint8)
        
        # Apply CLAHE
        clahe = cv2.createCLAHE(
            clipLimit=self.config['clahe_clip_limit'],
            tileGridSize=self.config['clahe_tile_grid_size']
        )
        l_clahe = clahe.apply(l_uint8)
        
        # Convert back to float
        l_clahe = l_clahe.astype(np.float32) / 255.0
        
        # Apply Retinex-lite normalization
        sigma = self.config['retinex_sigma']
        background = cv2.GaussianBlur(l_clahe, (0, 0), sigma)
        
        # Divide by background with small epsilon to avoid division by zero
        retinex = l_clahe / (background + 1e-6)
        
        # Normalize to [0,1]
        retinex = self._normalize_to_01(retinex)
        
        return retinex
    
    def _compute_dog(self, image: np.ndarray, sigmas: Tuple[float, float]) -> np.ndarray:
        """
        Compute Difference of Gaussians.
        
        Args:
            image: Input image [0,1]
            sigmas: Tuple of (sigma1, sigma2) for Gaussian kernels
            
        Returns:
            DoG response [0,1]
        """
        sigma1, sigma2 = sigmas
        
        # Apply Gaussian blurs
        blur1 = cv2.GaussianBlur(image, (0, 0), sigma1)
        blur2 = cv2.GaussianBlur(image, (0, 0), sigma2)
        
        # Compute difference and take absolute value
        dog = np.abs(blur1 - blur2)
        
        # Normalize to [0,1]
        dog = self._normalize_to_01(dog)
        
        return dog
    
    def _compute_local_entropy(self, image: np.ndarray) -> np.ndarray:
        """
        Compute local entropy using sliding window.
        
        Args:
            image: Input image [0,1]
            
        Returns:
            Local entropy map [0,1]
        """
        # Convert to uint8 for entropy calculation
        image_uint8 = (image * 255).astype(np.uint8)
        
        # Create disk-shaped structuring element
        window_size = self.config['entropy_window_size']
        selem = disk(window_size // 2)
        
        # Compute local entropy
        try:
            entropy_map = entropy(image_uint8, selem)
            entropy_map = entropy_map.astype(np.float32)
        except Exception as e:
            logger.warning(f"Entropy calculation failed: {e}, using fallback")
            # Fallback: use local standard deviation as proxy for entropy
            entropy_map = self._compute_local_std(image, window_size)
        
        # Normalize to [0,1]
        entropy_map = self._normalize_to_01(entropy_map)
        
        return entropy_map
    
    def _compute_local_std(self, image: np.ndarray, window_size: int) -> np.ndarray:
        """Fallback local standard deviation calculation."""
        kernel = np.ones((window_size, window_size)) / (window_size * window_size)
        
        # Compute local mean and mean of squares
        local_mean = cv2.filter2D(image, -1, kernel)
        local_mean_sq = cv2.filter2D(image * image, -1, kernel)
        
        # Compute local variance and standard deviation
        local_var = local_mean_sq - local_mean * local_mean
        local_std = np.sqrt(np.maximum(local_var, 0))
        
        return local_std
    
    def _compute_edge_band_mask(self, l_channel: np.ndarray, part_mask: np.ndarray) -> np.ndarray:
        """
        Compute binary mask for edge band region.
        
        Args:
            l_channel: L channel [0,1]
            part_mask: Binary mask of the part
            
        Returns:
            Binary edge band mask [0,1]
        """
        try:
            # Find contours of the part
            part_uint8 = (part_mask * 255).astype(np.uint8)
            contours, _ = cv2.findContours(part_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            if not contours:
                logger.warning("No contours found for edge band mask")
                return np.zeros_like(l_channel)
            
            # Select largest contour
            largest_contour = max(contours, key=cv2.contourArea)
            
            if cv2.contourArea(largest_contour) < self.config['min_contour_area']:
                logger.warning("Contour too small for edge band mask")
                return np.zeros_like(l_channel)
            
            # Compute distance transform
            distance_map = cv2.distanceTransform(part_uint8, cv2.DIST_L2, 5)
            
            # Create edge band mask
            band_width = self.config['edge_band_width']
            edge_band = (distance_map > 0) & (distance_map <= band_width)
            
            return edge_band.astype(np.float32)
            
        except Exception as e:
            logger.warning(f"Edge band mask computation failed: {e}")
            return np.zeros_like(l_channel)
    
    def _compute_concavity_map(self, l_channel: np.ndarray, part_mask: np.ndarray) -> np.ndarray:
        """
        Compute concavity map showing edge deviations from smooth reference.
        
        Args:
            l_channel: L channel [0,1]
            part_mask: Binary mask of the part
            
        Returns:
            Concavity map [0,1] where higher values indicate concave defects
        """
        try:
            # Find contours
            part_uint8 = (part_mask * 255).astype(np.uint8)
            contours, _ = cv2.findContours(part_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            if not contours:
                return np.zeros_like(l_channel)
            
            # Select largest contour
            largest_contour = max(contours, key=cv2.contourArea)
            
            if cv2.contourArea(largest_contour) < self.config['min_contour_area']:
                return np.zeros_like(l_channel)
            
            # Extract contour points
            contour_points = largest_contour.reshape(-1, 2)
            
            # Create smooth reference contour using spline fitting
            smooth_contour = self._fit_smooth_contour(contour_points)
            
            # Compute signed distance from actual contour to smooth reference
            concavity_map = self._compute_contour_deviation(
                l_channel.shape, contour_points, smooth_contour
            )
            
            # Keep only negative deviations (concave regions) and normalize
            concavity_map = np.maximum(-concavity_map, 0)
            concavity_map = self._normalize_to_01(concavity_map)
            
            return concavity_map
            
        except Exception as e:
            logger.warning(f"Concavity map computation failed: {e}")
            return np.zeros_like(l_channel)
    
    def _fit_smooth_contour(self, contour_points: np.ndarray) -> np.ndarray:
        """
        Fit a smooth spline to contour points.
        
        Args:
            contour_points: Array of contour points (N, 2)
            
        Returns:
            Smooth contour points
        """
        if len(contour_points) < 4:
            return contour_points
        
        try:
            # Parameterize contour by arc length
            distances = np.sqrt(np.sum(np.diff(contour_points, axis=0)**2, axis=1))
            cumulative_distances = np.concatenate([[0], np.cumsum(distances)])
            
            # Normalize to [0, 1]
            if cumulative_distances[-1] > 0:
                t = cumulative_distances / cumulative_distances[-1]
            else:
                t = np.linspace(0, 1, len(contour_points))
            
            # Fit splines to x and y coordinates
            spline_x = interpolate.UnivariateSpline(t, contour_points[:, 0], 
                                                  s=self.config['concavity_smooth_sigma'])
            spline_y = interpolate.UnivariateSpline(t, contour_points[:, 1], 
                                                  s=self.config['concavity_smooth_sigma'])
            
            # Generate smooth contour points
            t_smooth = np.linspace(0, 1, self.config['concavity_spline_points'])
            smooth_x = spline_x(t_smooth)
            smooth_y = spline_y(t_smooth)
            
            smooth_contour = np.column_stack([smooth_x, smooth_y])
            
            return smooth_contour
            
        except Exception as e:
            logger.warning(f"Spline fitting failed: {e}, using original contour")
            return contour_points
    
    def _compute_contour_deviation(self, image_shape: Tuple[int, int], 
                                 actual_contour: np.ndarray, 
                                 smooth_contour: np.ndarray) -> np.ndarray:
        """
        Compute signed deviation map from actual to smooth contour.
        
        Args:
            image_shape: Shape of the output image (H, W)
            actual_contour: Actual contour points
            smooth_contour: Smooth reference contour points
            
        Returns:
            Signed deviation map
        """
        h, w = image_shape
        deviation_map = np.zeros((h, w), dtype=np.float32)
        
        # Create masks for actual and smooth contours
        actual_mask = np.zeros((h, w), dtype=np.uint8)
        smooth_mask = np.zeros((h, w), dtype=np.uint8)
        
        # Draw contours
        cv2.fillPoly(actual_mask, [actual_contour.astype(np.int32)], 255)
        cv2.fillPoly(smooth_mask, [smooth_contour.astype(np.int32)], 255)
        
        # Compute distance transforms
        actual_dist = cv2.distanceTransform(255 - actual_mask, cv2.DIST_L2, 5)
        smooth_dist = cv2.distanceTransform(255 - smooth_mask, cv2.DIST_L2, 5)
        
        # Compute signed deviation (negative = concave, positive = convex)
        deviation_map = smooth_dist - actual_dist
        
        # Apply Gaussian smoothing to reduce noise
        deviation_map = cv2.GaussianBlur(deviation_map, (5, 5), 1.0)
        
        return deviation_map
    
    def _normalize_to_01(self, image: np.ndarray) -> np.ndarray:
        """
        Normalize image to [0,1] range using min-max normalization.
        
        Args:
            image: Input image
            
        Returns:
            Normalized image [0,1]
        """
        min_val = np.min(image)
        max_val = np.max(image)
        
        if max_val > min_val:
            normalized = (image - min_val) / (max_val - min_val)
        else:
            normalized = np.zeros_like(image)
        
        return np.clip(normalized, 0, 1)


def extract_features_from_image(image_path: str, config: Optional[Dict[str, Any]] = None) -> np.ndarray:
    """
    Convenience function to extract features from a single image file.
    
    Args:
        image_path: Path to input image
        config: Optional configuration dictionary
        
    Returns:
        Feature tensor (H, W, 6)
    """
    # Load image
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Could not load image: {image_path}")
    
    # Convert BGR to RGB and normalize
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    
    # Create feature extractor and extract features
    extractor = GlassFeatureExtractor(config)
    features = extractor.extract_features(image)
    
    return features


if __name__ == "__main__":
    # Example usage
    import sys
    
    if len(sys.argv) != 2:
        print("Usage: python features_glass.py <image_path>")
        sys.exit(1)
    
    image_path = sys.argv[1]
    features = extract_features_from_image(image_path)
    
    print(f"Extracted features shape: {features.shape}")
    print("Channel statistics:")
    channel_names = ['L_CLAHE', 'DoG_s2_4', 'DoG_s4_8', 'Entropy11', 'EdgeBandMask', 'ConcavityMap']
    
    for i, name in enumerate(channel_names):
        channel = features[:, :, i]
        print(f"  {name}: min={np.min(channel):.3f}, max={np.max(channel):.3f}, "
              f"mean={np.mean(channel):.3f}, std={np.std(channel):.3f}")

