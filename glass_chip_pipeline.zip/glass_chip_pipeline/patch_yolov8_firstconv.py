"""
Script to patch YOLOv8 models to accept 6-channel inputs instead of 3-channel RGB.

This script modifies the first convolutional layer of a YOLOv8 model to accept
6-channel feature inputs from the glass chip detection pipeline.
"""

import torch
import torch.nn as nn
from typing import Optional, Dict, Any
import logging
from pathlib import Path
import yaml

try:
    from ultralytics import YOLO
    ULTRALYTICS_AVAILABLE = True
except ImportError:
    ULTRALYTICS_AVAILABLE = False
    logging.warning("ultralytics not available, YOLO patching will be limited")

logger = logging.getLogger(__name__)


class YOLOv8Patcher:
    """
    Utility class to patch YOLOv8 models for 6-channel inputs.
    """
    
    def __init__(self):
        """Initialize the patcher."""
        if not ULTRALYTICS_AVAILABLE:
            raise ImportError("ultralytics package is required for YOLO patching")
    
    def patch_model(self, model_path: str, output_path: str, 
                   input_channels: int = 6, method: str = 'average') -> str:
        """
        Patch a YOLOv8 model to accept different number of input channels.
        
        Args:
            model_path: Path to original YOLOv8 model (.pt file)
            output_path: Path to save patched model
            input_channels: Number of input channels (default: 6)
            method: Method to initialize new weights ('average', 'replicate', 'random')
            
        Returns:
            Path to patched model
        """
        # Load the original model
        model = YOLO(model_path)
        
        # Get the model's state dict
        state_dict = model.model.state_dict()
        
        # Find the first conv layer
        first_conv_key = self._find_first_conv_layer(state_dict)
        
        if first_conv_key is None:
            raise ValueError("Could not find first convolutional layer in model")
        
        # Patch the first conv layer
        original_weight = state_dict[first_conv_key]
        new_weight = self._create_new_conv_weight(original_weight, input_channels, method)
        state_dict[first_conv_key] = new_weight
        
        # Update model configuration if needed
        self._update_model_config(model, input_channels)
        
        # Load the modified state dict
        model.model.load_state_dict(state_dict)
        
        # Save the patched model
        torch.save(model.model.state_dict(), output_path)
        
        logger.info(f"Patched model saved to {output_path}")
        logger.info(f"First conv layer '{first_conv_key}' updated from {original_weight.shape} to {new_weight.shape}")
        
        return output_path
    
    def _find_first_conv_layer(self, state_dict: Dict[str, torch.Tensor]) -> Optional[str]:
        """Find the key of the first convolutional layer."""
        # Common patterns for first conv layer in YOLOv8
        patterns = [
            'model.0.conv.weight',
            'backbone.stem.conv.weight',
            'backbone.conv1.weight',
            'conv1.weight',
            '0.conv.weight'
        ]
        
        # Check exact matches first
        for pattern in patterns:
            if pattern in state_dict:
                return pattern
        
        # Search for conv layers with 3 input channels (likely first layer)
        for key, tensor in state_dict.items():
            if 'conv' in key.lower() and 'weight' in key and len(tensor.shape) == 4:
                if tensor.shape[1] == 3:  # 3 input channels
                    return key
        
        # Fallback: find any conv layer
        for key, tensor in state_dict.items():
            if 'conv' in key.lower() and 'weight' in key and len(tensor.shape) == 4:
                return key
        
        return None
    
    def _create_new_conv_weight(self, original_weight: torch.Tensor, 
                               new_channels: int, method: str) -> torch.Tensor:
        """
        Create new conv weight tensor with different number of input channels.
        
        Args:
            original_weight: Original weight tensor (out_channels, in_channels, H, W)
            new_channels: New number of input channels
            method: Method to initialize new weights
            
        Returns:
            New weight tensor (out_channels, new_channels, H, W)
        """
        out_channels, in_channels, h, w = original_weight.shape
        
        if new_channels == in_channels:
            return original_weight
        
        # Create new weight tensor
        new_weight = torch.zeros(out_channels, new_channels, h, w, 
                               dtype=original_weight.dtype, device=original_weight.device)
        
        if method == 'average':
            # Average the original RGB channels and replicate
            if in_channels == 3:
                avg_weight = original_weight.mean(dim=1, keepdim=True)  # Average across RGB
                for i in range(new_channels):
                    new_weight[:, i:i+1, :, :] = avg_weight
            else:
                # If original is not RGB, just replicate first channel
                for i in range(new_channels):
                    new_weight[:, i:i+1, :, :] = original_weight[:, 0:1, :, :]
                    
        elif method == 'replicate':
            # Replicate original channels cyclically
            for i in range(new_channels):
                source_channel = i % in_channels
                new_weight[:, i:i+1, :, :] = original_weight[:, source_channel:source_channel+1, :, :]
                
        elif method == 'random':
            # Initialize new channels randomly, copy original channels if possible
            nn.init.kaiming_normal_(new_weight, mode='fan_out', nonlinearity='relu')
            
            # Copy original channels to first positions
            copy_channels = min(new_channels, in_channels)
            new_weight[:, :copy_channels, :, :] = original_weight[:, :copy_channels, :, :]
            
        else:
            raise ValueError(f"Unknown method: {method}")
        
        return new_weight
    
    def _update_model_config(self, model: 'YOLO', input_channels: int):
        """Update model configuration for new input channels."""
        try:
            # Try to update the model's configuration
            if hasattr(model, 'cfg') and model.cfg:
                if isinstance(model.cfg, dict):
                    model.cfg['ch'] = input_channels
                elif hasattr(model.cfg, 'ch'):
                    model.cfg.ch = input_channels
            
            # Update model attributes if they exist
            if hasattr(model.model, 'yaml') and model.model.yaml:
                if isinstance(model.model.yaml, dict):
                    model.model.yaml['ch'] = input_channels
                    
        except Exception as e:
            logger.warning(f"Could not update model config: {e}")


def create_6channel_yolo_config() -> Dict[str, Any]:
    """
    Create a YOLOv8 configuration for 6-channel inputs.
    
    Returns:
        Configuration dictionary
    """
    config = {
        # Model architecture
        'nc': 1,  # Number of classes (chip/check)
        'ch': 6,  # Number of input channels
        'depth_multiple': 0.33,
        'width_multiple': 0.25,
        
        # Backbone
        'backbone': [
            [-1, 1, 'Conv', [64, 6, 2]],  # 0-P1/2, modified for 6 channels
            [-1, 1, 'Conv', [128, 3, 2]],  # 1-P2/4
            [-1, 3, 'C2f', [128, True]],
            [-1, 1, 'Conv', [256, 3, 2]],  # 3-P3/8
            [-1, 6, 'C2f', [256, True]],
            [-1, 1, 'Conv', [512, 3, 2]],  # 5-P4/16
            [-1, 6, 'C2f', [512, True]],
            [-1, 1, 'Conv', [1024, 3, 2]],  # 7-P5/32
            [-1, 3, 'C2f', [1024, True]],
            [-1, 1, 'SPPF', [1024, 5]],  # 9
        ],
        
        # Head
        'head': [
            [-1, 1, 'nn.Upsample', [None, 2, 'nearest']],
            [[-1, 6], 1, 'Concat', [1]],  # cat backbone P4
            [-1, 3, 'C2f', [512]],  # 12
            
            [-1, 1, 'nn.Upsample', [None, 2, 'nearest']],
            [[-1, 4], 1, 'Concat', [1]],  # cat backbone P3
            [-1, 3, 'C2f', [256]],  # 15 (P3/8-small)
            
            [-1, 1, 'Conv', [256, 3, 2]],
            [[-1, 12], 1, 'Concat', [1]],  # cat head P4
            [-1, 3, 'C2f', [512]],  # 18 (P4/16-medium)
            
            [-1, 1, 'Conv', [512, 3, 2]],
            [[-1, 9], 1, 'Concat', [1]],  # cat head P5
            [-1, 3, 'C2f', [1024]],  # 21 (P5/32-large)
            
            [[15, 18, 21], 1, 'Detect', ['nc']],  # Detect(P3, P4, P5)
        ]
    }
    
    return config


def patch_yolo_model(model_path: str, output_path: str, 
                    input_channels: int = 6, method: str = 'average') -> str:
    """
    Convenience function to patch a YOLOv8 model.
    
    Args:
        model_path: Path to original model
        output_path: Path to save patched model
        input_channels: Number of input channels
        method: Weight initialization method
        
    Returns:
        Path to patched model
    """
    patcher = YOLOv8Patcher()
    return patcher.patch_model(model_path, output_path, input_channels, method)


def create_training_script() -> str:
    """
    Create a simple training script for the patched model.
    
    Returns:
        Training script as string
    """
    script = '''
import torch
from ultralytics import YOLO
from dataset_glass import create_dataloader

def train_6channel_yolo(
    model_path: str,
    train_data_dir: str,
    val_data_dir: str,
    epochs: int = 100,
    batch_size: int = 16,
    img_size: int = 640
):
    """Train YOLOv8 with 6-channel inputs."""
    
    # Load patched model
    model = YOLO(model_path)
    
    # Create data loaders
    train_loader = create_dataloader(
        root=train_data_dir,
        batch_size=batch_size,
        shuffle=True,
        train=True,
        augment=True
    )
    
    val_loader = create_dataloader(
        root=val_data_dir,
        batch_size=batch_size,
        shuffle=False,
        train=False,
        augment=False
    )
    
    # Training configuration
    train_config = {
        'epochs': epochs,
        'batch': batch_size,
        'imgsz': img_size,
        'device': 'cuda' if torch.cuda.is_available() else 'cpu',
        'workers': 8,
        'project': 'glass_chip_detection',
        'name': '6channel_yolo',
        'save_period': 10,
        'val': True,
        'plots': True,
        'verbose': True
    }
    
    # Start training
    results = model.train(**train_config)
    
    return results

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True, help="Path to patched model")
    parser.add_argument("--train_data", required=True, help="Training data directory")
    parser.add_argument("--val_data", required=True, help="Validation data directory")
    parser.add_argument("--epochs", type=int, default=100, help="Number of epochs")
    parser.add_argument("--batch_size", type=int, default=16, help="Batch size")
    
    args = parser.parse_args()
    
    train_6channel_yolo(
        model_path=args.model,
        train_data_dir=args.train_data,
        val_data_dir=args.val_data,
        epochs=args.epochs,
        batch_size=args.batch_size
    )
'''
    return script


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Patch YOLOv8 for 6-channel inputs")
    parser.add_argument("--model", required=True, help="Path to original YOLOv8 model")
    parser.add_argument("--output", required=True, help="Path to save patched model")
    parser.add_argument("--channels", type=int, default=6, help="Number of input channels")
    parser.add_argument("--method", choices=['average', 'replicate', 'random'], 
                       default='average', help="Weight initialization method")
    parser.add_argument("--create_config", action='store_true', 
                       help="Create 6-channel YOLO config file")
    parser.add_argument("--create_training_script", action='store_true',
                       help="Create training script")
    
    args = parser.parse_args()
    
    if args.create_config:
        config = create_6channel_yolo_config()
        config_path = "yolov8_6channel.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(config, f, default_flow_style=False)
        print(f"Created config file: {config_path}")
    
    if args.create_training_script:
        script = create_training_script()
        script_path = "train_6channel_yolo.py"
        with open(script_path, 'w') as f:
            f.write(script)
        print(f"Created training script: {script_path}")
    
    if args.model and args.output:
        try:
            patched_path = patch_yolo_model(
                model_path=args.model,
                output_path=args.output,
                input_channels=args.channels,
                method=args.method
            )
            print(f"Successfully patched model: {patched_path}")
        except Exception as e:
            print(f"Error patching model: {e}")

