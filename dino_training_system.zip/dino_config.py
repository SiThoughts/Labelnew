#!/usr/bin/env python3
"""
DINO Model Configuration for Photomask Defect Detection
Optimized for 11GB VRAM constraint
"""

import torch
from typing import Dict, Any
import os

class DINOConfig:
    """Configuration class for DINO model training"""
    
    def __init__(self, model_type: str = "dino", backbone: str = "resnet50"):
        self.model_type = model_type
        self.backbone = backbone
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        
        # Memory optimization settings for 11GB VRAM
        self.memory_optimized = True
        self.gradient_checkpointing = True
        self.mixed_precision = True
        
    def get_model_config(self) -> Dict[str, Any]:
        """Get model configuration optimized for 11GB VRAM"""
        
        if self.backbone == "resnet50":
            config = {
                # Model architecture
                "model_name": "facebook/detr-resnet-50",
                "backbone": "resnet50",
                "hidden_dim": 256,
                "num_queries": 100,  # Reduced from default 300 for memory
                "num_classes": 2,  # chip, check
                
                # Training parameters
                "batch_size": 4,  # Reduced for 11GB VRAM
                "gradient_accumulation_steps": 4,  # Effective batch size = 16
                "learning_rate": 1e-4,
                "weight_decay": 1e-4,
                "num_epochs": 100,
                "warmup_steps": 1000,
                
                # Memory optimization
                "gradient_checkpointing": True,
                "mixed_precision": True,
                "dataloader_num_workers": 4,
                "pin_memory": True,
                
                # Image preprocessing
                "image_size": 800,  # Reduced from 1333 for memory
                "max_size": 1333,
                "normalize_mean": [0.485, 0.456, 0.406],
                "normalize_std": [0.229, 0.224, 0.225],
                
                # Loss configuration
                "class_loss_coef": 1.0,
                "bbox_loss_coef": 5.0,
                "giou_loss_coef": 2.0,
                "eos_coef": 0.1,  # End-of-sequence coefficient
                
                # Matcher configuration
                "set_cost_class": 1.0,
                "set_cost_bbox": 5.0,
                "set_cost_giou": 2.0,
                
                # Optimizer
                "optimizer": "AdamW",
                "lr_scheduler": "cosine",
                "lr_drop": 80,
                
                # Validation
                "eval_every": 5,
                "save_every": 10,
                "early_stopping_patience": 15,
                "target_accuracy": 0.90,
                
                # Data augmentation
                "horizontal_flip_prob": 0.5,
                "vertical_flip_prob": 0.3,
                "rotation_degrees": 15,
                "brightness": 0.2,
                "contrast": 0.2,
                "saturation": 0.2,
                "hue": 0.1,
            }
        
        elif self.backbone == "swin_tiny":
            config = {
                # Model architecture - Swin Transformer Tiny for better accuracy
                "model_name": "microsoft/swin-tiny-patch4-window7-224",
                "backbone": "swin_tiny",
                "hidden_dim": 256,
                "num_queries": 100,
                "num_classes": 2,
                
                # Training parameters
                "batch_size": 2,  # Further reduced for Swin
                "gradient_accumulation_steps": 8,  # Effective batch size = 16
                "learning_rate": 5e-5,  # Lower LR for transformer
                "weight_decay": 1e-4,
                "num_epochs": 120,
                "warmup_steps": 1500,
                
                # Memory optimization
                "gradient_checkpointing": True,
                "mixed_precision": True,
                "dataloader_num_workers": 2,
                "pin_memory": True,
                
                # Image preprocessing
                "image_size": 800,
                "max_size": 1333,
                "normalize_mean": [0.485, 0.456, 0.406],
                "normalize_std": [0.229, 0.224, 0.225],
                
                # Loss configuration
                "class_loss_coef": 1.0,
                "bbox_loss_coef": 5.0,
                "giou_loss_coef": 2.0,
                "eos_coef": 0.1,
                
                # Matcher configuration
                "set_cost_class": 1.0,
                "set_cost_bbox": 5.0,
                "set_cost_giou": 2.0,
                
                # Optimizer
                "optimizer": "AdamW",
                "lr_scheduler": "cosine",
                "lr_drop": 100,
                
                # Validation
                "eval_every": 5,
                "save_every": 10,
                "early_stopping_patience": 20,
                "target_accuracy": 0.90,
                
                # Data augmentation
                "horizontal_flip_prob": 0.5,
                "vertical_flip_prob": 0.3,
                "rotation_degrees": 10,
                "brightness": 0.15,
                "contrast": 0.15,
                "saturation": 0.15,
                "hue": 0.05,
            }
        
        else:
            raise ValueError(f"Unsupported backbone: {self.backbone}")
        
        return config
    
    def get_data_config(self, data_root: str, image_type: str) -> Dict[str, Any]:
        """Get data configuration for specific image type"""
        return {
            "data_root": data_root,
            "image_type": image_type,
            "train_dir": os.path.join(data_root, "DS0", image_type),
            "val_dir": os.path.join(data_root, "MSA_Sort3", image_type),
            "cache_dir": f"./cache_{image_type.lower()}",
            "num_workers": 4,
            "prefetch_factor": 2,
        }
    
    def get_training_config(self) -> Dict[str, Any]:
        """Get training-specific configuration"""
        return {
            "output_dir": "./models",
            "log_dir": "./logs",
            "checkpoint_dir": "./checkpoints",
            "tensorboard_dir": "./tensorboard",
            "wandb_project": "photomask-detection",
            "experiment_name": f"dino_{self.backbone}",
            "seed": 42,
            "deterministic": True,
            "benchmark": True,
        }
    
    def optimize_for_memory(self) -> Dict[str, Any]:
        """Get memory optimization settings"""
        return {
            "torch_compile": False,  # Disable for compatibility
            "channels_last": True,
            "empty_cache_every": 50,  # Empty cache every N steps
            "max_memory_allocated": 10.5,  # GB, leave some headroom
            "gradient_clipping": 1.0,
            "find_unused_parameters": False,
        }
    
    def get_inference_config(self) -> Dict[str, Any]:
        """Get inference configuration"""
        return {
            "confidence_threshold": 0.5,
            "nms_threshold": 0.5,
            "max_detections": 100,
            "batch_size": 1,  # For inference
            "tta": False,  # Test Time Augmentation
            "multiscale": False,  # Multiscale inference
        }

def create_config_files():
    """Create configuration files for both EV and SV models"""
    
    # ResNet50 configuration (faster training, good baseline)
    resnet_config = DINOConfig(backbone="resnet50")
    
    # Swin Tiny configuration (better accuracy, slower training)
    swin_config = DINOConfig(backbone="swin_tiny")
    
    configs = {
        "resnet50": resnet_config,
        "swin_tiny": swin_config
    }
    
    return configs

def print_memory_requirements():
    """Print estimated memory requirements"""
    print("Estimated VRAM Requirements:")
    print("=" * 40)
    print("ResNet50 backbone:")
    print("  - Training: ~8-9 GB")
    print("  - Inference: ~2-3 GB")
    print()
    print("Swin Tiny backbone:")
    print("  - Training: ~9-10 GB")
    print("  - Inference: ~3-4 GB")
    print()
    print("Optimizations applied:")
    print("  - Mixed precision training")
    print("  - Gradient checkpointing")
    print("  - Reduced batch size")
    print("  - Gradient accumulation")
    print("  - Memory-efficient data loading")

if __name__ == "__main__":
    print("DINO Configuration for Photomask Detection")
    print("=" * 50)
    
    configs = create_config_files()
    
    for backbone, config in configs.items():
        print(f"\n{backbone.upper()} Configuration:")
        model_config = config.get_model_config()
        print(f"  Batch size: {model_config['batch_size']}")
        print(f"  Gradient accumulation: {model_config['gradient_accumulation_steps']}")
        print(f"  Effective batch size: {model_config['batch_size'] * model_config['gradient_accumulation_steps']}")
        print(f"  Learning rate: {model_config['learning_rate']}")
        print(f"  Image size: {model_config['image_size']}")
        print(f"  Number of queries: {model_config['num_queries']}")
    
    print_memory_requirements()

