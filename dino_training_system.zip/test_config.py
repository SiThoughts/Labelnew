#!/usr/bin/env python3
"""
Test DINO configuration without torch dependency
"""

import json

# Mock torch for testing
class MockTorch:
    class cuda:
        @staticmethod
        def is_available():
            return True

# Replace torch import
import sys
sys.modules['torch'] = MockTorch()

from dino_config import DINOConfig, create_config_files, print_memory_requirements

def test_configurations():
    """Test configuration creation"""
    print("Testing DINO Configuration")
    print("=" * 50)
    
    try:
        configs = create_config_files()
        
        for backbone, config in configs.items():
            print(f"\n{backbone.upper()} Configuration Test:")
            print("-" * 30)
            
            # Test model config
            model_config = config.get_model_config()
            print(f"✅ Model config created: {len(model_config)} parameters")
            
            # Test data config
            data_config = config.get_data_config("D/Photomask", "EV")
            print(f"✅ Data config created: {len(data_config)} parameters")
            
            # Test training config
            training_config = config.get_training_config()
            print(f"✅ Training config created: {len(training_config)} parameters")
            
            # Test memory optimization
            memory_config = config.optimize_for_memory()
            print(f"✅ Memory config created: {len(memory_config)} parameters")
            
            # Test inference config
            inference_config = config.get_inference_config()
            print(f"✅ Inference config created: {len(inference_config)} parameters")
            
            # Print key parameters
            print(f"  Batch size: {model_config['batch_size']}")
            print(f"  Gradient accumulation: {model_config['gradient_accumulation_steps']}")
            print(f"  Learning rate: {model_config['learning_rate']}")
            print(f"  Image size: {model_config['image_size']}")
            print(f"  Target accuracy: {model_config['target_accuracy']}")
        
        print("\n✅ All configuration tests passed!")
        print_memory_requirements()
        return True
        
    except Exception as e:
        print(f"❌ Configuration test failed: {e}")
        return False

if __name__ == "__main__":
    success = test_configurations()
    if success:
        print("\n🎉 Configuration system ready!")
    else:
        print("\n❌ Configuration system has issues.")

