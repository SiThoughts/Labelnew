#!/usr/bin/env python3
"""
Simple Training Launcher for Photomask Defect Detection
Quick start script for training DINO models
"""

import os
import sys
import subprocess
from pathlib import Path

def main():
    """Main launcher function"""
    print("🚀 DINO Photomask Defect Detection Training Launcher")
    print("=" * 60)
    
    # Check if data directory exists
    data_root = input("Enter your data root directory (default: D/Photomask): ").strip()
    if not data_root:
        data_root = "D/Photomask"
    
    if not os.path.exists(data_root):
        print(f"❌ Data directory not found: {data_root}")
        print("Please ensure your data is organized as described in README.md")
        return
    
    print(f"✅ Data directory found: {data_root}")
    
    # Choose backbone
    print("\nChoose model backbone:")
    print("1. ResNet50 (faster, ~8-9GB VRAM)")
    print("2. Swin Tiny (better accuracy, ~9-10GB VRAM)")
    
    choice = input("Enter choice (1 or 2, default: 1): ").strip()
    backbone = "swin_tiny" if choice == "2" else "resnet50"
    
    print(f"✅ Selected backbone: {backbone}")
    
    # Choose training mode
    print("\nChoose training mode:")
    print("1. Train both EV and SV models")
    print("2. Train only EV model")
    print("3. Train only SV model")
    
    mode_choice = input("Enter choice (1, 2, or 3, default: 1): ").strip()
    train_only = None
    if mode_choice == "2":
        train_only = "EV"
    elif mode_choice == "3":
        train_only = "SV"
    
    # Target accuracy
    target_acc = input("Enter target accuracy (default: 0.90): ").strip()
    if not target_acc:
        target_acc = "0.90"
    
    try:
        target_accuracy = float(target_acc)
        if target_accuracy <= 0 or target_accuracy > 1:
            raise ValueError("Invalid accuracy")
    except ValueError:
        print("Invalid accuracy value, using default 0.90")
        target_accuracy = 0.90
    
    print(f"✅ Target accuracy: {target_accuracy:.2%}")
    
    # Build command
    cmd = [
        "python", "train_models.py",
        "--data_root", data_root,
        "--backbone", backbone,
        "--target_accuracy", str(target_accuracy)
    ]
    
    if train_only:
        cmd.extend(["--train_only", train_only])
    
    print(f"\n🏃 Starting training...")
    print(f"Command: {' '.join(cmd)}")
    print("\nTraining will start in 3 seconds...")
    print("Press Ctrl+C to cancel")
    
    try:
        import time
        time.sleep(3)
        
        # Run training
        result = subprocess.run(cmd, check=True)
        
        print("\n🎉 Training completed successfully!")
        print("\nNext steps:")
        print("1. Check the models/ directory for trained models")
        print("2. Review training logs in logs/ directory")
        print("3. Run evaluation with evaluate_models.py")
        
    except KeyboardInterrupt:
        print("\n❌ Training cancelled by user")
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Training failed with error code: {e.returncode}")
        print("Check the logs/ directory for detailed error information")
    except FileNotFoundError:
        print("\n❌ train_models.py not found")
        print("Please ensure all files are in the current directory")

if __name__ == "__main__":
    main()

