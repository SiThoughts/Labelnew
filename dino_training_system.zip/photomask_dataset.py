#!/usr/bin/env python3
"""
PyTorch Dataset Class for Photomask Defect Detection
Optimized for DINO model training
"""

import os
import json
import torch
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
import cv2

try:
    import albumentations as A
    from albumentations.pytorch import ToTensorV2
    ALBUMENTATIONS_AVAILABLE = True
except ImportError:
    ALBUMENTATIONS_AVAILABLE = False

try:
    import torchvision.transforms as T
    TORCHVISION_AVAILABLE = True
except ImportError:
    TORCHVISION_AVAILABLE = False

class PhotomaskDataset(Dataset):
    """Dataset class for photomask defect detection"""
    
    def __init__(
        self,
        coco_file: str,
        images_dir: str,
        transforms: Optional[Any] = None,
        image_size: int = 800,
        max_size: int = 1333,
        return_masks: bool = False
    ):
        """
        Initialize dataset
        
        Args:
            coco_file: Path to COCO format annotation file
            images_dir: Directory containing images
            transforms: Data augmentation transforms
            image_size: Target image size
            max_size: Maximum image size
            return_masks: Whether to return segmentation masks
        """
        self.images_dir = images_dir
        self.transforms = transforms
        self.image_size = image_size
        self.max_size = max_size
        self.return_masks = return_masks
        
        # Load COCO annotations
        with open(coco_file, 'r') as f:
            self.coco_data = json.load(f)
        
        # Create mappings
        self.images = {img['id']: img for img in self.coco_data['images']}
        self.categories = {cat['id']: cat for cat in self.coco_data['categories']}
        
        # Group annotations by image
        self.image_annotations = {}
        for ann in self.coco_data['annotations']:
            image_id = ann['image_id']
            if image_id not in self.image_annotations:
                self.image_annotations[image_id] = []
            self.image_annotations[image_id].append(ann)
        
        # Filter images that have annotations
        self.image_ids = [img_id for img_id in self.images.keys() 
                         if img_id in self.image_annotations]
        
        print(f"Dataset initialized with {len(self.image_ids)} images")
        
        # Class mapping
        self.class_names = ['chip', 'check']
        self.num_classes = len(self.class_names)
    
    def __len__(self) -> int:
        return len(self.image_ids)
    
    def __getitem__(self, idx: int) -> Dict[str, Any]:
        """Get dataset item"""
        image_id = self.image_ids[idx]
        image_info = self.images[image_id]
        annotations = self.image_annotations[image_id]
        
        # Load image
        image_path = os.path.join(self.images_dir, image_info['file_name'])
        image = Image.open(image_path).convert('RGB')
        image_array = np.array(image)
        
        # Prepare target
        target = self._prepare_target(annotations, image_info)
        
        # Apply transforms
        if self.transforms:
            if ALBUMENTATIONS_AVAILABLE and hasattr(self.transforms, 'bbox_params'):
                # Albumentations transforms
                transformed = self._apply_albumentations_transforms(image_array, target)
                image_array = transformed['image']
                target = self._update_target_from_albumentations(transformed, target)
            else:
                # Torchvision transforms
                image_array, target = self._apply_torchvision_transforms(image_array, target)
        
        # Convert to tensor if not already
        if not isinstance(image_array, torch.Tensor):
            if image_array.dtype != np.uint8:
                image_array = (image_array * 255).astype(np.uint8)
            image_tensor = torch.from_numpy(image_array).permute(2, 0, 1).float() / 255.0
        else:
            image_tensor = image_array
        
        # Ensure target tensors are correct type
        target = self._ensure_target_tensors(target)
        
        return {
            'image': image_tensor,
            'target': target,
            'image_id': image_id,
            'orig_size': torch.tensor([image_info['height'], image_info['width']]),
            'size': torch.tensor(image_tensor.shape[-2:])
        }
    
    def _prepare_target(self, annotations: List[Dict], image_info: Dict) -> Dict[str, Any]:
        """Prepare target dictionary from annotations"""
        boxes = []
        labels = []
        areas = []
        iscrowd = []
        
        for ann in annotations:
            # COCO format: [x, y, width, height]
            x, y, w, h = ann['bbox']
            
            # Convert to [x1, y1, x2, y2] format
            x1, y1, x2, y2 = x, y, x + w, y + h
            
            # Ensure valid box
            x1 = max(0, x1)
            y1 = max(0, y1)
            x2 = min(image_info['width'], x2)
            y2 = min(image_info['height'], y2)
            
            if x2 > x1 and y2 > y1:
                boxes.append([x1, y1, x2, y2])
                labels.append(ann['category_id'])
                areas.append(ann['area'])
                iscrowd.append(ann.get('iscrowd', 0))
        
        target = {
            'boxes': torch.tensor(boxes, dtype=torch.float32) if boxes else torch.zeros((0, 4), dtype=torch.float32),
            'labels': torch.tensor(labels, dtype=torch.int64) if labels else torch.zeros((0,), dtype=torch.int64),
            'area': torch.tensor(areas, dtype=torch.float32) if areas else torch.zeros((0,), dtype=torch.float32),
            'iscrowd': torch.tensor(iscrowd, dtype=torch.int64) if iscrowd else torch.zeros((0,), dtype=torch.int64),
            'image_id': torch.tensor(image_info['id'], dtype=torch.int64),
            'orig_size': torch.tensor([image_info['height'], image_info['width']], dtype=torch.int64)
        }
        
        return target
    
    def _apply_albumentations_transforms(self, image: np.ndarray, target: Dict) -> Dict:
        """Apply albumentations transforms"""
        # Convert boxes to albumentations format
        boxes = target['boxes'].numpy() if isinstance(target['boxes'], torch.Tensor) else target['boxes']
        labels = target['labels'].numpy() if isinstance(target['labels'], torch.Tensor) else target['labels']
        
        # Convert from [x1, y1, x2, y2] to [x, y, width, height] for albumentations
        albu_boxes = []
        for box in boxes:
            x1, y1, x2, y2 = box
            albu_boxes.append([x1, y1, x2 - x1, y2 - y1])
        
        transformed = self.transforms(
            image=image,
            bboxes=albu_boxes,
            class_labels=labels.tolist()
        )
        
        return transformed
    
    def _update_target_from_albumentations(self, transformed: Dict, original_target: Dict) -> Dict:
        """Update target from albumentations transform results"""
        # Convert boxes back to [x1, y1, x2, y2] format
        new_boxes = []
        for box in transformed['bboxes']:
            x, y, w, h = box
            new_boxes.append([x, y, x + w, y + h])
        
        target = original_target.copy()
        target['boxes'] = torch.tensor(new_boxes, dtype=torch.float32) if new_boxes else torch.zeros((0, 4), dtype=torch.float32)
        target['labels'] = torch.tensor(transformed['class_labels'], dtype=torch.int64) if transformed['class_labels'] else torch.zeros((0,), dtype=torch.int64)
        
        # Update areas
        if new_boxes:
            areas = [(box[2] - box[0]) * (box[3] - box[1]) for box in new_boxes]
            target['area'] = torch.tensor(areas, dtype=torch.float32)
        else:
            target['area'] = torch.zeros((0,), dtype=torch.float32)
        
        return target
    
    def _apply_torchvision_transforms(self, image: np.ndarray, target: Dict) -> Tuple[np.ndarray, Dict]:
        """Apply torchvision transforms (basic implementation)"""
        # Convert to PIL for torchvision
        pil_image = Image.fromarray(image)
        
        # Apply transforms (this is a simplified version)
        if self.transforms:
            pil_image = self.transforms(pil_image)
        
        # Convert back to numpy
        if isinstance(pil_image, torch.Tensor):
            image_array = pil_image.permute(1, 2, 0).numpy()
        else:
            image_array = np.array(pil_image)
        
        return image_array, target
    
    def _ensure_target_tensors(self, target: Dict) -> Dict:
        """Ensure all target values are proper tensors"""
        for key, value in target.items():
            if not isinstance(value, torch.Tensor):
                if key in ['boxes', 'area']:
                    target[key] = torch.tensor(value, dtype=torch.float32)
                elif key in ['labels', 'iscrowd', 'image_id', 'orig_size']:
                    target[key] = torch.tensor(value, dtype=torch.int64)
        
        return target
    
    def get_class_weights(self) -> torch.Tensor:
        """Calculate class weights for balanced training"""
        class_counts = [0] * self.num_classes
        
        for image_id in self.image_ids:
            annotations = self.image_annotations[image_id]
            for ann in annotations:
                class_counts[ann['category_id']] += 1
        
        total_samples = sum(class_counts)
        class_weights = [total_samples / (self.num_classes * count) if count > 0 else 1.0 
                        for count in class_counts]
        
        return torch.tensor(class_weights, dtype=torch.float32)
    
    def get_dataset_stats(self) -> Dict:
        """Get dataset statistics"""
        stats = {
            'num_images': len(self.image_ids),
            'num_classes': self.num_classes,
            'class_names': self.class_names,
            'class_counts': [0] * self.num_classes,
            'total_objects': 0,
            'avg_objects_per_image': 0,
            'image_sizes': []
        }
        
        for image_id in self.image_ids:
            image_info = self.images[image_id]
            stats['image_sizes'].append((image_info['width'], image_info['height']))
            
            annotations = self.image_annotations[image_id]
            stats['total_objects'] += len(annotations)
            
            for ann in annotations:
                stats['class_counts'][ann['category_id']] += 1
        
        stats['avg_objects_per_image'] = stats['total_objects'] / stats['num_images']
        
        return stats

def create_transforms(config: Dict, is_training: bool = True) -> Optional[Any]:
    """Create data transforms based on configuration"""
    
    if ALBUMENTATIONS_AVAILABLE:
        return create_albumentations_transforms(config, is_training)
    elif TORCHVISION_AVAILABLE:
        return create_torchvision_transforms(config, is_training)
    else:
        print("Warning: No augmentation library available")
        return None

def create_albumentations_transforms(config: Dict, is_training: bool = True) -> A.Compose:
    """Create albumentations transforms"""
    transforms = []
    
    # Resize
    transforms.append(A.LongestMaxSize(max_size=config.get('image_size', 800)))
    transforms.append(A.PadIfNeeded(
        min_height=config.get('image_size', 800),
        min_width=config.get('image_size', 800),
        border_mode=cv2.BORDER_CONSTANT,
        value=0
    ))
    
    if is_training:
        # Training augmentations
        if config.get('horizontal_flip_prob', 0) > 0:
            transforms.append(A.HorizontalFlip(p=config['horizontal_flip_prob']))
        
        if config.get('vertical_flip_prob', 0) > 0:
            transforms.append(A.VerticalFlip(p=config['vertical_flip_prob']))
        
        if config.get('rotation_degrees', 0) > 0:
            transforms.append(A.Rotate(
                limit=config['rotation_degrees'],
                border_mode=cv2.BORDER_CONSTANT,
                value=0,
                p=0.5
            ))
        
        # Color augmentations
        transforms.append(A.ColorJitter(
            brightness=config.get('brightness', 0.2),
            contrast=config.get('contrast', 0.2),
            saturation=config.get('saturation', 0.2),
            hue=config.get('hue', 0.1),
            p=0.5
        ))
    
    # Normalization
    transforms.append(A.Normalize(
        mean=config.get('normalize_mean', [0.485, 0.456, 0.406]),
        std=config.get('normalize_std', [0.229, 0.224, 0.225])
    ))
    
    return A.Compose(
        transforms,
        bbox_params=A.BboxParams(
            format='coco',
            label_fields=['class_labels'],
            min_visibility=0.3
        )
    )

def create_torchvision_transforms(config: Dict, is_training: bool = True) -> T.Compose:
    """Create torchvision transforms (basic implementation)"""
    transforms = []
    
    # Resize
    transforms.append(T.Resize((config.get('image_size', 800), config.get('image_size', 800))))
    
    if is_training:
        # Basic augmentations
        if config.get('horizontal_flip_prob', 0) > 0:
            transforms.append(T.RandomHorizontalFlip(p=config['horizontal_flip_prob']))
        
        transforms.append(T.ColorJitter(
            brightness=config.get('brightness', 0.2),
            contrast=config.get('contrast', 0.2),
            saturation=config.get('saturation', 0.2),
            hue=config.get('hue', 0.1)
        ))
    
    # Convert to tensor and normalize
    transforms.extend([
        T.ToTensor(),
        T.Normalize(
            mean=config.get('normalize_mean', [0.485, 0.456, 0.406]),
            std=config.get('normalize_std', [0.229, 0.224, 0.225])
        )
    ])
    
    return T.Compose(transforms)

def collate_fn(batch: List[Dict]) -> Dict[str, Any]:
    """Custom collate function for DINO training"""
    images = []
    targets = []
    image_ids = []
    orig_sizes = []
    sizes = []
    
    for item in batch:
        images.append(item['image'])
        targets.append(item['target'])
        image_ids.append(item['image_id'])
        orig_sizes.append(item['orig_size'])
        sizes.append(item['size'])
    
    # Stack images
    images = torch.stack(images, dim=0)
    
    return {
        'images': images,
        'targets': targets,
        'image_ids': torch.stack(image_ids),
        'orig_sizes': torch.stack(orig_sizes),
        'sizes': torch.stack(sizes)
    }

def create_dataloaders(
    train_dataset: PhotomaskDataset,
    val_dataset: PhotomaskDataset,
    config: Dict
) -> Tuple[DataLoader, DataLoader]:
    """Create train and validation dataloaders"""
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.get('batch_size', 4),
        shuffle=True,
        num_workers=config.get('dataloader_num_workers', 4),
        pin_memory=config.get('pin_memory', True),
        collate_fn=collate_fn,
        drop_last=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=config.get('batch_size', 4),
        shuffle=False,
        num_workers=config.get('dataloader_num_workers', 4),
        pin_memory=config.get('pin_memory', True),
        collate_fn=collate_fn,
        drop_last=False
    )
    
    return train_loader, val_loader

def main():
    """Test the dataset class"""
    print("Testing PhotomaskDataset")
    print("=" * 30)
    
    # This would be used with actual processed data
    sample_config = {
        'image_size': 800,
        'horizontal_flip_prob': 0.5,
        'brightness': 0.2,
        'contrast': 0.2,
        'normalize_mean': [0.485, 0.456, 0.406],
        'normalize_std': [0.229, 0.224, 0.225]
    }
    
    print("Dataset class ready for use!")
    print("Usage:")
    print("1. Process your data with data_preprocessor.py")
    print("2. Create dataset instances with processed COCO files")
    print("3. Create dataloaders for training")

if __name__ == "__main__":
    main()

