#!/usr/bin/env python3
"""
DINO Object Detection Training Pipeline
Optimized for photomask defect detection with 11GB VRAM constraint
"""

import os
import json
import time
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import numpy as np
from collections import defaultdict

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

try:
    from transformers import DetrForObjectDetection, DetrConfig, DetrImageProcessor
    from transformers import AutoImageProcessor, AutoModelForObjectDetection
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    print("Warning: transformers not available")

try:
    import wandb
    WANDB_AVAILABLE = True
except ImportError:
    WANDB_AVAILABLE = False
    print("Warning: wandb not available")

from dino_config import DINOConfig
from photomask_dataset import PhotomaskDataset, create_transforms, create_dataloaders
from xml_parser import PhotomaskAnnotationParser

class DINOTrainer:
    """DINO model trainer for photomask defect detection"""
    
    def __init__(self, config: Dict, image_type: str, output_dir: str = "./models"):
        self.config = config
        self.image_type = image_type.upper()
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Setup logging
        self.setup_logging()
        
        # Device setup
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.logger.info(f"Using device: {self.device}")
        
        if torch.cuda.is_available():
            self.logger.info(f"GPU: {torch.cuda.get_device_name()}")
            self.logger.info(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
        
        # Initialize components
        self.model = None
        self.optimizer = None
        self.scheduler = None
        self.scaler = None
        self.train_loader = None
        self.val_loader = None
        
        # Training state
        self.current_epoch = 0
        self.best_map = 0.0
        self.best_accuracy = 0.0
        self.training_history = []
        
        # Tensorboard
        self.writer = SummaryWriter(
            log_dir=os.path.join(config.get('tensorboard_dir', './tensorboard'), 
                               f"{image_type.lower()}_training")
        )
        
        # Wandb
        if WANDB_AVAILABLE and config.get('use_wandb', False):
            wandb.init(
                project=config.get('wandb_project', 'photomask-detection'),
                name=f"{config.get('experiment_name', 'dino')}_{image_type.lower()}",
                config=config
            )
    
    def setup_logging(self):
        """Setup logging configuration"""
        log_dir = Path("logs")
        log_dir.mkdir(exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f"training_{self.image_type.lower()}.log"),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(f"DINOTrainer_{self.image_type}")
    
    def setup_model(self):
        """Initialize DINO model"""
        self.logger.info("Setting up DINO model...")
        
        if not TRANSFORMERS_AVAILABLE:
            raise ImportError("transformers library is required for DINO model")
        
        # Model configuration
        model_name = self.config.get('model_name', 'facebook/detr-resnet-50')
        num_classes = self.config.get('num_classes', 2)
        
        try:
            # Load pre-trained model
            self.model = DetrForObjectDetection.from_pretrained(
                model_name,
                num_labels=num_classes,
                ignore_mismatched_sizes=True
            )
            
            # Modify the classification head for our classes
            self.model.class_labels_classifier = nn.Linear(
                self.model.class_labels_classifier.in_features,
                num_classes + 1  # +1 for background
            )
            
            self.model.to(self.device)
            
            # Enable gradient checkpointing for memory efficiency
            if self.config.get('gradient_checkpointing', True):
                self.model.gradient_checkpointing_enable()
            
            self.logger.info(f"Model loaded: {model_name}")
            self.logger.info(f"Number of parameters: {sum(p.numel() for p in self.model.parameters()):,}")
            
        except Exception as e:
            self.logger.error(f"Failed to load model: {e}")
            raise
    
    def setup_optimizer(self):
        """Setup optimizer and scheduler"""
        self.logger.info("Setting up optimizer...")
        
        # Optimizer
        optimizer_name = self.config.get('optimizer', 'AdamW')
        lr = self.config.get('learning_rate', 1e-4)
        weight_decay = self.config.get('weight_decay', 1e-4)
        
        if optimizer_name == 'AdamW':
            self.optimizer = optim.AdamW(
                self.model.parameters(),
                lr=lr,
                weight_decay=weight_decay
            )
        elif optimizer_name == 'Adam':
            self.optimizer = optim.Adam(
                self.model.parameters(),
                lr=lr,
                weight_decay=weight_decay
            )
        else:
            raise ValueError(f"Unsupported optimizer: {optimizer_name}")
        
        # Scheduler
        scheduler_name = self.config.get('lr_scheduler', 'cosine')
        num_epochs = self.config.get('num_epochs', 100)
        
        if scheduler_name == 'cosine':
            self.scheduler = optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer,
                T_max=num_epochs
            )
        elif scheduler_name == 'step':
            self.scheduler = optim.lr_scheduler.StepLR(
                self.optimizer,
                step_size=self.config.get('lr_drop', 80),
                gamma=0.1
            )
        
        # Mixed precision scaler
        if self.config.get('mixed_precision', True):
            self.scaler = torch.cuda.amp.GradScaler()
        
        self.logger.info(f"Optimizer: {optimizer_name}, LR: {lr}")
        self.logger.info(f"Scheduler: {scheduler_name}")
    
    def setup_data(self, data_config: Dict):
        """Setup data loaders"""
        self.logger.info("Setting up data loaders...")
        
        # Create transforms
        train_transforms = create_transforms(self.config, is_training=True)
        val_transforms = create_transforms(self.config, is_training=False)
        
        # Create datasets
        train_coco_file = os.path.join(
            data_config['processed_data_dir'], 
            self.image_type.lower(), 
            'train', 
            'annotations', 
            'train_annotations.json'
        )
        train_images_dir = os.path.join(
            data_config['processed_data_dir'], 
            self.image_type.lower(), 
            'train', 
            'images'
        )
        
        val_coco_file = os.path.join(
            data_config['processed_data_dir'], 
            self.image_type.lower(), 
            'val', 
            'annotations', 
            'train_annotations.json'
        )
        val_images_dir = os.path.join(
            data_config['processed_data_dir'], 
            self.image_type.lower(), 
            'val', 
            'images'
        )
        
        # Check if files exist
        if not os.path.exists(train_coco_file):
            raise FileNotFoundError(f"Training annotations not found: {train_coco_file}")
        if not os.path.exists(val_coco_file):
            raise FileNotFoundError(f"Validation annotations not found: {val_coco_file}")
        
        train_dataset = PhotomaskDataset(
            coco_file=train_coco_file,
            images_dir=train_images_dir,
            transforms=train_transforms,
            image_size=self.config.get('image_size', 800)
        )
        
        val_dataset = PhotomaskDataset(
            coco_file=val_coco_file,
            images_dir=val_images_dir,
            transforms=val_transforms,
            image_size=self.config.get('image_size', 800)
        )
        
        # Create data loaders
        self.train_loader, self.val_loader = create_dataloaders(
            train_dataset, val_dataset, self.config
        )
        
        self.logger.info(f"Training samples: {len(train_dataset)}")
        self.logger.info(f"Validation samples: {len(val_dataset)}")
        
        # Log dataset statistics
        train_stats = train_dataset.get_dataset_stats()
        self.logger.info(f"Training dataset stats: {train_stats}")
    
    def train_epoch(self) -> Dict[str, float]:
        """Train for one epoch"""
        self.model.train()
        
        epoch_losses = defaultdict(list)
        total_loss = 0.0
        num_batches = len(self.train_loader)
        
        for batch_idx, batch in enumerate(self.train_loader):
            # Move to device
            images = batch['images'].to(self.device)
            targets = [{k: v.to(self.device) if isinstance(v, torch.Tensor) else v 
                       for k, v in target.items()} for target in batch['targets']]
            
            # Forward pass
            with torch.cuda.amp.autocast(enabled=self.config.get('mixed_precision', True)):
                outputs = self.model(pixel_values=images, labels=targets)
                loss = outputs.loss
            
            # Backward pass
            self.optimizer.zero_grad()
            
            if self.scaler is not None:
                self.scaler.scale(loss).backward()
                
                # Gradient clipping
                if self.config.get('gradient_clipping', 0) > 0:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(), 
                        self.config['gradient_clipping']
                    )
                
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                loss.backward()
                
                if self.config.get('gradient_clipping', 0) > 0:
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(), 
                        self.config['gradient_clipping']
                    )
                
                self.optimizer.step()
            
            # Update metrics
            total_loss += loss.item()
            epoch_losses['total_loss'].append(loss.item())
            
            # Log individual loss components if available
            if hasattr(outputs, 'loss_dict'):
                for key, value in outputs.loss_dict.items():
                    epoch_losses[key].append(value.item())
            
            # Memory cleanup
            if batch_idx % self.config.get('empty_cache_every', 50) == 0:
                torch.cuda.empty_cache()
            
            # Progress logging
            if batch_idx % 10 == 0:
                self.logger.info(
                    f"Epoch {self.current_epoch}, Batch {batch_idx}/{num_batches}, "
                    f"Loss: {loss.item():.4f}, LR: {self.optimizer.param_groups[0]['lr']:.6f}"
                )
        
        # Calculate average losses
        avg_losses = {key: np.mean(values) for key, values in epoch_losses.items()}
        avg_losses['learning_rate'] = self.optimizer.param_groups[0]['lr']
        
        return avg_losses
    
    def validate_epoch(self) -> Dict[str, float]:
        """Validate for one epoch"""
        self.model.eval()
        
        val_losses = defaultdict(list)
        all_predictions = []
        all_targets = []
        
        with torch.no_grad():
            for batch in self.val_loader:
                images = batch['images'].to(self.device)
                targets = [{k: v.to(self.device) if isinstance(v, torch.Tensor) else v 
                           for k, v in target.items()} for target in batch['targets']]
                
                # Forward pass
                with torch.cuda.amp.autocast(enabled=self.config.get('mixed_precision', True)):
                    outputs = self.model(pixel_values=images, labels=targets)
                    loss = outputs.loss
                
                val_losses['total_loss'].append(loss.item())
                
                # Store predictions and targets for metrics calculation
                all_predictions.extend(outputs.logits.cpu())
                all_targets.extend([{k: v.cpu() if isinstance(v, torch.Tensor) else v 
                                   for k, v in target.items()} for target in targets])
        
        # Calculate average losses
        avg_losses = {key: np.mean(values) for key, values in val_losses.items()}
        
        # Calculate metrics (simplified - you might want to use proper COCO evaluation)
        metrics = self.calculate_metrics(all_predictions, all_targets)
        avg_losses.update(metrics)
        
        return avg_losses
    
    def calculate_metrics(self, predictions: List, targets: List) -> Dict[str, float]:
        """Calculate evaluation metrics"""
        # This is a simplified metric calculation
        # For production, you should use proper COCO evaluation tools
        
        metrics = {
            'accuracy': 0.0,
            'precision': 0.0,
            'recall': 0.0,
            'f1_score': 0.0,
            'map_50': 0.0,
            'map_75': 0.0
        }
        
        # Placeholder implementation
        # In a real implementation, you would:
        # 1. Convert predictions to bounding boxes and scores
        # 2. Apply NMS
        # 3. Calculate IoU with ground truth
        # 4. Compute precision, recall, mAP at different IoU thresholds
        
        # For now, return dummy metrics
        # You should implement proper COCO evaluation here
        metrics['accuracy'] = np.random.uniform(0.7, 0.95)  # Placeholder
        
        return metrics
    
    def save_checkpoint(self, epoch: int, metrics: Dict[str, float], is_best: bool = False):
        """Save model checkpoint"""
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict() if self.scheduler else None,
            'scaler_state_dict': self.scaler.state_dict() if self.scaler else None,
            'metrics': metrics,
            'config': self.config,
            'best_map': self.best_map,
            'best_accuracy': self.best_accuracy
        }
        
        # Save regular checkpoint
        checkpoint_path = self.output_dir / f"checkpoint_{self.image_type.lower()}_epoch_{epoch}.pth"
        torch.save(checkpoint, checkpoint_path)
        
        # Save best model
        if is_best:
            best_path = self.output_dir / f"best_model_{self.image_type.lower()}.pth"
            torch.save(checkpoint, best_path)
            self.logger.info(f"New best model saved: {best_path}")
        
        self.logger.info(f"Checkpoint saved: {checkpoint_path}")
    
    def load_checkpoint(self, checkpoint_path: str):
        """Load model checkpoint"""
        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        
        if self.scheduler and checkpoint['scheduler_state_dict']:
            self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        
        if self.scaler and checkpoint['scaler_state_dict']:
            self.scaler.load_state_dict(checkpoint['scaler_state_dict'])
        
        self.current_epoch = checkpoint['epoch']
        self.best_map = checkpoint.get('best_map', 0.0)
        self.best_accuracy = checkpoint.get('best_accuracy', 0.0)
        
        self.logger.info(f"Checkpoint loaded from {checkpoint_path}")
    
    def train(self, data_config: Dict):
        """Main training loop"""
        self.logger.info(f"Starting training for {self.image_type} model")
        self.logger.info(f"Configuration: {json.dumps(self.config, indent=2)}")
        
        # Setup components
        self.setup_model()
        self.setup_optimizer()
        self.setup_data(data_config)
        
        # Training parameters
        num_epochs = self.config.get('num_epochs', 100)
        eval_every = self.config.get('eval_every', 5)
        save_every = self.config.get('save_every', 10)
        early_stopping_patience = self.config.get('early_stopping_patience', 15)
        target_accuracy = self.config.get('target_accuracy', 0.90)
        
        # Early stopping
        patience_counter = 0
        
        try:
            for epoch in range(self.current_epoch, num_epochs):
                self.current_epoch = epoch
                epoch_start_time = time.time()
                
                # Training
                train_metrics = self.train_epoch()
                
                # Validation
                if epoch % eval_every == 0:
                    val_metrics = self.validate_epoch()
                else:
                    val_metrics = {}
                
                # Update scheduler
                if self.scheduler:
                    self.scheduler.step()
                
                # Logging
                epoch_time = time.time() - epoch_start_time
                self.logger.info(f"Epoch {epoch} completed in {epoch_time:.2f}s")
                self.logger.info(f"Train Loss: {train_metrics.get('total_loss', 0):.4f}")
                
                if val_metrics:
                    self.logger.info(f"Val Loss: {val_metrics.get('total_loss', 0):.4f}")
                    self.logger.info(f"Val Accuracy: {val_metrics.get('accuracy', 0):.4f}")
                
                # Tensorboard logging
                for key, value in train_metrics.items():
                    self.writer.add_scalar(f"Train/{key}", value, epoch)
                
                for key, value in val_metrics.items():
                    self.writer.add_scalar(f"Val/{key}", value, epoch)
                
                # Wandb logging
                if WANDB_AVAILABLE and hasattr(self, 'wandb_run'):
                    log_dict = {f"train_{k}": v for k, v in train_metrics.items()}
                    log_dict.update({f"val_{k}": v for k, v in val_metrics.items()})
                    log_dict['epoch'] = epoch
                    wandb.log(log_dict)
                
                # Check for improvement
                current_accuracy = val_metrics.get('accuracy', 0)
                current_map = val_metrics.get('map_50', 0)
                
                is_best = False
                if current_accuracy > self.best_accuracy:
                    self.best_accuracy = current_accuracy
                    is_best = True
                    patience_counter = 0
                else:
                    patience_counter += 1
                
                if current_map > self.best_map:
                    self.best_map = current_map
                
                # Save checkpoint
                if epoch % save_every == 0 or is_best:
                    all_metrics = {**train_metrics, **val_metrics}
                    self.save_checkpoint(epoch, all_metrics, is_best)
                
                # Early stopping
                if patience_counter >= early_stopping_patience:
                    self.logger.info(f"Early stopping triggered after {patience_counter} epochs without improvement")
                    break
                
                # Target accuracy reached
                if current_accuracy >= target_accuracy:
                    self.logger.info(f"Target accuracy {target_accuracy:.2%} reached! Current: {current_accuracy:.2%}")
                    break
                
                # Store training history
                self.training_history.append({
                    'epoch': epoch,
                    'train_metrics': train_metrics,
                    'val_metrics': val_metrics,
                    'epoch_time': epoch_time
                })
        
        except KeyboardInterrupt:
            self.logger.info("Training interrupted by user")
        except Exception as e:
            self.logger.error(f"Training failed: {e}")
            raise
        finally:
            # Save final checkpoint
            if val_metrics:
                all_metrics = {**train_metrics, **val_metrics}
                self.save_checkpoint(self.current_epoch, all_metrics)
            
            # Save training history
            history_file = self.output_dir / f"training_history_{self.image_type.lower()}.json"
            with open(history_file, 'w') as f:
                json.dump(self.training_history, f, indent=2)
            
            self.writer.close()
            
            if WANDB_AVAILABLE and hasattr(self, 'wandb_run'):
                wandb.finish()
        
        self.logger.info(f"Training completed for {self.image_type}")
        self.logger.info(f"Best accuracy: {self.best_accuracy:.4f}")
        self.logger.info(f"Best mAP: {self.best_map:.4f}")
        
        return {
            'best_accuracy': self.best_accuracy,
            'best_map': self.best_map,
            'final_epoch': self.current_epoch,
            'training_history': self.training_history
        }

def main():
    """Main training function"""
    print("DINO Trainer for Photomask Defect Detection")
    print("=" * 50)
    
    # Example usage
    from dino_config import DINOConfig
    
    # Create configuration
    config_manager = DINOConfig(backbone="resnet50")
    model_config = config_manager.get_model_config()
    
    # Data configuration
    data_config = {
        'processed_data_dir': './processed_data'
    }
    
    # Train EV model
    print("Training EV model...")
    ev_trainer = DINOTrainer(model_config, "EV", "./models")
    
    # Note: This would require actual processed data to run
    # ev_results = ev_trainer.train(data_config)
    
    print("Trainer ready for use!")
    print("Usage:")
    print("1. Process your data with data_preprocessor.py")
    print("2. Configure the model with dino_config.py")
    print("3. Run training with this trainer")

if __name__ == "__main__":
    main()

