#!/usr/bin/env python3
"""
Main Training Script for Photomask Defect Detection
Trains both EV and SV models using DINO architecture
"""

import os
import sys
import json
import argparse
import logging
from pathlib import Path
from typing import Dict, Any

import torch

from dino_config import DINOConfig, create_config_files
from dino_trainer import DINOTrainer
from data_preprocessor import PhotomaskDataPreprocessor
from xml_parser import PhotomaskAnnotationParser

def setup_logging(log_level: str = "INFO"):
    """Setup logging configuration"""
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_dir / "main_training.log"),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger("MainTraining")

def check_system_requirements(logger):
    """Check system requirements"""
    logger.info("Checking system requirements...")
    
    # Check CUDA
    if not torch.cuda.is_available():
        logger.error("CUDA not available. GPU training required.")
        return False
    
    # Check VRAM
    gpu_memory = torch.cuda.get_device_properties(0).total_memory / (1024**3)
    logger.info(f"Available VRAM: {gpu_memory:.1f} GB")
    
    if gpu_memory < 10.5:
        logger.warning(f"Low VRAM detected: {gpu_memory:.1f} GB. Training may be limited.")
    
    # Check required packages
    required_packages = ['torch', 'transformers', 'albumentations', 'cv2']
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        logger.error(f"Missing required packages: {missing_packages}")
        logger.error("Please run: pip install -r requirements.txt")
        return False
    
    logger.info("✅ System requirements check passed")
    return True

def validate_data_structure(data_root: str, logger) -> bool:
    """Validate data directory structure"""
    logger.info("Validating data structure...")
    
    required_dirs = [
        os.path.join(data_root, "DS0", "EV"),
        os.path.join(data_root, "DS0", "SV"),
        os.path.join(data_root, "MSA_Sort3", "EV"),
        os.path.join(data_root, "MSA_Sort3", "SV")
    ]
    
    missing_dirs = []
    for dir_path in required_dirs:
        if not os.path.exists(dir_path):
            missing_dirs.append(dir_path)
    
    if missing_dirs:
        logger.error("Missing required directories:")
        for dir_path in missing_dirs:
            logger.error(f"  - {dir_path}")
        return False
    
    # Check for XML and image files
    parser = PhotomaskAnnotationParser()
    
    for image_type in ['EV', 'SV']:
        for split in ['DS0', 'MSA_Sort3']:
            data_dir = os.path.join(data_root, split)
            annotations = parser.parse_dataset_directory(data_dir, image_type)
            
            if not annotations:
                logger.warning(f"No valid annotations found in {data_dir}/{image_type}")
            else:
                logger.info(f"Found {len(annotations)} annotations in {data_dir}/{image_type}")
    
    logger.info("✅ Data structure validation completed")
    return True

def preprocess_data(data_root: str, output_dir: str, logger) -> bool:
    """Preprocess data for training"""
    logger.info("Starting data preprocessing...")
    
    try:
        preprocessor = PhotomaskDataPreprocessor(data_root, output_dir)
        
        # Process both EV and SV datasets
        for image_type in ['EV', 'SV']:
            logger.info(f"Processing {image_type} dataset...")
            results = preprocessor.create_dataset_splits(image_type)
            
            if not results:
                logger.error(f"Failed to process {image_type} dataset")
                return False
            
            logger.info(f"✅ {image_type} dataset processed successfully")
        
        # Generate report
        report = preprocessor.generate_dataset_report()
        
        # Log summary
        logger.info("Dataset Summary:")
        for image_type, stats in report['summary'].items():
            logger.info(f"  {image_type.upper()}: {stats['images']} images, {stats['annotations']} objects")
        
        # Check for issues
        if report['issues']:
            logger.warning("Issues found:")
            for issue in report['issues']:
                logger.warning(f"  - {issue}")
        
        if report['recommendations']:
            logger.info("Recommendations:")
            for rec in report['recommendations']:
                logger.info(f"  - {rec}")
        
        logger.info("✅ Data preprocessing completed")
        return True
        
    except Exception as e:
        logger.error(f"Data preprocessing failed: {e}")
        return False

def train_model(image_type: str, config: Dict, data_config: Dict, logger) -> Dict[str, Any]:
    """Train a single model"""
    logger.info(f"Starting training for {image_type} model...")
    
    try:
        trainer = DINOTrainer(config, image_type, config.get('output_dir', './models'))
        results = trainer.train(data_config)
        
        logger.info(f"✅ {image_type} model training completed")
        logger.info(f"  Best accuracy: {results['best_accuracy']:.4f}")
        logger.info(f"  Best mAP: {results['best_map']:.4f}")
        logger.info(f"  Final epoch: {results['final_epoch']}")
        
        return results
        
    except Exception as e:
        logger.error(f"Training failed for {image_type} model: {e}")
        raise

def main():
    """Main training function"""
    parser = argparse.ArgumentParser(description="Train DINO models for photomask defect detection")
    parser.add_argument("--data_root", type=str, default="D/Photomask", 
                       help="Root directory containing the dataset")
    parser.add_argument("--output_dir", type=str, default="./models",
                       help="Output directory for trained models")
    parser.add_argument("--processed_data_dir", type=str, default="./processed_data",
                       help="Directory for processed data")
    parser.add_argument("--backbone", type=str, default="resnet50", 
                       choices=["resnet50", "swin_tiny"],
                       help="Model backbone to use")
    parser.add_argument("--batch_size", type=int, default=None,
                       help="Batch size (overrides config)")
    parser.add_argument("--learning_rate", type=float, default=None,
                       help="Learning rate (overrides config)")
    parser.add_argument("--num_epochs", type=int, default=None,
                       help="Number of epochs (overrides config)")
    parser.add_argument("--target_accuracy", type=float, default=0.90,
                       help="Target accuracy to achieve")
    parser.add_argument("--skip_preprocessing", action="store_true",
                       help="Skip data preprocessing step")
    parser.add_argument("--train_only", type=str, choices=["EV", "SV"],
                       help="Train only specified model type")
    parser.add_argument("--resume", type=str, default=None,
                       help="Resume training from checkpoint")
    parser.add_argument("--log_level", type=str, default="INFO",
                       choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                       help="Logging level")
    
    args = parser.parse_args()
    
    # Setup logging
    logger = setup_logging(args.log_level)
    
    logger.info("=" * 60)
    logger.info("DINO Photomask Defect Detection Training")
    logger.info("=" * 60)
    logger.info(f"Data root: {args.data_root}")
    logger.info(f"Output directory: {args.output_dir}")
    logger.info(f"Backbone: {args.backbone}")
    logger.info(f"Target accuracy: {args.target_accuracy:.2%}")
    
    # Check system requirements
    if not check_system_requirements(logger):
        logger.error("System requirements not met. Exiting.")
        sys.exit(1)
    
    # Validate data structure
    if not validate_data_structure(args.data_root, logger):
        logger.error("Data validation failed. Please check your data structure.")
        sys.exit(1)
    
    # Data preprocessing
    if not args.skip_preprocessing:
        if not preprocess_data(args.data_root, args.processed_data_dir, logger):
            logger.error("Data preprocessing failed. Exiting.")
            sys.exit(1)
    else:
        logger.info("Skipping data preprocessing as requested")
    
    # Create model configurations
    logger.info("Creating model configurations...")
    config_manager = DINOConfig(backbone=args.backbone)
    model_config = config_manager.get_model_config()
    
    # Override config with command line arguments
    if args.batch_size is not None:
        model_config['batch_size'] = args.batch_size
    if args.learning_rate is not None:
        model_config['learning_rate'] = args.learning_rate
    if args.num_epochs is not None:
        model_config['num_epochs'] = args.num_epochs
    
    model_config['target_accuracy'] = args.target_accuracy
    model_config['output_dir'] = args.output_dir
    
    # Data configuration
    data_config = {
        'processed_data_dir': args.processed_data_dir
    }
    
    # Create output directory
    Path(args.output_dir).mkdir(exist_ok=True)
    
    # Save configuration
    config_file = os.path.join(args.output_dir, "training_config.json")
    with open(config_file, 'w') as f:
        json.dump({
            'model_config': model_config,
            'data_config': data_config,
            'args': vars(args)
        }, f, indent=2)
    logger.info(f"Configuration saved to {config_file}")
    
    # Training
    training_results = {}
    
    # Determine which models to train
    models_to_train = ['EV', 'SV']
    if args.train_only:
        models_to_train = [args.train_only]
    
    try:
        for image_type in models_to_train:
            logger.info(f"\n{'='*20} Training {image_type} Model {'='*20}")
            
            # Train model
            results = train_model(image_type, model_config, data_config, logger)
            training_results[image_type] = results
            
            # Check if target accuracy achieved
            if results['best_accuracy'] >= args.target_accuracy:
                logger.info(f"🎉 {image_type} model achieved target accuracy!")
            else:
                logger.warning(f"⚠️  {image_type} model did not reach target accuracy")
                logger.warning(f"   Target: {args.target_accuracy:.2%}, Achieved: {results['best_accuracy']:.2%}")
    
    except KeyboardInterrupt:
        logger.info("Training interrupted by user")
    except Exception as e:
        logger.error(f"Training failed: {e}")
        sys.exit(1)
    
    # Final summary
    logger.info("\n" + "="*60)
    logger.info("TRAINING SUMMARY")
    logger.info("="*60)
    
    for image_type, results in training_results.items():
        logger.info(f"\n{image_type} Model:")
        logger.info(f"  Best Accuracy: {results['best_accuracy']:.4f}")
        logger.info(f"  Best mAP: {results['best_map']:.4f}")
        logger.info(f"  Training Epochs: {results['final_epoch']}")
        logger.info(f"  Target Achieved: {'✅' if results['best_accuracy'] >= args.target_accuracy else '❌'}")
    
    # Save final results
    results_file = os.path.join(args.output_dir, "training_results.json")
    with open(results_file, 'w') as f:
        json.dump(training_results, f, indent=2)
    
    logger.info(f"\nTraining results saved to: {results_file}")
    logger.info("Training completed successfully! 🎉")
    
    # Next steps
    logger.info("\nNext steps:")
    logger.info("1. Evaluate models on test data")
    logger.info("2. Fine-tune hyperparameters if needed")
    logger.info("3. Deploy models for inference")

if __name__ == "__main__":
    main()

