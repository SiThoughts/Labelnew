#!/usr/bin/env python3
"""
XML Annotation Parser for Photomask Defect Detection
Parses XML files containing chip and check annotations for glass inspection
"""

import xml.etree.ElementTree as ET
import os
import json
from pathlib import Path
from typing import Dict, List, Tuple, Optional

class PhotomaskAnnotationParser:
    """Parser for photomask XML annotations"""
    
    def __init__(self):
        self.class_mapping = {
            'chip': 0,
            'check': 1
        }
        
    def parse_xml_file(self, xml_path: str) -> Optional[Dict]:
        """
        Parse a single XML annotation file
        
        Args:
            xml_path: Path to XML file
            
        Returns:
            Dictionary containing parsed annotation data
        """
        try:
            tree = ET.parse(xml_path)
            root = tree.getroot()
            
            # Extract image information
            annotation_data = {
                'xml_filename': os.path.basename(xml_path),
                'image_filename': None,  # Will be derived from XML filename
                'width': 0,
                'height': 0,
                'objects': []
            }
            
            # Get image dimensions
            size_elem = root.find('size')
            if size_elem is not None:
                width_elem = size_elem.find('width')
                height_elem = size_elem.find('height')
                if width_elem is not None:
                    annotation_data['width'] = int(width_elem.text)
                if height_elem is not None:
                    annotation_data['height'] = int(height_elem.text)
            
            # Parse objects (chips and checks)
            for obj in root.findall('object'):
                name_elem = obj.find('name')
                if name_elem is None:
                    continue
                    
                class_name = name_elem.text.lower()
                if class_name not in self.class_mapping:
                    continue
                
                # Get bounding box
                bndbox = obj.find('bndbox')
                if bndbox is None:
                    continue
                
                xmin = int(float(bndbox.find('xmin').text))
                ymin = int(float(bndbox.find('ymin').text))
                xmax = int(float(bndbox.find('xmax').text))
                ymax = int(float(bndbox.find('ymax').text))
                
                # Calculate width and height
                bbox_width = xmax - xmin
                bbox_height = ymax - ymin
                
                # Skip invalid bounding boxes
                if bbox_width <= 0 or bbox_height <= 0:
                    continue
                
                obj_data = {
                    'class_name': class_name,
                    'class_id': self.class_mapping[class_name],
                    'bbox': [xmin, ymin, bbox_width, bbox_height],  # COCO format: [x, y, width, height]
                    'bbox_xyxy': [xmin, ymin, xmax, ymax],  # [x1, y1, x2, y2] format
                    'area': bbox_width * bbox_height
                }
                
                # Check for additional attributes
                pose_elem = obj.find('pose')
                truncated_elem = obj.find('truncated')
                difficult_elem = obj.find('difficult')
                
                if pose_elem is not None:
                    obj_data['pose'] = pose_elem.text
                if truncated_elem is not None:
                    obj_data['truncated'] = int(truncated_elem.text)
                if difficult_elem is not None:
                    obj_data['difficult'] = int(difficult_elem.text)
                
                annotation_data['objects'].append(obj_data)
            
            return annotation_data
            
        except Exception as e:
            print(f"Error parsing XML file {xml_path}: {str(e)}")
            return None
    
    def get_image_filename_from_xml(self, xml_path: str) -> str:
        """
        Get corresponding image filename from XML filename
        Since the filename in XML is wrong, we use the XML base name
        """
        xml_basename = os.path.splitext(os.path.basename(xml_path))[0]
        # Common image extensions to try
        for ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif']:
            return xml_basename + ext
        return xml_basename + '.jpg'  # Default fallback
    
    def find_matching_image(self, xml_path: str, image_dir: str) -> Optional[str]:
        """
        Find the matching image file for an XML annotation
        
        Args:
            xml_path: Path to XML file
            image_dir: Directory containing images
            
        Returns:
            Path to matching image file or None if not found
        """
        xml_basename = os.path.splitext(os.path.basename(xml_path))[0]
        
        # Try different extensions
        for ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif']:
            image_path = os.path.join(image_dir, xml_basename + ext)
            if os.path.exists(image_path):
                return image_path
        
        return None
    
    def parse_dataset_directory(self, data_dir: str, image_type: str = 'EV') -> List[Dict]:
        """
        Parse all XML files in a dataset directory
        
        Args:
            data_dir: Path to dataset directory (should contain EV or SV subdirectory)
            image_type: 'EV' or 'SV'
            
        Returns:
            List of parsed annotation dictionaries
        """
        dataset_path = os.path.join(data_dir, image_type)
        if not os.path.exists(dataset_path):
            print(f"Dataset path {dataset_path} does not exist")
            return []
        
        annotations = []
        xml_files = list(Path(dataset_path).glob('*.xml'))
        
        print(f"Found {len(xml_files)} XML files in {dataset_path}")
        
        for xml_file in xml_files:
            annotation = self.parse_xml_file(str(xml_file))
            if annotation is not None:
                # Find matching image
                image_path = self.find_matching_image(str(xml_file), dataset_path)
                if image_path:
                    annotation['image_path'] = image_path
                    annotation['image_filename'] = os.path.basename(image_path)
                    annotations.append(annotation)
                else:
                    print(f"Warning: No matching image found for {xml_file}")
        
        return annotations
    
    def convert_to_coco_format(self, annotations: List[Dict], dataset_name: str = "photomask") -> Dict:
        """
        Convert annotations to COCO format
        
        Args:
            annotations: List of parsed annotations
            dataset_name: Name of the dataset
            
        Returns:
            COCO format dictionary
        """
        coco_data = {
            "info": {
                "description": f"Photomask {dataset_name} Dataset",
                "version": "1.0",
                "year": 2024,
                "contributor": "Photomask Detection System",
                "date_created": "2024-01-01"
            },
            "licenses": [
                {
                    "id": 1,
                    "name": "Custom License",
                    "url": ""
                }
            ],
            "images": [],
            "annotations": [],
            "categories": [
                {"id": 0, "name": "chip", "supercategory": "defect"},
                {"id": 1, "name": "check", "supercategory": "defect"}
            ]
        }
        
        image_id = 0
        annotation_id = 0
        
        for ann in annotations:
            if 'image_path' not in ann:
                continue
                
            # Add image info
            image_info = {
                "id": image_id,
                "width": ann['width'],
                "height": ann['height'],
                "file_name": ann['image_filename'],
                "license": 1,
                "flickr_url": "",
                "coco_url": "",
                "date_captured": ""
            }
            coco_data["images"].append(image_info)
            
            # Add annotations for this image
            for obj in ann['objects']:
                annotation_info = {
                    "id": annotation_id,
                    "image_id": image_id,
                    "category_id": obj['class_id'],
                    "segmentation": [],  # We don't have segmentation data
                    "area": obj['area'],
                    "bbox": obj['bbox'],  # [x, y, width, height]
                    "iscrowd": 0
                }
                coco_data["annotations"].append(annotation_info)
                annotation_id += 1
            
            image_id += 1
        
        return coco_data
    
    def validate_dataset(self, data_dir: str) -> Dict[str, any]:
        """
        Validate dataset structure and content
        
        Args:
            data_dir: Path to dataset directory
            
        Returns:
            Validation report
        """
        report = {
            'ev_data': {'xml_count': 0, 'image_count': 0, 'matched_pairs': 0, 'total_objects': 0},
            'sv_data': {'xml_count': 0, 'image_count': 0, 'matched_pairs': 0, 'total_objects': 0},
            'class_distribution': {'chip': 0, 'check': 0},
            'issues': []
        }
        
        for image_type in ['EV', 'SV']:
            type_dir = os.path.join(data_dir, image_type)
            if not os.path.exists(type_dir):
                report['issues'].append(f"Directory {type_dir} does not exist")
                continue
            
            # Count files
            xml_files = list(Path(type_dir).glob('*.xml'))
            image_files = []
            for ext in ['*.jpg', '*.jpeg', '*.png', '*.bmp', '*.tiff', '*.tif']:
                image_files.extend(list(Path(type_dir).glob(ext)))
            
            key = f"{image_type.lower()}_data"
            report[key]['xml_count'] = len(xml_files)
            report[key]['image_count'] = len(image_files)
            
            # Parse annotations and count objects
            annotations = self.parse_dataset_directory(data_dir, image_type)
            report[key]['matched_pairs'] = len(annotations)
            
            for ann in annotations:
                report[key]['total_objects'] += len(ann['objects'])
                for obj in ann['objects']:
                    report['class_distribution'][obj['class_name']] += 1
        
        return report

def main():
    """Test the parser with sample data"""
    parser = PhotomaskAnnotationParser()
    
    # Example usage - replace with actual paths
    print("Photomask Annotation Parser")
    print("=" * 50)
    
    # Test with sample data structure
    sample_dirs = [
        "D/Photomask/DS0",
        "D/Photomask/MSA_Sort3"
    ]
    
    for data_dir in sample_dirs:
        if os.path.exists(data_dir):
            print(f"\nValidating dataset: {data_dir}")
            report = parser.validate_dataset(data_dir)
            print(json.dumps(report, indent=2))
        else:
            print(f"\nDataset directory {data_dir} not found")
    
    print("\nParser ready for use!")

if __name__ == "__main__":
    main()

