#!/usr/bin/env python3
"""
Model Evaluation Script for Photomask Defect Detection
Evaluates trained DINO models and generates performance reports
"""

import os
import json
import argparse
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Any
import numpy as np
from collections import defaultdict

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt
import seaborn as sns

try:
    from transformers import DetrForObjectDetection
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False

from photomask_dataset import PhotomaskDataset, create_transforms, collate_fn
from dino_config import DINOConfig

class ModelEvaluator:
    """Evaluator for trained DINO models"""
    
    def __init__(self, model_path: str, config: Dict, device: str = None):
        self.model_path = model_path
        self.config = config
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        
        # Setup logging
        self.logger = logging.getLogger(f"Evaluator_{Path(model_path).stem}")
        
        # Load model
        self.model = self.load_model()
        self.model.eval()
        
        # Class names
        self.class_names = ['chip', 'check']
        self.num_classes = len(self.class_names)
        
        # Evaluation results
        self.results = {
            'predictions': [],
            'targets': [],
            'metrics': {},
            'per_class_metrics': {},
            'confusion_matrix': None
        }
    
    def load_model(self):
        """Load trained model from checkpoint"""
        self.logger.info(f"Loading model from {self.model_path}")
        
        if not TRANSFORMERS_AVAILABLE:
            raise ImportError("transformers library required for model loading")
        
        # Load checkpoint
        checkpoint = torch.load(self.model_path, map_location=self.device)
        
        # Initialize model
        model_name = self.config.get('model_name', 'facebook/detr-resnet-50')
        model = DetrForObjectDetection.from_pretrained(
            model_name,
            num_labels=self.num_classes,
            ignore_mismatched_sizes=True
        )
        
        # Load state dict
        model.load_state_dict(checkpoint['model_state_dict'])
        model.to(self.device)
        
        self.logger.info("Model loaded successfully")
        return model
    
    def preprocess_predictions(self, outputs, targets, confidence_threshold: float = 0.5):
        """Preprocess model outputs for evaluation"""
        predictions = []
        
        # Process each image in the batch
        for i, (logits, boxes) in enumerate(zip(outputs.logits, outputs.pred_boxes)):
            # Apply softmax to get probabilities
            probs = F.softmax(logits, dim=-1)
            
            # Get confidence scores (max probability excluding background)
            scores, labels = probs[:, :-1].max(dim=-1)  # Exclude background class
            
            # Filter by confidence threshold
            keep = scores > confidence_threshold
            
            if keep.sum() > 0:
                pred_boxes = boxes[keep]
                pred_labels = labels[keep]
                pred_scores = scores[keep]
                
                predictions.append({
                    'boxes': pred_boxes.cpu().numpy(),
                    'labels': pred_labels.cpu().numpy(),
                    'scores': pred_scores.cpu().numpy()
                })
            else:
                predictions.append({
                    'boxes': np.array([]).reshape(0, 4),
                    'labels': np.array([]),
                    'scores': np.array([])
                })
        
        return predictions
    
    def calculate_iou(self, box1: np.ndarray, box2: np.ndarray) -> float:
        """Calculate IoU between two bounding boxes"""
        # Convert from center format to corner format if needed
        if box1.shape[-1] == 4 and box2.shape[-1] == 4:
            # Assume format is [x_center, y_center, width, height]
            x1_min = box1[0] - box1[2] / 2
            y1_min = box1[1] - box1[3] / 2
            x1_max = box1[0] + box1[2] / 2
            y1_max = box1[1] + box1[3] / 2
            
            x2_min = box2[0] - box2[2] / 2
            y2_min = box2[1] - box2[3] / 2
            x2_max = box2[0] + box2[2] / 2
            y2_max = box2[1] + box2[3] / 2
        else:
            x1_min, y1_min, x1_max, y1_max = box1
            x2_min, y2_min, x2_max, y2_max = box2
        
        # Calculate intersection
        inter_x_min = max(x1_min, x2_min)
        inter_y_min = max(y1_min, y2_min)
        inter_x_max = min(x1_max, x2_max)
        inter_y_max = min(y1_max, y2_max)
        
        if inter_x_max <= inter_x_min or inter_y_max <= inter_y_min:
            return 0.0
        
        inter_area = (inter_x_max - inter_x_min) * (inter_y_max - inter_y_min)
        
        # Calculate union
        box1_area = (x1_max - x1_min) * (y1_max - y1_min)
        box2_area = (x2_max - x2_min) * (y2_max - y2_min)
        union_area = box1_area + box2_area - inter_area
        
        return inter_area / union_area if union_area > 0 else 0.0
    
    def calculate_metrics(self, predictions: List[Dict], targets: List[Dict], iou_threshold: float = 0.5) -> Dict[str, float]:
        """Calculate evaluation metrics"""
        true_positives = defaultdict(int)
        false_positives = defaultdict(int)
        false_negatives = defaultdict(int)
        
        all_pred_scores = []
        all_pred_labels = []
        all_true_labels = []
        
        for pred, target in zip(predictions, targets):
            pred_boxes = pred['boxes']
            pred_labels = pred['labels']
            pred_scores = pred['scores']
            
            target_boxes = target['boxes'].cpu().numpy() if isinstance(target['boxes'], torch.Tensor) else target['boxes']
            target_labels = target['labels'].cpu().numpy() if isinstance(target['labels'], torch.Tensor) else target['labels']
            
            # Track which ground truth boxes have been matched
            matched_gt = set()
            
            # For each prediction
            for i, (pred_box, pred_label, pred_score) in enumerate(zip(pred_boxes, pred_labels, pred_scores)):
                all_pred_scores.append(pred_score)
                all_pred_labels.append(pred_label)
                
                best_iou = 0
                best_gt_idx = -1
                
                # Find best matching ground truth box
                for j, (gt_box, gt_label) in enumerate(zip(target_boxes, target_labels)):
                    if gt_label == pred_label and j not in matched_gt:
                        iou = self.calculate_iou(pred_box, gt_box)
                        if iou > best_iou:
                            best_iou = iou
                            best_gt_idx = j
                
                # Check if it's a true positive
                if best_iou >= iou_threshold and best_gt_idx != -1:
                    true_positives[pred_label] += 1
                    matched_gt.add(best_gt_idx)
                else:
                    false_positives[pred_label] += 1
            
            # Count false negatives (unmatched ground truth boxes)
            for j, gt_label in enumerate(target_labels):
                if j not in matched_gt:
                    false_negatives[gt_label] += 1
                all_true_labels.append(gt_label)
        
        # Calculate metrics per class
        per_class_metrics = {}
        overall_tp = 0
        overall_fp = 0
        overall_fn = 0
        
        for class_id in range(self.num_classes):
            tp = true_positives[class_id]
            fp = false_positives[class_id]
            fn = false_negatives[class_id]
            
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
            
            per_class_metrics[self.class_names[class_id]] = {
                'precision': precision,
                'recall': recall,
                'f1_score': f1,
                'true_positives': tp,
                'false_positives': fp,
                'false_negatives': fn
            }
            
            overall_tp += tp
            overall_fp += fp
            overall_fn += fn
        
        # Overall metrics
        overall_precision = overall_tp / (overall_tp + overall_fp) if (overall_tp + overall_fp) > 0 else 0.0
        overall_recall = overall_tp / (overall_tp + overall_fn) if (overall_tp + overall_fn) > 0 else 0.0
        overall_f1 = 2 * overall_precision * overall_recall / (overall_precision + overall_recall) if (overall_precision + overall_recall) > 0 else 0.0
        overall_accuracy = overall_tp / (overall_tp + overall_fp + overall_fn) if (overall_tp + overall_fp + overall_fn) > 0 else 0.0
        
        metrics = {
            'accuracy': overall_accuracy,
            'precision': overall_precision,
            'recall': overall_recall,
            'f1_score': overall_f1,
            'map_50': self.calculate_map(predictions, targets, iou_threshold=0.5),
            'map_75': self.calculate_map(predictions, targets, iou_threshold=0.75),
            'per_class': per_class_metrics
        }
        
        return metrics
    
    def calculate_map(self, predictions: List[Dict], targets: List[Dict], iou_threshold: float = 0.5) -> float:
        """Calculate mean Average Precision (simplified implementation)"""
        # This is a simplified mAP calculation
        # For production use, consider using official COCO evaluation tools
        
        ap_scores = []
        
        for class_id in range(self.num_classes):
            # Collect all predictions and targets for this class
            class_predictions = []
            class_targets = []
            
            for pred, target in zip(predictions, targets):
                # Filter predictions for this class
                class_mask = pred['labels'] == class_id
                if class_mask.sum() > 0:
                    class_predictions.extend([
                        {
                            'box': box,
                            'score': score
                        }
                        for box, score in zip(pred['boxes'][class_mask], pred['scores'][class_mask])
                    ])
                
                # Filter targets for this class
                target_labels = target['labels'].cpu().numpy() if isinstance(target['labels'], torch.Tensor) else target['labels']
                target_boxes = target['boxes'].cpu().numpy() if isinstance(target['boxes'], torch.Tensor) else target['boxes']
                
                class_target_mask = target_labels == class_id
                if class_target_mask.sum() > 0:
                    class_targets.extend([
                        {'box': box}
                        for box in target_boxes[class_target_mask]
                    ])
            
            if not class_targets:
                continue
            
            # Sort predictions by confidence
            class_predictions.sort(key=lambda x: x['score'], reverse=True)
            
            # Calculate precision-recall curve
            tp = 0
            fp = 0
            precisions = []
            recalls = []
            
            for pred in class_predictions:
                # Find best matching target
                best_iou = 0
                for target in class_targets:
                    iou = self.calculate_iou(pred['box'], target['box'])
                    best_iou = max(best_iou, iou)
                
                if best_iou >= iou_threshold:
                    tp += 1
                else:
                    fp += 1
                
                precision = tp / (tp + fp)
                recall = tp / len(class_targets)
                
                precisions.append(precision)
                recalls.append(recall)
            
            # Calculate AP using trapezoidal rule (simplified)
            if precisions and recalls:
                ap = np.trapz(precisions, recalls)
                ap_scores.append(ap)
        
        return np.mean(ap_scores) if ap_scores else 0.0
    
    def evaluate_dataset(self, dataset: PhotomaskDataset, batch_size: int = 4) -> Dict[str, Any]:
        """Evaluate model on dataset"""
        self.logger.info(f"Evaluating on dataset with {len(dataset)} samples")
        
        dataloader = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=2,
            collate_fn=collate_fn
        )
        
        all_predictions = []
        all_targets = []
        
        with torch.no_grad():
            for batch_idx, batch in enumerate(dataloader):
                images = batch['images'].to(self.device)
                targets = batch['targets']
                
                # Forward pass
                outputs = self.model(pixel_values=images)
                
                # Process predictions
                batch_predictions = self.preprocess_predictions(outputs, targets)
                
                all_predictions.extend(batch_predictions)
                all_targets.extend(targets)
                
                if batch_idx % 10 == 0:
                    self.logger.info(f"Processed {batch_idx * batch_size}/{len(dataset)} samples")
        
        # Calculate metrics
        metrics = self.calculate_metrics(all_predictions, all_targets)
        
        self.results['predictions'] = all_predictions
        self.results['targets'] = all_targets
        self.results['metrics'] = metrics
        
        return metrics
    
    def generate_report(self, output_dir: str):
        """Generate evaluation report"""
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        metrics = self.results['metrics']
        
        # Text report
        report_file = output_path / "evaluation_report.txt"
        with open(report_file, 'w') as f:
            f.write("DINO Model Evaluation Report\n")
            f.write("=" * 50 + "\n\n")
            
            f.write("Overall Metrics:\n")
            f.write(f"  Accuracy: {metrics['accuracy']:.4f}\n")
            f.write(f"  Precision: {metrics['precision']:.4f}\n")
            f.write(f"  Recall: {metrics['recall']:.4f}\n")
            f.write(f"  F1-Score: {metrics['f1_score']:.4f}\n")
            f.write(f"  mAP@0.5: {metrics['map_50']:.4f}\n")
            f.write(f"  mAP@0.75: {metrics['map_75']:.4f}\n\n")
            
            f.write("Per-Class Metrics:\n")
            for class_name, class_metrics in metrics['per_class'].items():
                f.write(f"  {class_name}:\n")
                f.write(f"    Precision: {class_metrics['precision']:.4f}\n")
                f.write(f"    Recall: {class_metrics['recall']:.4f}\n")
                f.write(f"    F1-Score: {class_metrics['f1_score']:.4f}\n")
                f.write(f"    True Positives: {class_metrics['true_positives']}\n")
                f.write(f"    False Positives: {class_metrics['false_positives']}\n")
                f.write(f"    False Negatives: {class_metrics['false_negatives']}\n\n")
        
        # JSON report
        json_file = output_path / "evaluation_metrics.json"
        with open(json_file, 'w') as f:
            json.dump(metrics, f, indent=2)
        
        # Visualization
        self.create_visualizations(output_path)
        
        self.logger.info(f"Evaluation report saved to {output_path}")
    
    def create_visualizations(self, output_dir: Path):
        """Create evaluation visualizations"""
        metrics = self.results['metrics']
        
        # Metrics bar chart
        plt.figure(figsize=(12, 8))
        
        # Overall metrics
        plt.subplot(2, 2, 1)
        overall_metrics = ['accuracy', 'precision', 'recall', 'f1_score', 'map_50', 'map_75']
        values = [metrics[metric] for metric in overall_metrics]
        
        bars = plt.bar(overall_metrics, values)
        plt.title('Overall Metrics')
        plt.ylabel('Score')
        plt.xticks(rotation=45)
        plt.ylim(0, 1)
        
        # Add value labels on bars
        for bar, value in zip(bars, values):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                    f'{value:.3f}', ha='center', va='bottom')
        
        # Per-class precision
        plt.subplot(2, 2, 2)
        class_names = list(metrics['per_class'].keys())
        precisions = [metrics['per_class'][name]['precision'] for name in class_names]
        
        bars = plt.bar(class_names, precisions)
        plt.title('Per-Class Precision')
        plt.ylabel('Precision')
        plt.ylim(0, 1)
        
        for bar, value in zip(bars, precisions):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                    f'{value:.3f}', ha='center', va='bottom')
        
        # Per-class recall
        plt.subplot(2, 2, 3)
        recalls = [metrics['per_class'][name]['recall'] for name in class_names]
        
        bars = plt.bar(class_names, recalls)
        plt.title('Per-Class Recall')
        plt.ylabel('Recall')
        plt.ylim(0, 1)
        
        for bar, value in zip(bars, recalls):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                    f'{value:.3f}', ha='center', va='bottom')
        
        # Per-class F1-score
        plt.subplot(2, 2, 4)
        f1_scores = [metrics['per_class'][name]['f1_score'] for name in class_names]
        
        bars = plt.bar(class_names, f1_scores)
        plt.title('Per-Class F1-Score')
        plt.ylabel('F1-Score')
        plt.ylim(0, 1)
        
        for bar, value in zip(bars, f1_scores):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                    f'{value:.3f}', ha='center', va='bottom')
        
        plt.tight_layout()
        plt.savefig(output_dir / "metrics_visualization.png", dpi=300, bbox_inches='tight')
        plt.close()
        
        self.logger.info("Visualizations saved")

def main():
    """Main evaluation function"""
    parser = argparse.ArgumentParser(description="Evaluate trained DINO models")
    parser.add_argument("--model_path", type=str, required=True,
                       help="Path to trained model checkpoint")
    parser.add_argument("--data_dir", type=str, required=True,
                       help="Path to processed validation data directory")
    parser.add_argument("--output_dir", type=str, default="./evaluation_results",
                       help="Output directory for evaluation results")
    parser.add_argument("--batch_size", type=int, default=4,
                       help="Batch size for evaluation")
    parser.add_argument("--confidence_threshold", type=float, default=0.5,
                       help="Confidence threshold for predictions")
    parser.add_argument("--iou_threshold", type=float, default=0.5,
                       help="IoU threshold for evaluation")
    
    args = parser.parse_args()
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("ModelEvaluation")
    
    logger.info("Starting model evaluation...")
    
    # Load configuration
    config_file = Path(args.model_path).parent / "training_config.json"
    if config_file.exists():
        with open(config_file, 'r') as f:
            config = json.load(f)['model_config']
    else:
        # Default configuration
        config_manager = DINOConfig()
        config = config_manager.get_model_config()
    
    # Initialize evaluator
    evaluator = ModelEvaluator(args.model_path, config)
    
    # Load validation dataset
    val_transforms = create_transforms(config, is_training=False)
    
    # Determine image type from model path
    image_type = 'ev' if 'ev' in args.model_path.lower() else 'sv'
    
    val_coco_file = os.path.join(args.data_dir, image_type, 'val', 'annotations', 'train_annotations.json')
    val_images_dir = os.path.join(args.data_dir, image_type, 'val', 'images')
    
    if not os.path.exists(val_coco_file):
        logger.error(f"Validation annotations not found: {val_coco_file}")
        return
    
    val_dataset = PhotomaskDataset(
        coco_file=val_coco_file,
        images_dir=val_images_dir,
        transforms=val_transforms,
        image_size=config.get('image_size', 800)
    )
    
    # Evaluate model
    metrics = evaluator.evaluate_dataset(val_dataset, args.batch_size)
    
    # Print results
    logger.info("\nEvaluation Results:")
    logger.info(f"Accuracy: {metrics['accuracy']:.4f}")
    logger.info(f"Precision: {metrics['precision']:.4f}")
    logger.info(f"Recall: {metrics['recall']:.4f}")
    logger.info(f"F1-Score: {metrics['f1_score']:.4f}")
    logger.info(f"mAP@0.5: {metrics['map_50']:.4f}")
    logger.info(f"mAP@0.75: {metrics['map_75']:.4f}")
    
    # Generate report
    evaluator.generate_report(args.output_dir)
    
    logger.info("Evaluation completed successfully!")

if __name__ == "__main__":
    main()

