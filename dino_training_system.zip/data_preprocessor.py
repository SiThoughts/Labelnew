#!/usr/bin/env python3
"""
Data Preprocessing System for DINO Object Detection Training
Handles XML to COCO conversion, data augmentation, and dataset preparation
"""

import os
import json
import shutil
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Union
import numpy as np
from PIL import Image
import cv2
from xml_parser import PhotomaskAnnotationParser

try:
    import albumentations as A
    from albumentations.pytorch import ToTensorV2
    ALBUMENTATIONS_AVAILABLE = True
except ImportError:
    ALBUMENTATIONS_AVAILABLE = False
    print("Warning: albumentations not available. Using basic augmentations.")

class PhotomaskDataPreprocessor:
    """Data preprocessor for photomask defect detection"""
    
    def __init__(self, data_root: str, output_dir: str = "./processed_data"):
        self.data_root = data_root
        self.output_dir = output_dir
        self.parser = PhotomaskAnnotationParser()
        
        # Create output directories
        Path(output_dir).mkdir(exist_ok=True)
        
        # Statistics
        self.stats = {
            'ev': {'images': 0, 'annotations': 0, 'chips': 0, 'checks': 0},
            'sv': {'images': 0, 'annotations': 0, 'chips': 0, 'checks': 0}
        }
    
    def create_augmentation_pipeline(self, config: Dict) -> Optional[object]:
        """Create data augmentation pipeline"""
        if not ALBUMENTATIONS_AVAILABLE:
            return None
        
        transforms = []
        
        # Resize
        transforms.append(A.LongestMaxSize(max_size=config.get('image_size', 800)))
        transforms.append(A.PadIfNeeded(
            min_height=config.get('image_size', 800),
            min_width=config.get('image_size', 800),
            border_mode=cv2.BORDER_CONSTANT,
            value=0
        ))
        
        # Geometric augmentations
        if config.get('horizontal_flip_prob', 0) > 0:
            transforms.append(A.HorizontalFlip(p=config['horizontal_flip_prob']))
        
        if config.get('vertical_flip_prob', 0) > 0:
            transforms.append(A.VerticalFlip(p=config['vertical_flip_prob']))
        
        if config.get('rotation_degrees', 0) > 0:
            transforms.append(A.Rotate(
                limit=config['rotation_degrees'],
                border_mode=cv2.BORDER_CONSTANT,
                value=0,
                p=0.5
            ))
        
        # Color augmentations
        color_transforms = []
        if config.get('brightness', 0) > 0:
            color_transforms.append(A.RandomBrightness(limit=config['brightness'], p=0.5))
        
        if config.get('contrast', 0) > 0:
            color_transforms.append(A.RandomContrast(limit=config['contrast'], p=0.5))
        
        if config.get('saturation', 0) > 0 or config.get('hue', 0) > 0:
            color_transforms.append(A.HueSaturationValue(
                hue_shift_limit=int(config.get('hue', 0) * 255),
                sat_shift_limit=int(config.get('saturation', 0) * 255),
                val_shift_limit=0,
                p=0.5
            ))
        
        if color_transforms:
            transforms.append(A.OneOf(color_transforms, p=0.5))
        
        # Noise and blur
        transforms.extend([
            A.OneOf([
                A.GaussNoise(var_limit=(10.0, 50.0)),
                A.ISONoise(),
                A.MultiplicativeNoise(),
            ], p=0.2),
            
            A.OneOf([
                A.MotionBlur(blur_limit=3),
                A.MedianBlur(blur_limit=3),
                A.Blur(blur_limit=3),
            ], p=0.1),
        ])
        
        # Normalization
        transforms.append(A.Normalize(
            mean=config.get('normalize_mean', [0.485, 0.456, 0.406]),
            std=config.get('normalize_std', [0.229, 0.224, 0.225])
        ))
        
        return A.Compose(
            transforms,
            bbox_params=A.BboxParams(
                format='coco',
                label_fields=['class_labels'],
                min_visibility=0.3
            )
        )
    
    def validate_image_annotation_pair(self, image_path: str, annotation: Dict) -> bool:
        """Validate image and annotation pair"""
        try:
            # Check if image exists and is readable
            if not os.path.exists(image_path):
                print(f"Warning: Image not found: {image_path}")
                return False
            
            # Load and check image
            image = Image.open(image_path)
            img_width, img_height = image.size
            
            # Check if annotation dimensions match
            if annotation['width'] != img_width or annotation['height'] != img_height:
                print(f"Warning: Dimension mismatch for {image_path}")
                print(f"  Image: {img_width}x{img_height}, Annotation: {annotation['width']}x{annotation['height']}")
                # Update annotation dimensions to match image
                annotation['width'] = img_width
                annotation['height'] = img_height
            
            # Validate bounding boxes
            valid_objects = []
            for obj in annotation['objects']:
                x, y, w, h = obj['bbox']
                
                # Check if bbox is within image bounds
                if x >= 0 and y >= 0 and x + w <= img_width and y + h <= img_height and w > 0 and h > 0:
                    valid_objects.append(obj)
                else:
                    print(f"Warning: Invalid bbox in {image_path}: {obj['bbox']}")
            
            annotation['objects'] = valid_objects
            return len(valid_objects) > 0
            
        except Exception as e:
            print(f"Error validating {image_path}: {e}")
            return False
    
    def process_dataset(self, image_type: str, split: str = 'train') -> Dict:
        """Process dataset for specific image type and split"""
        print(f"Processing {image_type} {split} dataset...")
        
        # Determine source directory
        if split == 'train':
            source_dir = os.path.join(self.data_root, "DS0")
        elif split == 'val':
            source_dir = os.path.join(self.data_root, "MSA_Sort3")
        else:
            raise ValueError(f"Unknown split: {split}")
        
        # Parse annotations
        annotations = self.parser.parse_dataset_directory(source_dir, image_type)
        
        if not annotations:
            print(f"No annotations found for {image_type} {split}")
            return {}
        
        print(f"Found {len(annotations)} annotations for {image_type} {split}")
        
        # Create output directories
        output_split_dir = os.path.join(self.output_dir, image_type.lower(), split)
        images_dir = os.path.join(output_split_dir, "images")
        annotations_dir = os.path.join(output_split_dir, "annotations")
        
        Path(images_dir).mkdir(parents=True, exist_ok=True)
        Path(annotations_dir).mkdir(parents=True, exist_ok=True)
        
        # Process each annotation
        valid_annotations = []
        for i, annotation in enumerate(annotations):
            if 'image_path' not in annotation:
                continue
            
            # Validate image-annotation pair
            if not self.validate_image_annotation_pair(annotation['image_path'], annotation):
                continue
            
            # Copy image to output directory
            image_filename = f"{image_type.lower()}_{split}_{i:06d}.jpg"
            output_image_path = os.path.join(images_dir, image_filename)
            
            try:
                # Load, convert and save image
                image = Image.open(annotation['image_path'])
                if image.mode != 'RGB':
                    image = image.convert('RGB')
                image.save(output_image_path, 'JPEG', quality=95)
                
                # Update annotation with new filename
                annotation['image_filename'] = image_filename
                annotation['image_path'] = output_image_path
                
                valid_annotations.append(annotation)
                
                # Update statistics
                self.stats[image_type.lower()]['images'] += 1
                self.stats[image_type.lower()]['annotations'] += len(annotation['objects'])
                
                for obj in annotation['objects']:
                    if obj['class_name'] == 'chip':
                        self.stats[image_type.lower()]['chips'] += 1
                    elif obj['class_name'] == 'check':
                        self.stats[image_type.lower()]['checks'] += 1
                
            except Exception as e:
                print(f"Error processing image {annotation['image_path']}: {e}")
                continue
        
        print(f"Successfully processed {len(valid_annotations)} images for {image_type} {split}")
        
        # Convert to COCO format
        coco_data = self.parser.convert_to_coco_format(
            valid_annotations, 
            f"photomask_{image_type.lower()}_{split}"
        )
        
        # Save COCO annotation file
        coco_file = os.path.join(annotations_dir, f"{split}_annotations.json")
        with open(coco_file, 'w') as f:
            json.dump(coco_data, f, indent=2)
        
        print(f"COCO annotations saved to {coco_file}")
        
        return {
            'coco_file': coco_file,
            'images_dir': images_dir,
            'num_images': len(valid_annotations),
            'num_annotations': sum(len(ann['objects']) for ann in valid_annotations)
        }
    
    def create_dataset_splits(self, image_type: str) -> Dict:
        """Create train and validation splits for image type"""
        print(f"\nCreating dataset splits for {image_type}")
        print("=" * 50)
        
        results = {}
        
        # Process training data
        train_result = self.process_dataset(image_type, 'train')
        if train_result:
            results['train'] = train_result
        
        # Process validation data
        val_result = self.process_dataset(image_type, 'val')
        if val_result:
            results['val'] = val_result
        
        return results
    
    def generate_dataset_report(self) -> Dict:
        """Generate comprehensive dataset report"""
        report = {
            'summary': self.stats,
            'recommendations': [],
            'issues': []
        }
        
        # Check class balance
        for image_type in ['ev', 'sv']:
            stats = self.stats[image_type]
            if stats['images'] == 0:
                report['issues'].append(f"No {image_type.upper()} images found")
                continue
            
            total_objects = stats['chips'] + stats['checks']
            if total_objects == 0:
                report['issues'].append(f"No objects found in {image_type.upper()} images")
                continue
            
            chip_ratio = stats['chips'] / total_objects
            check_ratio = stats['checks'] / total_objects
            
            report['summary'][image_type]['chip_ratio'] = chip_ratio
            report['summary'][image_type]['check_ratio'] = check_ratio
            
            # Check for class imbalance
            if chip_ratio < 0.1 or chip_ratio > 0.9:
                report['issues'].append(f"Severe class imbalance in {image_type.upper()}: {chip_ratio:.2%} chips")
            elif chip_ratio < 0.2 or chip_ratio > 0.8:
                report['recommendations'].append(f"Consider class balancing for {image_type.upper()}: {chip_ratio:.2%} chips")
            
            # Check dataset size
            if stats['images'] < 100:
                report['issues'].append(f"Small dataset for {image_type.upper()}: {stats['images']} images")
            elif stats['images'] < 500:
                report['recommendations'].append(f"Consider data augmentation for {image_type.upper()}: {stats['images']} images")
        
        return report
    
    def save_preprocessing_config(self, config: Dict):
        """Save preprocessing configuration"""
        config_file = os.path.join(self.output_dir, "preprocessing_config.json")
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=2)
        print(f"Preprocessing config saved to {config_file}")

def main():
    """Main preprocessing function"""
    print("Photomask Data Preprocessor")
    print("=" * 50)
    
    # Configuration
    data_root = "D/Photomask"  # User should update this path
    output_dir = "./processed_data"
    
    if not os.path.exists(data_root):
        print(f"Data root directory not found: {data_root}")
        print("Please update the data_root path in the script")
        return
    
    # Initialize preprocessor
    preprocessor = PhotomaskDataPreprocessor(data_root, output_dir)
    
    # Process both EV and SV datasets
    all_results = {}
    
    for image_type in ['EV', 'SV']:
        print(f"\n{'='*20} Processing {image_type} {'='*20}")
        results = preprocessor.create_dataset_splits(image_type)
        all_results[image_type] = results
    
    # Generate and save report
    report = preprocessor.generate_dataset_report()
    
    print("\n" + "="*50)
    print("DATASET PROCESSING COMPLETE")
    print("="*50)
    
    print("\nDataset Summary:")
    for image_type, stats in report['summary'].items():
        print(f"\n{image_type.upper()}:")
        print(f"  Images: {stats['images']}")
        print(f"  Total objects: {stats['annotations']}")
        print(f"  Chips: {stats['chips']}")
        print(f"  Checks: {stats['checks']}")
        if 'chip_ratio' in stats:
            print(f"  Chip ratio: {stats['chip_ratio']:.2%}")
    
    if report['issues']:
        print("\n⚠️  Issues found:")
        for issue in report['issues']:
            print(f"  - {issue}")
    
    if report['recommendations']:
        print("\n💡 Recommendations:")
        for rec in report['recommendations']:
            print(f"  - {rec}")
    
    # Save report
    report_file = os.path.join(output_dir, "dataset_report.json")
    with open(report_file, 'w') as f:
        json.dump(report, f, indent=2)
    
    print(f"\nDetailed report saved to: {report_file}")
    print(f"Processed data saved to: {output_dir}")
    
    print("\nNext steps:")
    print("1. Review the dataset report")
    print("2. Run the DINO training pipeline")
    print("3. Monitor training progress and adjust hyperparameters if needed")

if __name__ == "__main__":
    main()

