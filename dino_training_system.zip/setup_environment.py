#!/usr/bin/env python3
"""
Environment Setup Script for DINO Object Detection Training
Handles installation and configuration for 11GB VRAM systems
"""

import subprocess
import sys
import os
import torch
import platform
from pathlib import Path

def check_system_requirements():
    """Check system requirements and GPU availability"""
    print("Checking System Requirements...")
    print("=" * 50)
    
    # Python version
    python_version = sys.version_info
    print(f"Python version: {python_version.major}.{python_version.minor}.{python_version.micro}")
    
    if python_version < (3, 8):
        print("❌ Python 3.8+ required")
        return False
    else:
        print("✅ Python version OK")
    
    # Platform
    print(f"Platform: {platform.system()} {platform.release()}")
    
    # CUDA availability
    cuda_available = torch.cuda.is_available()
    print(f"CUDA available: {cuda_available}")
    
    if cuda_available:
        gpu_count = torch.cuda.device_count()
        print(f"GPU count: {gpu_count}")
        
        for i in range(gpu_count):
            gpu_name = torch.cuda.get_device_name(i)
            gpu_memory = torch.cuda.get_device_properties(i).total_memory / (1024**3)
            print(f"  GPU {i}: {gpu_name} ({gpu_memory:.1f} GB)")
            
            if gpu_memory < 10.5:
                print(f"⚠️  GPU {i} has less than 11GB VRAM, training may be limited")
            else:
                print(f"✅ GPU {i} has sufficient VRAM")
    else:
        print("❌ No CUDA GPU detected. Training will be very slow on CPU.")
        return False
    
    return True

def install_pytorch():
    """Install PyTorch with CUDA support"""
    print("\nInstalling PyTorch...")
    print("=" * 30)
    
    # Detect CUDA version
    if torch.cuda.is_available():
        cuda_version = torch.version.cuda
        print(f"Detected CUDA version: {cuda_version}")
        
        # Install PyTorch with appropriate CUDA version
        if cuda_version.startswith("11.8"):
            torch_cmd = ["pip", "install", "torch", "torchvision", "torchaudio", "--index-url", "https://download.pytorch.org/whl/cu118"]
        elif cuda_version.startswith("12.1"):
            torch_cmd = ["pip", "install", "torch", "torchvision", "torchaudio", "--index-url", "https://download.pytorch.org/whl/cu121"]
        else:
            torch_cmd = ["pip", "install", "torch", "torchvision", "torchaudio"]
    else:
        torch_cmd = ["pip", "install", "torch", "torchvision", "torchaudio", "--index-url", "https://download.pytorch.org/whl/cpu"]
    
    try:
        subprocess.run(torch_cmd, check=True)
        print("✅ PyTorch installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install PyTorch: {e}")
        return False

def install_detectron2():
    """Install Detectron2"""
    print("\nInstalling Detectron2...")
    print("=" * 30)
    
    try:
        # Install pre-built detectron2
        if torch.cuda.is_available():
            cuda_version = torch.version.cuda.replace(".", "")
            torch_version = torch.__version__.split("+")[0]
            
            detectron2_cmd = [
                "pip", "install", 
                f"detectron2 -f https://dl.fbaipublicfiles.com/detectron2/wheels/cu{cuda_version}/torch{torch_version}/index.html"
            ]
        else:
            detectron2_cmd = ["pip", "install", "detectron2", "-f", "https://dl.fbaipublicfiles.com/detectron2/wheels/cpu/torch1.10/index.html"]
        
        subprocess.run(detectron2_cmd, check=True)
        print("✅ Detectron2 installed successfully")
        return True
    except subprocess.CalledProcessError:
        print("⚠️  Pre-built Detectron2 failed, trying from source...")
        try:
            # Install from source
            subprocess.run(["pip", "install", "git+https://github.com/facebookresearch/detectron2.git"], check=True)
            print("✅ Detectron2 installed from source")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to install Detectron2: {e}")
            return False

def install_requirements():
    """Install all requirements"""
    print("\nInstalling Requirements...")
    print("=" * 30)
    
    try:
        subprocess.run(["pip", "install", "-r", "requirements.txt"], check=True)
        print("✅ Requirements installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install requirements: {e}")
        return False

def create_directories():
    """Create necessary directories"""
    print("\nCreating Directories...")
    print("=" * 30)
    
    directories = [
        "models",
        "logs", 
        "checkpoints",
        "tensorboard",
        "cache_ev",
        "cache_sv",
        "data",
        "results"
    ]
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        print(f"✅ Created directory: {directory}")

def test_installation():
    """Test the installation"""
    print("\nTesting Installation...")
    print("=" * 30)
    
    try:
        # Test PyTorch
        import torch
        print(f"✅ PyTorch {torch.__version__}")
        
        # Test CUDA
        if torch.cuda.is_available():
            print(f"✅ CUDA {torch.version.cuda}")
            print(f"✅ cuDNN {torch.backends.cudnn.version()}")
        
        # Test Detectron2
        import detectron2
        print(f"✅ Detectron2 {detectron2.__version__}")
        
        # Test Transformers
        import transformers
        print(f"✅ Transformers {transformers.__version__}")
        
        # Test other key packages
        import cv2
        print(f"✅ OpenCV {cv2.__version__}")
        
        import albumentations
        print(f"✅ Albumentations {albumentations.__version__}")
        
        # Test memory
        if torch.cuda.is_available():
            device = torch.device("cuda")
            # Test tensor creation
            test_tensor = torch.randn(1000, 1000, device=device)
            memory_allocated = torch.cuda.memory_allocated() / (1024**3)
            print(f"✅ GPU memory test: {memory_allocated:.2f} GB allocated")
            del test_tensor
            torch.cuda.empty_cache()
        
        print("\n🎉 Installation test completed successfully!")
        return True
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ Test error: {e}")
        return False

def optimize_environment():
    """Apply environment optimizations"""
    print("\nApplying Environment Optimizations...")
    print("=" * 40)
    
    # Set environment variables for memory optimization
    os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:512"
    os.environ["CUDA_LAUNCH_BLOCKING"] = "0"
    os.environ["TORCH_USE_CUDA_DSA"] = "1"
    
    print("✅ Environment variables set for memory optimization")
    
    # Create optimization script
    with open("optimize_memory.py", "w") as f:
        f.write("""#!/usr/bin/env python3
import torch
import gc
import os

def optimize_memory():
    '''Apply memory optimizations'''
    if torch.cuda.is_available():
        # Clear cache
        torch.cuda.empty_cache()
        
        # Set memory fraction
        torch.cuda.set_per_process_memory_fraction(0.95)
        
        # Enable memory efficient attention if available
        try:
            torch.backends.cuda.enable_flash_sdp(True)
        except:
            pass
        
        print("✅ CUDA memory optimizations applied")
    
    # Python garbage collection
    gc.collect()
    print("✅ Garbage collection completed")

if __name__ == "__main__":
    optimize_memory()
""")
    
    print("✅ Memory optimization script created")

def main():
    """Main setup function"""
    print("DINO Object Detection Environment Setup")
    print("=" * 50)
    
    # Check system requirements
    if not check_system_requirements():
        print("\n❌ System requirements not met. Please check your setup.")
        return False
    
    # Install PyTorch
    if not install_pytorch():
        print("\n❌ PyTorch installation failed.")
        return False
    
    # Install Detectron2
    if not install_detectron2():
        print("\n❌ Detectron2 installation failed.")
        return False
    
    # Install other requirements
    if not install_requirements():
        print("\n❌ Requirements installation failed.")
        return False
    
    # Create directories
    create_directories()
    
    # Apply optimizations
    optimize_environment()
    
    # Test installation
    if not test_installation():
        print("\n❌ Installation test failed.")
        return False
    
    print("\n🎉 Environment setup completed successfully!")
    print("\nNext steps:")
    print("1. Place your data in the correct directory structure:")
    print("   - Training: D/Photomask/DS0/EV/ and D/Photomask/DS0/SV/")
    print("   - Validation: D/Photomask/MSA_Sort3/EV/ and D/Photomask/MSA_Sort3/SV/")
    print("2. Run the data preprocessing script")
    print("3. Start training with the DINO trainer")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

