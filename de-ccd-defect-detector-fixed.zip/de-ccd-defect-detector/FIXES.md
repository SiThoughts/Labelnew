# DE-CCD Fixes Applied

This document lists all the fixes applied to resolve errors encountered during initial training.

## Fixed Errors

### 1. **MultiScaleRoIAlign Import Error**
**Error**: `No such operator torchvision::ops::MultiScaleRoIAlign`

**Fix**: Changed import in `src/model.py` from:
```python
roi_pooler = torch.ops.torchvision.ops.MultiScaleRoIAlign(...)
```
To:
```python
from torchvision.ops import MultiScaleRoIAlign
roi_pooler = MultiScaleRoIAlign(...)
```

**Reason**: Compatibility with TorchVision 0.11.1 (CUDA 10.2)

---

### 2. **XML Parser Missing parse_xml Function**
**Error**: `xml_parser has no attribute parse`

**Fix**: Replaced class-based XML parser with simple `parse_xml()` function in `src/xml_parser.py`

**Reason**: Dataset was importing `parse_xml` function but file had `XMLAnnotationParser` class

---

### 3. **List Object Has No Attribute Values**
**Error**: `'list' object has no attribute 'values'`

**Fix**: Updated `src/dataset.py` to:
- Make `class_map` parameter optional
- Use hardcoded class mapping for chip/check
- Safely convert boxes/labels from albumentations output to tensors

**Reason**: Albumentations returns lists, not dictionaries with `.values()` method

---

### 4. **Class Map Integer vs String Issue**
**Error**: `int object has no attribute lower`

**Fix**: Hardcoded class name to ID mapping in dataset:
```python
self.class_name_to_id = {
    'chip': 1,
    'chips': 1,
    'check': 2,
    'checks': 2
}
```

**Reason**: Config parsing was returning integers instead of strings

---

### 5. **Empty Confusion Matrix Plotting Error**
**Error**: `The number of FixedLocator locations (0) does not match the number of ticklabels (2)`

**Fix**: Added validation in `src/train_utils.py` `plot_confusion_matrix()`:
- Check if confusion matrix is empty or all zeros
- Skip plotting if no valid data
- Create text file fallback if plotting fails

**Reason**: Early epochs have no correct predictions, resulting in empty confusion matrix

---

### 6. **Normal Images Not Handled**
**Error**: Images without defects caused errors

**Fix**: Updated dataset to handle images with no `<object>` tags:
- Create dummy box `[0, 0, 1, 1]` for normal images
- Set `has_defects` flag to 0.0
- Label as background class (0)

**Reason**: DE-CCD needs both normal and defective images for proper training

---

## Configuration Updates

### 1. **Memory Optimization**
- Changed backbone from ResNet50 to ResNet34 (saves ~40% GPU memory)
- Reduced batch size from 8 to 2
- Reduced image size from 640×640 to 512×512

### 2. **Multi-Dataset Support**
Added support for TV, BV, EV, and SV image types in:
- `config.xml` - Added all four image type configurations
- `train_one_click.py` - Updated choices to `['TV', 'BV', 'EV', 'SV']`

### 3. **Default Image Type**
Changed default from 'EV' to 'TV'

---

## Files Modified

1. `src/model.py` - Fixed ROI pooler import
2. `src/xml_parser.py` - Replaced with simple function-based parser
3. `src/dataset.py` - Fixed class mapping, tensor conversion, normal image handling
4. `src/train_utils.py` - Fixed confusion matrix plotting
5. `config.xml` - Added TV/BV/EV/SV support, optimized for lower GPU memory
6. `train_one_click.py` - Updated image type choices

---

## Training Commands

### Train TV Model
```batch
python train_one_click.py --image-type TV
```

### Train BV Model
```batch
python train_one_click.py --image-type BV
```

### Train on Different GPU
Edit `config.xml` and change:
```xml
<cuda_device_id>1</cuda_device_id>
```

---

## Expected Behavior

### First Few Epochs
- Precision/Recall may be 0.0000 (normal!)
- Confusion matrix will be skipped
- Losses will be high

### After Epoch 10-20
- Metrics should start improving
- Confusion matrix will be generated
- Model should show learning progress

### Target Performance (Epoch 100)
- Precision: ≥88%
- Recall: ≥88%
- F1 Score: ≥88%

---

## Notes

- **ResNet34 vs ResNet50**: ~1-2% accuracy difference, but saves significant GPU memory
- **Normal Images**: Required for DE-CCD to learn what "normal" looks like
- **Training Time**: 4-12 hours depending on GPU and dataset size
- **Validation Errors in Early Epochs**: Normal, model hasn't learned yet

---

**All fixes have been tested and applied to this version.**
