"""
XML annotation parser for Pascal VOC format.
"""
import xml.etree.ElementTree as ET


def parse_xml(xml_path):
    """
    Parse Pascal VOC XML annotation file.
    
    Args:
        xml_path: Path to XML file
    
    Returns:
        Dictionary with annotation data
    """
    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
        
        annotations = {
            'filename': '',
            'size': {'width': 0, 'height': 0},
            'objects': []
        }
        
        # Get filename
        filename_elem = root.find('filename')
        if filename_elem is not None and filename_elem.text:
            annotations['filename'] = filename_elem.text
        
        # Get size
        size_elem = root.find('size')
        if size_elem is not None:
            width_elem = size_elem.find('width')
            height_elem = size_elem.find('height')
            
            if width_elem is not None and width_elem.text:
                annotations['size']['width'] = int(width_elem.text)
            if height_elem is not None and height_elem.text:
                annotations['size']['height'] = int(height_elem.text)
        
        # Get objects
        for obj in root.findall('object'):
            name_elem = obj.find('name')
            bndbox_elem = obj.find('bndbox')
            
            # Skip if missing required elements
            if name_elem is None or bndbox_elem is None:
                continue
            
            if name_elem.text is None:
                continue
            
            xmin_elem = bndbox_elem.find('xmin')
            ymin_elem = bndbox_elem.find('ymin')
            xmax_elem = bndbox_elem.find('xmax')
            ymax_elem = bndbox_elem.find('ymax')
            
            # Skip if bounding box is incomplete
            if None in [xmin_elem, ymin_elem, xmax_elem, ymax_elem]:
                continue
            
            # Skip if any text is None
            if None in [xmin_elem.text, ymin_elem.text, xmax_elem.text, ymax_elem.text]:
                continue
            
            try:
                xmin = float(xmin_elem.text)
                ymin = float(ymin_elem.text)
                xmax = float(xmax_elem.text)
                ymax = float(ymax_elem.text)
                
                # Validate bounding box
                if xmax <= xmin or ymax <= ymin:
                    continue
                
                obj_dict = {
                    'name': name_elem.text.lower().strip(),
                    'bndbox': {
                        'xmin': xmin,
                        'ymin': ymin,
                        'xmax': xmax,
                        'ymax': ymax
                    }
                }
                
                annotations['objects'].append(obj_dict)
                
            except (ValueError, AttributeError):
                # Skip malformed bounding boxes
                continue
        
        return annotations
        
    except Exception as e:
        print(f"Error parsing {xml_path}: {e}")
        # Return empty annotation for problematic files
        return {
            'filename': '',
            'size': {'width': 0, 'height': 0},
            'objects': []
        }
