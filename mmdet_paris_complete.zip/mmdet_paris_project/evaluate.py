#!/usr/bin/env python3
"""
Evaluation script for Cascade R-CNN on Paris dataset
Usage: python evaluate.py [checkpoint_path]
"""

import os
import sys
import subprocess

def main():
    # Configuration file path
    config_file = "configs/paris_cascade_x101_p2.py"
    
    # Default checkpoint path
    default_checkpoint = "work_dirs/paris_cascade_x101_p2/latest.pth"
    
    # Get checkpoint path from command line or use default
    if len(sys.argv) > 1:
        checkpoint_path = sys.argv[1]
    else:
        checkpoint_path = default_checkpoint
    
    # Check if files exist
    if not os.path.exists(config_file):
        print(f"ERROR: Config file {config_file} not found!")
        sys.exit(1)
    
    if not os.path.exists(checkpoint_path):
        print(f"ERROR: Checkpoint {checkpoint_path} not found!")
        print("Available checkpoints:")
        work_dir = "work_dirs/paris_cascade_x101_p2"
        if os.path.exists(work_dir):
            for f in os.listdir(work_dir):
                if f.endswith('.pth'):
                    print(f"  {os.path.join(work_dir, f)}")
        sys.exit(1)
    
    print("=== STARTING EVALUATION ===")
    print(f"Config: {config_file}")
    print(f"Checkpoint: {checkpoint_path}")
    
    # Evaluation command
    cmd = [
        "python", "-m", "mmdet.tools.test",
        config_file,
        checkpoint_path,
        "--eval", "bbox"
    ]
    
    print(f"Command: {' '.join(cmd)}")
    print("\n" + "="*50)
    
    try:
        # Run evaluation
        subprocess.run(cmd, check=True)
        print("\n=== EVALUATION COMPLETED SUCCESSFULLY ===")
        print("\nKey metrics to look for:")
        print("- AP_small: Average Precision for small objects")
        print("- AP_0.50: AP at IoU threshold 0.5")
        print("- AP_0.75: AP at IoU threshold 0.75")
    except subprocess.CalledProcessError as e:
        print(f"\n=== EVALUATION FAILED ===")
        print(f"Error code: {e.returncode}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n=== EVALUATION INTERRUPTED BY USER ===")
        sys.exit(1)

if __name__ == "__main__":
    main()

