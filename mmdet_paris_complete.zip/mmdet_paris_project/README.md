# Cascade R-CNN Training for Paris Dataset

This project contains all the necessary files to train a Cascade R-CNN model on your Paris dataset for small defect detection (chips and checks) using MMDetection without conda.

## Dataset Structure

Your dataset should be organized as follows:
```
D:/Photomask/paris/dataset/
├── annotations/
│   ├── instances_train.json
│   └── instances_val.json
├── train/images/*.png
└── val/images/*.png
```

## Key Features

- **Fixed Image Size**: Configured for your 2048x1460 images (no resizing)
- **Small Object Detection**: Optimized with P2 features and small anchors
- **pycocotools Compatible**: Uses pycocotools instead of mmpycocotools
- **ONNX Export**: Ready for edge deployment with baked-in normalization

## Quick Start

### 1. Environment Setup

Run the automated setup script:
```bash
python setup_environment.py
```

Or install manually:
```bash
# Upgrade pip
python -m pip install --upgrade pip wheel setuptools

# Install PyTorch (choose your CUDA version)
pip install --index-url https://download.pytorch.org/whl/cu121 torch torchvision

# Install MMDetection ecosystem
pip install -U openmim
mim install "mmengine>=0.10.0" "mmcv>=2.1.0" "mmdet>=3.3.0"

# Install pycocotools (Windows)
pip uninstall -y mmpycocotools
pip install pycocotools-windows

# Install additional packages
pip install onnxruntime-gpu opencv-python Pillow matplotlib
```

### 2. Validate Dataset

Check your dataset format:
```bash
python check_coco.py
```

### 3. Train Model

Start training:
```bash
python train.py
```

Training will save checkpoints to `work_dirs/paris_cascade_x101_p2/`

### 4. Evaluate Model

Evaluate the trained model:
```bash
python evaluate.py
# or specify checkpoint:
python evaluate.py work_dirs/paris_cascade_x101_p2/epoch_12.pth
```

### 5. Export to ONNX

Export for edge deployment:
```bash
python export_cascade_onnx.py
# or specify checkpoint:
python export_cascade_onnx.py work_dirs/paris_cascade_x101_p2/best.pth
```

### 6. Test ONNX Model

Test the exported ONNX model:
```bash
python test_onnx.py
# or specify image and model:
python test_onnx.py path/to/image.png cascade_paris_2048x1460.onnx
```

## File Descriptions

### Configuration
- `configs/paris_cascade_x101_p2.py` - Main training configuration
- `mmpycocotools/__init__.py` - Compatibility shim for pycocotools

### Scripts
- `setup_environment.py` - Automated environment setup
- `check_coco.py` - Dataset validation
- `train.py` - Training script
- `evaluate.py` - Evaluation script
- `export_cascade_onnx.py` - ONNX export script
- `test_onnx.py` - ONNX model testing

### Documentation
- `requirements.txt` - Python package requirements
- `README.md` - This file

## Model Configuration Details

### Architecture
- **Backbone**: ResNeXt-101-32x4d
- **Neck**: FPN with P2 (stride=4) for small objects
- **Head**: Cascade R-CNN with 3 stages
- **Classes**: 2 (chip, check)

### Small Object Optimizations
- **P2 Features**: Includes highest resolution FPN level (1/4 scale)
- **Small Anchors**: Base scale=4 (instead of 8) for tiny defects
- **High Proposal Counts**: 2000 RPN proposals, 300 final detections
- **Fixed Resolution**: No resizing - preserves all detail in 2048x1460 images

### Training Settings
- **Optimizer**: AdamW with lr=2e-4
- **Schedule**: 24 epochs with validation every epoch
- **Batch Size**: 1 (due to large image size)
- **Augmentations**: RandomFlip + PhotoMetricDistortion (no resizing/cropping)

## ONNX Model Details

The exported ONNX model:
- **Input**: (1, 3, 1460, 2048) float32 in range [0, 1]
- **Outputs**: boxes, labels, scores (pre-NMS)
- **Normalization**: Baked into the model
- **Post-processing**: Apply Soft-NMS on device with your thresholds

## Troubleshooting

### Common Issues

1. **OOM (Out of Memory)**
   - Reduce batch_size to 1 in config
   - Use gradient checkpointing if available
   - Consider using a smaller backbone

2. **pycocotools Import Error**
   - Ensure mmpycocotools is uninstalled
   - Use pycocotools-windows on Windows
   - The mmpycocotools shim should handle compatibility

3. **ONNX Export Fails**
   - Try opset_version=13 instead of 11
   - Ensure MMDetection >= 3.3.0
   - Check that the checkpoint file exists

4. **Low AP_small**
   - Try anchor scales=[3] for even smaller anchors
   - Increase max_per_img limits
   - Train for more epochs (36 instead of 24)

### Performance Tips

- **For faster training**: Use mixed precision if supported
- **For better small object detection**: Consider increasing image resolution if memory allows
- **For deployment**: Use TensorRT or INT8 quantization after ONNX export

## Expected Results

Focus on these metrics during evaluation:
- **AP_small**: Most important for your tiny defects
- **AP_0.50**: General detection performance
- **Recall**: Ensure you're not missing defects

Typical workflow:
1. Train for 24 epochs
2. Evaluate and check AP_small
3. If needed, adjust anchors/proposals and retrain
4. Export best checkpoint to ONNX
5. Deploy with Soft-NMS post-processing

## Support

If you encounter issues:
1. Check the console output for specific error messages
2. Verify dataset paths and format with `check_coco.py`
3. Ensure all dependencies are correctly installed
4. Check GPU memory usage and reduce batch size if needed

