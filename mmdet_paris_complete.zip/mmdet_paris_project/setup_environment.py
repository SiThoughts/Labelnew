#!/usr/bin/env python3
"""
Environment setup script for Cascade R-CNN training
This script helps set up the Python environment without conda
"""

import subprocess
import sys
import os

def run_command(cmd, description):
    """Run a command and handle errors"""
    print(f"\n=== {description} ===")
    print(f"Running: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
        print("✓ Success")
        if result.stdout:
            print(result.stdout)
        return True
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed with error code {e.returncode}")
        if e.stdout:
            print("STDOUT:", e.stdout)
        if e.stderr:
            print("STDERR:", e.stderr)
        return False

def check_python_version():
    """Check if Python version is compatible"""
    version = sys.version_info
    print(f"Python version: {version.major}.{version.minor}.{version.micro}")
    
    if version.major != 3 or version.minor < 9:
        print("WARNING: Python 3.9+ recommended for MMDetection")
        return False
    return True

def check_gpu():
    """Check if CUDA is available"""
    try:
        import torch
        if torch.cuda.is_available():
            print(f"✓ CUDA available: {torch.cuda.get_device_name(0)}")
            print(f"CUDA version: {torch.version.cuda}")
            return True
        else:
            print("⚠ CUDA not available - will use CPU (slower)")
            return False
    except ImportError:
        print("PyTorch not installed yet")
        return None

def main():
    print("=== MMDetection Environment Setup ===")
    print("This script will help you set up the environment for training Cascade R-CNN")
    
    # Check Python version
    if not check_python_version():
        print("Consider upgrading to Python 3.9 or 3.10")
    
    # Upgrade pip
    if not run_command([sys.executable, "-m", "pip", "install", "--upgrade", "pip", "wheel", "setuptools"], 
                      "Upgrading pip, wheel, and setuptools"):
        print("Failed to upgrade pip")
        return False
    
    # Install PyTorch with CUDA support
    print("\n=== Installing PyTorch ===")
    print("Choose your installation:")
    print("1. CUDA 12.1 (recommended for newer GPUs)")
    print("2. CUDA 11.8 (for older GPUs)")
    print("3. CPU only")
    
    choice = input("Enter choice (1-3): ").strip()
    
    if choice == "1":
        torch_cmd = [sys.executable, "-m", "pip", "install", "--index-url", 
                    "https://download.pytorch.org/whl/cu121", "torch", "torchvision"]
    elif choice == "2":
        torch_cmd = [sys.executable, "-m", "pip", "install", "--index-url", 
                    "https://download.pytorch.org/whl/cu118", "torch", "torchvision"]
    elif choice == "3":
        torch_cmd = [sys.executable, "-m", "pip", "install", "--index-url", 
                    "https://download.pytorch.org/whl/cpu", "torch", "torchvision"]
    else:
        print("Invalid choice")
        return False
    
    if not run_command(torch_cmd, "Installing PyTorch"):
        print("Failed to install PyTorch")
        return False
    
    # Check GPU after PyTorch installation
    check_gpu()
    
    # Install OpenMMLab packages
    if not run_command([sys.executable, "-m", "pip", "install", "-U", "openmim"], 
                      "Installing OpenMIM"):
        return False
    
    if not run_command([sys.executable, "-m", "mim", "install", 
                       "mmengine>=0.10.0", "mmcv>=2.1.0", "mmdet>=3.3.0"], 
                      "Installing MMEngine, MMCV, and MMDetection"):
        return False
    
    # Install pycocotools
    print("\n=== Installing pycocotools ===")
    # Uninstall mmpycocotools if present
    subprocess.run([sys.executable, "-m", "pip", "uninstall", "-y", "mmpycocotools"], 
                  capture_output=True)
    
    # Install pycocotools (Windows version if on Windows)
    if os.name == 'nt':  # Windows
        coco_package = "pycocotools-windows"
    else:
        coco_package = "pycocotools"
    
    if not run_command([sys.executable, "-m", "pip", "install", coco_package], 
                      f"Installing {coco_package}"):
        return False
    
    # Install additional packages
    if not run_command([sys.executable, "-m", "pip", "install", "onnxruntime-gpu", 
                       "opencv-python", "Pillow", "matplotlib"], 
                      "Installing additional packages"):
        print("Some packages failed to install, but continuing...")
    
    # Test installation
    print("\n=== Testing Installation ===")
    test_imports = [
        ("torch", "PyTorch"),
        ("mmdet", "MMDetection"),
        ("pycocotools.coco", "pycocotools"),
        ("onnxruntime", "ONNX Runtime")
    ]
    
    all_good = True
    for module, name in test_imports:
        try:
            __import__(module)
            print(f"✓ {name} imported successfully")
        except ImportError as e:
            print(f"✗ {name} import failed: {e}")
            all_good = False
    
    if all_good:
        print("\n🎉 Environment setup complete!")
        print("\nNext steps:")
        print("1. Run: python check_coco.py  # to validate your dataset")
        print("2. Run: python train.py       # to start training")
        print("3. Run: python evaluate.py    # to evaluate trained model")
        print("4. Run: python export_cascade_onnx.py  # to export to ONNX")
    else:
        print("\n⚠ Some packages failed to install. Please check the errors above.")
    
    return all_good

if __name__ == "__main__":
    main()

