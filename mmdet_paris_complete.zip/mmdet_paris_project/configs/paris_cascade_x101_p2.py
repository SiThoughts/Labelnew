# configs/paris_cascade_x101_p2.py
_base_ = ['mmdet::cascade_rcnn/cascade-rcnn_x101-32x4d_fpn_1x_coco.py']

# ---------------- DATA ----------------
dataset_type = 'CocoDataset'
data_root = 'D:/Photomask/paris/dataset/'
classes = ('chip', 'check')  # MUST match JSON categories order

train_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='LoadAnnotations', with_bbox=True),
    dict(type='RandomFlip', prob=0.5),
    # No resizing - images are fixed at 2048x1460
    # Add photometric distortion for robustness with noisy images
    dict(type='PhotoMetricDistortion',
         brightness_delta=32,
         contrast_range=(0.5, 1.5),
         saturation_range=(0.5, 1.5),
         hue_delta=18),
    dict(type='PackDetInputs')
]

test_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='PackDetInputs')
]

train_dataloader = dict(
    batch_size=1,  # Fixed 2048x1460 imgs + X101 → start at 1; may need to stay at 1 due to memory
    num_workers=2,
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file='annotations/instances_train.json',
        data_prefix=dict(img='train/images/'),
        metainfo=dict(classes=classes),
        pipeline=train_pipeline
    )
)
val_dataloader = dict(
    batch_size=1, num_workers=2,
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file='annotations/instances_val.json',
        data_prefix=dict(img='val/images/'),
        metainfo=dict(classes=classes),
        pipeline=test_pipeline, test_mode=True
    )
)
test_dataloader = val_dataloader

val_evaluator = dict(type='CocoMetric',
                     ann_file=data_root + 'annotations/instances_val.json',
                     metric='bbox')
test_evaluator = val_evaluator

# -------------- MODEL ---------------
model = dict(
    data_preprocessor=dict(
        type='DetDataPreprocessor',
        mean=[123.675,116.28,103.53], std=[58.395,57.12,57.375],
        bgr_to_rgb=True, pad_size_divisor=32  # FPN-friendly pad inside model
    ),
    # FPN with P2 (start_level=0 → include C2)
    neck=dict(
        type='FPN',
        in_channels=[256,512,1024,2048],
        out_channels=256,
        start_level=0,         # include C2 -> P2
        add_extra_convs='on_output',
        num_outs=5             # P2..P6
    ),
    # smaller anchors for tiny defects
    rpn_head=dict(
        anchor_generator=dict(
            type='AnchorGenerator',
            scales=[4],                 # ~16x16 on P2 (stride 4)
            ratios=[0.5,1.0,2.0],
            strides=[4,8,16,32,64]
        )
    ),
    # set your 2 classes in all cascade stages
    roi_head=dict(
        bbox_head=[dict(num_classes=2),
                   dict(num_classes=2),
                   dict(num_classes=2)]
    ),
    # keep many proposals/dets; you will threshold on device
    test_cfg=dict(
        rpn=dict(nms_pre=3000, max_per_img=2000, nms=dict(type='nms', iou_threshold=0.8)),
        rcnn=dict(score_thr=0.001, max_per_img=300)
    )
)

# ------------- OPTIM & SCHEDULE -------------
optim_wrapper = dict(
    optimizer=dict(type='AdamW', lr=2e-4, weight_decay=0.05),
    paramwise_cfg=dict(norm_decay_mult=0.0)
)
train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=24, val_interval=1)
default_hooks = dict(checkpoint=dict(interval=1, max_keep_ckpts=3))
work_dir = 'work_dirs/paris_cascade_x101_p2'

