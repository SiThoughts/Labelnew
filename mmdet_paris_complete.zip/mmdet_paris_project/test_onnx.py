#!/usr/bin/env python3
"""
Test script for ONNX exported Cascade R-CNN model
Usage: python test_onnx.py [image_path] [onnx_model_path]
"""

import cv2
import numpy as np
import os
import sys

def test_onnx_model():
    # Default paths
    default_model = "cascade_paris_2048x1460.onnx"
    default_image = r"D:\Photomask\paris\dataset\val\images"  # Will pick first image
    
    # Get paths from command line or use defaults
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
    else:
        # Find first image in validation set
        if os.path.exists(default_image):
            images = [f for f in os.listdir(default_image) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
            if images:
                image_path = os.path.join(default_image, images[0])
            else:
                print(f"No images found in {default_image}")
                sys.exit(1)
        else:
            print(f"Default image directory {default_image} not found")
            print("Usage: python test_onnx.py <image_path> [onnx_model_path]")
            sys.exit(1)
    
    if len(sys.argv) > 2:
        model_path = sys.argv[2]
    else:
        model_path = default_model
    
    # Check if files exist
    if not os.path.exists(image_path):
        print(f"ERROR: Image {image_path} not found!")
        sys.exit(1)
    
    if not os.path.exists(model_path):
        print(f"ERROR: ONNX model {model_path} not found!")
        print("Run export_cascade_onnx.py first to create the ONNX model.")
        sys.exit(1)
    
    # Try to import onnxruntime
    try:
        import onnxruntime as ort
    except ImportError:
        print("ERROR: onnxruntime not installed!")
        print("Install with: pip install onnxruntime-gpu  # or onnxruntime for CPU")
        sys.exit(1)
    
    print("=== ONNX MODEL TEST ===")
    print(f"Model: {model_path}")
    print(f"Image: {image_path}")
    
    # Load ONNX model
    try:
        providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
        sess = ort.InferenceSession(model_path, providers=providers)
        print(f"✓ Model loaded with providers: {sess.get_providers()}")
    except Exception as e:
        print(f"ERROR loading ONNX model: {e}")
        sys.exit(1)
    
    # Load and preprocess image
    try:
        im = cv2.imread(image_path)
        if im is None:
            print(f"ERROR: Could not load image {image_path}")
            sys.exit(1)
        
        print(f"Original image shape: {im.shape}")
        
        # Check if image is the expected size
        if im.shape[:2] != (1460, 2048):
            print(f"WARNING: Image size {im.shape[:2]} != expected (1460, 2048)")
            print("Model was exported for fixed 2048x1460 images")
        
        # Convert BGR to RGB and normalize to [0,1]
        im_rgb = cv2.cvtColor(im, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        
        # Transpose to CHW format and add batch dimension
        x = np.transpose(im_rgb, (2, 0, 1))[None]  # (1, 3, H, W)
        print(f"Input tensor shape: {x.shape}")
        
    except Exception as e:
        print(f"ERROR preprocessing image: {e}")
        sys.exit(1)
    
    # Run inference
    try:
        print("Running inference...")
        boxes, labels, scores = sess.run(None, {'input': x})
        
        print(f"✓ Inference successful!")
        print(f"Boxes shape: {boxes.shape}")
        print(f"Labels shape: {labels.shape}")
        print(f"Scores shape: {scores.shape}")
        
        # Filter detections by confidence threshold
        conf_threshold = 0.3
        valid_indices = scores > conf_threshold
        
        filtered_boxes = boxes[valid_indices]
        filtered_labels = labels[valid_indices]
        filtered_scores = scores[valid_indices]
        
        print(f"\nDetections above {conf_threshold} confidence: {len(filtered_boxes)}")
        
        if len(filtered_boxes) > 0:
            print("\nTop detections:")
            # Sort by score
            sorted_indices = np.argsort(filtered_scores)[::-1]
            
            class_names = ['chip', 'check']  # Your classes
            
            for i in sorted_indices[:10]:  # Show top 10
                box = filtered_boxes[i]
                label = filtered_labels[i]
                score = filtered_scores[i]
                class_name = class_names[label] if label < len(class_names) else f"class_{label}"
                
                print(f"  {class_name}: {score:.3f} at [{box[0]:.1f}, {box[1]:.1f}, {box[2]:.1f}, {box[3]:.1f}]")
        else:
            print("No detections above confidence threshold")
            print("Try lowering the threshold or check if the model needs more training")
        
        print("\n=== TEST COMPLETE ===")
        print("Next steps:")
        print("1. Apply Soft-NMS for final post-processing")
        print("2. Adjust confidence thresholds based on your requirements")
        print("3. Consider IoU thresholds for NMS (typically 0.5-0.6)")
        
    except Exception as e:
        print(f"ERROR during inference: {e}")
        sys.exit(1)

if __name__ == "__main__":
    test_onnx_model()

