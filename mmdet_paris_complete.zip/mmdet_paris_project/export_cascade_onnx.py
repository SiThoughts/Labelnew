#!/usr/bin/env python3
"""
ONNX Export script for Cascade R-CNN trained on Paris dataset
Exports model with baked-in normalization for 2048x1460 images
Usage: python export_cascade_onnx.py [checkpoint_path]
"""

import torch
import os
import sys
from mmengine.config import Config
from mmengine.runner import load_checkpoint
from mmdet.registry import MODELS

class CascadeWrapper(torch.nn.Module):
    def __init__(self, cfg_path, ckpt_path):
        super().__init__()
        cfg = Config.fromfile(cfg_path)
        self.det = MODELS.build(cfg.model)  # build model module only
        self.det.eval()
        load_checkpoint(self.det, ckpt_path, map_location='cpu')
        
        # Generous proposal caps (pre-NMS outputs) for small object detection
        self.det.test_cfg.rpn.max_per_img = 2000
        self.det.test_cfg.rcnn.max_per_img = 300

        # Bake normalization (same as data_preprocessor) INTO the graph
        # This means the ONNX model expects input in [0,1] range
        mean = torch.tensor([123.675, 116.28, 103.53]).view(1, 3, 1, 1) / 255.0
        std = torch.tensor([58.395, 57.12, 57.375]).view(1, 3, 1, 1) / 255.0
        self.register_buffer('mean', mean.float())
        self.register_buffer('std', std.float())

    @torch.no_grad()
    def forward(self, x):
        # x: (1,3,H,W) float32 in [0,1] -> normalize inside ONNX graph
        x = (x - self.mean) / self.std
        
        # Run the detector's forward test path
        # Use predict method for newer mmdet versions
        try:
            outs = self.det.predict(x, data_samples=None, rescale=True)[0]
            inst = outs.pred_instances  # InstanceData
        except AttributeError:
            # Fallback for older versions
            outs = self.det.test_step([{'inputs': x}])[0]
            inst = outs.pred_instances
        
        return (
            inst.bboxes.to(torch.float32), 
            inst.labels.to(torch.int64), 
            inst.scores.to(torch.float32)
        )

def main():
    # Configuration file path
    config_file = "configs/paris_cascade_x101_p2.py"
    
    # Default checkpoint path
    default_checkpoint = "work_dirs/paris_cascade_x101_p2/latest.pth"
    
    # Get checkpoint path from command line or use default
    if len(sys.argv) > 1:
        checkpoint_path = sys.argv[1]
    else:
        checkpoint_path = default_checkpoint
    
    # Check if files exist
    if not os.path.exists(config_file):
        print(f"ERROR: Config file {config_file} not found!")
        sys.exit(1)
    
    if not os.path.exists(checkpoint_path):
        print(f"ERROR: Checkpoint {checkpoint_path} not found!")
        print("Available checkpoints:")
        work_dir = "work_dirs/paris_cascade_x101_p2"
        if os.path.exists(work_dir):
            for f in os.listdir(work_dir):
                if f.endswith('.pth'):
                    print(f"  {os.path.join(work_dir, f)}")
        sys.exit(1)
    
    print("=== STARTING ONNX EXPORT ===")
    print(f"Config: {config_file}")
    print(f"Checkpoint: {checkpoint_path}")
    print("Target image size: 2048x1460 (fixed)")
    
    # Create wrapper model
    try:
        net = CascadeWrapper(config_file, checkpoint_path).eval()
        print("✓ Model loaded successfully")
    except Exception as e:
        print(f"ERROR loading model: {e}")
        sys.exit(1)
    
    # Create dummy input for fixed image size
    dummy = torch.zeros(1, 3, 1460, 2048, dtype=torch.float32)
    print(f"Dummy input shape: {dummy.shape}")
    
    # Output filename
    output_file = "cascade_paris_2048x1460.onnx"
    
    print(f"Exporting to: {output_file}")
    
    try:
        torch.onnx.export(
            net, dummy, output_file,
            export_params=True, 
            opset_version=11, 
            do_constant_folding=True,
            input_names=['input'],
            output_names=['boxes', 'labels', 'scores'],
            dynamic_axes={
                # Input is fixed size for this export
                # Only detection outputs are dynamic
                'boxes':  {0: 'num_boxes'},
                'labels': {0: 'num_boxes'},
                'scores': {0: 'num_boxes'}
            }
        )
        print(f"✓ ONNX export successful: {output_file}")
        
        # Print file size
        file_size = os.path.getsize(output_file) / (1024 * 1024)  # MB
        print(f"File size: {file_size:.1f} MB")
        
        print("\n=== EXPORT COMPLETE ===")
        print("Model details:")
        print("- Input: (1, 3, 1460, 2048) float32 in range [0, 1]")
        print("- Outputs: boxes, labels, scores (pre-NMS)")
        print("- Normalization: baked into model")
        print("- Ready for edge deployment with Soft-NMS post-processing")
        
    except Exception as e:
        print(f"ERROR during ONNX export: {e}")
        print("\nTrying with opset_version=13...")
        try:
            torch.onnx.export(
                net, dummy, output_file,
                export_params=True, 
                opset_version=13,  # Try newer opset
                do_constant_folding=True,
                input_names=['input'],
                output_names=['boxes', 'labels', 'scores'],
                dynamic_axes={
                    'boxes':  {0: 'num_boxes'},
                    'labels': {0: 'num_boxes'},
                    'scores': {0: 'num_boxes'}
                }
            )
            print(f"✓ ONNX export successful with opset 13: {output_file}")
        except Exception as e2:
            print(f"ERROR with opset 13: {e2}")
            sys.exit(1)

if __name__ == "__main__":
    main()

