# mmpycocotools shim - redirects to pycocotools
# This allows code that expects mmpycocotools to work with pycocotools

from pycocotools.coco import COCO  # re-export
from pycocotools.cocoeval import COCOeval
from pycocotools import mask  # noqa: F401

