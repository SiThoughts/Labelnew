#!/usr/bin/env python3
"""
Training script for Cascade R-CNN on Paris dataset
Usage: python train.py
"""

import os
import sys
import subprocess

def main():
    # Configuration file path
    config_file = "configs/paris_cascade_x101_p2.py"
    
    # Check if config exists
    if not os.path.exists(config_file):
        print(f"ERROR: Config file {config_file} not found!")
        print("Make sure you're running this from the project root directory.")
        sys.exit(1)
    
    # Check if dataset exists
    dataset_root = r"D:\Photomask\paris\dataset"
    if not os.path.exists(dataset_root):
        print(f"ERROR: Dataset root {dataset_root} not found!")
        print("Please check your dataset path.")
        sys.exit(1)
    
    print("=== STARTING TRAINING ===")
    print(f"Config: {config_file}")
    print(f"Dataset: {dataset_root}")
    print(f"GPU: 0")
    
    # Training command
    cmd = [
        "python", "-m", "mmdet.tools.train",
        config_file,
        "--gpu-id", "0"
    ]
    
    print(f"Command: {' '.join(cmd)}")
    print("\n" + "="*50)
    
    try:
        # Run training
        subprocess.run(cmd, check=True)
        print("\n=== TRAINING COMPLETED SUCCESSFULLY ===")
    except subprocess.CalledProcessError as e:
        print(f"\n=== TRAINING FAILED ===")
        print(f"Error code: {e.returncode}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n=== TRAINING INTERRUPTED BY USER ===")
        sys.exit(1)

if __name__ == "__main__":
    main()

