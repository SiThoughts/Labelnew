import json, os, sys

def check_dataset():
    root = r"D:\Photomask\paris\dataset"
    ann_train = os.path.join(root, "annotations", "instances_train.json")
    ann_val = os.path.join(root, "annotations", "instances_val.json")
    
    print("=== DATASET VALIDATION ===")
    print(f"Dataset root: {root}")
    
    # Check if annotation files exist
    for ann_file, split in [(ann_train, "train"), (ann_val, "val")]:
        print(f"\n--- {split.upper()} SET ---")
        if not os.path.exists(ann_file):
            print(f"ERROR: {ann_file} not found!")
            continue
            
        with open(ann_file, "r") as f:
            j = json.load(f)
        
        # Check categories
        cats = [c["name"] for c in j["categories"]]
        print(f"Categories: {cats}")
        print(f"Number of categories: {len(cats)}")
        
        # Check images
        print(f"Number of images: {len(j['images'])}")
        print(f"Number of annotations: {len(j['annotations'])}")
        
        # Check image paths (sample first 10)
        bad = []
        img_prefix = os.path.join(root, split, "images")
        print(f"Looking for images in: {img_prefix}")
        
        for im in j["images"][:10]:  # sample first 10
            img_path = os.path.join(img_prefix, im["file_name"])
            if not os.path.exists(img_path):
                bad.append(img_path)
        
        if bad:
            print(f"Missing images (sampled): {bad}")
        else:
            print("✓ All sampled images found")
        
        # Check image dimensions
        sample_img = j["images"][0]
        print(f"Sample image dimensions: {sample_img['width']}x{sample_img['height']}")
        
        # Check annotation format
        if j["annotations"]:
            sample_ann = j["annotations"][0]
            print(f"Sample annotation bbox: {sample_ann['bbox']} (format: [x,y,w,h])")
            print(f"Sample annotation category_id: {sample_ann['category_id']}")
    
    print("\n=== VALIDATION COMPLETE ===")

if __name__ == "__main__":
    check_dataset()

