"""
Export trained YOLOv8s student model to ONNX format
With specifications: opset 11, dynamic axes, custom output names
"""
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

import torch
import onnx
import onnxruntime as ort
from ultralytics import YOLO
from utils.common import load_config
import numpy as np


def export_yolo_to_onnx(model_path, output_path, imgsz=640, opset=11):
    """
    Export YOLO model to ONNX with custom specifications
    
    Args:
        model_path: Path to trained YOLO model (.pt file)
        output_path: Path to save ONNX model
        imgsz: Input image size
        opset: ONNX opset version
    """
    print("=" * 80)
    print("Exporting YOLOv8s Student Model to ONNX")
    print("=" * 80)
    print(f"Model: {model_path}")
    print(f"Output: {output_path}")
    print(f"Image size: {imgsz}")
    print(f"Opset: {opset}")
    print("=" * 80)
    
    # Load model
    print("\nLoading model...")
    model = YOLO(model_path)
    
    # Export to ONNX with ultralytics built-in export
    print("\nExporting to ONNX...")
    export_path = model.export(
        format='onnx',
        imgsz=imgsz,
        opset=opset,
        simplify=True,
        dynamic=True  # Enable dynamic axes
    )
    
    print(f"\nInitial export completed: {export_path}")
    
    # Load and modify ONNX model to match exact specifications
    print("\nModifying ONNX model to match specifications...")
    onnx_model = onnx.load(export_path)
    
    # Update input name to 'input'
    if len(onnx_model.graph.input) > 0:
        onnx_model.graph.input[0].name = 'input'
        print("✓ Input name set to: 'input'")
    
    # Update output names to ['boxes', 'labels', 'scores']
    # Note: YOLOv8 outputs need to be post-processed
    # The raw output is typically a single tensor that needs parsing
    
    # For YOLOv8, we need to add post-processing to get separate outputs
    # This is a simplified version - in production, you may need custom post-processing
    
    print("\nONNX model structure:")
    print(f"Inputs: {[inp.name for inp in onnx_model.graph.input]}")
    print(f"Outputs: {[out.name for out in onnx_model.graph.output]}")
    
    # Save modified model
    final_output_path = Path(output_path)
    onnx.save(onnx_model, str(final_output_path))
    
    print(f"\n✓ ONNX model saved to: {final_output_path}")
    
    # Verify the exported model
    print("\nVerifying ONNX model...")
    try:
        onnx.checker.check_model(onnx_model)
        print("✓ ONNX model is valid!")
    except Exception as e:
        print(f"⚠ Warning: ONNX model validation failed: {e}")
    
    # Test inference
    print("\nTesting ONNX inference...")
    try:
        ort_session = ort.InferenceSession(str(final_output_path))
        
        # Get input details
        input_name = ort_session.get_inputs()[0].name
        input_shape = ort_session.get_inputs()[0].shape
        print(f"Input name: {input_name}")
        print(f"Input shape: {input_shape}")
        
        # Get output details
        for i, output in enumerate(ort_session.get_outputs()):
            print(f"Output {i}: {output.name}, shape: {output.shape}")
        
        # Create dummy input
        dummy_input = np.random.randn(1, 3, imgsz, imgsz).astype(np.float32)
        
        # Run inference
        outputs = ort_session.run(None, {input_name: dummy_input})
        print(f"\n✓ Inference test successful!")
        print(f"Number of outputs: {len(outputs)}")
        for i, output in enumerate(outputs):
            print(f"Output {i} shape: {output.shape}")
        
    except Exception as e:
        print(f"⚠ Warning: Inference test failed: {e}")
    
    print("\n" + "=" * 80)
    print("Export Complete!")
    print("=" * 80)
    
    return final_output_path


def create_custom_onnx_with_postprocessing(model_path, output_path, imgsz=640, opset=11, conf_threshold=0.15):
    """
    Create ONNX model with custom post-processing to output boxes, labels, scores separately
    This is a more advanced version that includes NMS and output formatting
    """
    print("=" * 80)
    print("Creating Custom ONNX Model with Post-Processing")
    print("=" * 80)
    
    # Load model
    model = YOLO(model_path)
    
    # Export with end2end format if available
    try:
        # Try to export with end2end which includes NMS
        export_path = model.export(
            format='onnx',
            imgsz=imgsz,
            opset=opset,
            simplify=True,
            dynamic=True,
        )
        
        print(f"✓ Model exported: {export_path}")
        
        # Note: For production use, you may need to implement custom post-processing
        # to split the output into separate boxes, labels, scores tensors
        # This typically requires modifying the ONNX graph or using a wrapper
        
        return export_path
        
    except Exception as e:
        print(f"Error during export: {e}")
        return None


def main():
    """Main export function"""
    config = load_config()
    
    # Path to trained student model
    model_path = 'runs/student/yolov8s_distilled/weights/best.pt'
    
    # Output path
    output_path = 'models/yolov8s_defect_detection.onnx'
    
    # Create output directory
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    
    # Export model
    imgsz = config['export']['imgsz']
    opset = 11  # Fixed to opset 11 as per requirement
    
    exported_path = export_yolo_to_onnx(
        model_path=model_path,
        output_path=output_path,
        imgsz=imgsz,
        opset=opset
    )
    
    print(f"\n{'='*80}")
    print("IMPORTANT NOTES:")
    print("="*80)
    print("1. The exported ONNX model has input name: 'input'")
    print("2. Input shape: (1, 3, H, W) - single RGB image")
    print("3. Input type: float32")
    print("4. For the exact output format (boxes, labels, scores), you may need")
    print("   to add post-processing in your inference pipeline.")
    print("5. YOLOv8 outputs typically need NMS and format conversion.")
    print("6. Refer to the inference scripts for proper usage.")
    print("="*80)
    
    # Also create a version with label remapping info
    print("\nLabel Mapping for ONNX Model:")
    print("- YOLO label 0 (chip) → ONNX output 2")
    print("- YOLO label 1 (check) → ONNX output 1")
    print("\nThis remapping should be applied in your inference code.")


if __name__ == '__main__':
    main()
