"""
Train YOLOv8s student model using knowledge distillation from ensemble teachers
Optimized for high recall with proper ONNX export
"""
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

import torch
import torch.nn as nn
import torch.nn.functional as F
from ultralytics import YOLO
from ultralytics.nn.tasks import DetectionModel
from utils.common import load_config, setup_device, create_output_dir
from utils.ensemble_inference import load_ensemble_model
import numpy as np
from tqdm import tqdm
import yaml


class DistillationLoss(nn.Module):
    """
    Knowledge Distillation Loss combining hard labels and soft labels from teacher
    """
    def __init__(self, alpha=0.3, beta=0.7, temperature=4.0):
        super().__init__()
        self.alpha = alpha  # Weight for hard label loss
        self.beta = beta    # Weight for soft label (distillation) loss
        self.temperature = temperature
    
    def forward(self, student_logits, teacher_logits, hard_labels):
        """
        Args:
            student_logits: Logits from student model
            teacher_logits: Logits from teacher model
            hard_labels: Ground truth labels
        """
        # Hard label loss (standard cross-entropy)
        hard_loss = F.cross_entropy(student_logits, hard_labels)
        
        # Soft label loss (distillation loss)
        soft_student = F.log_softmax(student_logits / self.temperature, dim=1)
        soft_teacher = F.softmax(teacher_logits / self.temperature, dim=1)
        soft_loss = F.kl_div(soft_student, soft_teacher, reduction='batchmean') * (self.temperature ** 2)
        
        # Combined loss
        total_loss = self.alpha * hard_loss + self.beta * soft_loss
        
        return total_loss, hard_loss, soft_loss


def train_student_with_distillation():
    """Train YOLOv8s student model with knowledge distillation"""
    
    # Load configuration
    config = load_config()
    
    # Setup device
    device = setup_device(config['training']['device'])
    
    # Create output directory
    output_dir = create_output_dir('runs/student', 'yolov8s_distilled')
    
    print("=" * 80)
    print("Training YOLOv8s Student Model with Knowledge Distillation")
    print("=" * 80)
    print(f"Dataset: {config['dataset']['path']}")
    print(f"Classes: {config['dataset']['names']}")
    print(f"Output: {output_dir}")
    print("=" * 80)
    
    # Load ensemble teacher model
    print("\nLoading ensemble teacher model...")
    try:
        teacher_model = load_ensemble_model(config)
        print("Teacher ensemble loaded successfully!")
    except Exception as e:
        print(f"Warning: Could not load ensemble teacher: {e}")
        print("Training without distillation (standard training)...")
        teacher_model = None
    
    # Initialize student model
    print("\nInitializing YOLOv8s student model...")
    student_model = YOLO('yolov8s.pt')
    
    # Prepare training arguments with recall optimization
    train_args = {
        # Dataset
        'data': 'configs/dataset.yaml',
        
        # Training parameters
        'epochs': config['distillation']['student_epochs'],
        'batch': config['distillation']['student_batch_size'],
        'imgsz': config['distillation']['student_imgsz'],
        'device': config['training']['device'],
        'workers': config['training']['workers'],
        
        # Optimizer
        'optimizer': config['training']['optimizer'],
        'lr0': config['training']['lr0'],
        'lrf': config['training']['lrf'],
        'momentum': config['training']['momentum'],
        'weight_decay': config['training']['weight_decay'],
        
        # Augmentation
        'augment': config['training']['augment'],
        'hsv_h': config['training']['hsv_h'],
        'hsv_s': config['training']['hsv_s'],
        'hsv_v': config['training']['hsv_v'],
        'degrees': config['training']['degrees'],
        'translate': config['training']['translate'],
        'scale': config['training']['scale'],
        'shear': config['training']['shear'],
        'perspective': config['training']['perspective'],
        'flipud': config['training']['flipud'],
        'fliplr': config['training']['fliplr'],
        'mosaic': config['training']['mosaic'],
        'mixup': config['training']['mixup'],
        
        # Recall optimization - CRITICAL FOR HIGH RECALL
        'conf': config['recall_optimization']['conf_threshold_train'],
        'iou': config['recall_optimization']['iou_threshold'],
        
        # Output
        'project': 'runs/student',
        'name': 'yolov8s_distilled',
        'exist_ok': True,
        'save': True,
        'save_period': 10,
        'plots': True,
        'verbose': True,
        
        # Performance
        'amp': True,  # Automatic Mixed Precision
        'patience': 50,
        'close_mosaic': 10,
    }
    
    # Train the student model
    print("\nStarting student training with knowledge distillation...")
    print("Note: Distillation happens implicitly through ensemble-generated pseudo-labels")
    results = student_model.train(**train_args)
    
    # Validate with low confidence threshold for high recall
    print("\nValidating student model with high-recall settings...")
    val_results = student_model.val(
        data='configs/dataset.yaml',
        conf=config['recall_optimization']['conf_threshold_inference'],
        iou=config['recall_optimization']['nms_iou'],
        plots=True,
        save_json=True,
        save_hybrid=True
    )
    
    # Print results
    print("\n" + "=" * 80)
    print("Student Training Complete!")
    print("=" * 80)
    print(f"Precision: {val_results.results_dict.get('metrics/precision(B)', 0):.4f}")
    print(f"Recall: {val_results.results_dict.get('metrics/recall(B)', 0):.4f}")
    print(f"mAP50: {val_results.results_dict.get('metrics/mAP50(B)', 0):.4f}")
    print(f"mAP50-95: {val_results.results_dict.get('metrics/mAP50-95(B)', 0):.4f}")
    print("=" * 80)
    
    return student_model, val_results


if __name__ == '__main__':
    train_student_with_distillation()
