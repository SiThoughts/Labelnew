# Defect Detection Project - Usage Guide

## Overview

This project implements a high-recall defect detection system using:
1. **Ensemble Learning**: YOLOv8-NAS + Faster R-CNN ResNet101
2. **Teacher-Student Distillation**: YOLOv8s student model
3. **ONNX Export**: Production-ready deployment

**Target Performance**: 90% Precision, 90% Recall

## Project Structure

```
defect_detection_project/
├── configs/
│   ├── config.yaml          # Main configuration
│   └── dataset.yaml         # Dataset configuration
├── ensemble_training/
│   ├── train_yolov8_nas.py  # Train YOLOv8-NAS
│   └── train_frcnn_resnet101.py  # Train Faster R-CNN
├── student_training/
│   ├── train_student_yolov8s.py  # Train student with distillation
│   └── export_to_onnx.py    # Export to ONNX
├── inference/
│   ├── onnx_inference.py    # ONNX inference
│   └── evaluate.py          # Model evaluation
├── utils/
│   ├── common.py            # Common utilities
│   ├── focal_loss.py        # Focal loss implementation
│   ├── yolo_to_coco.py      # Format conversion
│   └── ensemble_inference.py # Ensemble inference
├── train_all.py             # Main training pipeline
├── train.bat                # Windows training script
├── train.sh                 # Linux/Mac training script
└── requirements.txt         # Python dependencies
```

## Quick Start

### 1. Setup

**Windows:**
```batch
train.bat
```

**Linux/Mac:**
```bash
./train.sh
```

Or manually:
```bash
pip install -r requirements.txt
python train_all.py
```

### 2. Configuration

Edit `configs/config.yaml` to set:
- Dataset path
- Training parameters (batch size, epochs, image size)
- Recall optimization settings
- Class names and mappings

Edit `configs/dataset.yaml` to match your dataset structure:
```yaml
path: D:\Photomask\merlin\barelyai\dataset\SV
train: images/train
val: images/val
names:
  0: chip
  1: check
nc: 2
```

### 3. Dataset Format

Your dataset should be in YOLO format:
```
dataset/
├── images/
│   ├── train/
│   │   ├── image1.jpg
│   │   └── image2.jpg
│   └── val/
│       ├── image3.jpg
│       └── image4.jpg
└── labels/
    ├── train/
    │   ├── image1.txt
    │   └── image2.txt
    └── val/
        ├── image3.txt
        └── image4.txt
```

Label format (YOLO):
```
class_id x_center y_center width height
```
All values normalized to [0, 1].

## Training Pipeline

### Step 1: Train Ensemble Models

**YOLOv8-NAS:**
```bash
python ensemble_training/train_yolov8_nas.py
```
Output: `runs/ensemble/yolov8n/weights/best.pt`

**Faster R-CNN ResNet101:**
```bash
python ensemble_training/train_frcnn_resnet101.py
```
Output: `runs/ensemble/frcnn_resnet101/best.pth`

### Step 2: Train Student Model

```bash
python student_training/train_student_yolov8s.py
```
Output: `runs/student/yolov8s_distilled/weights/best.pt`

### Step 3: Export to ONNX

```bash
python student_training/export_to_onnx.py
```
Output: `models/yolov8s_defect_detection.onnx`

**ONNX Specifications:**
- Opset: 11
- Input: `input` (1, 3, H, W) float32
- Outputs: `boxes` (N, 4), `labels` (N,), `scores` (N,)
- Dynamic axes for variable number of detections

## Inference

### ONNX Inference

```bash
python inference/onnx_inference.py \
  --model models/yolov8s_defect_detection.onnx \
  --image path/to/image.jpg \
  --output output.jpg \
  --conf 0.15 \
  --iou 0.5
```

### Python API

```python
from inference.onnx_inference import ONNXDefectDetector

# Initialize detector
detector = ONNXDefectDetector(
    onnx_path='models/yolov8s_defect_detection.onnx',
    conf_threshold=0.15,
    iou_threshold=0.5
)

# Run inference
results = detector.predict('image.jpg')

# Results format:
# {
#   'boxes': np.ndarray (N, 4),  # [x1, y1, x2, y2]
#   'labels': np.ndarray (N,),   # class IDs
#   'scores': np.ndarray (N,)    # confidence scores
# }

# Visualize
detector.visualize('image.jpg', 'output.jpg')
```

## Evaluation

```bash
python inference/evaluate.py \
  --model runs/student/yolov8s_distilled/weights/best.pt \
  --model-type yolo \
  --dataset D:\Photomask\merlin\barelyai\dataset\SV \
  --split val \
  --conf 0.15 \
  --iou 0.5 \
  --output evaluation_results.json
```

For ONNX model:
```bash
python inference/evaluate.py \
  --model models/yolov8s_defect_detection.onnx \
  --model-type onnx \
  --dataset D:\Photomask\merlin\barelyai\dataset\SV \
  --split val \
  --conf 0.15 \
  --iou 0.5 \
  --output evaluation_results.json
```

## Label Mapping

**Important**: The ONNX model uses a different label mapping:

| Defect Type | YOLO Label | ONNX Output |
|-------------|------------|-------------|
| chip        | 0          | 2           |
| check       | 1          | 1           |

This mapping is automatically handled in `inference/onnx_inference.py`.

## Recall Optimization

The project includes several techniques to maximize recall:

1. **Focal Loss**: Focuses on hard-to-detect defects
2. **Low Confidence Threshold**: Default 0.15 (can be lowered to 0.01 for even higher recall)
3. **Class Weights**: Higher weight for defect classes
4. **High NMS IoU**: Keeps more overlapping detections
5. **Ensemble Fusion**: Combines predictions from multiple models

To tune for higher recall, adjust in `configs/config.yaml`:
```yaml
recall_optimization:
  conf_threshold_inference: 0.10  # Lower = higher recall
  nms_iou: 0.7                    # Higher = more detections kept
  class_weights: [2.0, 2.0]       # Higher = more focus on defects
```

## Hardware Requirements

- **GPU**: 11GB VRAM (tested configuration)
- **RAM**: 16GB+ recommended
- **Storage**: 10GB+ for models and datasets

## Training Time Estimates

- YOLOv8-NAS: ~2-4 hours (300 epochs)
- Faster R-CNN: ~4-6 hours (300 epochs)
- YOLOv8s Student: ~2-3 hours (200 epochs)

Total: ~8-13 hours for complete pipeline

## Troubleshooting

### Out of Memory Error
- Reduce batch size in `configs/config.yaml`
- Reduce image size (default 640)
- Enable gradient checkpointing

### Low Recall
- Lower confidence threshold
- Increase class weights
- Train for more epochs
- Use more data augmentation

### ONNX Export Issues
- Ensure model is fully trained
- Check ONNX opset compatibility
- Verify input/output shapes

## Support

For issues or questions, refer to:
- Ultralytics documentation: https://docs.ultralytics.com
- PyTorch documentation: https://pytorch.org/docs
- ONNX documentation: https://onnx.ai/onnx/
