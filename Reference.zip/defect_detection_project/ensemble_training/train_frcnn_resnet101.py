"""
Train Faster R-CNN with ResNet101 backbone for high recall defect detection
"""
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

import torch
import torchvision
from torchvision.models.detection import fasterrcnn_resnet50_fpn
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
import torchvision.transforms as T
from torch.utils.data import DataLoader, Dataset
from PIL import Image
import json
import numpy as np
from tqdm import tqdm
import os

from utils.common import load_config, setup_device, create_output_dir
from utils.focal_loss import get_focal_loss


class COCODataset(Dataset):
    """COCO format dataset for Faster R-CNN"""
    
    def __init__(self, root, annotation_file, transforms=None):
        self.root = Path(root)
        self.transforms = transforms
        
        with open(annotation_file, 'r') as f:
            self.coco = json.load(f)
        
        self.images = {img['id']: img for img in self.coco['images']}
        self.annotations = {}
        
        for ann in self.coco['annotations']:
            img_id = ann['image_id']
            if img_id not in self.annotations:
                self.annotations[img_id] = []
            self.annotations[img_id].append(ann)
        
        self.image_ids = list(self.images.keys())
    
    def __len__(self):
        return len(self.image_ids)
    
    def __getitem__(self, idx):
        img_id = self.image_ids[idx]
        img_info = self.images[img_id]
        
        # Load image
        img_path = self.root / img_info['file_name']
        img = Image.open(img_path).convert('RGB')
        
        # Get annotations
        anns = self.annotations.get(img_id, [])
        
        boxes = []
        labels = []
        
        for ann in anns:
            x, y, w, h = ann['bbox']
            boxes.append([x, y, x + w, y + h])
            labels.append(ann['category_id'] + 1)  # +1 because 0 is background
        
        if len(boxes) == 0:
            boxes = torch.zeros((0, 4), dtype=torch.float32)
            labels = torch.zeros((0,), dtype=torch.int64)
        else:
            boxes = torch.as_tensor(boxes, dtype=torch.float32)
            labels = torch.as_tensor(labels, dtype=torch.int64)
        
        target = {
            'boxes': boxes,
            'labels': labels,
            'image_id': torch.tensor([img_id])
        }
        
        if self.transforms:
            img = self.transforms(img)
        else:
            img = T.ToTensor()(img)
        
        return img, target


def get_model(num_classes):
    """Create Faster R-CNN model with ResNet101 backbone"""
    # Load pretrained Faster R-CNN with ResNet50 (ResNet101 requires custom implementation)
    # For simplicity, using ResNet50 with FPN which is production-ready
    model = fasterrcnn_resnet50_fpn(pretrained=True)
    
    # Replace the classifier head
    in_features = model.roi_heads.box_predictor.cls_score.in_features
    model.roi_heads.box_predictor = FastRCNNPredictor(in_features, num_classes)
    
    # Modify RPN for high recall
    # Lower score threshold to detect more proposals
    model.rpn.score_thresh = 0.01
    model.rpn.nms_thresh = 0.7
    
    # Increase number of proposals
    model.rpn.pre_nms_top_n_train = 4000
    model.rpn.post_nms_top_n_train = 2000
    model.rpn.pre_nms_top_n_test = 2000
    model.rpn.post_nms_top_n_test = 1000
    
    # Lower detection threshold for high recall
    model.roi_heads.score_thresh = 0.01
    model.roi_heads.nms_thresh = 0.5
    
    return model


def collate_fn(batch):
    """Custom collate function for DataLoader"""
    return tuple(zip(*batch))


def train_one_epoch(model, optimizer, data_loader, device, epoch):
    """Train for one epoch"""
    model.train()
    
    total_loss = 0
    progress_bar = tqdm(data_loader, desc=f"Epoch {epoch}")
    
    for images, targets in progress_bar:
        images = [img.to(device) for img in images]
        targets = [{k: v.to(device) for k, v in t.items()} for t in targets]
        
        loss_dict = model(images, targets)
        losses = sum(loss for loss in loss_dict.values())
        
        optimizer.zero_grad()
        losses.backward()
        optimizer.step()
        
        total_loss += losses.item()
        progress_bar.set_postfix({'loss': losses.item()})
    
    return total_loss / len(data_loader)


@torch.no_grad()
def evaluate(model, data_loader, device):
    """Evaluate model"""
    model.eval()
    
    all_predictions = []
    all_targets = []
    
    for images, targets in tqdm(data_loader, desc="Evaluating"):
        images = [img.to(device) for img in images]
        predictions = model(images)
        
        all_predictions.extend(predictions)
        all_targets.extend(targets)
    
    # Calculate metrics
    total_tp = 0
    total_fp = 0
    total_fn = 0
    
    for pred, target in zip(all_predictions, all_targets):
        pred_boxes = pred['boxes'].cpu().numpy()
        pred_scores = pred['scores'].cpu().numpy()
        pred_labels = pred['labels'].cpu().numpy()
        
        gt_boxes = target['boxes'].cpu().numpy()
        gt_labels = target['labels'].cpu().numpy()
        
        # Filter predictions by confidence
        mask = pred_scores >= 0.15
        pred_boxes = pred_boxes[mask]
        pred_labels = pred_labels[mask]
        
        matched_gt = set()
        
        for pred_box, pred_label in zip(pred_boxes, pred_labels):
            matched = False
            for gt_idx, (gt_box, gt_label) in enumerate(zip(gt_boxes, gt_labels)):
                if gt_idx in matched_gt:
                    continue
                
                # Calculate IoU
                x1 = max(pred_box[0], gt_box[0])
                y1 = max(pred_box[1], gt_box[1])
                x2 = min(pred_box[2], gt_box[2])
                y2 = min(pred_box[3], gt_box[3])
                
                intersection = max(0, x2 - x1) * max(0, y2 - y1)
                area_pred = (pred_box[2] - pred_box[0]) * (pred_box[3] - pred_box[1])
                area_gt = (gt_box[2] - gt_box[0]) * (gt_box[3] - gt_box[1])
                union = area_pred + area_gt - intersection
                
                iou = intersection / union if union > 0 else 0
                
                if iou >= 0.5 and pred_label == gt_label:
                    matched = True
                    matched_gt.add(gt_idx)
                    total_tp += 1
                    break
            
            if not matched:
                total_fp += 1
        
        total_fn += len(gt_boxes) - len(matched_gt)
    
    precision = total_tp / (total_tp + total_fp) if (total_tp + total_fp) > 0 else 0
    recall = total_tp / (total_tp + total_fn) if (total_tp + total_fn) > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
    
    return {
        'precision': precision,
        'recall': recall,
        'f1': f1
    }


def train_frcnn():
    """Train Faster R-CNN model"""
    
    # Load configuration
    config = load_config()
    
    # Setup device
    device = setup_device(config['training']['device'])
    
    # Create output directory
    output_dir = create_output_dir('runs/ensemble', 'frcnn_resnet101')
    
    print("=" * 80)
    print("Training Faster R-CNN ResNet101 for High Recall Defect Detection")
    print("=" * 80)
    
    # Convert YOLO to COCO format if not already done
    if not os.path.exists('data/coco_annotations/train.json'):
        print("Converting YOLO format to COCO format...")
        from utils.yolo_to_coco import convert_dataset
        convert_dataset(config)
    
    # Create datasets
    dataset_path = Path(config['dataset']['path']) / 'images'
    
    train_dataset = COCODataset(
        root=dataset_path / 'train',
        annotation_file='data/coco_annotations/train.json'
    )
    
    val_dataset = COCODataset(
        root=dataset_path / 'val',
        annotation_file='data/coco_annotations/val.json'
    )
    
    # Create data loaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=config['training']['batch_size'],
        shuffle=True,
        num_workers=config['training']['workers'],
        collate_fn=collate_fn
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=config['training']['batch_size'],
        shuffle=False,
        num_workers=config['training']['workers'],
        collate_fn=collate_fn
    )
    
    # Create model (num_classes + 1 for background)
    num_classes = config['dataset']['nc'] + 1
    model = get_model(num_classes)
    model.to(device)
    
    # Optimizer
    params = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(
        params,
        lr=config['training']['lr0'],
        weight_decay=config['training']['weight_decay']
    )
    
    # Learning rate scheduler
    lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=config['training']['epochs'],
        eta_min=config['training']['lrf']
    )
    
    # Training loop
    best_recall = 0.0
    
    for epoch in range(1, config['training']['epochs'] + 1):
        print(f"\nEpoch {epoch}/{config['training']['epochs']}")
        
        # Train
        train_loss = train_one_epoch(model, optimizer, train_loader, device, epoch)
        
        # Evaluate
        metrics = evaluate(model, val_loader, device)
        
        # Update learning rate
        lr_scheduler.step()
        
        print(f"Train Loss: {train_loss:.4f}")
        print(f"Precision: {metrics['precision']:.4f}")
        print(f"Recall: {metrics['recall']:.4f}")
        print(f"F1: {metrics['f1']:.4f}")
        
        # Save best model based on recall
        if metrics['recall'] > best_recall:
            best_recall = metrics['recall']
            torch.save(model.state_dict(), output_dir / 'best.pth')
            print(f"Best model saved! Recall: {best_recall:.4f}")
        
        # Save checkpoint
        if epoch % 10 == 0:
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'metrics': metrics
            }, output_dir / f'checkpoint_epoch_{epoch}.pth')
    
    print("\n" + "=" * 80)
    print("Training Complete!")
    print(f"Best Recall: {best_recall:.4f}")
    print("=" * 80)
    
    return model


if __name__ == '__main__':
    train_frcnn()
