"""
Train YOLOv8-NAS model with high recall optimization
"""
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

import torch
from ultralytics import YOLO
from utils.common import load_config, setup_device, create_output_dir
import yaml


def train_yolov8_nas():
    """Train YOLOv8-NAS model optimized for high recall"""
    
    # Load configuration
    config = load_config()
    
    # Setup device
    device = setup_device(config['training']['device'])
    
    # Create output directory
    output_dir = create_output_dir('runs/ensemble', 'yolov8n')
    
    print("=" * 80)
    print("Training YOLOv8-NAS for High Recall Defect Detection")
    print("=" * 80)
    print(f"Dataset: {config['dataset']['path']}")
    print(f"Classes: {config['dataset']['names']}")
    print(f"Output: {output_dir}")
    print("=" * 80)
    
    # Initialize model
    model = YOLO('yolov8n.pt')  # YOLOv8-Nano (NAS architecture)
    
    # Prepare training arguments with recall optimization
    train_args = {
        # Dataset
        'data': 'configs/dataset.yaml',
        
        # Training parameters
        'epochs': config['training']['epochs'],
        'batch': config['training']['batch_size'],
        'imgsz': config['training']['imgsz'],
        'device': config['training']['device'],
        'workers': config['training']['workers'],
        
        # Optimizer
        'optimizer': config['training']['optimizer'],
        'lr0': config['training']['lr0'],
        'lrf': config['training']['lrf'],
        'momentum': config['training']['momentum'],
        'weight_decay': config['training']['weight_decay'],
        
        # Augmentation
        'augment': config['training']['augment'],
        'hsv_h': config['training']['hsv_h'],
        'hsv_s': config['training']['hsv_s'],
        'hsv_v': config['training']['hsv_v'],
        'degrees': config['training']['degrees'],
        'translate': config['training']['translate'],
        'scale': config['training']['scale'],
        'shear': config['training']['shear'],
        'perspective': config['training']['perspective'],
        'flipud': config['training']['flipud'],
        'fliplr': config['training']['fliplr'],
        'mosaic': config['training']['mosaic'],
        'mixup': config['training']['mixup'],
        
        # Recall optimization
        'conf': config['recall_optimization']['conf_threshold_train'],
        'iou': config['recall_optimization']['iou_threshold'],
        
        # Output
        'project': 'runs/ensemble',
        'name': 'yolov8n',
        'exist_ok': True,
        'save': True,
        'save_period': 10,
        'plots': True,
        'verbose': True,
        
        # Performance
        'amp': True,  # Automatic Mixed Precision
        'patience': 50,
        'close_mosaic': 10,
    }
    
    # Train the model
    print("\nStarting training...")
    results = model.train(**train_args)
    
    # Validate with low confidence threshold for high recall
    print("\nValidating with high-recall settings...")
    val_results = model.val(
        data='configs/dataset.yaml',
        conf=config['recall_optimization']['conf_threshold_inference'],
        iou=config['recall_optimization']['nms_iou'],
        plots=True,
        save_json=True,
        save_hybrid=True
    )
    
    # Save final model
    model_save_path = output_dir / 'best.pt'
    print(f"\nBest model saved to: {model_save_path}")
    
    # Print results
    print("\n" + "=" * 80)
    print("Training Complete!")
    print("=" * 80)
    print(f"Precision: {val_results.results_dict.get('metrics/precision(B)', 0):.4f}")
    print(f"Recall: {val_results.results_dict.get('metrics/recall(B)', 0):.4f}")
    print(f"mAP50: {val_results.results_dict.get('metrics/mAP50(B)', 0):.4f}")
    print(f"mAP50-95: {val_results.results_dict.get('metrics/mAP50-95(B)', 0):.4f}")
    print("=" * 80)
    
    return model, val_results


if __name__ == '__main__':
    train_yolov8_nas()
