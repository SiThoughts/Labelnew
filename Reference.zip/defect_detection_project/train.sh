#!/bin/bash
# Defect Detection Training Pipeline
# Automated training script for Linux/Mac

echo "================================================================================"
echo "DEFECT DETECTION TRAINING PIPELINE"
echo "High-Recall Ensemble + Teacher-Student Distillation"
echo "================================================================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed or not in PATH"
    exit 1
fi

# Install dependencies
echo "Installing dependencies..."
pip3 install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install dependencies"
    exit 1
fi

echo ""
echo "Dependencies installed successfully!"
echo ""

# Run training pipeline
echo "Starting training pipeline..."
python3 train_all.py

echo ""
echo "================================================================================"
echo "Training pipeline completed!"
echo "================================================================================"
echo ""
