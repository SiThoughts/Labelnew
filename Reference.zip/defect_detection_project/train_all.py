"""
Main training script - Runs complete pipeline:
1. Train YOLOv8-NAS (ensemble model 1)
2. Train Faster R-CNN ResNet101 (ensemble model 2)
3. Train YOLOv8s student with distillation
4. Export to ONNX
5. Evaluate all models
"""
import sys
from pathlib import Path

def main():
    """Run complete training pipeline"""
    
    print("=" * 80)
    print("DEFECT DETECTION TRAINING PIPELINE")
    print("High-Recall Ensemble + Teacher-Student Distillation")
    print("=" * 80)
    
    # Step 1: Train YOLOv8-NAS
    print("\n" + "=" * 80)
    print("STEP 1: Training YOLOv8-NAS (Ensemble Model 1)")
    print("=" * 80)
    
    try:
        from ensemble_training.train_yolov8_nas import train_yolov8_nas
        yolo_model, yolo_results = train_yolov8_nas()
        print("✓ YOLOv8-NAS training completed successfully!")
    except Exception as e:
        print(f"✗ Error training YOLOv8-NAS: {e}")
        print("Continuing with next step...")
    
    # Step 2: Train Faster R-CNN
    print("\n" + "=" * 80)
    print("STEP 2: Training Faster R-CNN ResNet101 (Ensemble Model 2)")
    print("=" * 80)
    
    try:
        from ensemble_training.train_frcnn_resnet101 import train_frcnn
        frcnn_model = train_frcnn()
        print("✓ Faster R-CNN training completed successfully!")
    except Exception as e:
        print(f"✗ Error training Faster R-CNN: {e}")
        print("Continuing with next step...")
    
    # Step 3: Train YOLOv8s Student
    print("\n" + "=" * 80)
    print("STEP 3: Training YOLOv8s Student with Knowledge Distillation")
    print("=" * 80)
    
    try:
        from student_training.train_student_yolov8s import train_student_with_distillation
        student_model, student_results = train_student_with_distillation()
        print("✓ YOLOv8s student training completed successfully!")
    except Exception as e:
        print(f"✗ Error training student model: {e}")
        print("Continuing with next step...")
    
    # Step 4: Export to ONNX
    print("\n" + "=" * 80)
    print("STEP 4: Exporting YOLOv8s Student to ONNX")
    print("=" * 80)
    
    try:
        from student_training.export_to_onnx import main as export_main
        export_main()
        print("✓ ONNX export completed successfully!")
    except Exception as e:
        print(f"✗ Error exporting to ONNX: {e}")
        print("Continuing with next step...")
    
    # Step 5: Evaluate models
    print("\n" + "=" * 80)
    print("STEP 5: Evaluating Models")
    print("=" * 80)
    
    print("\nEvaluation can be run separately using:")
    print("  python inference/evaluate.py --model <model_path> --dataset <dataset_path>")
    
    # Summary
    print("\n" + "=" * 80)
    print("TRAINING PIPELINE COMPLETE!")
    print("=" * 80)
    
    print("\nGenerated Models:")
    print("  1. YOLOv8-NAS:        runs/ensemble/yolov8n/weights/best.pt")
    print("  2. Faster R-CNN:      runs/ensemble/frcnn_resnet101/best.pth")
    print("  3. YOLOv8s Student:   runs/student/yolov8s_distilled/weights/best.pt")
    print("  4. ONNX Model:        models/yolov8s_defect_detection.onnx")
    
    print("\nNext Steps:")
    print("  - Evaluate models using inference/evaluate.py")
    print("  - Test ONNX inference using inference/onnx_inference.py")
    print("  - Deploy ONNX model to production")
    
    print("\nLabel Mapping (ONNX):")
    print("  - chip (YOLO 0) → ONNX output 2")
    print("  - check (YOLO 1) → ONNX output 1")
    
    print("\n" + "=" * 80)


if __name__ == '__main__':
    main()
