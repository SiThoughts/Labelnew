"""
Evaluation script for measuring precision, recall, F1, and mAP
"""
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

import numpy as np
from tqdm import tqdm
import json
from typing import Dict, List
from utils.common import load_config, compute_iou
import cv2


def parse_yolo_label(label_path: str, img_width: int, img_height: int) -> Dict:
    """Parse YOLO format label file"""
    boxes = []
    labels = []
    
    if not Path(label_path).exists():
        return {'boxes': np.array([]), 'labels': np.array([])}
    
    with open(label_path, 'r') as f:
        lines = f.readlines()
    
    for line in lines:
        parts = line.strip().split()
        if len(parts) < 5:
            continue
        
        class_id = int(parts[0])
        x_center = float(parts[1]) * img_width
        y_center = float(parts[2]) * img_height
        width = float(parts[3]) * img_width
        height = float(parts[4]) * img_height
        
        x1 = x_center - width / 2
        y1 = y_center - height / 2
        x2 = x_center + width / 2
        y2 = y_center + height / 2
        
        boxes.append([x1, y1, x2, y2])
        labels.append(class_id)
    
    return {
        'boxes': np.array(boxes),
        'labels': np.array(labels, dtype=int)
    }


def calculate_metrics_per_image(pred_boxes, pred_labels, pred_scores,
                                 gt_boxes, gt_labels, iou_threshold=0.5):
    """Calculate TP, FP, FN for a single image"""
    tp = 0
    fp = 0
    fn = 0
    
    if len(pred_boxes) == 0 and len(gt_boxes) == 0:
        return tp, fp, fn
    
    if len(pred_boxes) == 0:
        fn = len(gt_boxes)
        return tp, fp, fn
    
    if len(gt_boxes) == 0:
        fp = len(pred_boxes)
        return tp, fp, fn
    
    matched_gt = set()
    
    # For each prediction, find best matching ground truth
    for pred_box, pred_label in zip(pred_boxes, pred_labels):
        best_iou = 0
        best_gt_idx = -1
        
        for gt_idx, (gt_box, gt_label) in enumerate(zip(gt_boxes, gt_labels)):
            if gt_idx in matched_gt:
                continue
            
            if pred_label != gt_label:
                continue
            
            iou = compute_iou(pred_box, gt_box)
            
            if iou > best_iou:
                best_iou = iou
                best_gt_idx = gt_idx
        
        if best_iou >= iou_threshold:
            tp += 1
            matched_gt.add(best_gt_idx)
        else:
            fp += 1
    
    fn = len(gt_boxes) - len(matched_gt)
    
    return tp, fp, fn


def evaluate_model(model, dataset_path, split='val', conf_threshold=0.15, iou_threshold=0.5):
    """
    Evaluate model on dataset
    
    Args:
        model: Model object with predict() method
        dataset_path: Path to dataset root
        split: 'train', 'val', or 'test'
        conf_threshold: Confidence threshold
        iou_threshold: IoU threshold for matching
        
    Returns:
        Dictionary with metrics
    """
    dataset_path = Path(dataset_path)
    images_dir = dataset_path / 'images' / split
    labels_dir = dataset_path / 'labels' / split
    
    # Get all images
    image_files = list(images_dir.glob('*.jpg')) + list(images_dir.glob('*.png'))
    
    print(f"Evaluating on {len(image_files)} images from {split} set...")
    
    total_tp = 0
    total_fp = 0
    total_fn = 0
    
    # Per-class metrics
    class_tp = {0: 0, 1: 0}  # chip, check
    class_fp = {0: 0, 1: 0}
    class_fn = {0: 0, 1: 0}
    
    results_per_image = []
    
    for img_file in tqdm(image_files, desc="Evaluating"):
        # Get predictions
        try:
            predictions = model.predict(str(img_file))
            pred_boxes = predictions['boxes']
            pred_labels = predictions['labels']
            pred_scores = predictions['scores']
        except Exception as e:
            print(f"Error predicting {img_file}: {e}")
            continue
        
        # Get ground truth
        img = cv2.imread(str(img_file))
        img_h, img_w = img.shape[:2]
        
        label_file = labels_dir / f"{img_file.stem}.txt"
        ground_truth = parse_yolo_label(str(label_file), img_w, img_h)
        gt_boxes = ground_truth['boxes']
        gt_labels = ground_truth['labels']
        
        # Calculate metrics for this image
        tp, fp, fn = calculate_metrics_per_image(
            pred_boxes, pred_labels, pred_scores,
            gt_boxes, gt_labels, iou_threshold
        )
        
        total_tp += tp
        total_fp += fp
        total_fn += fn
        
        # Per-class metrics
        for class_id in [0, 1]:
            pred_mask = pred_labels == class_id
            gt_mask = gt_labels == class_id
            
            class_pred_boxes = pred_boxes[pred_mask] if len(pred_boxes) > 0 else np.array([])
            class_pred_labels = pred_labels[pred_mask] if len(pred_labels) > 0 else np.array([])
            class_pred_scores = pred_scores[pred_mask] if len(pred_scores) > 0 else np.array([])
            
            class_gt_boxes = gt_boxes[gt_mask] if len(gt_boxes) > 0 else np.array([])
            class_gt_labels = gt_labels[gt_mask] if len(gt_labels) > 0 else np.array([])
            
            c_tp, c_fp, c_fn = calculate_metrics_per_image(
                class_pred_boxes, class_pred_labels, class_pred_scores,
                class_gt_boxes, class_gt_labels, iou_threshold
            )
            
            class_tp[class_id] += c_tp
            class_fp[class_id] += c_fp
            class_fn[class_id] += c_fn
        
        results_per_image.append({
            'image': img_file.name,
            'tp': tp,
            'fp': fp,
            'fn': fn
        })
    
    # Calculate overall metrics
    precision = total_tp / (total_tp + total_fp) if (total_tp + total_fp) > 0 else 0
    recall = total_tp / (total_tp + total_fn) if (total_tp + total_fn) > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
    
    # Calculate per-class metrics
    class_metrics = {}
    for class_id, class_name in [(0, 'chip'), (1, 'check')]:
        c_precision = class_tp[class_id] / (class_tp[class_id] + class_fp[class_id]) \
            if (class_tp[class_id] + class_fp[class_id]) > 0 else 0
        c_recall = class_tp[class_id] / (class_tp[class_id] + class_fn[class_id]) \
            if (class_tp[class_id] + class_fn[class_id]) > 0 else 0
        c_f1 = 2 * c_precision * c_recall / (c_precision + c_recall) \
            if (c_precision + c_recall) > 0 else 0
        
        class_metrics[class_name] = {
            'precision': c_precision,
            'recall': c_recall,
            'f1': c_f1,
            'tp': class_tp[class_id],
            'fp': class_fp[class_id],
            'fn': class_fn[class_id]
        }
    
    results = {
        'overall': {
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'tp': total_tp,
            'fp': total_fp,
            'fn': total_fn
        },
        'per_class': class_metrics,
        'per_image': results_per_image
    }
    
    return results


def print_results(results: Dict):
    """Print evaluation results"""
    print("\n" + "=" * 80)
    print("EVALUATION RESULTS")
    print("=" * 80)
    
    overall = results['overall']
    print("\nOverall Metrics:")
    print(f"  Precision: {overall['precision']:.4f} ({overall['precision']*100:.2f}%)")
    print(f"  Recall:    {overall['recall']:.4f} ({overall['recall']*100:.2f}%)")
    print(f"  F1 Score:  {overall['f1']:.4f}")
    print(f"  TP: {overall['tp']}, FP: {overall['fp']}, FN: {overall['fn']}")
    
    print("\nPer-Class Metrics:")
    for class_name, metrics in results['per_class'].items():
        print(f"\n  {class_name.upper()}:")
        print(f"    Precision: {metrics['precision']:.4f} ({metrics['precision']*100:.2f}%)")
        print(f"    Recall:    {metrics['recall']:.4f} ({metrics['recall']*100:.2f}%)")
        print(f"    F1 Score:  {metrics['f1']:.4f}")
        print(f"    TP: {metrics['tp']}, FP: {metrics['fp']}, FN: {metrics['fn']}")
    
    print("\n" + "=" * 80)
    
    # Check if target metrics are met
    target_precision = 0.90
    target_recall = 0.90
    
    print("\nTarget Performance (90% precision, 90% recall):")
    if overall['precision'] >= target_precision:
        print(f"  ✓ Precision target met: {overall['precision']*100:.2f}% >= 90%")
    else:
        print(f"  ✗ Precision below target: {overall['precision']*100:.2f}% < 90%")
    
    if overall['recall'] >= target_recall:
        print(f"  ✓ Recall target met: {overall['recall']*100:.2f}% >= 90%")
    else:
        print(f"  ✗ Recall below target: {overall['recall']*100:.2f}% < 90%")
    
    print("=" * 80)


def main():
    """Main evaluation function"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Evaluate Defect Detection Model')
    parser.add_argument('--model', type=str, required=True, help='Path to model')
    parser.add_argument('--model-type', type=str, choices=['yolo', 'onnx'], default='yolo',
                       help='Model type')
    parser.add_argument('--dataset', type=str, required=True, help='Path to dataset root')
    parser.add_argument('--split', type=str, default='val', choices=['train', 'val', 'test'],
                       help='Dataset split to evaluate')
    parser.add_argument('--conf', type=float, default=0.15, help='Confidence threshold')
    parser.add_argument('--iou', type=float, default=0.5, help='IoU threshold')
    parser.add_argument('--output', type=str, default='evaluation_results.json',
                       help='Output JSON file')
    
    args = parser.parse_args()
    
    # Load model
    if args.model_type == 'yolo':
        from ultralytics import YOLO
        model = YOLO(args.model)
        
        # Wrapper to match interface
        class YOLOWrapper:
            def __init__(self, yolo_model, conf_threshold):
                self.model = yolo_model
                self.conf_threshold = conf_threshold
            
            def predict(self, image_path):
                results = self.model.predict(image_path, conf=self.conf_threshold, verbose=False)[0]
                return {
                    'boxes': results.boxes.xyxy.cpu().numpy(),
                    'labels': results.boxes.cls.cpu().numpy().astype(int),
                    'scores': results.boxes.conf.cpu().numpy()
                }
        
        model = YOLOWrapper(model, args.conf)
        
    elif args.model_type == 'onnx':
        from onnx_inference import ONNXDefectDetector
        model = ONNXDefectDetector(args.model, args.conf, args.iou)
    
    # Evaluate
    results = evaluate_model(model, args.dataset, args.split, args.conf, args.iou)
    
    # Print results
    print_results(results)
    
    # Save results
    with open(args.output, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\nResults saved to: {args.output}")


if __name__ == '__main__':
    main()
