"""
ONNX Inference script for defect detection
Handles label remapping: chip (0→2), check (1→1)
"""
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

import onnxruntime as ort
import numpy as np
import cv2
from typing import Dict, List, Tuple
from utils.common import load_config


class ONNXDefectDetector:
    """ONNX-based defect detector with label remapping"""
    
    def __init__(self, onnx_path: str, conf_threshold: float = 0.15, iou_threshold: float = 0.5):
        """
        Initialize ONNX detector
        
        Args:
            onnx_path: Path to ONNX model
            conf_threshold: Confidence threshold for detections
            iou_threshold: IoU threshold for NMS
        """
        self.onnx_path = onnx_path
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold
        
        # Load ONNX model
        print(f"Loading ONNX model from: {onnx_path}")
        self.session = ort.InferenceSession(onnx_path)
        
        # Get input/output details
        self.input_name = self.session.get_inputs()[0].name
        self.input_shape = self.session.get_inputs()[0].shape
        self.output_names = [output.name for output in self.session.get_outputs()]
        
        print(f"Input name: {self.input_name}")
        print(f"Input shape: {self.input_shape}")
        print(f"Output names: {self.output_names}")
        
        # Label mapping: YOLO → ONNX output
        # chip: 0 → 2
        # check: 1 → 1
        self.label_mapping = {0: 2, 1: 1}
        self.class_names = {2: 'chip', 1: 'check'}
        
        print("Label mapping configured:")
        print("  YOLO 0 (chip) → ONNX 2")
        print("  YOLO 1 (check) → ONNX 1")
    
    def preprocess(self, image_path: str) -> Tuple[np.ndarray, Tuple[int, int]]:
        """
        Preprocess image for ONNX inference
        
        Args:
            image_path: Path to input image
            
        Returns:
            Preprocessed image tensor and original size
        """
        # Read image
        img = cv2.imread(str(image_path))
        if img is None:
            raise ValueError(f"Failed to load image: {image_path}")
        
        orig_h, orig_w = img.shape[:2]
        
        # Get target size from input shape
        if isinstance(self.input_shape[2], int):
            target_h = self.input_shape[2]
            target_w = self.input_shape[3]
        else:
            # Dynamic shape, use default
            target_h = target_w = 640
        
        # Resize image
        img_resized = cv2.resize(img, (target_w, target_h))
        
        # Convert BGR to RGB
        img_rgb = cv2.cvtColor(img_resized, cv2.COLOR_BGR2RGB)
        
        # Normalize to [0, 1]
        img_normalized = img_rgb.astype(np.float32) / 255.0
        
        # Transpose to (C, H, W)
        img_transposed = np.transpose(img_normalized, (2, 0, 1))
        
        # Add batch dimension (1, C, H, W)
        img_tensor = np.expand_dims(img_transposed, axis=0)
        
        return img_tensor, (orig_w, orig_h)
    
    def postprocess(self, outputs: List[np.ndarray], orig_size: Tuple[int, int]) -> Dict[str, np.ndarray]:
        """
        Post-process ONNX outputs to get boxes, labels, scores
        
        Args:
            outputs: Raw ONNX outputs
            orig_size: Original image size (width, height)
            
        Returns:
            Dictionary with 'boxes', 'labels', 'scores'
        """
        # YOLOv8 output format is typically (1, num_predictions, 5+num_classes)
        # where each prediction is [x, y, w, h, conf, class_probs...]
        
        output = outputs[0]  # Get first output
        
        if len(output.shape) == 3:
            # Shape: (1, num_predictions, features)
            output = output[0]  # Remove batch dimension
        
        # Parse predictions
        # Assuming format: [x_center, y_center, width, height, ...class_scores...]
        
        boxes = []
        scores = []
        labels = []
        
        orig_w, orig_h = orig_size
        
        # Get target size
        if isinstance(self.input_shape[2], int):
            input_h = self.input_shape[2]
            input_w = self.input_shape[3]
        else:
            input_h = input_w = 640
        
        for pred in output:
            # Extract box coordinates (normalized or in input size)
            # This depends on YOLOv8 export format
            # Typical format: [x, y, w, h, conf, class0_prob, class1_prob, ...]
            
            if len(pred) < 6:
                continue
            
            # Get class scores (skip first 4 coords)
            class_scores = pred[4:]
            
            # Get best class
            class_id = np.argmax(class_scores)
            confidence = class_scores[class_id]
            
            # Filter by confidence
            if confidence < self.conf_threshold:
                continue
            
            # Extract box coordinates
            x_center, y_center, width, height = pred[:4]
            
            # Convert to xyxy format and scale to original image size
            # Note: Coordinates might already be in input image size
            x1 = (x_center - width / 2) * orig_w / input_w
            y1 = (y_center - height / 2) * orig_h / input_h
            x2 = (x_center + width / 2) * orig_w / input_w
            y2 = (y_center + height / 2) * orig_h / input_h
            
            # Apply label mapping
            mapped_label = self.label_mapping.get(class_id, class_id)
            
            boxes.append([x1, y1, x2, y2])
            scores.append(confidence)
            labels.append(mapped_label)
        
        # Convert to numpy arrays
        boxes = np.array(boxes) if boxes else np.zeros((0, 4))
        scores = np.array(scores) if scores else np.zeros((0,))
        labels = np.array(labels, dtype=int) if labels else np.zeros((0,), dtype=int)
        
        # Apply NMS
        if len(boxes) > 0:
            boxes, scores, labels = self.nms(boxes, scores, labels, self.iou_threshold)
        
        return {
            'boxes': boxes,
            'labels': labels,
            'scores': scores
        }
    
    def nms(self, boxes: np.ndarray, scores: np.ndarray, labels: np.ndarray, 
            iou_threshold: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Apply Non-Maximum Suppression"""
        if len(boxes) == 0:
            return boxes, scores, labels
        
        # Convert to format for cv2.dnn.NMSBoxes
        boxes_list = boxes.tolist()
        scores_list = scores.tolist()
        
        # Apply NMS
        indices = cv2.dnn.NMSBoxes(boxes_list, scores_list, self.conf_threshold, iou_threshold)
        
        if len(indices) > 0:
            indices = indices.flatten()
            return boxes[indices], scores[indices], labels[indices]
        else:
            return np.zeros((0, 4)), np.zeros((0,)), np.zeros((0,), dtype=int)
    
    def predict(self, image_path: str) -> Dict[str, np.ndarray]:
        """
        Run inference on an image
        
        Args:
            image_path: Path to input image
            
        Returns:
            Dictionary with 'boxes', 'labels', 'scores'
        """
        # Preprocess
        img_tensor, orig_size = self.preprocess(image_path)
        
        # Run inference
        outputs = self.session.run(self.output_names, {self.input_name: img_tensor})
        
        # Postprocess
        results = self.postprocess(outputs, orig_size)
        
        return results
    
    def visualize(self, image_path: str, output_path: str):
        """
        Run inference and save visualization
        
        Args:
            image_path: Path to input image
            output_path: Path to save output image
        """
        # Get predictions
        results = self.predict(image_path)
        
        # Load image
        img = cv2.imread(str(image_path))
        
        # Draw predictions
        for box, label, score in zip(results['boxes'], results['labels'], results['scores']):
            x1, y1, x2, y2 = box.astype(int)
            
            # Color based on class
            color = (0, 255, 0) if label == 2 else (255, 0, 0)  # Green for chip, Red for check
            
            # Draw box
            cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
            
            # Draw label
            class_name = self.class_names.get(label, f'class_{label}')
            text = f"{class_name}: {score:.2f}"
            cv2.putText(img, text, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        # Save
        cv2.imwrite(str(output_path), img)
        print(f"Visualization saved to: {output_path}")
        
        return results


def main():
    """Test ONNX inference"""
    import argparse
    
    parser = argparse.ArgumentParser(description='ONNX Defect Detection Inference')
    parser.add_argument('--model', type=str, required=True, help='Path to ONNX model')
    parser.add_argument('--image', type=str, required=True, help='Path to input image')
    parser.add_argument('--output', type=str, default='output.jpg', help='Path to output image')
    parser.add_argument('--conf', type=float, default=0.15, help='Confidence threshold')
    parser.add_argument('--iou', type=float, default=0.5, help='IoU threshold for NMS')
    
    args = parser.parse_args()
    
    # Initialize detector
    detector = ONNXDefectDetector(args.model, args.conf, args.iou)
    
    # Run inference
    results = detector.visualize(args.image, args.output)
    
    # Print results
    print(f"\nDetections: {len(results['boxes'])}")
    for i, (box, label, score) in enumerate(zip(results['boxes'], results['labels'], results['scores'])):
        class_name = detector.class_names.get(label, f'class_{label}')
        print(f"  {i+1}. {class_name}: {score:.3f} at {box}")


if __name__ == '__main__':
    main()
