"""
Ensemble inference combining YOLOv8-NAS and Faster R-CNN predictions
"""
import torch
import numpy as np
from ensemble_boxes import weighted_boxes_fusion
from ultralytics import YOLO
from pathlib import Path


class EnsembleModel:
    """Ensemble model combining YOLO and Faster R-CNN"""
    
    def __init__(self, yolo_path, frcnn_path, config):
        """
        Initialize ensemble model
        
        Args:
            yolo_path: Path to YOLO model weights
            frcnn_path: Path to Faster R-CNN model weights
            config: Configuration dictionary
        """
        self.config = config
        self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        
        # Load YOLO model
        print(f"Loading YOLO model from {yolo_path}...")
        self.yolo_model = YOLO(yolo_path)
        
        # Load Faster R-CNN model
        print(f"Loading Faster R-CNN model from {frcnn_path}...")
        from torchvision.models.detection import fasterrcnn_resnet50_fpn
        from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
        
        self.frcnn_model = fasterrcnn_resnet50_fpn(pretrained=False)
        in_features = self.frcnn_model.roi_heads.box_predictor.cls_score.in_features
        num_classes = config['dataset']['nc'] + 1
        self.frcnn_model.roi_heads.box_predictor = FastRCNNPredictor(in_features, num_classes)
        
        # Load weights
        checkpoint = torch.load(frcnn_path, map_location=self.device)
        if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
            self.frcnn_model.load_state_dict(checkpoint['model_state_dict'])
        else:
            self.frcnn_model.load_state_dict(checkpoint)
        
        self.frcnn_model.to(self.device)
        self.frcnn_model.eval()
        
        # Ensemble parameters
        self.yolo_weight = config['ensemble']['models'][0]['weight']
        self.frcnn_weight = config['ensemble']['models'][1]['weight']
        self.iou_threshold = config['ensemble']['wbf_iou_threshold']
        self.skip_box_threshold = config['ensemble']['wbf_skip_box_threshold']
        
        print("Ensemble model loaded successfully!")
    
    def predict(self, image_path, conf_threshold=0.15):
        """
        Run ensemble prediction on an image
        
        Args:
            image_path: Path to input image
            conf_threshold: Confidence threshold for filtering
            
        Returns:
            Dictionary with boxes, labels, scores
        """
        # YOLO prediction
        yolo_results = self.yolo_model.predict(
            image_path,
            conf=conf_threshold,
            iou=self.config['recall_optimization']['nms_iou'],
            verbose=False
        )[0]
        
        # Extract YOLO predictions
        yolo_boxes = []
        yolo_scores = []
        yolo_labels = []
        
        if len(yolo_results.boxes) > 0:
            boxes_xyxy = yolo_results.boxes.xyxy.cpu().numpy()
            scores = yolo_results.boxes.conf.cpu().numpy()
            labels = yolo_results.boxes.cls.cpu().numpy().astype(int)
            
            # Normalize boxes to [0, 1]
            img_h, img_w = yolo_results.orig_shape
            boxes_norm = boxes_xyxy.copy()
            boxes_norm[:, [0, 2]] /= img_w
            boxes_norm[:, [1, 3]] /= img_h
            
            yolo_boxes = boxes_norm.tolist()
            yolo_scores = scores.tolist()
            yolo_labels = labels.tolist()
        
        # Faster R-CNN prediction
        from PIL import Image
        import torchvision.transforms as T
        
        img = Image.open(image_path).convert('RGB')
        img_tensor = T.ToTensor()(img).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            frcnn_output = self.frcnn_model(img_tensor)[0]
        
        # Extract Faster R-CNN predictions
        frcnn_boxes = []
        frcnn_scores = []
        frcnn_labels = []
        
        mask = frcnn_output['scores'] >= conf_threshold
        if mask.sum() > 0:
            boxes_xyxy = frcnn_output['boxes'][mask].cpu().numpy()
            scores = frcnn_output['scores'][mask].cpu().numpy()
            labels = frcnn_output['labels'][mask].cpu().numpy() - 1  # Convert back to 0-indexed
            
            # Normalize boxes to [0, 1]
            img_w, img_h = img.size
            boxes_norm = boxes_xyxy.copy()
            boxes_norm[:, [0, 2]] /= img_w
            boxes_norm[:, [1, 3]] /= img_h
            
            frcnn_boxes = boxes_norm.tolist()
            frcnn_scores = scores.tolist()
            frcnn_labels = labels.tolist()
        
        # Combine predictions using Weighted Boxes Fusion
        if len(yolo_boxes) == 0 and len(frcnn_boxes) == 0:
            return {
                'boxes': np.array([]),
                'labels': np.array([]),
                'scores': np.array([])
            }
        
        boxes_list = [yolo_boxes, frcnn_boxes]
        scores_list = [yolo_scores, frcnn_scores]
        labels_list = [yolo_labels, frcnn_labels]
        weights = [self.yolo_weight, self.frcnn_weight]
        
        # Apply Weighted Boxes Fusion
        fused_boxes, fused_scores, fused_labels = weighted_boxes_fusion(
            boxes_list,
            scores_list,
            labels_list,
            weights=weights,
            iou_thr=self.iou_threshold,
            skip_box_thr=self.skip_box_threshold
        )
        
        # Denormalize boxes
        fused_boxes[:, [0, 2]] *= img_w
        fused_boxes[:, [1, 3]] *= img_h
        
        return {
            'boxes': fused_boxes,
            'labels': fused_labels.astype(int),
            'scores': fused_scores
        }
    
    def predict_batch(self, image_paths, conf_threshold=0.15):
        """Run ensemble prediction on multiple images"""
        results = []
        for img_path in image_paths:
            result = self.predict(img_path, conf_threshold)
            results.append(result)
        return results
    
    def save_predictions(self, image_path, output_path, conf_threshold=0.15):
        """Save predictions with visualizations"""
        import cv2
        
        # Get predictions
        predictions = self.predict(image_path, conf_threshold)
        
        # Load image
        img = cv2.imread(str(image_path))
        
        # Draw predictions
        for box, label, score in zip(predictions['boxes'], predictions['labels'], predictions['scores']):
            x1, y1, x2, y2 = box.astype(int)
            
            # Color based on class
            color = (0, 255, 0) if label == 0 else (255, 0, 0)  # Green for chip, Red for check
            
            # Draw box
            cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
            
            # Draw label
            class_name = self.config['dataset']['names'][label]
            text = f"{class_name}: {score:.2f}"
            cv2.putText(img, text, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        # Save
        cv2.imwrite(str(output_path), img)
        
        return predictions


def load_ensemble_model(config):
    """Load ensemble model from configuration"""
    yolo_path = 'runs/ensemble/yolov8n/weights/best.pt'
    frcnn_path = 'runs/ensemble/frcnn_resnet101/best.pth'
    
    return EnsembleModel(yolo_path, frcnn_path, config)
