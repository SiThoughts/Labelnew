"""
Common utility functions for defect detection project
"""
import yaml
import torch
import numpy as np
from pathlib import Path
from typing import Dict, List, Tuple, Any


def load_config(config_path: str = "configs/config.yaml") -> Dict:
    """Load configuration from YAML file"""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config


def setup_device(device_id: int = 0) -> torch.device:
    """Setup training device"""
    if torch.cuda.is_available():
        device = torch.device(f'cuda:{device_id}')
        print(f"Using GPU: {torch.cuda.get_device_name(device_id)}")
        print(f"GPU Memory: {torch.cuda.get_device_properties(device_id).total_memory / 1024**3:.2f} GB")
    else:
        device = torch.device('cpu')
        print("Using CPU")
    return device


def create_output_dir(base_dir: str, experiment_name: str) -> Path:
    """Create output directory for experiment"""
    output_dir = Path(base_dir) / experiment_name
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir


def save_results(results: Dict, save_path: str):
    """Save results to YAML file"""
    with open(save_path, 'w') as f:
        yaml.dump(results, f, default_flow_style=False)


def calculate_metrics(tp: int, fp: int, fn: int) -> Dict[str, float]:
    """Calculate precision, recall, and F1 score"""
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0
    
    return {
        'precision': precision,
        'recall': recall,
        'f1': f1
    }


def xywh2xyxy(boxes: np.ndarray) -> np.ndarray:
    """Convert boxes from [x_center, y_center, width, height] to [x1, y1, x2, y2]"""
    boxes_xyxy = np.copy(boxes)
    boxes_xyxy[:, 0] = boxes[:, 0] - boxes[:, 2] / 2  # x1
    boxes_xyxy[:, 1] = boxes[:, 1] - boxes[:, 3] / 2  # y1
    boxes_xyxy[:, 2] = boxes[:, 0] + boxes[:, 2] / 2  # x2
    boxes_xyxy[:, 3] = boxes[:, 1] + boxes[:, 3] / 2  # y2
    return boxes_xyxy


def xyxy2xywh(boxes: np.ndarray) -> np.ndarray:
    """Convert boxes from [x1, y1, x2, y2] to [x_center, y_center, width, height]"""
    boxes_xywh = np.copy(boxes)
    boxes_xywh[:, 0] = (boxes[:, 0] + boxes[:, 2]) / 2  # x_center
    boxes_xywh[:, 1] = (boxes[:, 1] + boxes[:, 3]) / 2  # y_center
    boxes_xywh[:, 2] = boxes[:, 2] - boxes[:, 0]        # width
    boxes_xywh[:, 3] = boxes[:, 3] - boxes[:, 1]        # height
    return boxes_xywh


def normalize_boxes(boxes: np.ndarray, img_width: int, img_height: int) -> np.ndarray:
    """Normalize boxes to [0, 1] range"""
    boxes_norm = np.copy(boxes).astype(float)
    boxes_norm[:, [0, 2]] /= img_width
    boxes_norm[:, [1, 3]] /= img_height
    return boxes_norm


def denormalize_boxes(boxes: np.ndarray, img_width: int, img_height: int) -> np.ndarray:
    """Denormalize boxes from [0, 1] range"""
    boxes_denorm = np.copy(boxes)
    boxes_denorm[:, [0, 2]] *= img_width
    boxes_denorm[:, [1, 3]] *= img_height
    return boxes_denorm


def compute_iou(box1: np.ndarray, box2: np.ndarray) -> float:
    """Compute IoU between two boxes in xyxy format"""
    x1 = max(box1[0], box2[0])
    y1 = max(box1[1], box2[1])
    x2 = min(box1[2], box2[2])
    y2 = min(box1[3], box2[3])
    
    intersection = max(0, x2 - x1) * max(0, y2 - y1)
    
    area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
    area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
    union = area1 + area2 - intersection
    
    return intersection / union if union > 0 else 0.0


def filter_boxes_by_confidence(boxes: np.ndarray, scores: np.ndarray, 
                               labels: np.ndarray, conf_threshold: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Filter boxes by confidence threshold"""
    mask = scores >= conf_threshold
    return boxes[mask], scores[mask], labels[mask]


def adjust_threshold_for_recall(predictions: List[Dict], ground_truths: List[Dict], 
                                target_recall: float = 0.90) -> float:
    """
    Automatically adjust confidence threshold to achieve target recall
    Returns optimal threshold
    """
    # Collect all confidence scores
    all_scores = []
    for pred in predictions:
        if 'scores' in pred:
            all_scores.extend(pred['scores'])
    
    if not all_scores:
        return 0.15  # Default threshold
    
    all_scores = sorted(all_scores, reverse=True)
    
    # Binary search for optimal threshold
    best_threshold = 0.15
    best_recall = 0.0
    
    for threshold in np.linspace(0.01, 0.5, 50):
        # Calculate recall at this threshold
        total_tp = 0
        total_fn = 0
        
        for pred, gt in zip(predictions, ground_truths):
            pred_boxes = pred['boxes'][pred['scores'] >= threshold]
            gt_boxes = gt['boxes']
            
            matched = set()
            for gt_idx, gt_box in enumerate(gt_boxes):
                for pred_box in pred_boxes:
                    if compute_iou(pred_box, gt_box) >= 0.5 and gt_idx not in matched:
                        matched.add(gt_idx)
                        total_tp += 1
                        break
            
            total_fn += len(gt_boxes) - len(matched)
        
        recall = total_tp / (total_tp + total_fn) if (total_tp + total_fn) > 0 else 0.0
        
        if recall >= target_recall and recall > best_recall:
            best_recall = recall
            best_threshold = threshold
    
    print(f"Optimal threshold for {target_recall:.1%} recall: {best_threshold:.3f} (achieved: {best_recall:.1%})")
    return best_threshold
