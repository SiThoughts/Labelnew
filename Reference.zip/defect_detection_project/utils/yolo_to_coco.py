"""
Convert YOLO format labels to COCO format for Faster R-CNN training
"""
import json
import os
from pathlib import Path
from PIL import Image
from tqdm import tqdm
import yaml


def yolo_to_coco(dataset_path, output_path, split='train'):
    """
    Convert YOLO format dataset to COCO format
    
    Args:
        dataset_path: Path to dataset root
        output_path: Path to save COCO JSON file
        split: 'train' or 'val'
    """
    dataset_path = Path(dataset_path)
    images_dir = dataset_path / 'images' / split
    labels_dir = dataset_path / 'labels' / split
    
    # Load dataset config
    with open('configs/dataset.yaml', 'r') as f:
        dataset_config = yaml.safe_load(f)
    
    categories = [
        {'id': 0, 'name': dataset_config['names'][0]},  # chip
        {'id': 1, 'name': dataset_config['names'][1]}   # check
    ]
    
    coco_format = {
        'images': [],
        'annotations': [],
        'categories': categories
    }
    
    annotation_id = 0
    image_id = 0
    
    # Get all image files
    image_files = list(images_dir.glob('*.jpg')) + list(images_dir.glob('*.png')) + list(images_dir.glob('*.jpeg'))
    
    print(f"Converting {len(image_files)} images from {split} set...")
    
    for img_file in tqdm(image_files):
        # Get image dimensions
        try:
            img = Image.open(img_file)
            width, height = img.size
        except Exception as e:
            print(f"Error reading {img_file}: {e}")
            continue
        
        # Add image info
        coco_format['images'].append({
            'id': image_id,
            'file_name': img_file.name,
            'width': width,
            'height': height
        })
        
        # Read corresponding label file
        label_file = labels_dir / f"{img_file.stem}.txt"
        
        if label_file.exists():
            with open(label_file, 'r') as f:
                lines = f.readlines()
            
            for line in lines:
                parts = line.strip().split()
                if len(parts) < 5:
                    continue
                
                class_id = int(parts[0])
                x_center = float(parts[1])
                y_center = float(parts[2])
                w = float(parts[3])
                h = float(parts[4])
                
                # Convert from YOLO format (normalized xywh) to COCO format (absolute xyxy)
                x_min = (x_center - w / 2) * width
                y_min = (y_center - h / 2) * height
                box_width = w * width
                box_height = h * height
                
                # COCO uses [x_min, y_min, width, height]
                bbox = [x_min, y_min, box_width, box_height]
                area = box_width * box_height
                
                coco_format['annotations'].append({
                    'id': annotation_id,
                    'image_id': image_id,
                    'category_id': class_id,
                    'bbox': bbox,
                    'area': area,
                    'iscrowd': 0
                })
                
                annotation_id += 1
        
        image_id += 1
    
    # Save COCO format JSON
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump(coco_format, f, indent=2)
    
    print(f"COCO format saved to: {output_path}")
    print(f"Total images: {len(coco_format['images'])}")
    print(f"Total annotations: {len(coco_format['annotations'])}")
    
    return coco_format


def convert_dataset(config):
    """Convert entire dataset to COCO format"""
    dataset_path = config['dataset']['path']
    
    # Convert train set
    train_coco = yolo_to_coco(
        dataset_path,
        'data/coco_annotations/train.json',
        split='train'
    )
    
    # Convert val set
    val_coco = yolo_to_coco(
        dataset_path,
        'data/coco_annotations/val.json',
        split='val'
    )
    
    return train_coco, val_coco


if __name__ == '__main__':
    import sys
    sys.path.append(str(Path(__file__).parent.parent))
    from utils.common import load_config
    
    config = load_config()
    convert_dataset(config)
