"""
Loss functions for DE-CCD training.
Combines detection loss with anomaly map loss and consistency loss.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class DECCDLoss(nn.Module):
    """
    Combined loss for DE-CCD model.
    
    Components:
    1. Detection loss (from Faster R-CNN)
    2. Anomaly map loss (BCE for normal/abnormal classification)
    3. Consistency loss (encourages feature alignment)
    """
    
    def __init__(self, anomaly_weight=0.3, consistency_weight=0.2):
        """
        Initialize DE-CCD loss.
        
        Args:
            anomaly_weight: Weight for anomaly map loss
            consistency_weight: Weight for consistency loss
        """
        super().__init__()
        self.anomaly_weight = anomaly_weight
        self.consistency_weight = consistency_weight
        self.bce_loss = nn.BCELoss()
    
    def forward(self, detection_loss_dict, anomaly_map, targets, 
                features1=None, features2=None):
        """
        Calculate combined loss.
        
        Args:
            detection_loss_dict: Dictionary of detection losses from Faster R-CNN
            anomaly_map: Generated anomaly map [B, 1, H, W]
            targets: List of target dictionaries
            features1: Features from encoder 1 (optional, for consistency loss)
            features2: Features from encoder 2 (optional, for consistency loss)
        
        Returns:
            Tuple of (total_loss, detection_loss, anomaly_loss, consistency_loss)
        """
        # 1. Detection loss (sum all components)
        detection_loss = sum(loss for loss in detection_loss_dict.values())
        
        # 2. Anomaly map loss
        # Create anomaly labels from targets
        anomaly_labels = torch.stack([
            t.get('has_defects', torch.tensor([0.0])) 
            for t in targets
        ]).to(anomaly_map.device)
        
        # Global average pool anomaly map to get per-image score
        anomaly_scores = F.adaptive_avg_pool2d(anomaly_map, 1).squeeze()
        if anomaly_scores.dim() == 0:
            anomaly_scores = anomaly_scores.unsqueeze(0)
        
        anomaly_loss = self.bce_loss(anomaly_scores, anomaly_labels.squeeze())
        
        # 3. Consistency loss (optional)
        consistency_loss = torch.tensor(0.0).to(anomaly_map.device)
        if features1 is not None and features2 is not None:
            # Encourage features to be similar for normal regions
            # but different for anomalous regions
            feat_diff = torch.abs(features1 - features2)
            
            # Weight by inverse of anomaly map (normal regions should be consistent)
            consistency_weight_map = 1.0 - anomaly_map
            
            # Resize if needed
            if consistency_weight_map.shape[2:] != feat_diff.shape[2:]:
                consistency_weight_map = F.interpolate(
                    consistency_weight_map,
                    size=feat_diff.shape[2:],
                    mode='bilinear',
                    align_corners=False
                )
            
            weighted_diff = feat_diff * consistency_weight_map
            consistency_loss = weighted_diff.mean()
        
        # Combine losses
        total_loss = (
            detection_loss + 
            self.anomaly_weight * anomaly_loss +
            self.consistency_weight * consistency_loss
        )
        
        return total_loss, detection_loss, anomaly_loss, consistency_loss


class FocalLoss(nn.Module):
    """
    Focal loss for handling class imbalance in anomaly detection.
    """
    
    def __init__(self, alpha=0.25, gamma=2.0):
        """
        Initialize focal loss.
        
        Args:
            alpha: Weighting factor
            gamma: Focusing parameter
        """
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
    
    def forward(self, inputs, targets):
        """
        Calculate focal loss.
        
        Args:
            inputs: Predicted probabilities [B]
            targets: Ground truth labels [B]
        
        Returns:
            Focal loss
        """
        bce_loss = F.binary_cross_entropy(inputs, targets, reduction='none')
        
        pt = torch.where(targets == 1, inputs, 1 - inputs)
        focal_weight = (1 - pt) ** self.gamma
        
        alpha_weight = torch.where(targets == 1, self.alpha, 1 - self.alpha)
        
        loss = alpha_weight * focal_weight * bce_loss
        
        return loss.mean()


class DECCDLossWithFocal(nn.Module):
    """
    DE-CCD loss with focal loss for anomaly detection.
    Better for imbalanced datasets.
    """
    
    def __init__(self, anomaly_weight=0.3, consistency_weight=0.2, 
                 focal_alpha=0.25, focal_gamma=2.0):
        """
        Initialize DE-CCD loss with focal loss.
        
        Args:
            anomaly_weight: Weight for anomaly map loss
            consistency_weight: Weight for consistency loss
            focal_alpha: Alpha for focal loss
            focal_gamma: Gamma for focal loss
        """
        super().__init__()
        self.anomaly_weight = anomaly_weight
        self.consistency_weight = consistency_weight
        self.focal_loss = FocalLoss(alpha=focal_alpha, gamma=focal_gamma)
    
    def forward(self, detection_loss_dict, anomaly_map, targets,
                features1=None, features2=None):
        """
        Calculate combined loss with focal loss.
        
        Args:
            detection_loss_dict: Dictionary of detection losses
            anomaly_map: Generated anomaly map
            targets: List of target dictionaries
            features1: Features from encoder 1
            features2: Features from encoder 2
        
        Returns:
            Tuple of (total_loss, detection_loss, anomaly_loss, consistency_loss)
        """
        # Detection loss
        detection_loss = sum(loss for loss in detection_loss_dict.values())
        
        # Anomaly map loss with focal loss
        anomaly_labels = torch.stack([
            t.get('has_defects', torch.tensor([0.0]))
            for t in targets
        ]).to(anomaly_map.device)
        
        anomaly_scores = F.adaptive_avg_pool2d(anomaly_map, 1).squeeze()
        if anomaly_scores.dim() == 0:
            anomaly_scores = anomaly_scores.unsqueeze(0)
        
        anomaly_loss = self.focal_loss(anomaly_scores, anomaly_labels.squeeze())
        
        # Consistency loss
        consistency_loss = torch.tensor(0.0).to(anomaly_map.device)
        if features1 is not None and features2 is not None:
            feat_diff = torch.abs(features1 - features2)
            consistency_weight_map = 1.0 - anomaly_map
            
            if consistency_weight_map.shape[2:] != feat_diff.shape[2:]:
                consistency_weight_map = F.interpolate(
                    consistency_weight_map,
                    size=feat_diff.shape[2:],
                    mode='bilinear',
                    align_corners=False
                )
            
            weighted_diff = feat_diff * consistency_weight_map
            consistency_loss = weighted_diff.mean()
        
        # Combine losses
        total_loss = (
            detection_loss +
            self.anomaly_weight * anomaly_loss +
            self.consistency_weight * consistency_loss
        )
        
        return total_loss, detection_loss, anomaly_loss, consistency_loss
