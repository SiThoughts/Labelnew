"""
PyTorch Dataset for loading defect detection images and annotations.
"""
import os
import torch
from torch.utils.data import Dataset
from PIL import Image
import numpy as np
import albumentations as A
from albumentations.pytorch import ToTensorV2
from src.xml_parser import parse_xml


class DefectDetectionDataset(Dataset):
    """
    PyTorch Dataset for defect detection with XML annotations.
    """
    
    def __init__(self, image_dir, class_mapping=None, image_size=(640, 640), 
                 train=True, augment_config=None):
        """
        Initialize the dataset.
        
        Args:
            image_dir: Directory containing images and XML annotations
            class_mapping: Dictionary mapping class names to integer IDs (optional)
            image_size: Tuple of (width, height) to resize images
            train: Whether this is training data (enables augmentation)
            augment_config: Dictionary with augmentation parameters
        """
        self.image_dir = image_dir
        self.image_size = image_size
        self.train = train
        self.augment_config = augment_config or {}
        
        # Use hardcoded class mapping
        self.class_name_to_id = {
            'chip': 1,
            'chips': 1,
            'check': 2,
            'checks': 2
        }
        
        if class_mapping is None:
            self.class_mapping = {0: 'background', 1: 'chip', 2: 'check'}
        else:
            self.class_mapping = class_mapping
        
        # Find all image files
        self.image_files = []
        self.xml_files = []
        
        img_extensions = ['.png', '.jpg', '.bmp', '..png']
        
        for filename in os.listdir(image_dir):
            # Check if it's an image file
            if any(filename.lower().endswith(ext) for ext in img_extensions):
                image_path = os.path.join(image_dir, filename)
                
                # Find corresponding XML file
                base_name = os.path.splitext(filename)[0]
                xml_path = os.path.join(image_dir, base_name + '.xml')
                
                # Handle ..png case
                if filename.endswith('..png'):
                    base_name = filename[:-5]  # Remove ..png
                    xml_path = os.path.join(image_dir, base_name + '.xml')
                
                if os.path.exists(xml_path):
                    self.image_files.append(image_path)
                    self.xml_files.append(xml_path)
        
        if len(self.image_files) == 0:
            raise ValueError(f"No images with XML annotations found in {image_dir}")
        
        print(f"Found {len(self.image_files)} images with annotations in {image_dir}")
        
        # Setup augmentation pipeline
        self.transform = self._get_transforms()
    
    def _get_transforms(self):
        """
        Get the augmentation/transformation pipeline.
        
        Returns:
            Albumentations composition
        """
        if self.train:
            # Training augmentations
            transforms = [
                A.Resize(height=self.image_size[1], width=self.image_size[0]),
                A.HorizontalFlip(p=self.augment_config.get('horizontal_flip', 0.5)),
                A.VerticalFlip(p=self.augment_config.get('vertical_flip', 0.5)),
                A.Rotate(limit=self.augment_config.get('rotation', 45), p=0.5),
                A.RandomBrightnessContrast(
                    brightness_limit=self.augment_config.get('brightness', 0.2),
                    contrast_limit=self.augment_config.get('contrast', 0.2),
                    p=0.5
                ),
                A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                ToTensorV2()
            ]
        else:
            # Validation transforms (no augmentation)
            transforms = [
                A.Resize(height=self.image_size[1], width=self.image_size[0]),
                A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                ToTensorV2()
            ]
        
        return A.Compose(
            transforms,
            bbox_params=A.BboxParams(
                format='pascal_voc',
                label_fields=['labels'],
                min_visibility=0.3
            )
        )
    
    def __len__(self):
        """Return the number of samples in the dataset."""
        return len(self.image_files)
    
    def __getitem__(self, idx):
        """
        Get a sample from the dataset.
        
        Args:
            idx: Index of the sample
        
        Returns:
            Tuple of (image, target) where target is a dictionary containing:
                - boxes: Tensor of shape [N, 4]
                - labels: Tensor of shape [N]
                - image_id: Tensor of shape [1]
                - area: Tensor of shape [N]
                - iscrowd: Tensor of shape [N]
        """
        # Load image
        image_path = self.image_files[idx]
        image = Image.open(image_path).convert('RGB')
        image = np.array(image)
        
        # Parse XML annotation
        xml_path = self.xml_files[idx]
        annotation = parse_xml(xml_path)
        
        # Extract boxes and labels
        boxes = []
        labels = []
        
        for obj in annotation['objects']:
            # Get class name and map to ID
            class_name = obj['name'].lower().strip()
            
            # Handle variations (chip/chips, check/checks)
            if class_name.startswith('chip'):
                class_name = 'chip'
            elif class_name.startswith('check'):
                class_name = 'check'
            
            # Get class ID
            class_id = self.class_name_to_id.get(class_name)
            if class_id is None:
                continue
            
            # Get bounding box
            bbox = obj['bndbox']
            boxes.append([
                bbox['xmin'],
                bbox['ymin'],
                bbox['xmax'],
                bbox['ymax']
            ])
            labels.append(class_id)
        
        # Handle images with no annotations
        if len(boxes) == 0:
            # Create a dummy box for background
            boxes = [[0, 0, 1, 1]]
            labels = [0]  # Background class
        
        # Apply transformations
        transformed = self.transform(
            image=image,
            bboxes=boxes,
            labels=labels
        )
        
        image = transformed['image']
        boxes = transformed['bboxes']
        labels = transformed['labels']
        
        # Ensure boxes and labels are lists
        if not isinstance(boxes, list):
            boxes = list(boxes)
        if not isinstance(labels, list):
            labels = list(labels)
        
        # Handle case where all boxes were removed by augmentation
        if len(boxes) == 0:
            boxes = [[0, 0, 1, 1]]
            labels = [0]
        
        # Convert to tensors safely
        boxes_tensor = torch.zeros((len(boxes), 4), dtype=torch.float32)
        for i, box in enumerate(boxes):
            if isinstance(box, (list, tuple)) and len(box) == 4:
                boxes_tensor[i] = torch.tensor(box, dtype=torch.float32)
        
        labels_tensor = torch.zeros(len(labels), dtype=torch.int64)
        for i, label in enumerate(labels):
            labels_tensor[i] = int(label)
        
        boxes = boxes_tensor
        labels = labels_tensor
        
        # Calculate areas
        area = (boxes[:, 3] - boxes[:, 1]) * (boxes[:, 2] - boxes[:, 0])
        
        # Create target dictionary
        target = {
            'boxes': boxes,
            'labels': labels,
            'image_id': torch.tensor([idx]),
            'area': area,
            'iscrowd': torch.zeros((len(boxes),), dtype=torch.int64)
        }
        
        # Determine if image has defects (for one-class classification)
        has_defects = any(label > 0 for label in labels)
        target['has_defects'] = torch.tensor([1.0 if has_defects else 0.0], 
                                            dtype=torch.float32)
        
        return image, target


def collate_fn(batch):
    """
    Custom collate function for DataLoader.
    
    Args:
        batch: List of (image, target) tuples
    
    Returns:
        Tuple of (images, targets)
    """
    images = []
    targets = []
    
    for image, target in batch:
        images.append(image)
        targets.append(target)
    
    return images, targets
