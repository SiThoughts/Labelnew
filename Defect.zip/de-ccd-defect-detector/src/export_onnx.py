"""
ONNX export script for DE-CCD model.
Creates a self-contained ONNX model that includes all inference logic.
"""
import os
import sys
import torch
import onnx
import onnxruntime as ort
from PIL import Image
import torchvision.transforms as transforms

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.config_handler import ConfigHandler
from src.model import DECCD, DECCDWrapper


def export_to_onnx(model, image_size, save_path, opset_version=12):
    """
    Export DE-CCD model to ONNX format.
    
    Args:
        model: Trained DE-CCD model
        image_size: Tuple of (width, height)
        save_path: Path to save the ONNX model
        opset_version: ONNX opset version
    """
    print(f"\n{'='*60}")
    print("Exporting DE-CCD model to ONNX format...")
    print(f"{'='*60}\n")
    
    # Set model to eval mode
    model.eval()
    
    # Create wrapper for ONNX export
    wrapped_model = DECCDWrapper(model)
    wrapped_model.eval()
    
    # Create dummy input
    dummy_input = torch.randn(1, 3, image_size[1], image_size[0])
    
    # Move to CPU for export
    device = next(model.parameters()).device
    if device.type == 'cuda':
        model = model.cpu()
        wrapped_model = wrapped_model.cpu()
        dummy_input = dummy_input.cpu()
    
    print(f"Input shape: {dummy_input.shape}")
    print(f"Image size: {image_size}")
    
    # Test forward pass
    print("\nTesting forward pass before export...")
    try:
        with torch.no_grad():
            test_output = wrapped_model(dummy_input)
            print(f"Output types: {[type(o) for o in test_output]}")
            print(f"Output shapes: {[o.shape if isinstance(o, torch.Tensor) else 'N/A' for o in test_output]}")
    except Exception as e:
        print(f"Warning: Forward pass test failed: {e}")
    
    # Export to ONNX
    print("\nExporting to ONNX...")
    try:
        torch.onnx.export(
            wrapped_model,
            dummy_input,
            save_path,
            export_params=True,
            opset_version=opset_version,
            do_constant_folding=True,
            input_names=['input'],
            output_names=['boxes', 'labels', 'scores'],
            dynamic_axes={
                'input': {0: 'batch_size'},
                'boxes': {0: 'num_detections'},
                'labels': {0: 'num_detections'},
                'scores': {0: 'num_detections'}
            }
        )
        print(f"✓ Model exported successfully to: {save_path}")
    except Exception as e:
        print(f"✗ Export failed: {e}")
        raise
    
    # Verify the exported model
    print("\nVerifying exported ONNX model...")
    try:
        onnx_model = onnx.load(save_path)
        onnx.checker.check_model(onnx_model)
        print("✓ ONNX model is valid")
        
        # Print model info
        print(f"\nONNX Model Information:")
        print(f"  IR Version: {onnx_model.ir_version}")
        print(f"  Opset Version: {onnx_model.opset_import[0].version}")
        
        # Print input/output info
        print(f"\nInputs:")
        for input_tensor in onnx_model.graph.input:
            print(f"  - {input_tensor.name}")
        
        print(f"\nOutputs:")
        for output_tensor in onnx_model.graph.output:
            print(f"  - {output_tensor.name}")
        
    except Exception as e:
        print(f"✗ ONNX model verification failed: {e}")
        raise
    
    # Test inference with ONNX Runtime
    print("\nTesting ONNX Runtime inference...")
    try:
        ort_session = ort.InferenceSession(save_path)
        
        # Prepare input
        ort_inputs = {ort_session.get_inputs()[0].name: dummy_input.numpy()}
        
        # Run inference
        ort_outputs = ort_session.run(None, ort_inputs)
        
        print(f"✓ ONNX Runtime inference successful")
        print(f"  Output shapes: {[o.shape for o in ort_outputs]}")
        
    except Exception as e:
        print(f"✗ ONNX Runtime inference failed: {e}")
        raise
    
    print(f"\n{'='*60}")
    print("ONNX export complete!")
    print(f"{'='*60}\n")


def main(model_path, results_dir, image_type='EV'):
    """
    Main function to export model to ONNX.
    
    Args:
        model_path: Path to trained PyTorch model
        results_dir: Directory to save ONNX model
        image_type: Type of images (EV or SV)
    """
    # Load configuration
    config_handler = ConfigHandler('config.xml')
    config = config_handler.get_config()
    
    # Get image settings
    image_settings = config_handler.get_image_type_settings(image_type)
    image_size = image_settings['image_size']
    
    # Build model architecture
    num_classes = config['general']['num_classes']
    backbone = config['general'].get('encoder1_backbone', 'resnet50')
    
    model = DECCD(
        num_classes=num_classes,
        backbone_name=backbone,
        pretrained=False  # Don't need pretrained for loading weights
    )
    
    # Load trained weights
    print(f"Loading model from: {model_path}")
    model.load_state_dict(torch.load(model_path, map_location='cpu'))
    model.eval()
    
    # Export to ONNX
    onnx_path = os.path.join(results_dir, 'best_model.onnx')
    opset_version = config['onnx']['opset_version']
    
    export_to_onnx(model, image_size, onnx_path, opset_version)
    
    return onnx_path


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Export DE-CCD model to ONNX')
    parser.add_argument('--model', type=str, required=True, help='Path to trained model')
    parser.add_argument('--output', type=str, required=True, help='Output directory')
    parser.add_argument('--image-type', type=str, default='EV', help='Image type (EV or SV)')
    
    args = parser.parse_args()
    
    # Export model
    onnx_path = main(args.model, args.output, args.image_type)
