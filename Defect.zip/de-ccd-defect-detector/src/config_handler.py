"""
Configuration handler for parsing XML configuration files.
"""
import xml.etree.ElementTree as ET
import os


class ConfigHandler:
    """
    Handles loading and parsing of XML configuration files for the OCD-YOLO training system.
    """
    
    def __init__(self, config_path):
        """
        Initialize the configuration handler.
        
        Args:
            config_path: Path to the XML configuration file
        """
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        
        self.config_path = config_path
        self.tree = ET.parse(config_path)
        self.root = self.tree.getroot()
        self.config = self._parse_config()
    
    def _parse_config(self):
        """
        Parse the XML configuration file into a dictionary.
        
        Returns:
            Dictionary containing all configuration parameters
        """
        config = {}
        
        # Parse general settings
        general = self.root.find('general')
        if general is not None:
            config['general'] = {}
            for child in general:
                value = child.text
                # Try to convert to appropriate type
                if value and isinstance(value, str) and value.lower() in ['true', 'false']:
                    value = value.lower() == 'true'
                elif value.replace('.', '', 1).isdigit():
                    value = float(value) if '.' in value else int(value)
                config['general'][child.tag] = value
        
        # Parse class mapping
        class_map_elem = self.root.find('class_map')
        if class_map_elem is not None:
            config['class_map'] = {}
            for class_elem in class_map_elem.findall('class'):
                class_id = int(class_elem.get('id'))
                class_name = class_elem.text.strip()
                config['class_map'][class_name.lower()] = class_id
        
        # Parse image type configurations
        image_types = self.root.find('image_types')
        if image_types is not None:
            config['image_types'] = {}
            for img_type in image_types.findall('image_type'):
                type_name = img_type.get('name')
                config['image_types'][type_name] = {}
                
                # Results directory
                results_dir = img_type.find('results_dir')
                if results_dir is not None:
                    config['image_types'][type_name]['results_dir'] = results_dir.text
                
                # Reference libraries
                ref_libs_elem = img_type.find('ref_libs')
                if ref_libs_elem is not None:
                    ref_libs = [lib.text for lib in ref_libs_elem.findall('ref_lib')]
                    config['image_types'][type_name]['ref_libs'] = ref_libs
                
                # Image size
                img_size_elem = img_type.find('image_size')
                if img_size_elem is not None:
                    width = int(img_size_elem.find('width').text)
                    height = int(img_size_elem.find('height').text)
                    config['image_types'][type_name]['image_size'] = (width, height)
        
        # Parse augmentation settings
        augmentation = self.root.find('augmentation')
        if augmentation is not None:
            config['augmentation'] = {}
            for child in augmentation:
                value = child.text
                if value.replace('.', '', 1).isdigit():
                    value = float(value) if '.' in value else int(value)
                config['augmentation'][child.tag] = value
        
        # Parse ONNX settings
        onnx = self.root.find('onnx')
        if onnx is not None:
            config['onnx'] = {}
            for child in onnx:
                value = child.text
                if value and isinstance(value, str) and value.lower() in ['true', 'false']:
                    value = value.lower() == 'true'
                elif value.isdigit():
                    value = int(value)
                config['onnx'][child.tag] = value
        
        return config
    
    def get_config(self):
        """
        Get the complete configuration dictionary.
        
        Returns:
            Dictionary containing all configuration parameters
        """
        return self.config
    
    def get_image_type_settings(self, image_type):
        """
        Get settings for a specific image type (e.g., EV or SV).
        
        Args:
            image_type: The image type identifier (e.g., 'EV', 'SV')
        
        Returns:
            Dictionary containing settings for the specified image type
        """
        if 'image_types' not in self.config:
            raise ValueError("No image types configured")
        
        if image_type not in self.config['image_types']:
            raise ValueError(f"Image type '{image_type}' not found in configuration")
        
        return self.config['image_types'][image_type]
    
    def get_class_id(self, class_name):
        """
        Get the numeric ID for a class name.
        
        Args:
            class_name: The name of the class
        
        Returns:
            Integer ID for the class
        """
        class_name_lower = class_name.lower()
        if class_name_lower not in self.config['class_map']:
            raise ValueError(f"Class '{class_name}' not found in class mapping")
        
        return self.config['class_map'][class_name_lower]
    
    def get_class_name(self, class_id):
        """
        Get the name for a class ID.
        
        Args:
            class_id: The numeric ID of the class
        
        Returns:
            String name for the class
        """
        for name, cid in self.config['class_map'].items():
            if cid == class_id:
                return name
        
        raise ValueError(f"Class ID {class_id} not found in class mapping")
