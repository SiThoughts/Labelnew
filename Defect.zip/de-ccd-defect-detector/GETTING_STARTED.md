# Getting Started with DE-CCD Defect Detection

This guide will walk you through setting up and running your first DE-CCD training session.

## ⚡ Quick Start (3 Steps)

### Step 1: Install Dependencies

**Double-click:** `setup_environment.bat`

This will:
- Create a Python virtual environment
- Install PyTorch with CUDA 10.2 support
- Install all required packages

**Time:** ~5-10 minutes

### Step 2: Prepare Your Data

Make sure your EV images and XML annotations are in:
```
D:\Photomask\merlin\EV\
```

### Step 3: Train the Model

**Double-click:** `TRAIN.bat`

This will start the complete training process automatically!

**Expected Duration:** 4-12 hours (depending on your GPU and dataset size)

---

## 📋 Detailed Setup Instructions

### System Requirements

#### Minimum Requirements
- **CPU:** Intel i5 or AMD Ryzen 5
- **RAM:** 16 GB
- **GPU:** NVIDIA GTX 1060 (6GB VRAM) or better
- **Storage:** 15 GB free space
- **OS:** Windows 10/11 (64-bit)

#### Recommended Requirements
- **CPU:** Intel i7/i9 or AMD Ryzen 7/9
- **RAM:** 32 GB
- **GPU:** NVIDIA RTX 3060 (12GB VRAM) or better
- **Storage:** 50 GB free space (SSD recommended)
- **OS:** Windows 10/11 (64-bit)

**Note**: DE-CCD requires more GPU memory than single-encoder models due to dual encoders.

### Software Prerequisites

1. **Python 3.8 or higher**
   - Download from: https://www.python.org/downloads/
   - During installation, check "Add Python to PATH"

2. **NVIDIA CUDA 10.2** (for GPU acceleration)
   - Download from: https://developer.nvidia.com/cuda-10.2-download-archive
   - Install CUDA Toolkit 10.2
   - Verify: Open CMD and run `nvcc --version`

3. **NVIDIA cuDNN** (for CUDA 10.2)
   - Download from: https://developer.nvidia.com/cudnn
   - Extract and copy files to CUDA installation directory

---

## 📂 Data Preparation Guide

### XML Annotation Format

Your XML files should follow the Pascal VOC format:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<annotation>
    <filename>image_ev_001.png</filename>
    <size>
        <width>2048</width>
        <height>1460</height>
        <depth>3</depth>
    </size>
    <object>
        <name>chip</name>
        <bndbox>
            <xmin>150</xmin>
            <ymin>200</ymin>
            <xmax>350</xmax>
            <ymax>400</ymax>
        </bndbox>
    </object>
</annotation>
```

### Supported Defect Types

- **chip** (or chips, Chip, CHIP)
- **check** (or checks, Check, CHECK)

### Dataset Recommendations

For best results with DE-CCD:

1. **Minimum Dataset Size**: 100 images
2. **Recommended Size**: 200+ images
3. **Balance**: 50-60% defective, 40-50% normal
4. **Variety**: Include different defect sizes and locations

---

## 🎯 Training the Model

### Using the One-Click Launcher

1. **Double-click:** `TRAIN.bat`

2. The system will:
   - ✓ Check your environment
   - ✓ Verify your data
   - ✓ Split data into train/validation (85%/15%)
   - ✓ Train for 100 epochs
   - ✓ Export to ONNX format
   - ✓ Generate performance reports

3. **Monitor Progress:**
   - Watch the console for epoch progress
   - Training curves are updated after each epoch
   - Best models are saved automatically

### Training Progress

You'll see output like this:

```
Epoch 1/100
Training: 100%|████████████| 26/26 [02:15<00:00, 5.2s/it]
Validation: 100%|██████████| 5/5 [00:25<00:00, 5.0s/it]

Epoch 1 - Train
Total Loss:      3.4567
Detection Loss:  2.8901
Anomaly Loss:    0.4123
Consistency Loss: 0.1543
Precision:       0.6500
Recall:          0.5800
F1 Score:        0.6134
```

### What to Expect

- **First 10 epochs:** Rapid loss decrease, encoders learn basic features
- **Epochs 10-30:** Anomaly map starts forming, detection improves
- **Epochs 30-70:** Encoders specialize, significant performance gains
- **Epochs 70-100:** Fine-tuning, smaller improvements
- **Total time:** 4-12 hours (GPU dependent)

**Note**: DE-CCD takes longer to train than single-encoder models but provides better anomaly detection.

---

## 📊 Understanding Results

After training completes, check `./results/EV/` for:

### Key Files

1. **`best_model.pt`**
   - PyTorch model with lowest validation loss
   - Use for further training or fine-tuning

2. **`best_f1_model.pt`**
   - PyTorch model with highest F1 score
   - Often best for balanced performance

3. **`best_model.onnx`**
   - **Deploy this!**
   - Self-contained, no Python dependencies

### Performance Metrics

Open `training_curves.png` to see:
- **Total Loss**: Combined loss (should decrease)
- **Detection Loss**: Faster R-CNN loss
- **Anomaly Loss**: Anomaly map quality
- **Consistency Loss**: Feature alignment
- **Precision**: Percentage of correct detections
- **Recall**: Percentage of defects found

**Target Performance:**
- Precision: ≥ 90%
- Recall: ≥ 90%
- F1 Score: ≥ 90%

### Anomaly Map Quality

DE-CCD generates anomaly maps that highlight defect regions. Good anomaly maps should:
- Show high values (bright) in defect regions
- Show low values (dark) in normal regions
- Have clear boundaries between normal and defective areas

---

## 🚀 Next Steps

### If Performance is Good (>90%)

1. **Deploy the ONNX model:**
   - Copy `best_model.onnx` to your production system
   - Integrate with your inspection pipeline

2. **Inference Example:**
   ```python
   import onnxruntime as ort
   import numpy as np
   from PIL import Image
   
   # Load model
   session = ort.InferenceSession('best_model.onnx')
   
   # Prepare input
   image = Image.open('test.png').convert('RGB')
   image = image.resize((640, 640))
   image_array = np.array(image).transpose(2, 0, 1)
   image_array = image_array.astype(np.float32) / 255.0
   image_array = np.expand_dims(image_array, axis=0)
   
   # Run inference
   outputs = session.run(None, {'input': image_array})
   boxes, labels, scores = outputs
   
   # Process results
   for box, label, score in zip(boxes, labels, scores):
       if score > 0.5:
           print(f"Detected: {label} with confidence {score:.2f}")
   ```

### If Performance is Low (<90%)

1. **Check Anomaly Maps:**
   - Are they highlighting defect regions?
   - If not, increase `anomaly_weight` in config.xml

2. **Adjust Loss Weights:**
   ```xml
   <anomaly_weight>0.5</anomaly_weight>
   <consistency_loss_weight>0.1</consistency_loss_weight>
   ```

3. **Train Longer:**
   ```xml
   <epochs>150</epochs>
   ```

4. **Collect More Data:**
   - Aim for 200+ images
   - Ensure balanced defect/normal ratio

5. **Try Different Backbones:**
   ```xml
   <encoder1_backbone>resnet101</encoder1_backbone>
   <encoder2_backbone>resnet101</encoder2_backbone>
   ```

---

## ❓ Common Issues

### "CUDA out of memory"

**Cause:** Dual encoders require 2x GPU memory

**Solutions:**
1. Reduce batch size:
   ```xml
   <batch>4</batch>  <!-- or 2 -->
   ```

2. Use smaller backbones:
   ```xml
   <encoder1_backbone>resnet34</encoder1_backbone>
   <encoder2_backbone>resnet34</encoder2_backbone>
   ```

### "Training is very slow"

**Cause:** Dual encoders are computationally intensive

**Expected times** (per epoch):
- GTX 1060: ~15-20 minutes
- RTX 3060: ~8-12 minutes
- RTX 3090: ~4-6 minutes

**This is normal for DE-CCD!**

### "No images found"

**Cause:** Data path incorrect or images don't contain "ev"

**Fix:**
- Check `config.xml` data path
- Ensure filenames contain "ev"

### "Poor anomaly map quality"

**Cause:** Anomaly weight too low

**Fix:**
```xml
<anomaly_weight>0.5</anomaly_weight>  <!-- Increase from 0.3 -->
```

---

## 💡 Tips for Best Results

1. **GPU Memory is Critical**
   - DE-CCD needs more memory than single-encoder models
   - Ensure you have at least 6GB VRAM
   - 12GB+ is recommended

2. **Training Takes Time**
   - Don't expect quick results
   - Let it train for full 100 epochs
   - Monitor anomaly map quality

3. **Balance Your Dataset**
   - Include both defective and normal images
   - Aim for 50/50 or 60/40 ratio

4. **Monitor Anomaly Maps**
   - Check if they make sense
   - They should highlight defects
   - Adjust weights if needed

5. **Use the Right Model**
   - `best_model.pt` for lowest loss
   - `best_f1_model.pt` for balanced performance

---

## 🆚 DE-CCD vs OCD-YOLO

### When to Use DE-CCD

✅ **Use DE-CCD when:**
- Precision and recall are critical
- You need to detect unknown/novel defects
- You have sufficient GPU memory (6GB+)
- Training time is not a constraint
- Inference speed is acceptable (~40ms)

### When to Use OCD-YOLO

✅ **Use OCD-YOLO when:**
- Speed is critical (<20ms inference)
- GPU memory is limited (<6GB)
- Defect types are well-defined
- Model size matters
- Faster training is needed

### Performance Comparison

| Metric | OCD-YOLO | DE-CCD |
|--------|----------|--------|
| Precision | Good | Better |
| Recall | Good | Better |
| Novel Defects | May miss | Detects |
| Training Time | 2-6 hours | 4-12 hours |
| Inference Time | ~20ms | ~40ms |
| GPU Memory | 4GB+ | 6GB+ |
| Model Size | ~50MB | ~100MB |

---

## 📞 Getting Help

If you encounter issues:

1. **Check this guide** - Most issues are covered here
2. **Review the logs** - Error messages are informative
3. **Check configuration** - Verify `config.xml` settings
4. **Verify data** - Ensure proper format

---

**Ready to start? Double-click `TRAIN.bat` and let DE-CCD work its magic!**

**Remember**: DE-CCD is more complex than single-encoder models, but the superior anomaly detection capability is worth it!
