"""
Visualization Utilities for Glass Surface Extraction
====================================================

Create various visualizations of extraction results.

Author: Manus AI
Date: 2026-01-20
"""

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import json


def plot_surface_overlays(volume, top_surface, bottom_surface, output_dir="output",
                          sample_slices=None):
    """
    Plot sample slices with surface overlays.
    
    Args:
        volume: Original 3D volume
        top_surface: Top surface array
        bottom_surface: Bottom surface array
        output_dir: Directory to save visualizations
        sample_slices: List of slice indices to visualize (None = auto-select)
    """
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)
    
    n_slices, height, width = volume.shape
    
    # Auto-select sample slices if not provided
    if sample_slices is None:
        sample_slices = [200, 300, 400, 500, 600, 680, 750, 850]
        # Filter out slices beyond volume
        sample_slices = [s for s in sample_slices if s < n_slices]
    
    # Create figure
    n_samples = len(sample_slices)
    n_cols = 3
    n_rows = (n_samples + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 5*n_rows))
    
    if n_rows == 1:
        axes = axes.reshape(1, -1)
    
    axes = axes.flatten()
    
    for idx, z in enumerate(sample_slices):
        ax = axes[idx]
        
        # Show slice
        ax.imshow(volume[z], cmap='gray', aspect='auto')
        
        # Overlay surfaces
        ax.plot(range(width), top_surface[z], 'r-', linewidth=2, label='Top')
        ax.plot(range(width), bottom_surface[z], 'b-', linewidth=2, label='Bottom')
        
        ax.set_title(f'Slice {z}', fontsize=12)
        ax.set_xlabel('X (pixels)')
        ax.set_ylabel('Y (pixels)')
        ax.legend(loc='upper right')
        ax.grid(True, alpha=0.3)
    
    # Hide unused subplots
    for idx in range(len(sample_slices), len(axes)):
        axes[idx].axis('off')
    
    plt.tight_layout()
    plt.savefig(output_path / 'surface_overlays.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Saved: {output_path / 'surface_overlays.png'}")


def plot_xz_crosssection(volume, top_surface, bottom_surface, output_dir="output",
                         x_positions=None):
    """
    Plot XZ cross-sections showing surfaces through Z-axis.
    
    Args:
        volume: Original 3D volume
        top_surface: Top surface array
        bottom_surface: Bottom surface array
        output_dir: Directory to save visualizations
        x_positions: List of X positions for cross-sections (None = middle)
    """
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)
    
    n_slices, height, width = volume.shape
    
    if x_positions is None:
        x_positions = [width // 4, width // 2, 3 * width // 4]
    
    fig, axes = plt.subplots(len(x_positions), 1, figsize=(15, 5*len(x_positions)))
    
    if len(x_positions) == 1:
        axes = [axes]
    
    for idx, x in enumerate(x_positions):
        ax = axes[idx]
        
        # Create XZ slice
        xz_slice = volume[:, :, x].T
        ax.imshow(xz_slice, cmap='gray', aspect='auto', 
                 extent=[0, n_slices, height, 0])
        
        # Overlay surfaces
        ax.plot(range(n_slices), top_surface[:, x], 'r-', linewidth=2, 
               label='Top Surface')
        ax.plot(range(n_slices), bottom_surface[:, x], 'b-', linewidth=2, 
               label='Bottom Surface')
        
        # Mark regions
        ax.axvspan(200, 680, alpha=0.1, color='green', label='Clean Region')
        ax.axvspan(680, min(900, n_slices), alpha=0.1, color='red', 
                  label='Turret Region')
        
        ax.set_xlabel('Z (slice number)', fontsize=12)
        ax.set_ylabel('Y (pixels)', fontsize=12)
        ax.set_title(f'XZ Cross-Section at X={x}', fontsize=14)
        ax.legend(fontsize=10, loc='upper right')
        ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(output_path / 'xz_crosssections.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Saved: {output_path / 'xz_crosssections.png'}")


def plot_thickness_analysis(top_surface, bottom_surface, output_dir="output"):
    """
    Plot thickness map and distribution.
    
    Args:
        top_surface: Top surface array
        bottom_surface: Bottom surface array
        output_dir: Directory to save visualizations
    """
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)
    
    thickness = bottom_surface - top_surface
    n_slices, width = thickness.shape
    
    fig, axes = plt.subplots(1, 2, figsize=(15, 5))
    
    # Thickness heatmap
    im = axes[0].imshow(thickness.T, cmap='viridis', aspect='auto',
                       extent=[0, n_slices, width, 0])
    axes[0].set_xlabel('Z (slice number)', fontsize=12)
    axes[0].set_ylabel('X (pixels)', fontsize=12)
    axes[0].set_title('Thickness Map (pixels)', fontsize=14)
    cbar = plt.colorbar(im, ax=axes[0])
    cbar.set_label('Thickness (pixels)', fontsize=10)
    
    # Thickness histogram
    axes[1].hist(thickness.flatten(), bins=50, edgecolor='black', alpha=0.7)
    axes[1].axvline(np.median(thickness), color='r', linestyle='--', linewidth=2,
                   label=f'Median: {np.median(thickness):.1f}')
    axes[1].axvline(np.mean(thickness), color='g', linestyle='--', linewidth=2,
                   label=f'Mean: {np.mean(thickness):.1f}')
    axes[1].set_xlabel('Thickness (pixels)', fontsize=12)
    axes[1].set_ylabel('Count', fontsize=12)
    axes[1].set_title('Thickness Distribution', fontsize=14)
    axes[1].legend(fontsize=10)
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(output_path / 'thickness_analysis.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Saved: {output_path / 'thickness_analysis.png'}")


def plot_surface_3d(top_surface, bottom_surface, output_dir="output", 
                   downsample=10):
    """
    Plot 3D surface visualization.
    
    Args:
        top_surface: Top surface array
        bottom_surface: Bottom surface array
        output_dir: Directory to save visualizations
        downsample: Downsampling factor for visualization (higher = faster)
    """
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)
    
    n_slices, width = top_surface.shape
    
    # Downsample for visualization
    top_ds = top_surface[::downsample, ::downsample]
    bottom_ds = bottom_surface[::downsample, ::downsample]
    
    # Create meshgrid
    Z, X = np.meshgrid(np.arange(0, n_slices, downsample), 
                       np.arange(0, width, downsample), indexing='ij')
    
    # Create 3D plot
    fig = plt.figure(figsize=(15, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # Plot surfaces
    ax.plot_surface(X, Z, top_ds, cmap='Reds', alpha=0.7, label='Top Surface')
    ax.plot_surface(X, Z, bottom_ds, cmap='Blues', alpha=0.7, label='Bottom Surface')
    
    ax.set_xlabel('X (pixels)', fontsize=12)
    ax.set_ylabel('Z (slice number)', fontsize=12)
    ax.set_zlabel('Y (pixels)', fontsize=12)
    ax.set_title('3D Surface Visualization', fontsize=14)
    
    # Invert Z-axis for better visualization
    ax.invert_zaxis()
    
    plt.tight_layout()
    plt.savefig(output_path / 'surface_3d.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Saved: {output_path / 'surface_3d.png'}")


def plot_bloom_distribution(blooms, output_dir="output"):
    """
    Plot bloom detection results.
    
    Args:
        blooms: List of bloom dictionaries
        output_dir: Directory to save visualizations
    """
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)
    
    if len(blooms) == 0:
        print("No blooms to visualize")
        return
    
    # Extract data
    interior_blooms = [b for b in blooms if b['classification'] == 'interior']
    surface_blooms = [b for b in blooms if b['classification'] == 'surface']
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    
    # 1. XZ projection (top view)
    if len(interior_blooms) > 0:
        x_coords = [b['x'] for b in interior_blooms]
        z_coords = [b['z'] for b in interior_blooms]
        intensities = [b['intensity'] for b in interior_blooms]
        
        scatter = axes[0, 0].scatter(z_coords, x_coords, c=intensities, 
                                     cmap='hot', s=10, alpha=0.6)
        axes[0, 0].set_xlabel('Z (slice number)', fontsize=12)
        axes[0, 0].set_ylabel('X (pixels)', fontsize=12)
        axes[0, 0].set_title(f'Interior Blooms - XZ Projection ({len(interior_blooms)} blooms)', 
                            fontsize=14)
        plt.colorbar(scatter, ax=axes[0, 0], label='Intensity')
        axes[0, 0].grid(True, alpha=0.3)
    else:
        axes[0, 0].text(0.5, 0.5, 'No interior blooms detected', 
                       ha='center', va='center', fontsize=14)
        axes[0, 0].set_title('Interior Blooms - XZ Projection', fontsize=14)
    
    # 2. Depth distribution
    if len(interior_blooms) > 0:
        depths_from_top = [b['depth_from_top'] for b in interior_blooms]
        depths_from_bottom = [b['depth_from_bottom'] for b in interior_blooms]
        
        axes[0, 1].hist(depths_from_top, bins=30, alpha=0.7, label='From Top', 
                       edgecolor='black')
        axes[0, 1].hist(depths_from_bottom, bins=30, alpha=0.7, label='From Bottom', 
                       edgecolor='black')
        axes[0, 1].set_xlabel('Depth (pixels)', fontsize=12)
        axes[0, 1].set_ylabel('Count', fontsize=12)
        axes[0, 1].set_title('Interior Bloom Depth Distribution', fontsize=14)
        axes[0, 1].legend(fontsize=10)
        axes[0, 1].grid(True, alpha=0.3)
    else:
        axes[0, 1].text(0.5, 0.5, 'No interior blooms detected', 
                       ha='center', va='center', fontsize=14)
        axes[0, 1].set_title('Interior Bloom Depth Distribution', fontsize=14)
    
    # 3. Intensity distribution
    if len(interior_blooms) > 0:
        intensities = [b['intensity'] for b in interior_blooms]
        axes[1, 0].hist(intensities, bins=50, edgecolor='black', alpha=0.7)
        axes[1, 0].set_xlabel('Intensity', fontsize=12)
        axes[1, 0].set_ylabel('Count', fontsize=12)
        axes[1, 0].set_title('Interior Bloom Intensity Distribution', fontsize=14)
        axes[1, 0].grid(True, alpha=0.3)
    else:
        axes[1, 0].text(0.5, 0.5, 'No interior blooms detected', 
                       ha='center', va='center', fontsize=14)
        axes[1, 0].set_title('Interior Bloom Intensity Distribution', fontsize=14)
    
    # 4. Classification summary
    classifications = {
        'Interior': len(interior_blooms),
        'Surface': len(surface_blooms)
    }
    
    axes[1, 1].bar(classifications.keys(), classifications.values(), 
                  color=['red', 'orange'], edgecolor='black', alpha=0.7)
    axes[1, 1].set_ylabel('Count', fontsize=12)
    axes[1, 1].set_title('Bloom Classification Summary', fontsize=14)
    axes[1, 1].grid(True, alpha=0.3, axis='y')
    
    # Add counts on bars
    for i, (label, count) in enumerate(classifications.items()):
        axes[1, 1].text(i, count, str(count), ha='center', va='bottom', fontsize=12)
    
    plt.tight_layout()
    plt.savefig(output_path / 'bloom_analysis.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Saved: {output_path / 'bloom_analysis.png'}")


def create_all_visualizations(volume, top_surface, bottom_surface, blooms=None, 
                             output_dir="output"):
    """
    Create all visualizations.
    
    Args:
        volume: Original 3D volume
        top_surface: Top surface array
        bottom_surface: Bottom surface array
        blooms: List of bloom dictionaries (optional)
        output_dir: Directory to save visualizations
    """
    print("\n" + "="*70)
    print("CREATING VISUALIZATIONS")
    print("="*70)
    
    plot_surface_overlays(volume, top_surface, bottom_surface, output_dir)
    plot_xz_crosssection(volume, top_surface, bottom_surface, output_dir)
    plot_thickness_analysis(top_surface, bottom_surface, output_dir)
    
    try:
        plot_surface_3d(top_surface, bottom_surface, output_dir)
    except Exception as e:
        print(f"Warning: Could not create 3D plot: {e}")
    
    if blooms is not None and len(blooms) > 0:
        plot_bloom_distribution(blooms, output_dir)
    
    print("\n✓ All visualizations complete")


if __name__ == "__main__":
    print("Visualization Utilities")
    print("\nExample usage:")
    print("  from visualize import create_all_visualizations")
    print("  create_all_visualizations(volume, top_surface, bottom_surface)")
