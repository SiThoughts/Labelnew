# Quick Start Guide

## Installation (5 minutes)

### Step 1: Extract the Package

```bash
tar -xzf glass_surface_extraction_package.tar.gz
cd glass_surface_extraction/
```

### Step 2: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 3: Test Installation

```bash
python test_installation.py
```

You should see:
```
✅ ALL TESTS PASSED!
You're ready to run the extraction pipeline!
```

---

## Running Your First Extraction (2 minutes)

### If your data is in a directory of images:

```bash
python run_extraction.py /path/to/your/images --output results
```

### If your data is a NumPy array:

```bash
python run_extraction.py your_data.npy --output results
```

---

## Viewing Results

After extraction completes, check the `results/` directory:

```bash
ls results/
```

You'll find:
- `surface_overlays.png` - Visual inspection of surface detection
- `xz_crosssections.png` - Cross-sections showing surfaces through Z-axis
- `thickness_analysis.png` - Thickness map and distribution
- `top_surface.npy` - Top surface positions (load with `np.load()`)
- `bottom_surface.npy` - Bottom surface positions
- `blooms.json` - Detected defects with positions and depths

---

## Common Adjustments

### If surfaces look wrong in the first ~200 slices:

```bash
python run_extraction.py data --clean-start 250
```

### If turret region (slices 680+) looks wrong:

```bash
python run_extraction.py data --clean-end 650
```

### If too many blooms are detected:

```bash
python run_extraction.py data --bloom-threshold 150
```

---

## Getting Help

See `README.md` for:
- Detailed documentation
- Python API usage
- Troubleshooting guide
- Output file formats

See `thickness_constrained_methodology.md` for:
- Algorithm details
- Parameter explanations
- Technical background

---

## Example: Using Results in Your Code

```python
import numpy as np
import json

# Load surfaces
top = np.load('results/top_surface.npy')
bottom = np.load('results/bottom_surface.npy')

# Get thickness at slice 500
thickness_slice_500 = bottom[500] - top[500]
print(f"Average thickness: {thickness_slice_500.mean():.1f} pixels")

# Load blooms
with open('results/blooms.json') as f:
    blooms = json.load(f)

interior = [b for b in blooms if b['classification'] == 'interior']
print(f"Found {len(interior)} interior blooms")
```

---

That's it! You're ready to go. 🚀
