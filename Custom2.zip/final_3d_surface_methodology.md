# Comprehensive 3D Surface Extraction Methodology for Glass Blister Detection

## Executive Summary

Based on extensive parallel research of 12 different 3D surface extraction methods, this document presents the optimal hybrid approach for robustly extracting top and bottom glass surfaces from 900-slice darkfield volumetric data.

**Key Requirements:**
- Handle fragmented, curved surface lines
- Work with 3D features (camera turret/button) that cause surface bending
- Use entire clean region (slices 200-680)
- Bidirectional processing from middle outward
- Fully automated (no manual intervention)
- Computational efficiency (< 10 minutes for 900 slices)

---

## Research Summary: Top 5 Methods

### 1. **Bidirectional Kalman Filtering (RTS Smoother)** - Confidence: 8/10

**Strengths:**
- Optimal for temporal tracking with high overlap (0.2mm between slices)
- Naturally handles gradual curvature (turret features)
- Excellent noise reduction through smoothing
- Fast: 100-500ms for 900 slices
- Bridges gaps through prediction + backward smoothing

**Limitations:**
- Sensitive to model mismatch (sudden sharp corners)
- Requires good initialization
- May drift in long gaps (50+ slices)

**Best for:** Clean region tracking (200-680) with gradual curves

---

### 2. **3D RANSAC Surface Fitting** - Confidence: 9/10

**Strengths:**
- Globally robust to outliers (blooms, artifacts)
- Can fit curved surfaces (quadric, polynomial)
- Perfect for contaminated region (680-900) where tracking fails
- Provides statistical confidence measures

**Limitations:**
- Assumes surface model (planar/quadric)
- Computationally intensive: 5-15 minutes
- Threshold sensitivity

**Best for:** Building global 3D surface model from clean region, interpolating through contaminated region

---

### 3. **Graph-Cut Optimal Surface Segmentation** - Confidence: 9/10

**Strengths:**
- Globally optimal solution (min-cut theorem)
- Explicit smoothness constraints
- Handles complex 3D topology naturally
- Slice-to-slice consistency guaranteed

**Limitations:**
- Requires careful graph construction
- Memory intensive for 900 slices
- 2-10 minutes runtime

**Best for:** Final refinement and ensuring global consistency

---

### 4. **Gaussian Process Regression** - Confidence: 7/10

**Strengths:**
- Provides uncertainty estimates
- Excellent for interpolation through gaps
- Naturally smooth surfaces
- Handles missing data elegantly

**Limitations:**
- Computationally expensive: O(N³)
- Requires careful kernel selection
- May oversmooth sharp features

**Best for:** Interpolating surface positions in contaminated/gap regions

---

### 5. **Level Set Methods (VLSSE)** - Confidence: 8/10

**Strengths:**
- Topologically flexible (merging/splitting)
- Sub-voxel precision
- Region-based variants bridge gaps
- Curvature-based smoothing

**Limitations:**
- Initialization dependent
- Parameter tuning required
- 30s-5min runtime

**Best for:** Precise surface boundary extraction with complex topology

---

## Recommended Hybrid Approach

### **Phase 1: Automatic Initialization (Slices 200-500)**

**Method:** Temporal Average + Peak Detection

```python
# Use entire clean region for initialization
clean_slices = volume[200:500, :, :]  # 300 slices
consensus_image = np.median(clean_slices, axis=0)

# Edge detection
edges = sobel(consensus_image, axis=0)  # Horizontal edges
edge_strength = np.mean(np.abs(edges), axis=1)  # Profile along Y

# Find two peaks (top and bottom surfaces)
from scipy.signal import find_peaks
peaks, properties = find_peaks(edge_strength, 
                                distance=50,  # Min separation
                                prominence=10)  # Min strength

y_top_init = peaks[0]
y_bottom_init = peaks[1]
```

**Why this works:**
- 300-slice median eliminates all blooms and artifacts
- Surface lines are reinforced (300× signal)
- Fully automated peak detection
- Robust initialization for tracking

---

### **Phase 2: Bidirectional Kalman Tracking (Clean Region: 200-680)**

**Method:** Rauch-Tung-Striebel (RTS) Smoother

**Forward Pass (400 → 680):**
```python
from filterpy.kalman import KalmanFilter

# State: [y_position, y_velocity]
kf = KalmanFilter(dim_x=2, dim_z=1)
kf.x = np.array([y_top_init, 0])  # Initial state
kf.F = np.array([[1, 1], [0, 1]])  # State transition
kf.H = np.array([[1, 0]])  # Measurement function
kf.R = 5  # Measurement noise
kf.Q = np.eye(2) * 0.1  # Process noise

# Track forward
for z in range(400, 680):
    # Predict
    kf.predict()
    
    # Measure (search in narrow band)
    y_pred = int(kf.x[0])
    search_band = volume[z, y_pred-10:y_pred+10, :]
    
    # Find brightest horizontal feature
    profile = np.mean(search_band, axis=1)
    y_offset = np.argmax(profile) - 10
    y_measured = y_pred + y_offset
    
    # Update
    kf.update(y_measured)
    
    # Store
    y_top_forward[z] = kf.x[0]
```

**Backward Pass (400 → 200):**
- Same process in reverse direction

**RTS Smoothing:**
```python
from filterpy.kalman import rts_smoother
y_top_smoothed, _, _, _ = rts_smoother(
    y_top_forward, 
    P_forward,  # Covariances from forward pass
    F, Q
)
```

**Result:** Smooth, optimal surface trajectory through clean region

---

### **Phase 3: 3D RANSAC Surface Fitting (Global Model)**

**Method:** Fit 3D polynomial surface to clean region data

```python
from sklearn.linear_model import RANSACRegressor
from sklearn.preprocessing import PolynomialFeatures

# Extract point cloud from clean region
points = []
for z in range(200, 680):
    for x in range(width):
        y = y_top_smoothed[z, x]
        points.append([x, z, y])

points = np.array(points)
X = points[:, :2]  # (x, z)
y = points[:, 2]   # y position

# Fit 2nd order polynomial surface
poly = PolynomialFeatures(degree=2)
X_poly = poly.fit_transform(X)

ransac = RANSACRegressor(
    residual_threshold=5,  # 5 pixel tolerance
    max_trials=1000
)
ransac.fit(X_poly, y)

# Now we have a global 3D surface model
def predict_surface(x, z):
    X_test = poly.transform([[x, z]])
    return ransac.predict(X_test)[0]
```

**Result:** Robust 3D surface model that resists outliers

---

### **Phase 4: Contaminated Region Handling (680-900)**

**Method:** 3D Surface Model Interpolation + Confidence Weighting

```python
for z in range(680, 900):
    for x in range(width):
        # Get model prediction
        y_pred = predict_surface(x, z)
        
        # Try to measure actual surface
        search_band = volume[z, int(y_pred)-15:int(y_pred)+15, x]
        
        if has_strong_peak(search_band):
            # Trust measurement
            y_measured = find_peak(search_band)
            confidence = 0.8
        else:
            # Trust model
            y_measured = y_pred
            confidence = 0.3
        
        # Weighted combination
        y_top[z, x] = confidence * y_measured + (1-confidence) * y_pred
```

**Result:** Graceful degradation in contaminated region using 3D model

---

### **Phase 5: Graph-Cut Global Refinement (Optional)**

**Method:** Optimal surface segmentation for final consistency

```python
import maxflow

# Build graph for final refinement
g = maxflow.Graph[float]()

# Add nodes for each (x, z) column
nodes = g.add_grid_nodes((width, 900))

# Data term: prefer positions near our estimate
for z in range(900):
    for x in range(width):
        y_est = y_top[z, x]
        # Cost increases with distance from estimate
        for y in range(height):
            cost = abs(y - y_est) ** 2
            g.add_tedge(nodes[x, z], cost, 0)

# Smoothness term: penalize large jumps
for z in range(899):
    for x in range(width-1):
        # Horizontal smoothness
        g.add_edge(nodes[x, z], nodes[x+1, z], 10, 10)
        # Temporal smoothness
        g.add_edge(nodes[x, z], nodes[x, z+1], 10, 10)

# Solve
g.maxflow()

# Extract refined surface
for z in range(900):
    for x in range(width):
        if g.get_segment(nodes[x, z]) == 0:
            y_top_refined[z, x] = find_surface_at(x, z)
```

**Result:** Globally consistent, smooth 3D surface

---

## Final Algorithm: Step-by-Step

```
INPUT: 900 darkfield image slices (volume[z, y, x])
OUTPUT: Two 3D surfaces (top and bottom), bloom list with depths

1. AUTO-INITIALIZATION (200-500)
   - Compute median image from slices 200-500
   - Detect two peaks → y_top_init, y_bottom_init
   
2. BIDIRECTIONAL KALMAN TRACKING (200-680)
   - Forward pass: 400 → 680
   - Backward pass: 400 → 200
   - RTS smoothing → y_top_clean[200:680], y_bottom_clean[200:680]
   
3. 3D RANSAC SURFACE FITTING (200-680)
   - Extract point cloud from clean region
   - Fit polynomial surface model
   - Get global functions: f_top(x,z), f_bottom(x,z)
   
4. CONTAMINATED REGION (680-900)
   - For each (x, z):
     * Predict: y_pred = f_top(x, z)
     * Measure: y_meas = detect_in_band(y_pred ± 15)
     * Combine with confidence weighting
   
5. ENTRY REGION (130-200)
   - Use 3D model extrapolation
   - Validate with measurements where object is visible
   
6. OPTIONAL: GRAPH-CUT REFINEMENT
   - Build graph with data + smoothness terms
   - Solve min-cut for globally optimal surface
   
7. BLOOM DETECTION & DEPTH CALCULATION
   - Threshold volume → bright voxels
   - 3D connected components → blooms
   - For each bloom at (x, y, z):
     * y_top = f_top(x, z)
     * y_bottom = f_bottom(x, z)
     * depth = (y - y_top) / (y_bottom - y_top) × 100%
   
8. OUTPUT
   - Surface arrays: top_surface[z, x], bottom_surface[z, x]
   - Bloom list: [{x, y, z, depth, volume, brightness}, ...]
```

---

## Computational Performance

| Phase | Method | Time Estimate |
|-------|--------|---------------|
| 1. Initialization | Median + Peak Detection | 2-5 seconds |
| 2. Kalman Tracking | RTS Smoother | 0.5-2 seconds |
| 3. RANSAC Fitting | Polynomial RANSAC | 1-3 minutes |
| 4. Contaminated Region | Model Interpolation | 5-10 seconds |
| 5. Graph-Cut (Optional) | Min-Cut Optimization | 2-5 minutes |
| 6. Bloom Detection | 3D Connected Components | 10-20 seconds |
| **TOTAL (without Graph-Cut)** | | **2-4 minutes** |
| **TOTAL (with Graph-Cut)** | | **4-9 minutes** |

---

## Why This Hybrid Approach is Optimal

1. **Leverages strengths of multiple methods:**
   - Kalman for fast, smooth tracking in clean regions
   - RANSAC for robust global model resistant to outliers
   - 3D interpolation for handling contaminated regions
   - Graph-cut for global consistency (optional refinement)

2. **Addresses all challenges:**
   - ✅ Fragmentation: Kalman bridges gaps, RANSAC ignores outliers
   - ✅ Curvature: Kalman tracks gradual curves, polynomial surface fits curves
   - ✅ Turret/button: Naturally follows 3D topography
   - ✅ Noise: Multiple smoothing stages (median, Kalman, RANSAC)
   - ✅ Contaminated region: 3D model interpolation with confidence weighting

3. **Fully automated:**
   - No manual slice selection
   - No parameter tuning per dataset
   - Robust initialization from temporal average

4. **Computationally efficient:**
   - 2-4 minutes without refinement
   - 4-9 minutes with full refinement
   - Suitable for production use

5. **True 3D approach:**
   - Uses entire Z-axis (all 900 slices)
   - Fits 3D surface models
   - Exploits 3D continuity and consistency
   - Satisfies mentor's requirement for volumetric analysis

---

## Implementation Libraries

```python
# Core libraries
import numpy as np
import scipy.ndimage as ndi
from scipy.signal import find_peaks
from skimage.filters import sobel
from sklearn.linear_model import RANSACRegressor
from sklearn.preprocessing import PolynomialFeatures
from filterpy.kalman import KalmanFilter, rts_smoother

# Optional (for Graph-Cut)
import maxflow  # PyMaxflow

# Visualization
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
```

---

## Expected Output

**1. Surface Data:**
- `top_surface.npy`: Array of shape (900, width) with Y-positions
- `bottom_surface.npy`: Array of shape (900, width) with Y-positions

**2. Bloom Data (JSON):**
```json
{
  "blooms": [
    {
      "id": 1,
      "centroid": {"x": 1245, "y": 387, "z": 456},
      "depth_percent": 45.2,
      "depth_from_top_px": 23,
      "depth_from_bottom_px": 28,
      "volume_voxels": 145,
      "max_brightness": 245,
      "classification": "interior"
    },
    ...
  ],
  "statistics": {
    "total_blooms": 1937,
    "interior_blooms": 856,
    "surface_blooms": 1081
  }
}
```

**3. Visualizations:**
- `surface_3d.png`: 3D plot of both surfaces
- `sample_slices.png`: Detected surfaces overlaid on sample slices
- `depth_histogram.png`: Distribution of bloom depths

---

## Conclusion

This hybrid approach combines the best aspects of temporal tracking, robust statistical fitting, and global optimization to provide a reliable, automated, and efficient solution for 3D surface extraction in darkfield glass inspection. It directly addresses all identified challenges while maintaining computational efficiency and satisfying the requirement for true 3D volumetric analysis.

**Recommendation:** Implement Phases 1-4 first (2-4 minute runtime), validate results, then add Phase 5 (Graph-Cut) if additional refinement is needed.
