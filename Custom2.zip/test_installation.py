"""
Test Installation Script
========================

Quick test to verify all dependencies are installed correctly.
"""

import sys

def test_imports():
    """Test that all required packages can be imported."""
    
    print("Testing package imports...")
    print("-" * 50)
    
    packages = [
        ('numpy', 'NumPy'),
        ('scipy', 'SciPy'),
        ('sklearn', 'scikit-learn'),
        ('skimage', 'scikit-image'),
        ('matplotlib', 'Matplotlib'),
        ('PIL', 'Pillow'),
    ]
    
    optional_packages = [
        ('cv2', 'OpenCV (optional, for video loading)'),
    ]
    
    all_ok = True
    
    # Test required packages
    for module_name, display_name in packages:
        try:
            __import__(module_name)
            print(f"✓ {display_name}")
        except ImportError:
            print(f"✗ {display_name} - NOT INSTALLED")
            all_ok = False
    
    # Test optional packages
    for module_name, display_name in optional_packages:
        try:
            __import__(module_name)
            print(f"✓ {display_name}")
        except ImportError:
            print(f"○ {display_name} - not installed (optional)")
    
    print("-" * 50)
    
    if all_ok:
        print("✓ All required packages installed successfully!")
        return True
    else:
        print("✗ Some required packages are missing.")
        print("Install with: pip install -r requirements.txt")
        return False


def test_modules():
    """Test that custom modules can be imported."""
    
    print("\nTesting custom modules...")
    print("-" * 50)
    
    modules = [
        'glass_surface_extraction',
        'data_loader',
        'visualize',
    ]
    
    all_ok = True
    
    for module_name in modules:
        try:
            __import__(module_name)
            print(f"✓ {module_name}.py")
        except ImportError as e:
            print(f"✗ {module_name}.py - {e}")
            all_ok = False
    
    print("-" * 50)
    
    if all_ok:
        print("✓ All custom modules loaded successfully!")
        return True
    else:
        print("✗ Some custom modules failed to load.")
        return False


def test_basic_functionality():
    """Test basic functionality with synthetic data."""
    
    print("\nTesting basic functionality...")
    print("-" * 50)
    
    try:
        import numpy as np
        from glass_surface_extraction import GlassSurfaceExtractor
        
        # Create synthetic volume (small for speed)
        print("Creating synthetic test data...")
        volume = np.random.rand(100, 200, 300).astype(np.float32) * 50
        
        # Add two bright horizontal lines (simulated surfaces)
        for z in range(100):
            volume[z, 80:82, :] = 200  # Top surface
            volume[z, 130:132, :] = 200  # Bottom surface
        
        print("✓ Synthetic data created")
        
        # Try to initialize extractor
        print("Initializing extractor...")
        extractor = GlassSurfaceExtractor(
            volume,
            clean_start=10,
            clean_end=90,
            init_start=40,
            init_end=60
        )
        
        print("✓ Extractor initialized")
        
        # Try initialization phase
        print("Testing initialization phase...")
        extractor.initialize_surfaces()
        
        print("✓ Initialization successful")
        print(f"  Detected top surface at y={extractor.y_top_init:.1f}")
        print(f"  Detected bottom surface at y={extractor.y_bottom_init:.1f}")
        print(f"  Estimated thickness: {extractor.expected_thickness:.1f} pixels")
        
        print("-" * 50)
        print("✓ Basic functionality test passed!")
        return True
        
    except Exception as e:
        print(f"✗ Functionality test failed: {e}")
        print("-" * 50)
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all tests."""
    
    print("="*50)
    print("GLASS SURFACE EXTRACTION - INSTALLATION TEST")
    print("="*50)
    
    # Test 1: Package imports
    test1 = test_imports()
    
    if not test1:
        print("\n❌ Installation incomplete. Please install missing packages.")
        sys.exit(1)
    
    # Test 2: Custom modules
    test2 = test_modules()
    
    if not test2:
        print("\n❌ Custom modules not found. Ensure all .py files are in the same directory.")
        sys.exit(1)
    
    # Test 3: Basic functionality
    test3 = test_basic_functionality()
    
    if not test3:
        print("\n❌ Functionality test failed. Check error messages above.")
        sys.exit(1)
    
    # All tests passed
    print("\n" + "="*50)
    print("✅ ALL TESTS PASSED!")
    print("="*50)
    print("\nYou're ready to run the extraction pipeline!")
    print("Try: python run_extraction.py /path/to/your/images")
    

if __name__ == "__main__":
    main()
