# Glass Surface Extraction for Darkfield Imaging

**3D surface extraction and bloom detection for glass tablet/iPad screens using darkfield imaging.**

This package implements a robust algorithm for extracting top and bottom glass surfaces from 900-slice darkfield image stacks, handling fragmented lines, curved surfaces around camera turrets, and noise.

---

## Features

✅ **Thickness-Constrained Tracking**: Couples top and bottom surfaces using approximate constant thickness  
✅ **Kalman Filtering**: Smooth tracking with prediction and measurement fusion  
✅ **Bidirectional Processing**: Tracks forward and backward from initialization region  
✅ **3D RANSAC Modeling**: Fits polynomial surface models for extrapolation  
✅ **Turret Handling**: Robust to raised camera housing features  
✅ **Bloom Detection**: Identifies interior defects with depth calculation  
✅ **Comprehensive Visualization**: Multiple plots for quality assessment  

---

## Installation

### Requirements

- Python 3.7+
- NumPy
- SciPy
- scikit-learn
- scikit-image
- Matplotlib
- Pillow

### Install Dependencies

```bash
pip install numpy scipy scikit-learn scikit-image matplotlib pillow
```

**Optional** (for video loading):
```bash
pip install opencv-python
```

---

## Quick Start

### Basic Usage

```bash
python run_extraction.py /path/to/your/images --output results
```

This will:
1. Load all images from the directory
2. Extract top and bottom surfaces
3. Detect interior blooms
4. Create visualizations
5. Save results to `results/` directory

### Example with Custom Parameters

```bash
python run_extraction.py /path/to/images \
    --output my_results \
    --clean-start 200 \
    --clean-end 680 \
    --bloom-threshold 100
```

---

## Input Data Formats

The pipeline supports multiple input formats:

### 1. Directory of Images (Recommended)

```
/path/to/images/
├── Camera_1768922532.594877_A83E0A71.png
├── Camera_1768922532.794877_B94F1B82.png
├── Camera_1768922532.994877_C05G2C93.png
└── ...
```

**Usage:**
```bash
python run_extraction.py /path/to/images
```

### 2. NumPy Array File

Save your 3D array as `.npy`:
```python
import numpy as np
volume = np.load('your_data.npy')  # Shape: (900, height, width)
```

**Usage:**
```bash
python run_extraction.py your_data.npy
```

### 3. Video File

```bash
python run_extraction.py video.mp4
```

### 4. TIFF Stack

```bash
python run_extraction.py stack.tif
```

---

## Output Files

After running the extraction, you'll find these files in the output directory:

| File | Description |
|------|-------------|
| `top_surface.npy` | Top surface Y-positions (shape: [n_slices, width]) |
| `bottom_surface.npy` | Bottom surface Y-positions (shape: [n_slices, width]) |
| `metadata.json` | Extraction parameters and statistics |
| `blooms.json` | Detected blooms with 3D positions and depths |
| `surface_overlays.png` | Sample slices with surface overlays |
| `xz_crosssections.png` | Cross-sections through Z-axis |
| `thickness_analysis.png` | Thickness map and distribution |
| `surface_3d.png` | 3D surface visualization |
| `bloom_analysis.png` | Bloom distribution and statistics |

---

## Using Results in Your Code

### Load Surfaces

```python
import numpy as np

top_surface = np.load('output/top_surface.npy')
bottom_surface = np.load('output/bottom_surface.npy')

# Get surface position at slice z, column x
z, x = 500, 100
y_top = top_surface[z, x]
y_bottom = bottom_surface[z, x]
thickness = y_bottom - y_top
```

### Load Blooms

```python
import json

with open('output/blooms.json', 'r') as f:
    blooms = json.load(f)

# Filter interior blooms only
interior_blooms = [b for b in blooms if b['classification'] == 'interior']

print(f"Found {len(interior_blooms)} interior blooms")

# Access bloom properties
for bloom in interior_blooms[:5]:
    print(f"Position: ({bloom['x']}, {bloom['y']}, {bloom['z']})")
    print(f"Depth from top: {bloom['depth_from_top']:.1f} pixels")
    print(f"Intensity: {bloom['intensity']:.1f}")
```

---

## Advanced Usage

### Python API

For more control, use the Python API directly:

```python
from data_loader import auto_load
from glass_surface_extraction import GlassSurfaceExtractor, detect_blooms
from visualize import create_all_visualizations

# Load data
volume, metadata = auto_load('/path/to/images')

# Extract surfaces
extractor = GlassSurfaceExtractor(
    volume,
    clean_start=200,
    clean_end=680,
    init_start=400,
    init_end=500
)

top_surface, bottom_surface = extractor.extract()

# Detect blooms
blooms = detect_blooms(
    volume, 
    top_surface, 
    bottom_surface,
    intensity_threshold=100,
    min_depth=3
)

# Create visualizations
create_all_visualizations(volume, top_surface, bottom_surface, blooms)

# Save results
extractor.save_results('output')
```

### Customize Parameters

```python
extractor = GlassSurfaceExtractor(
    volume,
    clean_start=200,      # Start of clean region (no turret)
    clean_end=680,        # End of clean region
    init_start=400,       # Start of initialization region
    init_end=500          # End of initialization region
)
```

---

## Algorithm Overview

### Phase 1: Initialization
- Creates consensus image from clean region (slices 400-500)
- Finds brightest horizontal features (surface lines)
- Estimates expected glass thickness

### Phase 2: Kalman Tracking (Clean Region)
- Tracks surfaces bidirectionally from initialization region
- Uses coupled Kalman filter with thickness constraint
- Handles fragmented lines using prediction + measurement fusion

### Phase 3: 3D RANSAC Fitting
- Builds point clouds from tracked surfaces in clean region
- Fits 2nd-degree polynomial surface models
- Models both top surface and thickness variation

### Phase 4: Contaminated Region (Turret)
- Extrapolates surfaces using RANSAC models
- Blends model predictions with measurements (30% measurement, 70% model)
- Rejects turret edges as outliers (outside search band)

### Phase 5: Entry Region
- Fills early slices (130-200) using model predictions only

### Phase 6: Constraint Enforcement
- Ensures surfaces never cross (y_bottom > y_top)
- Maintains minimum separation (50% of expected thickness)

### Phase 7: Smoothing
- Applies Gaussian smoothing (σ=1.0) to remove remaining noise

---

## Troubleshooting

### Problem: "Could not find 2 surface peaks"

**Solution:** Adjust the initialization region to a cleaner area:
```bash
python run_extraction.py data --init-start 450 --init-end 550
```

### Problem: Surfaces look jagged or noisy

**Solution:** This shouldn't happen with the new algorithm (unlike the old DP approach). If it does:
1. Check that your images are properly loaded (not all black/white)
2. Try adjusting the clean region boundaries
3. Increase smoothing in the code (change `sigma=1.0` to `sigma=2.0`)

### Problem: Turret region surfaces are incorrect

**Solution:** Adjust the clean/contaminated region boundary:
```bash
python run_extraction.py data --clean-end 650  # End clean region earlier
```

### Problem: Too many/few blooms detected

**Solution:** Adjust the intensity threshold:
```bash
python run_extraction.py data --bloom-threshold 150  # Higher = fewer blooms
```

---

## Command-Line Options

```
usage: run_extraction.py [-h] [--output OUTPUT] [--clean-start CLEAN_START]
                         [--clean-end CLEAN_END] [--init-start INIT_START]
                         [--init-end INIT_END] [--bloom-threshold BLOOM_THRESHOLD]
                         [--bloom-min-depth BLOOM_MIN_DEPTH] [--no-blooms]
                         [--no-viz]
                         data_path

positional arguments:
  data_path             Path to data (directory of images, .npy file, video, etc.)

optional arguments:
  -h, --help            show this help message and exit
  --output OUTPUT       Output directory (default: output)
  --clean-start CLEAN_START
                        Start of clean region (default: 200)
  --clean-end CLEAN_END
                        End of clean region (default: 680)
  --init-start INIT_START
                        Start of initialization region (default: 400)
  --init-end INIT_END   End of initialization region (default: 500)
  --bloom-threshold BLOOM_THRESHOLD
                        Intensity threshold for bloom detection (default: 100)
  --bloom-min-depth BLOOM_MIN_DEPTH
                        Minimum depth from surface for interior bloom (default: 3)
  --no-blooms           Skip bloom detection
  --no-viz              Skip visualization
```

---

## Understanding the Results

### Surface Arrays

Both `top_surface.npy` and `bottom_surface.npy` are 2D arrays with shape `(n_slices, width)`.

- **Rows (axis 0)**: Z-coordinate (slice number)
- **Columns (axis 1)**: X-coordinate (pixel column)
- **Values**: Y-coordinate (vertical position in pixels)

Example:
```python
top_surface[500, 200] = 145.3  # At slice 500, column 200, top surface is at y=145.3
```

### Bloom Classification

Each bloom has a `classification` field:

- **"interior"**: Bloom is at least 3 pixels away from both surfaces (true defect inside glass)
- **"surface"**: Bloom is within 3 pixels of a surface (likely surface contamination)

### Depth Calculation

For each bloom:
- `depth_from_top`: Distance from bloom centroid to top surface (pixels)
- `depth_from_bottom`: Distance from bloom centroid to bottom surface (pixels)
- `total_thickness`: Glass thickness at that location (pixels)

---

## Performance

**Typical runtime on 900 slices (1920×1080):**
- Surface extraction: 2-3 minutes
- Bloom detection: 1-2 minutes
- Visualization: 30 seconds

**Memory usage:** ~2-3 GB for 900 slices

---

## Citation

If you use this code in your research, please cite:

```
Glass Surface Extraction for Darkfield Imaging
Manus AI, 2026
```

---

## License

This code is provided as-is for research and development purposes.

---

## Support

For questions or issues, please refer to the methodology documents:
- `thickness_constrained_methodology.md`: Detailed algorithm description
- `final_3d_surface_methodology.md`: Research and alternative approaches

---

## Author

**Manus AI**  
Date: 2026-01-20

---

## Changelog

### Version 1.0 (2026-01-20)
- Initial release
- Thickness-constrained Kalman tracking
- 3D RANSAC surface fitting
- Turret handling
- Bloom detection
- Comprehensive visualization
