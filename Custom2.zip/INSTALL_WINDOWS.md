# Installation Guide for Windows

## Prerequisites

1. **Python 3.7 or higher** installed
   - Download from: https://www.python.org/downloads/
   - During installation, check "Add Python to PATH"

2. **Verify Python installation**
   ```cmd
   python --version
   ```
   Should show: `Python 3.x.x`

---

## Installation Steps

### Step 1: Extract the ZIP File

1. Right-click `glass_surface_extraction_package.zip`
2. Select "Extract All..."
3. Choose a destination folder (e.g., `C:\Users\YourName\glass_extraction\`)
4. Click "Extract"

### Step 2: Open Command Prompt

1. Press `Win + R`
2. Type `cmd` and press Enter
3. Navigate to the extracted folder:
   ```cmd
   cd C:\Users\YourName\glass_extraction
   ```

### Step 3: Install Dependencies

```cmd
pip install -r requirements.txt
```

This will install:
- NumPy
- SciPy
- scikit-learn
- scikit-image
- Matplotlib
- Pillow
- OpenCV (optional)

**Note:** If you get "pip is not recognized", try:
```cmd
python -m pip install -r requirements.txt
```

### Step 4: Test Installation

```cmd
python test_installation.py
```

You should see:
```
✅ ALL TESTS PASSED!
You're ready to run the extraction pipeline!
```

---

## Running the Extraction

### Basic Usage

```cmd
python run_extraction.py "C:\path\to\your\images" --output results
```

**Important:** Use quotes around paths with spaces!

### Example

If your images are in `C:\Users\John\Documents\Glass Images\`:

```cmd
python run_extraction.py "C:\Users\John\Documents\Glass Images" --output results
```

---

## Viewing Results

After extraction completes, open the `results` folder:

```cmd
explorer results
```

You'll find:
- `surface_overlays.png` - Visual inspection
- `xz_crosssections.png` - Cross-sections
- `thickness_analysis.png` - Thickness map
- `top_surface.npy` - Top surface data
- `bottom_surface.npy` - Bottom surface data
- `blooms.json` - Detected defects

---

## Common Windows Issues

### Issue: "python is not recognized"

**Solution:** Add Python to PATH:
1. Search for "Environment Variables" in Windows
2. Click "Environment Variables"
3. Under "System variables", find "Path"
4. Click "Edit" → "New"
5. Add: `C:\Python3x\` (your Python installation path)
6. Restart Command Prompt

### Issue: Permission denied when installing packages

**Solution:** Run Command Prompt as Administrator:
1. Search for "cmd" in Start menu
2. Right-click "Command Prompt"
3. Select "Run as administrator"
4. Try installation again

### Issue: "No module named 'numpy'" after installation

**Solution:** Ensure you're using the same Python:
```cmd
python -m pip install -r requirements.txt
python test_installation.py
```

---

## Using Python in Windows

### Option 1: Command Prompt (cmd)
```cmd
python run_extraction.py data --output results
```

### Option 2: PowerShell
```powershell
python run_extraction.py data --output results
```

### Option 3: Anaconda Prompt (if using Anaconda)
```cmd
python run_extraction.py data --output results
```

---

## Loading Results in Python

Create a new Python script (e.g., `analyze_results.py`):

```python
import numpy as np
import json

# Load surfaces
top = np.load('results/top_surface.npy')
bottom = np.load('results/bottom_surface.npy')

# Calculate thickness
thickness = bottom - top
print(f"Average thickness: {thickness.mean():.1f} pixels")

# Load blooms
with open('results/blooms.json') as f:
    blooms = json.load(f)

interior = [b for b in blooms if b['classification'] == 'interior']
print(f"Interior blooms: {len(interior)}")
```

Run it:
```cmd
python analyze_results.py
```

---

## Tips for Windows Users

1. **Use absolute paths** with quotes:
   ```cmd
   python run_extraction.py "C:\Data\Images" --output "C:\Results"
   ```

2. **Use forward slashes** in Python code:
   ```python
   volume, metadata = auto_load('C:/Data/Images')
   ```

3. **Check file paths** in File Explorer:
   - Hold Shift + Right-click on folder
   - Select "Copy as path"
   - Paste in command prompt

4. **View images** in Windows Photo Viewer:
   - Double-click any `.png` file in results folder

---

## Next Steps

See `QUICKSTART.md` for usage examples  
See `README.md` for detailed documentation  
See `thickness_constrained_methodology.md` for algorithm details

---

## Getting Help

If you encounter issues:
1. Check that Python is in PATH
2. Verify all dependencies installed: `python test_installation.py`
3. Use absolute paths with quotes
4. Run Command Prompt as Administrator if needed

---

Good luck with your glass surface extraction! 🚀
