"""
3D Glass Surface Extraction with Thickness Constraints
========================================================

This implementation extracts top and bottom glass surfaces from darkfield
imaging data, handling:
- Fragmented/broken surface lines
- Curved surfaces around turret/camera housing
- Turret artifacts (raised oval feature)
- Constant thickness constraint

Works directly with raw intensity (no edge enhancement to avoid noise).

Author: Manus AI
Date: 2026-01-20
"""

import numpy as np
from scipy.signal import find_peaks
from scipy.ndimage import gaussian_filter, median_filter
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import RANSACRegressor
import matplotlib.pyplot as plt
from pathlib import Path
import json


class CoupledSurfaceTracker:
    """
    Kalman-like tracker for coupled top/bottom surfaces with thickness constraint.
    
    State: [y_top, velocity_top, thickness_deviation]
    """
    
    def __init__(self, y_top_init, expected_thickness, process_noise=0.5, 
                 measurement_noise=5.0):
        """
        Initialize coupled surface tracker.
        
        Args:
            y_top_init: Initial y-position of top surface
            expected_thickness: Expected glass thickness in pixels
            process_noise: Process noise covariance
            measurement_noise: Measurement noise covariance
        """
        # State: [y_top, velocity, thickness_deviation]
        self.state = np.array([y_top_init, 0.0, 0.0])
        
        # State covariance
        self.P = np.eye(3) * 10.0
        
        # State transition matrix
        self.F = np.array([
            [1, 1, 0],      # y_top(k+1) = y_top(k) + velocity
            [0, 1, 0],      # velocity(k+1) = velocity(k)
            [0, 0, 0.95]    # thickness deviation decays toward mean
        ])
        
        # Process noise covariance
        self.Q = np.array([
            [process_noise, 0, 0],
            [0, process_noise, 0],
            [0, 0, 1.0]
        ])
        
        # Measurement noise covariance
        self.R = np.eye(2) * measurement_noise
        
        self.expected_thickness = expected_thickness
    
    def predict(self):
        """Predict next state."""
        # Predict state
        self.state = self.F @ self.state
        
        # Predict covariance
        self.P = self.F @ self.P @ self.F.T + self.Q
        
        y_top = self.state[0]
        y_bottom = y_top + self.expected_thickness + self.state[2]
        
        return y_top, y_bottom
    
    def update(self, y_top_measured, y_bottom_measured, confidence=1.0):
        """
        Update state with measurements.
        
        Args:
            y_top_measured: Measured top surface position
            y_bottom_measured: Measured bottom surface position
            confidence: Measurement confidence (0-1), affects measurement noise
        """
        # Measurement matrix: [y_top, y_bottom]
        H = np.array([
            [1, 0, 0],      # measure y_top directly
            [1, 0, 1]       # measure y_bottom = y_top + expected_thickness + deviation
        ])
        
        # Adjust measurement noise based on confidence
        R = self.R / max(confidence, 0.1)
        
        # Innovation
        z = np.array([y_top_measured, y_bottom_measured])
        z_pred = H @ self.state
        y = z - z_pred
        
        # Innovation covariance
        S = H @ self.P @ H.T + R
        
        # Kalman gain
        K = self.P @ H.T @ np.linalg.inv(S)
        
        # Update state
        self.state = self.state + K @ y
        
        # Update covariance
        self.P = (np.eye(3) - K @ H) @ self.P
        
        y_top = self.state[0]
        y_bottom = y_top + self.expected_thickness + self.state[2]
        
        return y_top, y_bottom
    
    def get_surfaces(self):
        """Get current surface positions."""
        y_top = self.state[0]
        y_bottom = y_top + self.expected_thickness + self.state[2]
        return y_top, y_bottom


class GlassSurfaceExtractor:
    """
    Extract top and bottom glass surfaces from 3D darkfield imaging data.
    """
    
    def __init__(self, volume, clean_start=200, clean_end=680, 
                 init_start=400, init_end=500):
        """
        Initialize surface extractor.
        
        Args:
            volume: 3D numpy array (z, y, x) - darkfield image stack
            clean_start: Start of clean region (no turret)
            clean_end: End of clean region
            init_start: Start of initialization region
            init_end: End of initialization region
        """
        self.volume = volume.astype(np.float32)
        self.n_slices, self.height, self.width = volume.shape
        
        self.clean_start = clean_start
        self.clean_end = clean_end
        self.init_start = init_start
        self.init_end = init_end
        
        # Results
        self.top_surface = np.zeros((self.n_slices, self.width))
        self.bottom_surface = np.zeros((self.n_slices, self.width))
        
        # Parameters
        self.expected_thickness = None
        self.thickness_std = None
        self.y_top_init = None
        self.y_bottom_init = None
        
        # Models
        self.ransac_top = None
        self.ransac_thickness = None
        self.poly_features = None
        
        print(f"Initialized GlassSurfaceExtractor")
        print(f"  Volume shape: {self.volume.shape}")
        print(f"  Clean region: {self.clean_start}-{self.clean_end}")
        print(f"  Init region: {self.init_start}-{self.init_end}")
    
    def initialize_surfaces(self):
        """
        Automatically initialize surface positions and thickness from clean region.
        Uses raw intensity to find brightest horizontal features (surface lines).
        """
        print("\nPhase 1: Initializing surfaces from clean region...")
        
        # Create consensus image from initialization region
        # Use median to be robust to outliers
        consensus = np.median(self.volume[self.init_start:self.init_end], axis=0)
        
        # Smooth slightly to reduce noise
        consensus_smooth = gaussian_filter(consensus, sigma=1.0)
        
        # Average across width to get vertical profile
        profile = np.mean(consensus_smooth, axis=1)
        
        # Find peaks (brightest horizontal features = surface lines)
        # distance=30: surfaces must be at least 30 pixels apart
        # prominence=5: peaks must be significant
        peaks, properties = find_peaks(profile, distance=30, prominence=5)
        
        if len(peaks) < 2:
            raise ValueError(f"Could not find 2 surface peaks. Found {len(peaks)} peaks.")
        
        # Sort by intensity (brightness) and take top 2
        peak_intensities = profile[peaks]
        sorted_idx = np.argsort(peak_intensities)[::-1]
        top_peaks = peaks[sorted_idx[:2]]
        
        # Ensure correct order (top < bottom in y-coordinate)
        self.y_top_init = min(top_peaks)
        self.y_bottom_init = max(top_peaks)
        
        # Estimate thickness from multiple slices in clean region
        thickness_samples = []
        for z in range(self.clean_start, self.clean_end, 10):
            slice_profile = np.mean(gaussian_filter(self.volume[z], sigma=1.0), axis=1)
            slice_peaks, _ = find_peaks(slice_profile, distance=30, prominence=5)
            
            if len(slice_peaks) >= 2:
                # Sort by intensity
                slice_peak_intensities = slice_profile[slice_peaks]
                sorted_idx = np.argsort(slice_peak_intensities)[::-1]
                top_2_peaks = slice_peaks[sorted_idx[:2]]
                
                # Sort by y-position
                top_2_peaks_sorted = np.sort(top_2_peaks)
                thickness = top_2_peaks_sorted[1] - top_2_peaks_sorted[0]
                
                # Sanity check: thickness should be reasonable
                if 20 < thickness < 200:
                    thickness_samples.append(thickness)
        
        if len(thickness_samples) == 0:
            raise ValueError("Could not estimate thickness from clean region")
        
        self.expected_thickness = np.median(thickness_samples)
        self.thickness_std = np.std(thickness_samples)
        
        print(f"  ✓ Initial top surface: y = {self.y_top_init:.1f}")
        print(f"  ✓ Initial bottom surface: y = {self.y_bottom_init:.1f}")
        print(f"  ✓ Expected thickness: {self.expected_thickness:.1f} ± {self.thickness_std:.1f} pixels")
        print(f"  ✓ Thickness samples: {len(thickness_samples)}")
    
    def measure_surface_pair(self, slice_2d, y_top_pred, y_bottom_pred, 
                            search_band=15):
        """
        Measure both surfaces in a single slice using thickness constraint.
        Works with raw intensity - finds brightest horizontal features.
        
        Args:
            slice_2d: 2D array (y, x) - single slice from volume
            y_top_pred: Predicted top surface position
            y_bottom_pred: Predicted bottom surface position
            search_band: Search radius around prediction
        
        Returns:
            y_top_measured, y_bottom_measured, conf_top, conf_bottom
        """
        # Create horizontal profile (average across width)
        profile = np.mean(slice_2d, axis=1)
        
        # Search for top surface
        top_start = max(0, int(y_top_pred - search_band))
        top_end = min(self.height, int(y_top_pred + search_band))
        
        if top_end - top_start < 3:
            return y_top_pred, y_bottom_pred, 0.0, 0.0
        
        top_band = profile[top_start:top_end]
        top_offset = np.argmax(top_band)
        y_top_measured = top_start + top_offset
        
        # Confidence based on peak strength relative to local mean
        top_mean = np.mean(top_band)
        top_max = np.max(top_band)
        conf_top = (top_max / (top_mean + 1e-6)) if top_mean > 0 else 0.0
        
        # Search for bottom surface, constrained by thickness
        bottom_pred_from_top = y_top_measured + self.expected_thickness
        bottom_start = max(0, int(bottom_pred_from_top - search_band))
        bottom_end = min(self.height, int(bottom_pred_from_top + search_band))
        
        if bottom_end - bottom_start < 3:
            return y_top_measured, y_top_measured + self.expected_thickness, conf_top, 0.0
        
        bottom_band = profile[bottom_start:bottom_end]
        bottom_offset = np.argmax(bottom_band)
        y_bottom_measured = bottom_start + bottom_offset
        
        # Confidence
        bottom_mean = np.mean(bottom_band)
        bottom_max = np.max(bottom_band)
        conf_bottom = (bottom_max / (bottom_mean + 1e-6)) if bottom_mean > 0 else 0.0
        
        # Enforce non-crossing constraint
        if y_bottom_measured <= y_top_measured:
            y_bottom_measured = y_top_measured + self.expected_thickness
            conf_bottom = 0.0
        
        return y_top_measured, y_bottom_measured, conf_top, conf_bottom
    
    def track_surfaces_clean_region(self):
        """
        Track surfaces through clean region using coupled Kalman filtering.
        """
        print("\nPhase 2: Tracking surfaces in clean region...")
        
        # Track each column independently
        for x in range(self.width):
            if x % 100 == 0:
                print(f"  Processing column {x}/{self.width}")
            
            # Forward pass: init_start → clean_end
            tracker = CoupledSurfaceTracker(self.y_top_init, self.expected_thickness)
            
            for z in range(self.init_start, self.clean_end):
                # Predict
                y_top_pred, y_bottom_pred = tracker.predict()
                
                # Measure
                y_top_meas, y_bottom_meas, conf_top, conf_bottom = \
                    self.measure_surface_pair(self.volume[z], y_top_pred, y_bottom_pred)
                
                # Decide how to update based on confidence
                min_conf = 1.5
                
                if conf_top > min_conf and conf_bottom > min_conf:
                    # Both clear
                    y_top, y_bottom = tracker.update(y_top_meas, y_bottom_meas, 
                                                    confidence=min(conf_top, conf_bottom))
                elif conf_top > min_conf:
                    # Top clear, derive bottom from thickness
                    y_bottom_derived = y_top_meas + self.expected_thickness
                    y_top, y_bottom = tracker.update(y_top_meas, y_bottom_derived, 
                                                    confidence=conf_top)
                elif conf_bottom > min_conf:
                    # Bottom clear, derive top from thickness
                    y_top_derived = y_bottom_meas - self.expected_thickness
                    y_top, y_bottom = tracker.update(y_top_derived, y_bottom_meas, 
                                                    confidence=conf_bottom)
                else:
                    # Both unclear, use prediction only
                    y_top, y_bottom = y_top_pred, y_bottom_pred
                
                self.top_surface[z, x] = y_top
                self.bottom_surface[z, x] = y_bottom
            
            # Backward pass: init_start → clean_start
            tracker = CoupledSurfaceTracker(self.y_top_init, self.expected_thickness)
            
            for z in range(self.init_start, self.clean_start - 1, -1):
                # Predict
                y_top_pred, y_bottom_pred = tracker.predict()
                
                # Measure
                y_top_meas, y_bottom_meas, conf_top, conf_bottom = \
                    self.measure_surface_pair(self.volume[z], y_top_pred, y_bottom_pred)
                
                # Update logic (same as forward)
                min_conf = 1.5
                
                if conf_top > min_conf and conf_bottom > min_conf:
                    y_top, y_bottom = tracker.update(y_top_meas, y_bottom_meas, 
                                                    confidence=min(conf_top, conf_bottom))
                elif conf_top > min_conf:
                    y_bottom_derived = y_top_meas + self.expected_thickness
                    y_top, y_bottom = tracker.update(y_top_meas, y_bottom_derived, 
                                                    confidence=conf_top)
                elif conf_bottom > min_conf:
                    y_top_derived = y_bottom_meas - self.expected_thickness
                    y_top, y_bottom = tracker.update(y_top_derived, y_bottom_meas, 
                                                    confidence=conf_bottom)
                else:
                    y_top, y_bottom = y_top_pred, y_bottom_pred
                
                self.top_surface[z, x] = y_top
                self.bottom_surface[z, x] = y_bottom
        
        print("  ✓ Clean region tracking complete")
    
    def fit_3d_surface_models(self):
        """
        Fit 3D polynomial surface models using RANSAC on clean region data.
        These models will be used to extrapolate surfaces in turret region.
        """
        print("\nPhase 3: Fitting 3D surface models...")
        
        # Build point clouds from clean region
        top_points = []
        bottom_points = []
        
        for z in range(self.clean_start, self.clean_end):
            for x in range(0, self.width, 5):  # Sample every 5 pixels for speed
                top_points.append([x, z, self.top_surface[z, x]])
                bottom_points.append([x, z, self.bottom_surface[z, x]])
        
        top_points = np.array(top_points)
        bottom_points = np.array(bottom_points)
        
        print(f"  Point clouds: {len(top_points)} points each")
        
        # Polynomial features (degree 2 for smooth curvature)
        self.poly_features = PolynomialFeatures(degree=2)
        
        # Fit top surface
        X_top = self.poly_features.fit_transform(top_points[:, :2])
        y_top_vals = top_points[:, 2]
        
        self.ransac_top = RANSACRegressor(residual_threshold=5.0, max_trials=1000, 
                                         random_state=42)
        self.ransac_top.fit(X_top, y_top_vals)
        
        # Fit thickness model (bottom relative to top)
        X_bottom = self.poly_features.transform(bottom_points[:, :2])
        top_predicted = self.ransac_top.predict(X_bottom)
        thickness_vals = bottom_points[:, 2] - top_predicted
        
        self.ransac_thickness = RANSACRegressor(residual_threshold=3.0, max_trials=500,
                                               random_state=42)
        self.ransac_thickness.fit(X_bottom, thickness_vals)
        
        # Evaluate fit quality
        top_inliers = np.sum(self.ransac_top.inlier_mask_)
        thickness_inliers = np.sum(self.ransac_thickness.inlier_mask_)
        
        print(f"  ✓ Top surface inliers: {top_inliers}/{len(top_points)} "
              f"({100*top_inliers/len(top_points):.1f}%)")
        print(f"  ✓ Thickness inliers: {thickness_inliers}/{len(bottom_points)} "
              f"({100*thickness_inliers/len(bottom_points):.1f}%)")
    
    def predict_surfaces(self, x, z):
        """
        Predict surface positions at (x, z) using fitted models.
        
        Args:
            x: X-coordinate (column)
            z: Z-coordinate (slice)
        
        Returns:
            y_top, y_bottom
        """
        X_test = self.poly_features.transform([[x, z]])
        y_top = self.ransac_top.predict(X_test)[0]
        thickness = self.ransac_thickness.predict(X_test)[0]
        y_bottom = y_top + thickness
        
        return y_top, y_bottom
    
    def fill_contaminated_region(self, start_z=680, end_z=900, blend_weight=0.3):
        """
        Fill contaminated region (turret) using model predictions and measurements.
        
        Args:
            start_z: Start of contaminated region
            end_z: End of contaminated region
            blend_weight: Weight for measurements vs model (0=model only, 1=measurement only)
        """
        print(f"\nPhase 4: Filling contaminated region ({start_z}-{end_z})...")
        print(f"  Blend weight: {blend_weight} (measurement) / {1-blend_weight} (model)")
        
        for z in range(start_z, min(end_z, self.n_slices)):
            if z % 50 == 0:
                print(f"  Processing slice {z}/{end_z}")
            
            for x in range(self.width):
                # Model prediction (extrapolated from clean region)
                y_top_model, y_bottom_model = self.predict_surfaces(x, z)
                
                # Try to measure (with narrow search band to avoid turret edges)
                y_top_meas, y_bottom_meas, conf_top, conf_bottom = \
                    self.measure_surface_pair(self.volume[z], y_top_model, y_bottom_model, 
                                            search_band=10)
                
                # Blend based on confidence
                min_conf = 1.5
                
                if conf_top > min_conf:
                    # Measurement is reliable, blend with model
                    self.top_surface[z, x] = blend_weight * y_top_meas + \
                                            (1 - blend_weight) * y_top_model
                else:
                    # Measurement unreliable, use model only
                    self.top_surface[z, x] = y_top_model
                
                if conf_bottom > min_conf:
                    self.bottom_surface[z, x] = blend_weight * y_bottom_meas + \
                                               (1 - blend_weight) * y_bottom_model
                else:
                    self.bottom_surface[z, x] = y_bottom_model
        
        print("  ✓ Contaminated region filled")
    
    def fill_entry_region(self, start_z=130, end_z=200):
        """
        Fill entry region using model predictions only.
        
        Args:
            start_z: Start of entry region
            end_z: End of entry region
        """
        print(f"\nPhase 5: Filling entry region ({start_z}-{end_z})...")
        
        for z in range(start_z, end_z):
            for x in range(self.width):
                y_top, y_bottom = self.predict_surfaces(x, z)
                self.top_surface[z, x] = y_top
                self.bottom_surface[z, x] = y_bottom
        
        print("  ✓ Entry region filled")
    
    def enforce_constraints(self):
        """
        Enforce physical constraints on surfaces.
        """
        print("\nPhase 6: Enforcing constraints...")
        
        min_separation = self.expected_thickness * 0.5
        violations = 0
        
        for z in range(self.n_slices):
            for x in range(self.width):
                separation = self.bottom_surface[z, x] - self.top_surface[z, x]
                
                if separation < min_separation:
                    # Fix by adjusting bottom
                    self.bottom_surface[z, x] = self.top_surface[z, x] + \
                                               self.expected_thickness
                    violations += 1
        
        print(f"  ✓ Fixed {violations} constraint violations")
    
    def smooth_surfaces(self, sigma=1.0):
        """
        Apply mild smoothing to surfaces to remove remaining noise.
        
        Args:
            sigma: Gaussian smoothing parameter
        """
        print(f"\nPhase 7: Smoothing surfaces (sigma={sigma})...")
        
        self.top_surface = gaussian_filter(self.top_surface, sigma=sigma)
        self.bottom_surface = gaussian_filter(self.bottom_surface, sigma=sigma)
        
        print("  ✓ Smoothing complete")
    
    def extract(self):
        """
        Main extraction pipeline.
        
        Returns:
            top_surface, bottom_surface (both shape: [n_slices, width])
        """
        print("="*70)
        print("GLASS SURFACE EXTRACTION PIPELINE")
        print("="*70)
        
        # Phase 1: Initialize
        self.initialize_surfaces()
        
        # Phase 2: Track clean region
        self.track_surfaces_clean_region()
        
        # Phase 3: Fit 3D models
        self.fit_3d_surface_models()
        
        # Phase 4: Fill contaminated region
        self.fill_contaminated_region()
        
        # Phase 5: Fill entry region
        self.fill_entry_region()
        
        # Phase 6: Enforce constraints
        self.enforce_constraints()
        
        # Phase 7: Smooth
        self.smooth_surfaces(sigma=1.0)
        
        print("\n" + "="*70)
        print("EXTRACTION COMPLETE")
        print("="*70)
        print(f"Top surface range: [{self.top_surface.min():.1f}, {self.top_surface.max():.1f}]")
        print(f"Bottom surface range: [{self.bottom_surface.min():.1f}, {self.bottom_surface.max():.1f}]")
        
        thickness = self.bottom_surface - self.top_surface
        print(f"Thickness: {thickness.mean():.1f} ± {thickness.std():.1f} pixels")
        
        return self.top_surface, self.bottom_surface
    
    def save_results(self, output_dir="output"):
        """
        Save extraction results to files.
        
        Args:
            output_dir: Directory to save results
        """
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        # Save surfaces as numpy arrays
        np.save(output_path / "top_surface.npy", self.top_surface)
        np.save(output_path / "bottom_surface.npy", self.bottom_surface)
        
        # Save metadata
        metadata = {
            'n_slices': self.n_slices,
            'height': self.height,
            'width': self.width,
            'expected_thickness': float(self.expected_thickness),
            'thickness_std': float(self.thickness_std),
            'y_top_init': float(self.y_top_init),
            'y_bottom_init': float(self.y_bottom_init),
            'clean_start': self.clean_start,
            'clean_end': self.clean_end,
        }
        
        with open(output_path / "metadata.json", 'w') as f:
            json.dump(metadata, f, indent=2)
        
        print(f"\n✓ Results saved to {output_path}/")


def detect_blooms(volume, top_surface, bottom_surface, 
                  intensity_threshold=100, min_depth=3):
    """
    Detect interior blooms (defects) between surfaces.
    
    Args:
        volume: Original 3D volume
        top_surface: Top surface array
        bottom_surface: Bottom surface array
        intensity_threshold: Minimum intensity for bloom detection
        min_depth: Minimum distance from surfaces to be considered interior
    
    Returns:
        List of bloom dictionaries
    """
    print("\n" + "="*70)
    print("BLOOM DETECTION")
    print("="*70)
    
    n_slices, height, width = volume.shape
    blooms = []
    
    for z in range(n_slices):
        if z % 100 == 0:
            print(f"Processing slice {z}/{n_slices}")
        
        for x in range(width):
            y_top = int(top_surface[z, x])
            y_bottom = int(bottom_surface[z, x])
            
            # Search interior region only
            for y in range(y_top + 1, y_bottom):
                if volume[z, y, x] > intensity_threshold:
                    depth_from_top = y - y_top
                    depth_from_bottom = y_bottom - y
                    
                    # Classify
                    if depth_from_top < min_depth or depth_from_bottom < min_depth:
                        classification = "surface"
                    else:
                        classification = "interior"
                    
                    blooms.append({
                        'x': int(x),
                        'y': int(y),
                        'z': int(z),
                        'intensity': float(volume[z, y, x]),
                        'depth_from_top': float(depth_from_top),
                        'depth_from_bottom': float(depth_from_bottom),
                        'total_thickness': float(y_bottom - y_top),
                        'classification': classification
                    })
    
    interior_count = sum(1 for b in blooms if b['classification'] == 'interior')
    surface_count = sum(1 for b in blooms if b['classification'] == 'surface')
    
    print(f"\n✓ Total blooms detected: {len(blooms)}")
    print(f"  - Interior blooms: {interior_count}")
    print(f"  - Surface blooms: {surface_count}")
    
    return blooms


if __name__ == "__main__":
    print("Glass Surface Extraction Module")
    print("Import this module and use GlassSurfaceExtractor class")
    print("\nExample usage:")
    print("  from glass_surface_extraction import GlassSurfaceExtractor")
    print("  extractor = GlassSurfaceExtractor(volume)")
    print("  top_surface, bottom_surface = extractor.extract()")
