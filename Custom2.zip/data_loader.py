"""
Data Loading Utilities for Glass Surface Extraction
====================================================

Supports loading image stacks from various formats:
- Directory of PNG/JPG images
- NumPy array file (.npy)
- Video file (.mp4, .avi, etc.)
- TIFF stack

Author: Manus AI
Date: 2026-01-20
"""

import numpy as np
from pathlib import Path
from PIL import Image
import re


def load_from_directory(directory_path, pattern="*.png", sort_by="name"):
    """
    Load image stack from directory of image files.
    
    Args:
        directory_path: Path to directory containing images
        pattern: Glob pattern for image files (e.g., "*.png", "Camera_*.png")
        sort_by: How to sort files - "name" or "timestamp"
    
    Returns:
        volume: 3D numpy array (z, y, x)
        filenames: List of filenames in order
    """
    print(f"Loading images from directory: {directory_path}")
    print(f"  Pattern: {pattern}")
    
    directory = Path(directory_path)
    
    # Find all matching files
    image_files = sorted(directory.glob(pattern))
    
    if len(image_files) == 0:
        raise ValueError(f"No files found matching pattern '{pattern}' in {directory_path}")
    
    print(f"  Found {len(image_files)} files")
    
    # Sort by timestamp if requested
    if sort_by == "timestamp":
        # Extract timestamp from filename (assumes format like Camera_1768922532.594877_*.png)
        def extract_timestamp(path):
            match = re.search(r'(\d+\.\d+)', path.name)
            return float(match.group(1)) if match else 0
        
        image_files = sorted(image_files, key=extract_timestamp)
        print("  Sorted by timestamp")
    else:
        print("  Sorted by filename")
    
    # Load first image to get dimensions
    first_img = np.array(Image.open(image_files[0]))
    
    # Handle color images (convert to grayscale)
    if len(first_img.shape) == 3:
        print("  Converting color images to grayscale")
        first_img = np.mean(first_img, axis=2)
    
    height, width = first_img.shape
    n_slices = len(image_files)
    
    print(f"  Image dimensions: {height} x {width}")
    print(f"  Number of slices: {n_slices}")
    
    # Allocate volume
    volume = np.zeros((n_slices, height, width), dtype=np.float32)
    
    # Load all images
    for i, img_path in enumerate(image_files):
        if i % 100 == 0:
            print(f"  Loading slice {i}/{n_slices}")
        
        img = np.array(Image.open(img_path))
        
        # Convert to grayscale if needed
        if len(img.shape) == 3:
            img = np.mean(img, axis=2)
        
        volume[i] = img.astype(np.float32)
    
    print(f"✓ Loaded volume shape: {volume.shape}")
    print(f"  Value range: [{volume.min():.1f}, {volume.max():.1f}]")
    
    filenames = [f.name for f in image_files]
    
    return volume, filenames


def load_from_numpy(file_path):
    """
    Load image stack from NumPy array file.
    
    Args:
        file_path: Path to .npy file
    
    Returns:
        volume: 3D numpy array (z, y, x)
    """
    print(f"Loading from NumPy file: {file_path}")
    
    volume = np.load(file_path)
    
    print(f"✓ Loaded volume shape: {volume.shape}")
    print(f"  Value range: [{volume.min():.1f}, {volume.max():.1f}]")
    
    # Ensure 3D
    if len(volume.shape) != 3:
        raise ValueError(f"Expected 3D array, got shape {volume.shape}")
    
    return volume.astype(np.float32)


def load_from_video(video_path, max_frames=None):
    """
    Load image stack from video file.
    
    Args:
        video_path: Path to video file
        max_frames: Maximum number of frames to load (None = all)
    
    Returns:
        volume: 3D numpy array (z, y, x)
    """
    try:
        import cv2
    except ImportError:
        raise ImportError("OpenCV (cv2) is required to load video files. "
                         "Install with: pip install opencv-python")
    
    print(f"Loading from video file: {video_path}")
    
    cap = cv2.VideoCapture(str(video_path))
    
    if not cap.isOpened():
        raise ValueError(f"Could not open video file: {video_path}")
    
    # Get video properties
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    if max_frames is not None:
        n_frames = min(total_frames, max_frames)
    else:
        n_frames = total_frames
    
    print(f"  Video properties: {width}x{height}, {total_frames} frames")
    print(f"  Loading {n_frames} frames")
    
    # Allocate volume
    volume = np.zeros((n_frames, height, width), dtype=np.float32)
    
    # Read frames
    for i in range(n_frames):
        ret, frame = cap.read()
        
        if not ret:
            print(f"  Warning: Could only read {i} frames")
            volume = volume[:i]
            break
        
        if i % 100 == 0:
            print(f"  Loading frame {i}/{n_frames}")
        
        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        volume[i] = gray.astype(np.float32)
    
    cap.release()
    
    print(f"✓ Loaded volume shape: {volume.shape}")
    print(f"  Value range: [{volume.min():.1f}, {volume.max():.1f}]")
    
    return volume


def load_from_tiff_stack(tiff_path):
    """
    Load image stack from TIFF file (multi-page TIFF).
    
    Args:
        tiff_path: Path to TIFF file
    
    Returns:
        volume: 3D numpy array (z, y, x)
    """
    print(f"Loading from TIFF stack: {tiff_path}")
    
    from PIL import Image
    
    img = Image.open(tiff_path)
    
    # Get number of pages
    n_frames = img.n_frames
    
    print(f"  TIFF stack has {n_frames} pages")
    
    # Load first frame to get dimensions
    img.seek(0)
    first_frame = np.array(img)
    
    if len(first_frame.shape) == 3:
        print("  Converting color images to grayscale")
        first_frame = np.mean(first_frame, axis=2)
    
    height, width = first_frame.shape
    
    # Allocate volume
    volume = np.zeros((n_frames, height, width), dtype=np.float32)
    
    # Load all frames
    for i in range(n_frames):
        if i % 100 == 0:
            print(f"  Loading page {i}/{n_frames}")
        
        img.seek(i)
        frame = np.array(img)
        
        if len(frame.shape) == 3:
            frame = np.mean(frame, axis=2)
        
        volume[i] = frame.astype(np.float32)
    
    print(f"✓ Loaded volume shape: {volume.shape}")
    print(f"  Value range: [{volume.min():.1f}, {volume.max():.1f}]")
    
    return volume


def auto_load(path, **kwargs):
    """
    Automatically detect format and load data.
    
    Args:
        path: Path to data (directory, file, etc.)
        **kwargs: Additional arguments passed to specific loader
    
    Returns:
        volume: 3D numpy array (z, y, x)
        metadata: Dictionary with loading information
    """
    path = Path(path)
    
    metadata = {'source': str(path)}
    
    if path.is_dir():
        # Directory of images
        volume, filenames = load_from_directory(path, **kwargs)
        metadata['filenames'] = filenames
        metadata['format'] = 'directory'
    
    elif path.suffix == '.npy':
        # NumPy array
        volume = load_from_numpy(path)
        metadata['format'] = 'numpy'
    
    elif path.suffix in ['.tif', '.tiff']:
        # TIFF stack
        volume = load_from_tiff_stack(path)
        metadata['format'] = 'tiff'
    
    elif path.suffix in ['.mp4', '.avi', '.mov', '.mkv']:
        # Video file
        volume = load_from_video(path, **kwargs)
        metadata['format'] = 'video'
    
    else:
        raise ValueError(f"Unsupported file format: {path.suffix}")
    
    return volume, metadata


if __name__ == "__main__":
    print("Data Loading Utilities")
    print("\nSupported formats:")
    print("  - Directory of images (PNG, JPG, etc.)")
    print("  - NumPy array (.npy)")
    print("  - Video file (.mp4, .avi, etc.)")
    print("  - TIFF stack (.tif, .tiff)")
    print("\nExample usage:")
    print("  from data_loader import auto_load")
    print("  volume, metadata = auto_load('/path/to/data')")
