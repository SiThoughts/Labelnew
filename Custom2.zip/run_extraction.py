"""
Main Script for Glass Surface Extraction
=========================================

Complete example showing how to:
1. Load data
2. Extract surfaces
3. Detect blooms
4. Visualize results
5. Save outputs

Author: Manus AI
Date: 2026-01-20
"""

import numpy as np
from pathlib import Path
import json
import argparse

from data_loader import auto_load
from glass_surface_extraction import GlassSurfaceExtractor, detect_blooms
from visualize import create_all_visualizations


def main():
    """Main extraction pipeline."""
    
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Glass Surface Extraction')
    parser.add_argument('data_path', type=str, 
                       help='Path to data (directory of images, .npy file, video, etc.)')
    parser.add_argument('--output', type=str, default='output',
                       help='Output directory (default: output)')
    parser.add_argument('--clean-start', type=int, default=200,
                       help='Start of clean region (default: 200)')
    parser.add_argument('--clean-end', type=int, default=680,
                       help='End of clean region (default: 680)')
    parser.add_argument('--init-start', type=int, default=400,
                       help='Start of initialization region (default: 400)')
    parser.add_argument('--init-end', type=int, default=500,
                       help='End of initialization region (default: 500)')
    parser.add_argument('--bloom-threshold', type=int, default=100,
                       help='Intensity threshold for bloom detection (default: 100)')
    parser.add_argument('--bloom-min-depth', type=int, default=3,
                       help='Minimum depth from surface for interior bloom (default: 3)')
    parser.add_argument('--no-blooms', action='store_true',
                       help='Skip bloom detection')
    parser.add_argument('--no-viz', action='store_true',
                       help='Skip visualization')
    
    args = parser.parse_args()
    
    print("="*70)
    print("GLASS SURFACE EXTRACTION PIPELINE")
    print("="*70)
    print(f"Data path: {args.data_path}")
    print(f"Output directory: {args.output}")
    print(f"Clean region: {args.clean_start}-{args.clean_end}")
    print(f"Init region: {args.init_start}-{args.init_end}")
    print("="*70)
    
    # Create output directory
    output_path = Path(args.output)
    output_path.mkdir(exist_ok=True, parents=True)
    
    # Step 1: Load data
    print("\n" + "="*70)
    print("STEP 1: LOADING DATA")
    print("="*70)
    
    volume, metadata = auto_load(args.data_path)
    
    print(f"\n✓ Data loaded successfully")
    print(f"  Shape: {volume.shape}")
    print(f"  Format: {metadata['format']}")
    
    # Step 2: Extract surfaces
    print("\n" + "="*70)
    print("STEP 2: EXTRACTING SURFACES")
    print("="*70)
    
    extractor = GlassSurfaceExtractor(
        volume,
        clean_start=args.clean_start,
        clean_end=args.clean_end,
        init_start=args.init_start,
        init_end=args.init_end
    )
    
    top_surface, bottom_surface = extractor.extract()
    
    # Step 3: Save surfaces
    print("\n" + "="*70)
    print("STEP 3: SAVING RESULTS")
    print("="*70)
    
    extractor.save_results(args.output)
    
    # Step 4: Detect blooms (optional)
    blooms = None
    if not args.no_blooms:
        print("\n" + "="*70)
        print("STEP 4: DETECTING BLOOMS")
        print("="*70)
        
        blooms = detect_blooms(
            volume, 
            top_surface, 
            bottom_surface,
            intensity_threshold=args.bloom_threshold,
            min_depth=args.bloom_min_depth
        )
        
        # Save blooms
        bloom_file = output_path / 'blooms.json'
        with open(bloom_file, 'w') as f:
            json.dump(blooms, f, indent=2)
        
        print(f"\n✓ Blooms saved to {bloom_file}")
    
    # Step 5: Create visualizations (optional)
    if not args.no_viz:
        print("\n" + "="*70)
        print("STEP 5: CREATING VISUALIZATIONS")
        print("="*70)
        
        create_all_visualizations(
            volume, 
            top_surface, 
            bottom_surface, 
            blooms=blooms,
            output_dir=args.output
        )
    
    # Final summary
    print("\n" + "="*70)
    print("PIPELINE COMPLETE")
    print("="*70)
    print(f"\nResults saved to: {output_path.absolute()}")
    print("\nOutput files:")
    print(f"  - top_surface.npy: Top surface positions")
    print(f"  - bottom_surface.npy: Bottom surface positions")
    print(f"  - metadata.json: Extraction parameters and statistics")
    
    if not args.no_blooms:
        print(f"  - blooms.json: Detected blooms with positions and depths")
    
    if not args.no_viz:
        print(f"  - surface_overlays.png: Sample slices with surface overlays")
        print(f"  - xz_crosssections.png: Cross-sections through Z-axis")
        print(f"  - thickness_analysis.png: Thickness map and distribution")
        print(f"  - surface_3d.png: 3D surface visualization")
        if blooms and len(blooms) > 0:
            print(f"  - bloom_analysis.png: Bloom distribution and statistics")
    
    print("\n✓ All done!")


if __name__ == "__main__":
    main()
