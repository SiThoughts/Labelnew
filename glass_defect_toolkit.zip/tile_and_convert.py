#!/usr/bin/env python3
"""
Tile images and convert YOLO detection labels for tiled crops.
"""

import os
import argparse
import cv2
import numpy as np
from pathlib import Path
from tqdm import tqdm
import shutil

def parse_yolo_label(label_path, img_width, img_height):
    """Parse YOLO format label file and return list of (class_id, x_center, y_center, width, height)"""
    boxes = []
    if os.path.exists(label_path):
        with open(label_path, 'r') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 5:
                    class_id = int(parts[0])
                    x_center = float(parts[1]) * img_width
                    y_center = float(parts[2]) * img_height
                    width = float(parts[3]) * img_width
                    height = float(parts[4]) * img_height
                    boxes.append((class_id, x_center, y_center, width, height))
    return boxes

def save_yolo_label(label_path, boxes, tile_width, tile_height):
    """Save YOLO format labels for a tile"""
    os.makedirs(os.path.dirname(label_path), exist_ok=True)
    with open(label_path, 'w') as f:
        for class_id, x_center, y_center, width, height in boxes:
            # Normalize to tile dimensions
            x_norm = x_center / tile_width
            y_norm = y_center / tile_height
            w_norm = width / tile_width
            h_norm = height / tile_height
            f.write(f"{class_id} {x_norm:.6f} {y_norm:.6f} {w_norm:.6f} {h_norm:.6f}\n")

def clip_box_to_tile(box, tile_x, tile_y, tile_width, tile_height, min_area_frac):
    """Clip bounding box to tile boundaries and check if it meets minimum area requirement"""
    class_id, x_center, y_center, width, height = box
    
    # Convert to corner coordinates
    x1 = x_center - width / 2
    y1 = y_center - height / 2
    x2 = x_center + width / 2
    y2 = y_center + height / 2
    
    # Clip to tile boundaries
    x1_clipped = max(0, x1 - tile_x)
    y1_clipped = max(0, y1 - tile_y)
    x2_clipped = min(tile_width, x2 - tile_x)
    y2_clipped = min(tile_height, y2 - tile_y)
    
    # Check if box is valid after clipping
    if x2_clipped <= x1_clipped or y2_clipped <= y1_clipped:
        return None
    
    # Calculate clipped area and check minimum area requirement
    clipped_width = x2_clipped - x1_clipped
    clipped_height = y2_clipped - y1_clipped
    clipped_area = clipped_width * clipped_height
    tile_area = tile_width * tile_height
    
    if clipped_area / tile_area < min_area_frac:
        return None
    
    # Convert back to center format relative to tile
    new_x_center = (x1_clipped + x2_clipped) / 2
    new_y_center = (y1_clipped + y2_clipped) / 2
    new_width = clipped_width
    new_height = clipped_height
    
    return (class_id, new_x_center, new_y_center, new_width, new_height)

def tile_image_and_labels(src_dir, dst_dir, tile_size, overlap, min_area_frac):
    """Tile images and convert labels for a dataset"""
    
    splits = ['train', 'val', 'test']
    
    for split in splits:
        src_images_dir = os.path.join(src_dir, 'images', split)
        src_labels_dir = os.path.join(src_dir, 'labels', split)
        
        if not os.path.exists(src_images_dir):
            print(f"Skipping {split} - directory not found: {src_images_dir}")
            continue
            
        dst_images_dir = os.path.join(dst_dir, 'images', split)
        dst_labels_dir = os.path.join(dst_dir, 'labels', split)
        
        os.makedirs(dst_images_dir, exist_ok=True)
        os.makedirs(dst_labels_dir, exist_ok=True)
        
        image_files = [f for f in os.listdir(src_images_dir) 
                      if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.tiff'))]
        
        print(f"Processing {len(image_files)} images in {split} split...")
        
        for img_file in tqdm(image_files, desc=f"Tiling {split}"):
            img_path = os.path.join(src_images_dir, img_file)
            label_path = os.path.join(src_labels_dir, os.path.splitext(img_file)[0] + '.txt')
            
            # Load image
            img = cv2.imread(img_path)
            if img is None:
                print(f"Warning: Could not load image {img_path}")
                continue
                
            img_height, img_width = img.shape[:2]
            
            # Parse labels
            boxes = parse_yolo_label(label_path, img_width, img_height)
            
            # Calculate tile positions
            step_size = int(tile_size * (1 - overlap))
            tile_count = 0
            
            for y in range(0, img_height, step_size):
                for x in range(0, img_width, step_size):
                    # Calculate tile boundaries
                    tile_x1 = x
                    tile_y1 = y
                    tile_x2 = min(x + tile_size, img_width)
                    tile_y2 = min(y + tile_size, img_height)
                    
                    # Skip if tile is too small
                    if (tile_x2 - tile_x1) < tile_size * 0.5 or (tile_y2 - tile_y1) < tile_size * 0.5:
                        continue
                    
                    # Extract tile
                    tile = img[tile_y1:tile_y2, tile_x1:tile_x2]
                    
                    # Pad tile if necessary to reach target size
                    if tile.shape[0] < tile_size or tile.shape[1] < tile_size:
                        padded_tile = np.zeros((tile_size, tile_size, 3), dtype=np.uint8)
                        padded_tile[:tile.shape[0], :tile.shape[1]] = tile
                        tile = padded_tile
                    
                    # Process labels for this tile
                    tile_boxes = []
                    for box in boxes:
                        clipped_box = clip_box_to_tile(box, tile_x1, tile_y1, tile_size, tile_size, min_area_frac)
                        if clipped_box is not None:
                            tile_boxes.append(clipped_box)
                    
                    # Save tile and labels
                    base_name = os.path.splitext(img_file)[0]
                    tile_name = f"{base_name}_tile_{tile_count:04d}"
                    
                    tile_img_path = os.path.join(dst_images_dir, f"{tile_name}.jpg")
                    tile_label_path = os.path.join(dst_labels_dir, f"{tile_name}.txt")
                    
                    cv2.imwrite(tile_img_path, tile)
                    save_yolo_label(tile_label_path, tile_boxes, tile_size, tile_size)
                    
                    tile_count += 1

def main():
    parser = argparse.ArgumentParser(description='Tile images and convert YOLO labels')
    parser.add_argument('--src', required=True, help='Source dataset directory')
    parser.add_argument('--dst', required=True, help='Destination directory for tiled dataset')
    parser.add_argument('--tilesz', type=int, default=1024, help='Tile size (default: 1024)')
    parser.add_argument('--overlap', type=float, default=0.10, help='Overlap fraction (default: 0.10)')
    parser.add_argument('--min_area_frac', type=float, default=0.0002, help='Minimum area fraction to keep box (default: 0.0002)')
    
    args = parser.parse_args()
    
    print(f"Tiling dataset from {args.src} to {args.dst}")
    print(f"Tile size: {args.tilesz}x{args.tilesz}, Overlap: {args.overlap*100:.1f}%")
    print(f"Minimum area fraction: {args.min_area_frac}")
    
    tile_image_and_labels(args.src, args.dst, args.tilesz, args.overlap, args.min_area_frac)
    print("Tiling complete!")

if __name__ == "__main__":
    main()

