# Glass Defect Detection Toolkit

This toolkit converts YOLOv8 detection datasets to YOLOv8 segmentation datasets using SAM2 and trains YOLOv10n-seg models for glass defect detection.

## Quick Start

**Just double-click the batch files in order:**

1. **0_setup_env.bat** - Sets up Python virtual environment and installs dependencies
2. **prep_tile_EV.bat** - Tiles the EV dataset into 1024x1024 crops
3. **prep_tile_SV.bat** - Tiles the SV dataset into 1024x1024 crops  
4. **auto_mask_EV.bat** - Converts EV bounding boxes to segmentation masks using SAM2
5. **auto_mask_SV.bat** - Converts SV bounding boxes to segmentation masks using SAM2
6. **train_EV_seg.bat** - Trains YOLOv10n-seg model on EV dataset
7. **train_SV_seg.bat** - Trains YOLOv10n-seg model on SV dataset

## What Each Step Does

### Step 1: Environment Setup
- Creates a Python virtual environment (.venv)
- Installs all required packages including SAM2

### Step 2-3: Dataset Tiling
- Tiles large images into 1024x1024 crops with 10% overlap
- Adjusts YOLO bounding box labels for each tile
- Removes boxes smaller than 0.02% of tile area
- Outputs to: `D:\LIDS Data\Photomask\defect_detection_datasets_fixed\EV_tiled_seg` and `SV_tiled_seg`

### Step 4-5: SAM2 Auto-Masking
- Downloads SAM2 model checkpoint automatically (if needed)
- Uses bounding boxes as prompts for SAM2 to generate precise segmentation masks
- Applies 2-pixel dilation to "checks" class masks (class 1)
- Converts masks to YOLO segmentation format (polygon coordinates)

### Step 6-7: Model Training
- Trains YOLOv10n-seg models optimized for small defect detection
- Uses different augmentation parameters for EV vs SV datasets
- Models saved to `runs/segment/EV_seg_model` and `runs/segment/SV_seg_model`

## Training Parameters

### EV Dataset Parameters:
- Image size: 1024x1024
- Batch size: 8
- Epochs: 80
- HSV augmentation: h=0.0, s=0.15, v=0.15
- Geometric augmentation: degrees=2, translate=0.02, scale=0.15
- Copy-paste augmentation: 0.2
- Mosaic: 0.05 (reduced for small objects)

### SV Dataset Parameters:
- Same as EV except:
- HSV augmentation: h=0.0, s=0.18, v=0.20

## File Structure

```
glass_defect_toolkit/
├── 0_setup_env.bat              # Environment setup
├── prep_tile_EV.bat             # Tile EV dataset
├── prep_tile_SV.bat             # Tile SV dataset  
├── auto_mask_EV.bat             # SAM2 masking for EV
├── auto_mask_SV.bat             # SAM2 masking for SV
├── train_EV_seg.bat             # Train EV model
├── train_SV_seg.bat             # Train SV model
├── requirements.txt             # Python dependencies
├── tile_and_convert.py          # Tiling script
├── sam2_box2mask.py             # SAM2 conversion script
├── ev_tiled_seg.yaml            # EV dataset config
├── sv_tiled_seg.yaml            # SV dataset config
└── README.md                    # This file
```

## Requirements

- Windows 10/11
- Python 3.8+ installed and in PATH
- NVIDIA GPU with CUDA support (recommended for SAM2 and training)
- At least 16GB RAM
- 50GB+ free disk space

## Expected Input Structure

Your source datasets should be in YOLO format:
```
EV_dataset/
├── images/
│   ├── train/
│   ├── val/
│   └── test/
└── labels/
    ├── train/
    ├── val/
    └── test/
```

## Troubleshooting

- **"Python not found"**: Make sure Python is installed and in your system PATH
- **CUDA errors**: Install CUDA toolkit and PyTorch with CUDA support
- **Out of memory**: Reduce batch size in training scripts (change `batch=8` to `batch=4`)
- **SAM2 download fails**: Check internet connection, checkpoint will auto-download

## Class Labels

- Class 0: chips
- Class 1: checks (receives 2-pixel dilation during training)

The toolkit is designed for these specific defect types but can be adapted for other classes by modifying the YAML files.

