#!/usr/bin/env python3
"""
Convert YOLO bounding boxes to segmentation masks using SAM2.
"""

import os
import argparse
import cv2
import numpy as np
from pathlib import Path
from tqdm import tqdm
import torch
import urllib.request
from sam2.build_sam import build_sam2
from sam2.sam2_image_predictor import SAM2ImagePredictor

def download_sam2_checkpoint(checkpoint_path, model_type):
    """Download SAM2 checkpoint if it doesn't exist"""
    if os.path.exists(checkpoint_path):
        return
    
    print(f"Downloading SAM2 checkpoint: {checkpoint_path}")
    
    # SAM2 checkpoint URLs
    checkpoint_urls = {
        'vit_h': 'https://dl.fbaipublicfiles.com/segment_anything_2/072824/sam2_hiera_large.pt',
        'vit_l': 'https://dl.fbaipublicfiles.com/segment_anything_2/072824/sam2_hiera_large.pt',
        'vit_b': 'https://dl.fbaipublicfiles.com/segment_anything_2/072824/sam2_hiera_base_plus.pt',
        'vit_s': 'https://dl.fbaipublicfiles.com/segment_anything_2/072824/sam2_hiera_small.pt'
    }
    
    if model_type not in checkpoint_urls:
        raise ValueError(f"Unknown model type: {model_type}")
    
    url = checkpoint_urls[model_type]
    os.makedirs(os.path.dirname(checkpoint_path), exist_ok=True)
    
    try:
        urllib.request.urlretrieve(url, checkpoint_path)
        print(f"Downloaded checkpoint to {checkpoint_path}")
    except Exception as e:
        print(f"Error downloading checkpoint: {e}")
        raise

def parse_yolo_boxes(label_path, img_width, img_height):
    """Parse YOLO format bounding boxes"""
    boxes = []
    if os.path.exists(label_path):
        with open(label_path, 'r') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 5:
                    class_id = int(parts[0])
                    x_center = float(parts[1]) * img_width
                    y_center = float(parts[2]) * img_height
                    width = float(parts[3]) * img_width
                    height = float(parts[4]) * img_height
                    
                    # Convert to corner coordinates
                    x1 = x_center - width / 2
                    y1 = y_center - height / 2
                    x2 = x_center + width / 2
                    y2 = y_center + height / 2
                    
                    boxes.append((class_id, x1, y1, x2, y2))
    return boxes

def mask_to_polygon(mask):
    """Convert binary mask to polygon points"""
    # Find contours
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    if not contours:
        return []
    
    # Get the largest contour
    largest_contour = max(contours, key=cv2.contourArea)
    
    # Simplify contour
    epsilon = 0.002 * cv2.arcLength(largest_contour, True)
    simplified_contour = cv2.approxPolyDP(largest_contour, epsilon, True)
    
    # Convert to list of points
    points = simplified_contour.reshape(-1, 2)
    
    return points.flatten()

def save_yolo_segmentation(label_path, segmentations, img_width, img_height):
    """Save YOLO format segmentation labels"""
    os.makedirs(os.path.dirname(label_path), exist_ok=True)
    
    with open(label_path, 'w') as f:
        for class_id, polygon in segmentations:
            if len(polygon) >= 6:  # At least 3 points (6 coordinates)
                # Normalize coordinates
                normalized_polygon = []
                for i in range(0, len(polygon), 2):
                    x = polygon[i] / img_width
                    y = polygon[i + 1] / img_height
                    normalized_polygon.extend([x, y])
                
                # Write to file
                polygon_str = ' '.join([f"{coord:.6f}" for coord in normalized_polygon])
                f.write(f"{class_id} {polygon_str}\n")

def dilate_mask_for_checks(mask, class_id, dilation_pixels=2):
    """Apply dilation to masks for 'checks' class (class 1)"""
    if class_id == 1:  # checks class
        kernel = np.ones((dilation_pixels * 2 + 1, dilation_pixels * 2 + 1), np.uint8)
        mask = cv2.dilate(mask.astype(np.uint8), kernel, iterations=1)
    return mask

def process_dataset_with_sam2(src_dir, sam_checkpoint, model_type):
    """Process entire dataset with SAM2"""
    
    # Initialize SAM2
    print("Loading SAM2 model...")
    
    # Download checkpoint if needed
    download_sam2_checkpoint(sam_checkpoint, model_type)
    
    # Build SAM2 model
    sam2_model = build_sam2(model_type, sam_checkpoint)
    predictor = SAM2ImagePredictor(sam2_model)
    
    splits = ['train', 'val', 'test']
    
    for split in splits:
        images_dir = os.path.join(src_dir, 'images', split)
        labels_dir = os.path.join(src_dir, 'labels', split)
        
        if not os.path.exists(images_dir):
            print(f"Skipping {split} - directory not found: {images_dir}")
            continue
        
        image_files = [f for f in os.listdir(images_dir) 
                      if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.tiff'))]
        
        print(f"Processing {len(image_files)} images in {split} split...")
        
        for img_file in tqdm(image_files, desc=f"SAM2 {split}"):
            img_path = os.path.join(images_dir, img_file)
            label_path = os.path.join(labels_dir, os.path.splitext(img_file)[0] + '.txt')
            
            # Load image
            image = cv2.imread(img_path)
            if image is None:
                print(f"Warning: Could not load image {img_path}")
                continue
            
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            img_height, img_width = image_rgb.shape[:2]
            
            # Parse bounding boxes
            boxes = parse_yolo_boxes(label_path, img_width, img_height)
            
            if not boxes:
                # No boxes, create empty label file
                save_yolo_segmentation(label_path, [], img_width, img_height)
                continue
            
            # Set image for SAM2
            predictor.set_image(image_rgb)
            
            segmentations = []
            
            for class_id, x1, y1, x2, y2 in boxes:
                # Create input box for SAM2
                input_box = np.array([x1, y1, x2, y2])
                
                try:
                    # Predict mask
                    masks, scores, _ = predictor.predict(
                        point_coords=None,
                        point_labels=None,
                        box=input_box[None, :],
                        multimask_output=False,
                    )
                    
                    if len(masks) > 0:
                        mask = masks[0]  # Take the first (and only) mask
                        
                        # Apply dilation for checks class
                        mask = dilate_mask_for_checks(mask, class_id, dilation_pixels=2)
                        
                        # Convert mask to polygon
                        polygon = mask_to_polygon(mask)
                        
                        if len(polygon) >= 6:  # Valid polygon
                            segmentations.append((class_id, polygon))
                
                except Exception as e:
                    print(f"Warning: SAM2 failed for box in {img_file}: {e}")
                    continue
            
            # Save segmentation labels (overwrites box labels)
            save_yolo_segmentation(label_path, segmentations, img_width, img_height)

def main():
    parser = argparse.ArgumentParser(description='Convert YOLO boxes to segmentation masks using SAM2')
    parser.add_argument('--src', required=True, help='Source dataset directory (with tiled images and box labels)')
    parser.add_argument('--sam_checkpoint', default='sam2_h.pth', help='SAM2 checkpoint path')
    parser.add_argument('--model_type', default='vit_h', choices=['vit_h', 'vit_l', 'vit_b', 'vit_s'], 
                       help='SAM2 model type')
    
    args = parser.parse_args()
    
    print(f"Converting boxes to masks for dataset: {args.src}")
    print(f"SAM2 model: {args.model_type}, checkpoint: {args.sam_checkpoint}")
    
    process_dataset_with_sam2(args.src, args.sam_checkpoint, args.model_type)
    print("SAM2 conversion complete!")

if __name__ == "__main__":
    main()

