#!/usr/bin/env python3
"""
Compatible ONNX Export Script for EfficientDet Models
Exports models with output names and dynamic axes matching existing inference code
"""

import torch
import onnx
import yaml
import argparse
import os
import sys
import numpy as np
from pathlib import Path

def export_to_onnx_compatible(model_path, config_path, output_path, input_size, model_type='EV'):
    """Export EfficientDet model to ONNX format with compatible output names"""
    
    # Add efficientdet repo to path
    repo_path = Path(__file__).parent.parent / "efficientdet_repo"
    sys.path.insert(0, str(repo_path))
    
    try:
        from efficientdet.model import EfficientDet
        from efficientdet.utils import BBoxTransform, ClipBoxes
        from utils.utils import postprocess, invert_affine, display
        
        # Load config
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        
        print(f"Loading model from: {model_path}")
        print(f"Config: {config_path}")
        print(f"Input size: {input_size}x{input_size}")
        print(f"Model type: {model_type}")
        
        # Create model
        num_classes = len(config['obj_list'])
        model = EfficientDet(num_classes=num_classes, compound_coef=0)
        
        # Load trained weights
        checkpoint = torch.load(model_path, map_location='cpu')
        if 'model' in checkpoint:
            model.load_state_dict(checkpoint['model'])
        else:
            model.load_state_dict(checkpoint)
        
        model.eval()
        
        # Create wrapper model that outputs boxes, labels, scores
        class EfficientDetONNX(torch.nn.Module):
            def __init__(self, model, input_size, num_classes):
                super().__init__()
                self.model = model
                self.input_size = input_size
                self.num_classes = num_classes
                
                # Initialize postprocessing components
                self.regressBoxes = BBoxTransform()
                self.clipBoxes = ClipBoxes()
                
                # Anchor parameters for EfficientDet-D0
                self.anchor_scale = 4.0
                self.aspect_ratios = [(1.0, 1.0), (3.0, 1.0), (1.0, 3.0), (8.0, 1.0), (1.0, 8.0)]
                self.num_scales = 3
                
            def forward(self, x):
                # Get raw model outputs
                classification, regression = self.model(x)
                
                # Apply postprocessing to get final detections
                # This is a simplified version - in practice you'd need full anchor generation
                batch_size = x.shape[0]
                
                # For ONNX compatibility, we'll output the raw predictions
                # and let the inference code handle postprocessing
                
                # Reshape outputs to match expected format
                # classification: [batch, num_anchors, num_classes]
                # regression: [batch, num_anchors, 4]
                
                cls_shape = classification.shape
                reg_shape = regression.shape
                
                # Flatten spatial dimensions
                classification = classification.view(batch_size, -1, self.num_classes)
                regression = regression.view(batch_size, -1, 4)
                
                # Apply sigmoid to classification scores
                scores = torch.sigmoid(classification)
                
                # For compatibility, we need to output:
                # boxes: [batch, num_detections, 4] 
                # labels: [batch, num_detections]
                # scores: [batch, num_detections]
                
                # Since we can't do NMS in ONNX easily, output raw predictions
                # The inference code will need to handle postprocessing
                
                # Get max scores and labels for each anchor
                max_scores, labels = torch.max(scores, dim=2)
                
                # Return top-k detections (simplified)
                k = min(1000, classification.shape[1])  # Max 1000 detections
                
                topk_scores, topk_indices = torch.topk(max_scores, k, dim=1)
                
                # Gather corresponding boxes and labels
                batch_indices = torch.arange(batch_size).unsqueeze(1).expand(-1, k)
                topk_boxes = regression[batch_indices, topk_indices]
                topk_labels = labels[batch_indices, topk_indices]
                
                return topk_boxes, topk_labels, topk_scores
        
        # Create wrapper model
        onnx_model = EfficientDetONNX(model, input_size, num_classes)
        onnx_model.eval()
        
        # Create dummy input
        dummy_input = torch.randn(1, 3, input_size, input_size)
        
        print("Exporting to ONNX with compatible output names...")
        
        # Export to ONNX with compatible names and dynamic axes
        torch.onnx.export(
            onnx_model,
            dummy_input,
            output_path,
            export_params=True,
            opset_version=11,
            do_constant_folding=True,
            input_names=['input'],
            output_names=['boxes', 'labels', 'scores'],
            dynamic_axes={
                'input': {0: 'batch_size'},
                'boxes': {0: 'num_boxes'},
                'labels': {0: 'num_labels'}, 
                'scores': {0: 'num_scores'}
            }
        )
        
        print(f"ONNX export completed: {output_path}")
        
        # Verify the exported model
        try:
            onnx_model_check = onnx.load(output_path)
            onnx.checker.check_model(onnx_model_check)
            print("✅ ONNX model validation passed")
            
            # Print model info
            print(f"Model inputs: {[input.name for input in onnx_model_check.graph.input]}")
            print(f"Model outputs: {[output.name for output in onnx_model_check.graph.output]}")
            
        except Exception as e:
            print(f"⚠️ ONNX model validation warning: {e}")
        
        # Optimize ONNX model
        try:
            from onnxsim import simplify
            
            print("Optimizing ONNX model...")
            model_onnx = onnx.load(output_path)
            model_simp, check = simplify(model_onnx)
            
            if check:
                optimized_path = output_path.replace('.onnx', '_optimized.onnx')
                onnx.save(model_simp, optimized_path)
                print(f"ONNX optimization completed: {optimized_path}")
                return optimized_path
            else:
                print("ONNX optimization failed, using original model")
                return output_path
                
        except ImportError:
            print("onnx-simplifier not available, skipping optimization")
            return output_path
            
    except Exception as e:
        print(f"Error during export: {e}")
        import traceback
        traceback.print_exc()
        return None

def main():
    parser = argparse.ArgumentParser(description='Export EfficientDet to Compatible ONNX')
    parser.add_argument('--model', required=True, help='Path to trained PyTorch model (.pth)')
    parser.add_argument('--config', required=True, help='Path to config YAML file')
    parser.add_argument('--output', required=True, help='Output ONNX file path')
    parser.add_argument('--input_size', type=int, required=True, help='Input image size (e.g., 1024, 2048)')
    parser.add_argument('--model_type', default='EV', choices=['EV', 'SV'], help='Model type (EV or SV)')
    
    args = parser.parse_args()
    
    # Validate inputs
    if not os.path.exists(args.model):
        print(f"Error: Model file {args.model} not found!")
        return
    
    if not os.path.exists(args.config):
        print(f"Error: Config file {args.config} not found!")
        return
    
    # Create output directory if needed
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    
    # Export model
    result = export_to_onnx_compatible(args.model, args.config, args.output, args.input_size, args.model_type)
    
    if result:
        print(f"✅ Export completed successfully: {result}")
        print("\n📋 Usage in your inference code:")
        print("The exported ONNX model outputs:")
        print("- boxes: [batch_size, num_detections, 4] - bounding boxes")
        print("- labels: [batch_size, num_detections] - class labels") 
        print("- scores: [batch_size, num_detections] - confidence scores")
        print("\nNote: You may need to apply additional postprocessing (NMS, coordinate conversion)")
    else:
        print("❌ Export failed!")

if __name__ == "__main__":
    main()

