#!/usr/bin/env python3
"""
SV Dataset Preparation Script for EfficientDet Training
Merges train/val sets, performs 80/20 split, and converts YOLO to COCO format
"""

import os
import json
import shutil
import random
from pathlib import Path
import cv2
from typing import List, Dict, Tuple

# Configuration
RANDOM_SEED = 42
TRAIN_SPLIT = 0.8
SV_IMAGE_WIDTH = 1024
SV_IMAGE_HEIGHT = 500

def setup_directories(base_path: str) -> Dict[str, str]:
    """Create necessary directories for the dataset"""
    paths = {
        'base': base_path,
        'train_images': os.path.join(base_path, 'train', 'images'),
        'val_images': os.path.join(base_path, 'val', 'images'),
        'annotations': os.path.join(base_path, 'annotations')
    }
    
    for path in paths.values():
        os.makedirs(path, exist_ok=True)
    
    return paths

def collect_dataset_files(sv_dataset_path: str) -> List[Tuple[str, str]]:
    """
    Collect all image and label files from SV train and val sets
    Returns list of (image_path, label_path) tuples
    """
    files = []
    
    # Process train and val directories
    for subset in ['train', 'val']:
        images_dir = os.path.join(sv_dataset_path, subset, 'images')
        labels_dir = os.path.join(sv_dataset_path, subset, 'labels')
        
        if not os.path.exists(images_dir):
            print(f"Warning: {images_dir} not found, skipping...")
            continue
            
        if not os.path.exists(labels_dir):
            print(f"Warning: {labels_dir} not found, skipping...")
            continue
        
        # Get all image files
        for img_file in os.listdir(images_dir):
            if img_file.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
                img_path = os.path.join(images_dir, img_file)
                
                # Find corresponding label file
                label_name = os.path.splitext(img_file)[0] + '.txt'
                label_path = os.path.join(labels_dir, label_name)
                
                # Add even if label doesn't exist (negative samples)
                files.append((img_path, label_path if os.path.exists(label_path) else None))
    
    return files

def split_dataset(files: List[Tuple[str, str]], train_ratio: float = 0.8) -> Tuple[List, List]:
    """Split files into train and validation sets"""
    random.seed(RANDOM_SEED)
    random.shuffle(files)
    
    split_idx = int(len(files) * train_ratio)
    train_files = files[:split_idx]
    val_files = files[split_idx:]
    
    return train_files, val_files

def yolo_to_coco_bbox(yolo_bbox: List[float], img_width: int, img_height: int) -> List[float]:
    """
    Convert YOLO format (x_center, y_center, width, height) normalized to 
    COCO format (x_min, y_min, width, height) in pixels
    """
    x_center, y_center, width, height = yolo_bbox
    
    # Convert to pixel coordinates
    x_center_px = x_center * img_width
    y_center_px = y_center * img_height
    width_px = width * img_width
    height_px = height * img_height
    
    # Convert to COCO format (top-left corner)
    x_min = x_center_px - (width_px / 2)
    y_min = y_center_px - (height_px / 2)
    
    # Ensure coordinates are within image bounds
    x_min = max(0, min(x_min, img_width))
    y_min = max(0, min(y_min, img_height))
    width_px = min(width_px, img_width - x_min)
    height_px = min(height_px, img_height - y_min)
    
    return [x_min, y_min, width_px, height_px]

def process_label_file(label_path: str, img_width: int, img_height: int) -> List[Dict]:
    """
    Process a YOLO label file and return list of annotations
    Returns empty list for blank files (negative samples)
    """
    annotations = []
    
    if not label_path or not os.path.exists(label_path):
        return annotations
    
    try:
        with open(label_path, 'r') as f:
            lines = f.readlines()
        
        for line in lines:
            line = line.strip()
            if not line:  # Skip empty lines
                continue
                
            parts = line.split()
            if len(parts) != 5:
                print(f"Warning: Invalid line in {label_path}: {line}")
                continue
            
            class_id = int(parts[0])
            yolo_bbox = [float(x) for x in parts[1:5]]
            
            # Convert YOLO to COCO format
            coco_bbox = yolo_to_coco_bbox(yolo_bbox, img_width, img_height)
            
            # Map YOLO class IDs to COCO category IDs
            # YOLO: chip=0, check=1 -> COCO: chip=1, check=2
            category_id = class_id + 1
            
            annotations.append({
                'bbox': coco_bbox,
                'category_id': category_id
            })
    
    except Exception as e:
        print(f"Error processing {label_path}: {e}")
    
    return annotations

def create_coco_json(files: List[Tuple[str, str]], output_dir: str, split_name: str) -> str:
    """Create COCO format JSON file"""
    
    coco_data = {
        "images": [],
        "annotations": [],
        "categories": [
            {"id": 1, "name": "chip"},
            {"id": 2, "name": "check"}
        ]
    }
    
    image_id = 1
    annotation_id = 1
    
    for img_path, label_path in files:
        # Copy image to destination
        img_filename = f"SV_{image_id:06d}{os.path.splitext(img_path)[1]}"
        dest_img_path = os.path.join(output_dir, split_name, 'images', img_filename)
        shutil.copy2(img_path, dest_img_path)
        
        # Get image dimensions (assuming all SV images are same size)
        img_width, img_height = SV_IMAGE_WIDTH, SV_IMAGE_HEIGHT
        
        # Add image entry
        coco_data["images"].append({
            "id": image_id,
            "file_name": img_filename,
            "width": img_width,
            "height": img_height
        })
        
        # Process annotations
        annotations = process_label_file(label_path, img_width, img_height)
        
        for ann in annotations:
            coco_data["annotations"].append({
                "id": annotation_id,
                "image_id": image_id,
                "category_id": ann['category_id'],
                "bbox": ann['bbox'],
                "area": ann['bbox'][2] * ann['bbox'][3],  # width * height
                "iscrowd": 0
            })
            annotation_id += 1
        
        image_id += 1
    
    # Save JSON file
    json_path = os.path.join(output_dir, 'annotations', f'instances_{split_name}.json')
    with open(json_path, 'w') as f:
        json.dump(coco_data, f, indent=2)
    
    return json_path

def main():
    """Main function to prepare SV dataset"""
    
    # Paths - adjust these according to your setup
    sv_dataset_path = input("Enter path to SV_dataset folder: ").strip()
    if not os.path.exists(sv_dataset_path):
        print(f"Error: SV dataset path {sv_dataset_path} does not exist!")
        return
    
    output_path = "/home/ubuntu/EfficientDet_Training_Pipeline/SV_Defect_Detection"
    
    print("Setting up directories...")
    paths = setup_directories(output_path)
    
    print("Collecting dataset files...")
    all_files = collect_dataset_files(sv_dataset_path)
    print(f"Found {len(all_files)} total files")
    
    if len(all_files) == 0:
        print("Error: No files found in the dataset!")
        return
    
    print("Splitting dataset...")
    train_files, val_files = split_dataset(all_files, TRAIN_SPLIT)
    print(f"Train: {len(train_files)} files, Val: {len(val_files)} files")
    
    print("Creating training set COCO JSON...")
    train_json = create_coco_json(train_files, output_path, 'train')
    print(f"Training JSON saved to: {train_json}")
    
    print("Creating validation set COCO JSON...")
    val_json = create_coco_json(val_files, output_path, 'val')
    print(f"Validation JSON saved to: {val_json}")
    
    print("\nSV Dataset preparation complete!")
    print(f"Dataset location: {output_path}")
    print(f"Training images: {len(train_files)}")
    print(f"Validation images: {len(val_files)}")

if __name__ == "__main__":
    main()

