#!/usr/bin/env python3
"""
Pipeline Testing Script
Validates the complete EfficientDet training pipeline setup
"""

import os
import sys
import yaml
import json
from pathlib import Path

def test_directory_structure():
    """Test if all required directories exist"""
    print("Testing directory structure...")
    
    required_dirs = [
        "EV_Defect_Detection/train/images",
        "EV_Defect_Detection/val/images", 
        "EV_Defect_Detection/annotations",
        "SV_Defect_Detection/train/images",
        "SV_Defect_Detection/val/images",
        "SV_Defect_Detection/annotations",
        "efficientdet_repo",
        "configs",
        "scripts",
        "logs/ev_training",
        "logs/sv_training",
        "weights/ev_model",
        "weights/sv_model"
    ]
    
    missing_dirs = []
    for dir_path in required_dirs:
        if not os.path.exists(dir_path):
            missing_dirs.append(dir_path)
    
    if missing_dirs:
        print(f"❌ Missing directories: {missing_dirs}")
        return False
    else:
        print("✅ All required directories exist")
        return True

def test_config_files():
    """Test if configuration files are valid"""
    print("\nTesting configuration files...")
    
    config_files = [
        "configs/ev_photomask.yml",
        "configs/sv_photomask.yml"
    ]
    
    for config_file in config_files:
        if not os.path.exists(config_file):
            print(f"❌ Missing config file: {config_file}")
            return False
        
        try:
            with open(config_file, 'r') as f:
                config = yaml.safe_load(f)
            
            # Check required fields
            required_fields = ['project_name', 'obj_list', 'data_path']
            for field in required_fields:
                if field not in config:
                    print(f"❌ Missing field '{field}' in {config_file}")
                    return False
            
            print(f"✅ {config_file} is valid")
            
        except Exception as e:
            print(f"❌ Error reading {config_file}: {e}")
            return False
    
    return True

def test_scripts():
    """Test if all scripts exist and are executable"""
    print("\nTesting scripts...")
    
    scripts = [
        "scripts/setup_env.bat",
        "scripts/prepare_ev_dataset.py",
        "scripts/prepare_sv_dataset.py", 
        "scripts/train_ev_model.bat",
        "scripts/train_sv_model.bat",
        "scripts/export_to_onnx.py"
    ]
    
    for script in scripts:
        if not os.path.exists(script):
            print(f"❌ Missing script: {script}")
            return False
        
        # Check if Python scripts are executable
        if script.endswith('.py'):
            if not os.access(script, os.X_OK):
                print(f"⚠️  {script} is not executable (run: chmod +x {script})")
        
        print(f"✅ {script} exists")
    
    return True

def test_efficientdet_repo():
    """Test if EfficientDet repository is properly cloned"""
    print("\nTesting EfficientDet repository...")
    
    repo_path = "efficientdet_repo"
    required_files = [
        "train.py",
        "coco_eval.py",
        "efficientdet/model.py",
        "backbone.py"
    ]
    
    for file_path in required_files:
        full_path = os.path.join(repo_path, file_path)
        if not os.path.exists(full_path):
            print(f"❌ Missing file: {full_path}")
            return False
    
    print("✅ EfficientDet repository is properly set up")
    return True

def test_python_imports():
    """Test if required Python packages can be imported"""
    print("\nTesting Python package imports...")
    
    required_packages = [
        'torch',
        'torchvision', 
        'cv2',
        'yaml',
        'json',
        'numpy'
    ]
    
    optional_packages = [
        'pycocotools',
        'onnx',
        'onnxsim'
    ]
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package} imported successfully")
        except ImportError:
            print(f"❌ Failed to import {package}")
            return False
    
    for package in optional_packages:
        try:
            __import__(package)
            print(f"✅ {package} imported successfully")
        except ImportError:
            print(f"⚠️  {package} not available (install with: pip install {package})")
    
    return True

def test_gpu_availability():
    """Test GPU availability for training"""
    print("\nTesting GPU availability...")
    
    try:
        import torch
        
        if torch.cuda.is_available():
            gpu_count = torch.cuda.device_count()
            gpu_name = torch.cuda.get_device_name(0)
            memory = torch.cuda.get_device_properties(0).total_memory / 1024**3
            
            print(f"✅ GPU available: {gpu_name}")
            print(f"✅ GPU memory: {memory:.1f} GB")
            print(f"✅ CUDA version: {torch.version.cuda}")
            
            if memory < 10:
                print("⚠️  GPU memory < 10GB, consider reducing batch size")
            
            return True
        else:
            print("⚠️  No GPU available, training will be very slow on CPU")
            return False
            
    except Exception as e:
        print(f"❌ Error checking GPU: {e}")
        return False

def generate_test_summary():
    """Generate a summary of the pipeline setup"""
    print("\n" + "="*50)
    print("PIPELINE SETUP SUMMARY")
    print("="*50)
    
    print("\n📁 Directory Structure:")
    print("   ├── EV_Defect_Detection/")
    print("   │   ├── train/images/")
    print("   │   ├── val/images/")
    print("   │   └── annotations/")
    print("   ├── SV_Defect_Detection/")
    print("   │   ├── train/images/")
    print("   │   ├── val/images/")
    print("   │   └── annotations/")
    print("   ├── efficientdet_repo/")
    print("   ├── configs/")
    print("   ├── scripts/")
    print("   ├── logs/")
    print("   └── weights/")
    
    print("\n🔧 Configuration Files:")
    print("   ├── configs/ev_photomask.yml (EV model config)")
    print("   └── configs/sv_photomask.yml (SV model config)")
    
    print("\n📜 Scripts:")
    print("   ├── scripts/setup_env.bat (Environment setup)")
    print("   ├── scripts/prepare_ev_dataset.py (EV data prep)")
    print("   ├── scripts/prepare_sv_dataset.py (SV data prep)")
    print("   ├── scripts/train_ev_model.bat (EV training)")
    print("   ├── scripts/train_sv_model.bat (SV training)")
    print("   └── scripts/export_to_onnx.py (ONNX export)")
    
    print("\n🚀 Next Steps:")
    print("   1. Run setup_env.bat to install dependencies")
    print("   2. Run prepare_ev_dataset.py with your EV_dataset path")
    print("   3. Run prepare_sv_dataset.py with your SV_dataset path")
    print("   4. Run train_ev_model.bat to train EV model")
    print("   5. Run train_sv_model.bat to train SV model")
    print("   6. Find ONNX models in weights/ folders")

def main():
    """Main testing function"""
    print("EfficientDet Training Pipeline Test")
    print("="*40)
    
    tests = [
        test_directory_structure,
        test_config_files,
        test_scripts,
        test_efficientdet_repo,
        test_python_imports,
        test_gpu_availability
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
        print()
    
    print("="*40)
    print(f"Tests passed: {passed}/{total}")
    
    if passed == total:
        print("🎉 All tests passed! Pipeline is ready.")
        generate_test_summary()
    else:
        print("❌ Some tests failed. Please fix the issues above.")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

