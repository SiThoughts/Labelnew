#!/usr/bin/env python3
"""
Standalone ONNX Export Script for EfficientDet Models
Converts trained PyTorch models to optimized ONNX format
"""

import torch
import onnx
import yaml
import argparse
import os
import sys
from pathlib import Path

def export_to_onnx(model_path, config_path, output_path, input_size):
    """Export EfficientDet model to ONNX format"""
    
    # Add efficientdet repo to path
    repo_path = Path(__file__).parent.parent / "efficientdet_repo"
    sys.path.insert(0, str(repo_path))
    
    try:
        from efficientdet.model import EfficientDet
        
        # Load config
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        
        print(f"Loading model from: {model_path}")
        print(f"Config: {config_path}")
        print(f"Input size: {input_size}x{input_size}")
        
        # Create model
        num_classes = len(config['obj_list'])
        model = EfficientDet(num_classes=num_classes, compound_coef=0)
        
        # Load trained weights
        checkpoint = torch.load(model_path, map_location='cpu')
        if 'model' in checkpoint:
            model.load_state_dict(checkpoint['model'])
        else:
            model.load_state_dict(checkpoint)
        
        model.eval()
        
        # Create dummy input
        dummy_input = torch.randn(1, 3, input_size, input_size)
        
        print("Exporting to ONNX...")
        
        # Export to ONNX
        torch.onnx.export(
            model,
            dummy_input,
            output_path,
            export_params=True,
            opset_version=11,
            do_constant_folding=True,
            input_names=['input'],
            output_names=['classification', 'regression'],
            dynamic_axes={
                'input': {0: 'batch_size'},
                'classification': {0: 'batch_size'},
                'regression': {0: 'batch_size'}
            }
        )
        
        print(f"ONNX export completed: {output_path}")
        
        # Optimize ONNX model
        try:
            from onnxsim import simplify
            
            print("Optimizing ONNX model...")
            model_onnx = onnx.load(output_path)
            model_simp, check = simplify(model_onnx)
            
            if check:
                optimized_path = output_path.replace('.onnx', '_optimized.onnx')
                onnx.save(model_simp, optimized_path)
                print(f"ONNX optimization completed: {optimized_path}")
            else:
                print("ONNX optimization failed, using original model")
                
        except ImportError:
            print("onnx-simplifier not available, skipping optimization")
            
    except Exception as e:
        print(f"Error during export: {e}")
        return False
    
    return True

def main():
    parser = argparse.ArgumentParser(description='Export EfficientDet to ONNX')
    parser.add_argument('--model', required=True, help='Path to trained PyTorch model (.pth)')
    parser.add_argument('--config', required=True, help='Path to config YAML file')
    parser.add_argument('--output', required=True, help='Output ONNX file path')
    parser.add_argument('--input_size', type=int, required=True, help='Input image size (e.g., 1024, 2048)')
    
    args = parser.parse_args()
    
    # Validate inputs
    if not os.path.exists(args.model):
        print(f"Error: Model file {args.model} not found!")
        return
    
    if not os.path.exists(args.config):
        print(f"Error: Config file {args.config} not found!")
        return
    
    # Create output directory if needed
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    
    # Export model
    success = export_to_onnx(args.model, args.config, args.output, args.input_size)
    
    if success:
        print("Export completed successfully!")
    else:
        print("Export failed!")

if __name__ == "__main__":
    main()

