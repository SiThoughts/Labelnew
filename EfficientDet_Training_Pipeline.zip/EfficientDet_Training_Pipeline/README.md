# EfficientDet-D0 Training Pipeline for Chip & Check Defect Detection

This repository contains a complete training pipeline for two separate EfficientDet-D0 models:
- **EV Model**: For EV images (2048x1460 resolution)
- **SV Model**: For SV images (1024x500 resolution)

Both models detect two classes: `chip` (class 0) and `check` (class 1) defects.

## 🏗️ Project Structure

```
EfficientDet_Training_Pipeline/
├── EV_Defect_Detection/          # EV dataset (prepared)
│   ├── train/images/
│   ├── val/images/
│   └── annotations/
│       ├── instances_train.json
│       └── instances_val.json
├── SV_Defect_Detection/          # SV dataset (prepared)
│   ├── train/images/
│   ├── val/images/
│   └── annotations/
│       ├── instances_train.json
│       └── instances_val.json
├── efficientdet_repo/            # Yet-Another-EfficientDet-Pytorch
├── configs/
│   ├── ev_photomask.yml          # EV model configuration
│   └── sv_photomask.yml          # SV model configuration
├── scripts/
│   ├── setup_env.bat             # Environment setup
│   ├── prepare_ev_dataset.py     # EV dataset preparation
│   ├── prepare_sv_dataset.py     # SV dataset preparation
│   ├── train_ev_model.bat        # EV model training
│   ├── train_sv_model.bat        # SV model training
│   ├── export_to_onnx.py         # ONNX export utility
│   └── test_pipeline.py          # Pipeline testing
├── logs/                         # Training logs
│   ├── ev_training/
│   └── sv_training/
├── weights/                      # Model weights
│   ├── ev_model/
│   └── sv_model/
└── README.md
```

## 🚀 Quick Start

### 1. Environment Setup

First, run the environment setup script to install all dependencies:

```bash
# On Windows
scripts\setup_env.bat

# On Linux/Mac (if adapting the script)
pip install torch==1.13.1+cu117 torchvision==0.14.1+cu117 torchaudio==0.13.1+cu117 --extra-index-url https://download.pytorch.org/whl/cu117
pip install pycocotools-windows opencv-python numpy pyyaml tqdm tensorboard tensorboardX webcolors onnx onnx-simplifier matplotlib pillow
```

### 2. Dataset Preparation

Prepare your datasets by running the preparation scripts:

```bash
# Prepare EV dataset
python scripts/prepare_ev_dataset.py
# When prompted, enter the path to your EV_dataset folder

# Prepare SV dataset  
python scripts/prepare_sv_dataset.py
# When prompted, enter the path to your SV_dataset folder
```

**Expected Input Structure:**
```
EV_dataset/
├── train/
│   ├── images/
│   └── labels/  # YOLO format .txt files
└── val/
    ├── images/
    └── labels/  # YOLO format .txt files

SV_dataset/
├── train/
│   ├── images/
│   └── labels/  # YOLO format .txt files
└── val/
    ├── images/
    └── labels/  # YOLO format .txt files
```

### 3. Training

Train both models using the provided batch scripts:

```bash
# Train EV model (2048x1460 images)
scripts\train_ev_model.bat

# Train SV model (1024x500 images)  
scripts\train_sv_model.bat
```

### 4. Results

After training, you'll find:
- **PyTorch models**: `weights/ev_model/efficientdet-d0_60_best.pth` and `weights/sv_model/efficientdet-d0_60_best.pth`
- **Compatible ONNX models**: `weights/ev_model/ev_efficientdet_d0_compatible.onnx` and `weights/sv_model/sv_efficientdet_d0_compatible.onnx`
- **Training logs**: `logs/ev_training/` and `logs/sv_training/`

## 🔌 ONNX Compatibility

The exported ONNX models are compatible with your existing inference code that expects:
- **Output names**: `['boxes', 'labels', 'scores']`
- **Dynamic axes**: Compatible with your existing dynamic axis configuration
- **Class mapping**: 1=chip, 2=check (YOLO 0,1 → COCO 1,2)

See `COMPATIBILITY_NOTES.md` for detailed information about model outputs and usage.

## ⚙️ Configuration Details

### Model Architecture
- **Base Model**: EfficientDet-D0
- **Input Resolutions**: 
  - EV: 2048x2048 (padded from 2048x1460)
  - SV: 1024x1024 (padded from 1024x500)
- **Classes**: 2 (chip, check)
- **Anchor Ratios**: `[(1:1), (3:1), (1:3), (8:1), (1:8)]` for elongated defects

### Training Strategy
1. **Phase 1** (10 epochs): Head-only training with frozen backbone
2. **Phase 2** (50 epochs): Full fine-tuning with lower learning rate

### Memory Optimization
- **EV Model**: Batch size 2 (for 11GB GPU)
- **SV Model**: Batch size 4 (smaller input size)
- **Mixed Precision**: Enabled for memory efficiency

## 🔧 Hardware Requirements

- **GPU**: NVIDIA GTX 1080Ti (11GB VRAM) or better
- **CUDA**: 11.7 compatible drivers
- **RAM**: 16GB+ recommended
- **Storage**: 50GB+ free space

## 📊 Dataset Format

### Input (YOLO Format)
```
# Each .txt file contains:
class_id x_center y_center width height
# Example:
0 0.5 0.3 0.1 0.05  # chip at center-left
1 0.8 0.7 0.3 0.02  # elongated check
```

### Output (COCO Format)
The preparation scripts convert YOLO annotations to COCO JSON format with proper handling of:
- Blank label files (negative samples)
- Class mapping: YOLO (0,1) → COCO (1,2)
- Coordinate conversion: normalized → pixel coordinates

## 🎯 Key Features

### Defect-Optimized Anchors
Custom anchor ratios designed for:
- **Chips**: Square-ish defects (1:1 ratio)
- **Checks**: Highly elongated defects (up to 8:1 ratio)

### Class Imbalance Handling
- **Focal Loss**: Built-in handling of chip vs check imbalance
- **Negative Samples**: Proper handling of defect-free images

### Edge Deployment Ready
- **ONNX Export**: Optimized models for edge inference
- **Model Simplification**: Reduced graph complexity
- **Fixed Input Sizes**: Consistent inference dimensions

## 🧪 Testing

Test your pipeline setup:

```bash
python scripts/test_pipeline.py
```

This will verify:
- Directory structure
- Configuration files
- Script availability
- Python dependencies
- GPU availability

## 📝 Troubleshooting

### Common Issues

1. **CUDA Out of Memory**
   - Reduce batch size in config files
   - Use gradient checkpointing
   - Close other GPU applications

2. **Import Errors**
   - Run `setup_env.bat` again
   - Check CUDA version compatibility
   - Install missing packages manually

3. **Dataset Preparation Fails**
   - Verify input dataset structure
   - Check file permissions
   - Ensure sufficient disk space

4. **Training Doesn't Start**
   - Verify dataset preparation completed
   - Check config file paths
   - Ensure GPU is available

### Performance Tips

1. **For Better Accuracy**
   - Increase training epochs
   - Use data augmentation carefully
   - Adjust anchor scales for your defect sizes

2. **For Faster Training**
   - Use mixed precision training
   - Increase batch size if memory allows
   - Use multiple GPUs if available

## 📄 License

This project uses the Yet-Another-EfficientDet-Pytorch repository under its original license. Please refer to the original repository for licensing details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📞 Support

For issues and questions:
1. Check the troubleshooting section
2. Review the test pipeline output
3. Check the original EfficientDet repository documentation
4. Open an issue with detailed error logs

---

**Note**: This pipeline is optimized for chip and check defect detection on photomask images. Adjust configurations as needed for your specific use case.

