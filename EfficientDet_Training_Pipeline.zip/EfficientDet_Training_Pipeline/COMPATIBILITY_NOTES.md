# ONNX Model Compatibility Notes

## Output Format Compatibility

The exported ONNX models are now compatible with your existing inference code that expects:

```python
output_names=['boxes', 'labels', 'scores']
dynamic_axes={
    'boxes': {0: 'num_boxes'},
    'labels': {0: 'num_labels'}, 
    'scores': {0: 'num_scores'}
}
```

## Model Outputs

### EV Model (`ev_efficientdet_d0_compatible.onnx`)
- **Input**: `[batch_size, 3, 2048, 2048]` - RGB images padded to square
- **Outputs**:
  - `boxes`: `[batch_size, num_detections, 4]` - Bounding boxes in format [x1, y1, x2, y2]
  - `labels`: `[batch_size, num_detections]` - Class labels (1=chip, 2=check)
  - `scores`: `[batch_size, num_detections]` - Confidence scores (0.0 to 1.0)

### SV Model (`sv_efficientdet_d0_compatible.onnx`)
- **Input**: `[batch_size, 3, 1024, 1024]` - RGB images padded to square
- **Outputs**:
  - `boxes`: `[batch_size, num_detections, 4]` - Bounding boxes in format [x1, y1, x2, y2]
  - `labels`: `[batch_size, num_detections]` - Class labels (1=chip, 2=check)
  - `scores`: `[batch_size, num_detections]` - Confidence scores (0.0 to 1.0)

## Class Mapping

- **Class 1**: `chip` (YOLO class 0 → COCO class 1)
- **Class 2**: `check` (YOLO class 1 → COCO class 2)

## Image Preprocessing

Your inference code should:

1. **Resize and Pad**: 
   - EV images: Resize from 2048x1460 to 2048x2048 (pad height)
   - SV images: Resize from 1024x500 to 1024x1024 (pad height)

2. **Normalize**: Apply ImageNet normalization
   ```python
   mean = [0.485, 0.456, 0.406]
   std = [0.229, 0.224, 0.225]
   ```

3. **Convert**: RGB format, float32, range [0, 1]

## Postprocessing

The exported models include basic postprocessing but you may need to apply:

1. **Confidence Filtering**: Filter detections below your confidence threshold
2. **NMS (Non-Maximum Suppression)**: Remove duplicate detections
3. **Coordinate Conversion**: Convert from padded coordinates back to original image coordinates

## Example Usage

```python
import onnxruntime as ort
import numpy as np

# Load model
session = ort.InferenceSession("ev_efficientdet_d0_compatible.onnx")

# Prepare input (example for EV model)
input_image = np.random.randn(1, 3, 2048, 2048).astype(np.float32)

# Run inference
outputs = session.run(['boxes', 'labels', 'scores'], {'input': input_image})
boxes, labels, scores = outputs

# Filter by confidence
confidence_threshold = 0.5
valid_detections = scores[0] > confidence_threshold
filtered_boxes = boxes[0][valid_detections]
filtered_labels = labels[0][valid_detections]
filtered_scores = scores[0][valid_detections]
```

## Performance Notes

- **EV Model**: Higher resolution (2048px) for detecting very small defects
- **SV Model**: Lower resolution (1024px) for faster inference
- Both models use optimized anchor ratios for elongated "check" defects
- Models are optimized for edge deployment with ONNX simplification

## Troubleshooting

1. **Shape Mismatch**: Ensure input images are properly resized and padded
2. **Class Labels**: Remember class mapping (1=chip, 2=check, not 0-indexed)
3. **Coordinate System**: Boxes are in absolute pixel coordinates relative to padded image
4. **Memory Usage**: EV model requires more memory due to higher resolution

