"""
Hybrid Anomaly Detection and Segmentation Model
Combines anomaly detection, segmentation, and classification for high-recall defect detection
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models
from typing import Dict, List, Tuple, Optional


class FeatureExtractor(nn.Module):
    """
    Feature extraction backbone using pre-trained ResNet or EfficientNet
    """
    
    def __init__(self, backbone_name: str = "resnet34", feature_layers: List[int] = [2, 3, 4]):
        super().__init__()
        
        self.backbone_name = backbone_name
        self.feature_layers = feature_layers
        
        # Load pre-trained backbone
        if "resnet" in backbone_name:
            if backbone_name == "resnet34":
                backbone = models.resnet34(pretrained=True)
            elif backbone_name == "resnet50":
                backbone = models.resnet50(pretrained=True)
            else:
                raise ValueError(f"Unsupported backbone: {backbone_name}")
            
            # Extract layer modules
            self.layer0 = nn.Sequential(
                backbone.conv1,
                backbone.bn1,
                backbone.relu,
                backbone.maxpool
            )
            self.layer1 = backbone.layer1
            self.layer2 = backbone.layer2
            self.layer3 = backbone.layer3
            self.layer4 = backbone.layer4
            
            # Feature dimensions for ResNet34/50
            if backbone_name == "resnet34":
                self.feature_dims = [64, 128, 256, 512]
            else:  # resnet50
                self.feature_dims = [256, 512, 1024, 2048]
        
        elif "efficientnet" in backbone_name:
            if backbone_name == "efficientnet_b0":
                backbone = models.efficientnet_b0(pretrained=True)
            elif backbone_name == "efficientnet_b1":
                backbone = models.efficientnet_b1(pretrained=True)
            else:
                raise ValueError(f"Unsupported backbone: {backbone_name}")
            
            # EfficientNet has a different structure
            self.backbone = backbone.features
            self.feature_dims = [24, 40, 112, 320]  # For EfficientNet-B0
        
        else:
            raise ValueError(f"Unsupported backbone: {backbone_name}")
    
    def forward(self, x: torch.Tensor) -> Dict[int, torch.Tensor]:
        """
        Extract multi-scale features from input image
        
        Args:
            x: Input tensor of shape (B, 3, H, W)
        
        Returns:
            Dictionary mapping layer index to feature tensor
        """
        features = {}
        
        if "resnet" in self.backbone_name:
            x = self.layer0(x)  # 1/4 resolution
            
            x = self.layer1(x)  # Layer 1
            if 1 in self.feature_layers:
                features[1] = x
            
            x = self.layer2(x)  # Layer 2
            if 2 in self.feature_layers:
                features[2] = x
            
            x = self.layer3(x)  # Layer 3
            if 3 in self.feature_layers:
                features[3] = x
            
            x = self.layer4(x)  # Layer 4
            if 4 in self.feature_layers:
                features[4] = x
        
        else:  # efficientnet
            # EfficientNet feature extraction
            for idx, layer in enumerate(self.backbone):
                x = layer(x)
                if idx in self.feature_layers:
                    features[idx] = x
        
        return features


class AnomalyDetectionHead(nn.Module):
    """
    Anomaly detection head that generates an anomaly score map
    Inspired by SimpleNet architecture
    """
    
    def __init__(self, in_channels: int, hidden_channels: int = 256):
        super().__init__()
        
        # Feature adapter
        self.adapter = nn.Sequential(
            nn.Conv2d(in_channels, hidden_channels, kernel_size=1),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_channels, hidden_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True)
        )
        
        # Anomaly discriminator
        self.discriminator = nn.Sequential(
            nn.Conv2d(hidden_channels, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 1, kernel_size=1),
            nn.Sigmoid()
        )
    
    def forward(self, features: torch.Tensor) -> torch.Tensor:
        """
        Generate anomaly score map
        
        Args:
            features: Feature tensor of shape (B, C, H, W)
        
        Returns:
            Anomaly map of shape (B, 1, H, W) with values in [0, 1]
        """
        x = self.adapter(features)
        anomaly_map = self.discriminator(x)
        return anomaly_map


class SegmentationHead(nn.Module):
    """
    Segmentation head with U-Net style decoder
    Generates pixel-wise class predictions
    """
    
    def __init__(
        self,
        feature_dims: List[int],
        num_classes: int,
        base_channels: int = 128
    ):
        super().__init__()
        
        self.num_classes = num_classes
        
        # Decoder blocks (upsampling path)
        self.decoder_blocks = nn.ModuleList()
        
        # Start from the deepest features
        in_channels = feature_dims[-1]
        
        for i in range(len(feature_dims) - 1):
            out_channels = base_channels * (2 ** (len(feature_dims) - 2 - i))
            skip_channels = feature_dims[-(i + 2)]
            
            self.decoder_blocks.append(
                DecoderBlock(in_channels, skip_channels, out_channels)
            )
            in_channels = out_channels
        
        # Final upsampling and classification
        self.final_upsample = nn.Sequential(
            nn.ConvTranspose2d(in_channels, base_channels, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(base_channels),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(base_channels, base_channels, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(base_channels),
            nn.ReLU(inplace=True)
        )
        
        # Classification head (num_classes + 1 for background)
        self.classifier = nn.Conv2d(base_channels, num_classes + 1, kernel_size=1)
    
    def forward(self, features: Dict[int, torch.Tensor]) -> torch.Tensor:
        """
        Generate segmentation mask
        
        Args:
            features: Dictionary of multi-scale features
        
        Returns:
            Segmentation logits of shape (B, num_classes+1, H, W)
        """
        # Get features in reverse order (deepest to shallowest)
        feature_list = [features[k] for k in sorted(features.keys(), reverse=True)]
        
        x = feature_list[0]
        
        # Decoder path with skip connections
        for i, decoder_block in enumerate(self.decoder_blocks):
            skip = feature_list[i + 1]
            x = decoder_block(x, skip)
        
        # Final upsampling
        x = self.final_upsample(x)
        
        # Classification
        seg_logits = self.classifier(x)
        
        return seg_logits


class DecoderBlock(nn.Module):
    """
    Decoder block with skip connection for U-Net style architecture
    """
    
    def __init__(self, in_channels: int, skip_channels: int, out_channels: int):
        super().__init__()
        
        self.upsample = nn.ConvTranspose2d(
            in_channels, out_channels, kernel_size=4, stride=2, padding=1
        )
        
        self.conv = nn.Sequential(
            nn.Conv2d(out_channels + skip_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
    
    def forward(self, x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Input from previous layer
            skip: Skip connection from encoder
        """
        x = self.upsample(x)
        
        # Match spatial dimensions if needed
        if x.shape[2:] != skip.shape[2:]:
            x = F.interpolate(x, size=skip.shape[2:], mode='bilinear', align_corners=False)
        
        x = torch.cat([x, skip], dim=1)
        x = self.conv(x)
        
        return x


class ClassificationHead(nn.Module):
    """
    Classification head for defect type classification
    Takes ROI features and outputs class probabilities
    """
    
    def __init__(self, in_channels: int, num_classes: int, roi_size: int = 7):
        super().__init__()
        
        self.roi_size = roi_size
        self.num_classes = num_classes
        
        # Feature pooling and classification
        self.fc = nn.Sequential(
            nn.Linear(in_channels * roi_size * roi_size, 512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(512, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(256, num_classes)
        )
    
    def forward(self, roi_features: torch.Tensor) -> torch.Tensor:
        """
        Classify ROI features
        
        Args:
            roi_features: Tensor of shape (N, C, roi_size, roi_size)
        
        Returns:
            Class logits of shape (N, num_classes)
        """
        x = roi_features.flatten(1)
        logits = self.fc(x)
        return logits


class HybridDefectDetectionModel(nn.Module):
    """
    Complete hybrid model combining anomaly detection, segmentation, and classification
    """
    
    def __init__(self, config: Dict):
        super().__init__()
        
        self.config = config
        model_config = config['model']
        
        # Feature extractor backbone
        self.backbone = FeatureExtractor(
            backbone_name=model_config['backbone'],
            feature_layers=model_config['feature_layers']
        )
        
        # Get feature dimensions
        feature_dims = [
            self.backbone.feature_dims[i - 1]
            for i in model_config['feature_layers']
        ]
        
        # Anomaly detection head
        self.anomaly_head = AnomalyDetectionHead(
            in_channels=feature_dims[-1],
            hidden_channels=256
        )
        
        # Segmentation head
        self.segmentation_head = SegmentationHead(
            feature_dims=feature_dims,
            num_classes=len(config['dataset']['classes']),
            base_channels=model_config['segmentation']['base_channels']
        )
        
        # Classification head
        self.classification_head = ClassificationHead(
            in_channels=feature_dims[-1],
            num_classes=len(config['dataset']['classes']),
            roi_size=7
        )
        
        # Store configuration
        self.num_classes = len(config['dataset']['classes'])
        self.input_size = model_config['input_size']
    
    def forward(
        self,
        images: torch.Tensor,
        return_features: bool = False
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass through the model
        
        Args:
            images: Input images of shape (B, 3, H, W)
            return_features: Whether to return intermediate features
        
        Returns:
            Dictionary containing:
                - anomaly_map: Anomaly score map (B, 1, H, W)
                - seg_logits: Segmentation logits (B, num_classes+1, H, W)
                - features: Multi-scale features (optional)
        """
        # Extract features
        features = self.backbone(images)
        
        # Anomaly detection
        deepest_features = features[max(features.keys())]
        anomaly_map = self.anomaly_head(deepest_features)
        
        # Upsample anomaly map to match input size
        anomaly_map = F.interpolate(
            anomaly_map,
            size=images.shape[2:],
            mode='bilinear',
            align_corners=False
        )
        
        # Segmentation
        seg_logits = self.segmentation_head(features)
        
        # Ensure segmentation output matches input size
        if seg_logits.shape[2:] != images.shape[2:]:
            seg_logits = F.interpolate(
                seg_logits,
                size=images.shape[2:],
                mode='bilinear',
                align_corners=False
            )
        
        output = {
            'anomaly_map': anomaly_map,
            'seg_logits': seg_logits
        }
        
        if return_features:
            output['features'] = features
        
        return output
    
    def extract_roi_features(
        self,
        features: torch.Tensor,
        boxes: List[torch.Tensor]
    ) -> torch.Tensor:
        """
        Extract ROI features for classification
        
        Args:
            features: Feature map from backbone
            boxes: List of bounding boxes for each image in batch
        
        Returns:
            ROI features of shape (total_boxes, C, roi_size, roi_size)
        """
        from torchvision.ops import roi_align
        
        # Prepare boxes for ROI align (need to add batch index)
        roi_boxes = []
        for batch_idx, boxes_per_image in enumerate(boxes):
            if len(boxes_per_image) > 0:
                batch_indices = torch.full(
                    (len(boxes_per_image), 1),
                    batch_idx,
                    dtype=boxes_per_image.dtype,
                    device=boxes_per_image.device
                )
                roi_boxes.append(torch.cat([batch_indices, boxes_per_image], dim=1))
        
        if len(roi_boxes) == 0:
            # No boxes, return empty tensor
            return torch.zeros((0, features.shape[1], 7, 7), device=features.device)
        
        roi_boxes = torch.cat(roi_boxes, dim=0)
        
        # Extract ROI features
        roi_features = roi_align(
            features,
            roi_boxes,
            output_size=(7, 7),
            spatial_scale=features.shape[2] / self.input_size[1],  # Adjust for feature map scale
            aligned=True
        )
        
        return roi_features


def build_model(config: Dict) -> HybridDefectDetectionModel:
    """
    Build the hybrid defect detection model from configuration
    
    Args:
        config: Configuration dictionary
    
    Returns:
        Initialized model
    """
    model = HybridDefectDetectionModel(config)
    return model


if __name__ == "__main__":
    # Test the model
    import yaml
    
    with open('config.yaml', 'r') as f:
        config = yaml.safe_load(f)
    
    model = build_model(config)
    
    # Test forward pass
    batch_size = 2
    dummy_input = torch.randn(batch_size, 3, 1460, 2048)
    
    print("Testing model forward pass...")
    with torch.no_grad():
        output = model(dummy_input)
    
    print(f"Anomaly map shape: {output['anomaly_map'].shape}")
    print(f"Segmentation logits shape: {output['seg_logits'].shape}")
    print("Model test passed!")
