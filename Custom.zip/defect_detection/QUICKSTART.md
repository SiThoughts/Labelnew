# Quick Start Guide - Hybrid Defect Detection

## 🚀 Get Started in 3 Steps

### Step 1: Setup (5 minutes)

1. Extract the `defect_detection` folder to your desired location
2. Open Command Prompt in the `defect_detection` folder
3. Run the setup script:

```batch
setup.bat
```

Wait for the installation to complete. This creates a conda environment called `customml` with all dependencies.

### Step 2: Configure (2 minutes)

1. Open `config.yaml` in a text editor
2. Change the dataset path to your folder:

```yaml
dataset:
  root_path: "D:/your/dataset/path"  # ← Change this line
```

3. Verify your class names match your XML files:

```yaml
dataset:
  classes:
    - "chip"    # ← Must match <name> tags in XML
    - "check"   # ← Must match <name> tags in XML
```

4. (Optional) Adjust batch size if needed:

```yaml
training:
  batch_size: 2  # Use 1 if you get out-of-memory errors
```

5. Save and close `config.yaml`

### Step 3: Train (Automatic)

Double-click `run_training.bat` or run:

```batch
run_training.bat
```

**That's it!** The model will:
- ✅ Load your dataset
- ✅ Train for multiple stages
- ✅ Save checkpoints automatically
- ✅ Resume if interrupted
- ✅ Save the best model

**Training time**: Approximately 4-8 hours depending on your dataset size and GPU.

---

## 📊 Monitor Progress

While training is running, open a new Command Prompt and run:

```batch
conda activate customml
tensorboard --logdir=checkpoints/logs
```

Then open your browser to: http://localhost:6006

You'll see real-time graphs of:
- Training loss
- Validation loss
- Learning rate
- Individual loss components

---

## 🎯 After Training

### Export to ONNX

Once training completes, export the model:

```batch
conda activate customml
python export_onnx.py
```

Your ONNX model will be saved to: `onnx_models/defect_detection_model.onnx`

### Test the ONNX Model

```python
import onnxruntime as ort
import numpy as np

# Load model
session = ort.InferenceSession('onnx_models/defect_detection_model.onnx')

# Prepare your image (must be 2048x1460)
# image_array shape: [1, 3, 1460, 2048], dtype: float32, range: 0-1

# Run inference
boxes, labels, scores = session.run(None, {'input': image_array})

# boxes: [N, 4] - bounding boxes in [x1, y1, x2, y2] format
# labels: [N] - class indices (0=chip, 1=check)
# scores: [N] - confidence scores (0-1)
```

---

## 🔧 Common Issues

### "Conda is not installed"
- Download and install Miniconda: https://docs.conda.io/en/latest/miniconda.html
- Restart Command Prompt after installation

### "CUDA out of memory"
- Open `config.yaml`
- Change `batch_size: 2` to `batch_size: 1`
- Save and restart training

### "No images found"
- Check that `root_path` in `config.yaml` points to the correct folder
- Verify your images are `.png` or change `image_extension` in config
- Make sure XML files exist for each image

### Training interrupted
- Just run `run_training.bat` again
- It will automatically resume from the last checkpoint

---

## 📁 Your Dataset Format

Your dataset folder should look like this:

```
your_dataset/
├── image001.png
├── image001.xml
├── image002.png
├── image002.xml
├── image003.png
├── image003.xml
└── ...
```

Each XML file should contain bounding boxes in Pascal VOC format:

```xml
<annotation>
  <size>
    <width>2048</width>
    <height>1460</height>
  </size>
  <object>
    <name>chip</name>
    <bndbox>
      <xmin>100</xmin>
      <ymin>200</ymin>
      <xmax>300</xmax>
      <ymax>400</ymax>
    </bndbox>
  </object>
</annotation>
```

---

## 🎓 What's Happening During Training?

The model trains in 3 stages:

**Stage 1: Anomaly Detection (20 epochs)**
- Learns what "normal" looks like
- Identifies anything unusual

**Stage 2: Segmentation (40 epochs)**
- Learns precise boundaries of defects
- Separates chips from checks

**Stage 3: Fine-tuning (40 epochs)**
- Optimizes everything together
- Achieves high recall and precision

Total: ~100 epochs, but early stopping may finish sooner if the model converges.

---

## 💡 Tips for Best Results

1. **More data is better**: Aim for at least 100 images of each defect type
2. **Balance your classes**: Try to have similar numbers of chips and checks
3. **Quality annotations**: Make sure bounding boxes are tight and accurate
4. **Monitor validation loss**: If it stops improving, training will stop automatically
5. **Check TensorBoard**: Watch for overfitting (train loss decreasing but val loss increasing)

---

## 🆘 Need Help?

1. Check the full `README.md` for detailed documentation
2. Review the troubleshooting section
3. Check your TensorBoard logs for clues
4. Verify your dataset format matches the example above

---

## ✅ Success Checklist

Before you start:
- [ ] Conda is installed
- [ ] Dataset folder contains images and XML files
- [ ] XML files have correct class names (chip, check)
- [ ] `config.yaml` has correct dataset path
- [ ] You have at least 50GB free disk space
- [ ] GPU drivers are up to date

After training:
- [ ] Training completed without errors
- [ ] `best_checkpoint.pt` exists in `checkpoints/` folder
- [ ] Validation loss is reasonable (< 0.5)
- [ ] ONNX export succeeded
- [ ] ONNX model file exists in `onnx_models/` folder

---

**You're all set! Happy training! 🚀**
