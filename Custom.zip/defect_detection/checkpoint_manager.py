"""
Checkpoint Manager for Robust Training with Crash Recovery
Handles saving and loading of model checkpoints, optimizer state, and training progress
"""

import os
import json
import torch
from pathlib import Path
from typing import Dict, Optional, Tuple
from datetime import datetime


class CheckpointManager:
    """
    Manages checkpoints for training with automatic resume capability
    """
    
    def __init__(self, checkpoint_dir: str, keep_best_n: int = 3):
        """
        Args:
            checkpoint_dir: Directory to save checkpoints
            keep_best_n: Number of best checkpoints to keep
        """
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        self.keep_best_n = keep_best_n
        self.best_checkpoints = []  # List of (metric, path) tuples
        
        # Paths for different checkpoint types
        self.latest_path = self.checkpoint_dir / "latest_checkpoint.pt"
        self.best_path = self.checkpoint_dir / "best_checkpoint.pt"
        self.resume_path = self.checkpoint_dir / "resume_checkpoint.pt"
        self.metadata_path = self.checkpoint_dir / "training_metadata.json"
    
    def save_checkpoint(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        lr_scheduler: Optional[torch.optim.lr_scheduler._LRScheduler],
        epoch: int,
        stage: str,
        stage_epoch: int,
        metrics: Dict[str, float],
        is_best: bool = False
    ) -> None:
        """
        Save a training checkpoint
        
        Args:
            model: The model to save
            optimizer: The optimizer state
            lr_scheduler: Learning rate scheduler (optional)
            epoch: Global epoch number
            stage: Current training stage name
            stage_epoch: Epoch within current stage
            metrics: Dictionary of metrics (loss, accuracy, etc.)
            is_best: Whether this is the best checkpoint so far
        """
        checkpoint = {
            'epoch': epoch,
            'stage': stage,
            'stage_epoch': stage_epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'metrics': metrics,
            'timestamp': datetime.now().isoformat()
        }
        
        if lr_scheduler is not None:
            checkpoint['lr_scheduler_state_dict'] = lr_scheduler.state_dict()
        
        # Always save as latest
        torch.save(checkpoint, self.latest_path)
        
        # Also save as resume checkpoint (for crash recovery)
        torch.save(checkpoint, self.resume_path)
        
        # Save as best if applicable
        if is_best:
            torch.save(checkpoint, self.best_path)
            print(f"✓ Saved best checkpoint with metrics: {metrics}")
        
        # Save metadata
        self._save_metadata(epoch, stage, stage_epoch, metrics)
        
        # Manage best checkpoints
        if is_best and 'val_loss' in metrics:
            self._update_best_checkpoints(metrics['val_loss'], epoch)
    
    def _save_metadata(
        self,
        epoch: int,
        stage: str,
        stage_epoch: int,
        metrics: Dict[str, float]
    ) -> None:
        """Save training metadata to JSON file"""
        metadata = {
            'last_epoch': epoch,
            'last_stage': stage,
            'last_stage_epoch': stage_epoch,
            'last_metrics': metrics,
            'timestamp': datetime.now().isoformat()
        }
        
        with open(self.metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
    
    def _update_best_checkpoints(self, metric: float, epoch: int) -> None:
        """Keep track of best N checkpoints"""
        checkpoint_path = self.checkpoint_dir / f"checkpoint_epoch_{epoch}.pt"
        
        # Copy latest to this specific checkpoint
        if self.latest_path.exists():
            import shutil
            shutil.copy(self.latest_path, checkpoint_path)
        
        self.best_checkpoints.append((metric, checkpoint_path))
        self.best_checkpoints.sort(key=lambda x: x[0])  # Sort by metric (lower is better)
        
        # Remove checkpoints beyond keep_best_n
        while len(self.best_checkpoints) > self.keep_best_n:
            _, path_to_remove = self.best_checkpoints.pop()
            if path_to_remove.exists() and path_to_remove != self.best_path:
                path_to_remove.unlink()
    
    def load_checkpoint(
        self,
        model: torch.nn.Module,
        optimizer: Optional[torch.optim.Optimizer] = None,
        lr_scheduler: Optional[torch.optim.lr_scheduler._LRScheduler] = None,
        checkpoint_type: str = 'resume'
    ) -> Optional[Dict]:
        """
        Load a checkpoint
        
        Args:
            model: Model to load state into
            optimizer: Optimizer to load state into (optional)
            lr_scheduler: LR scheduler to load state into (optional)
            checkpoint_type: Type of checkpoint to load ('resume', 'latest', 'best')
        
        Returns:
            Dictionary with training state or None if no checkpoint exists
        """
        # Select checkpoint path based on type
        if checkpoint_type == 'resume':
            checkpoint_path = self.resume_path
        elif checkpoint_type == 'latest':
            checkpoint_path = self.latest_path
        elif checkpoint_type == 'best':
            checkpoint_path = self.best_path
        else:
            raise ValueError(f"Unknown checkpoint type: {checkpoint_type}")
        
        if not checkpoint_path.exists():
            print(f"No {checkpoint_type} checkpoint found at {checkpoint_path}")
            return None
        
        print(f"Loading {checkpoint_type} checkpoint from {checkpoint_path}")
        
        try:
            checkpoint = torch.load(checkpoint_path, map_location='cpu')
            
            # Load model state
            model.load_state_dict(checkpoint['model_state_dict'])
            
            # Load optimizer state if provided
            if optimizer is not None and 'optimizer_state_dict' in checkpoint:
                optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            
            # Load lr_scheduler state if provided
            if lr_scheduler is not None and 'lr_scheduler_state_dict' in checkpoint:
                lr_scheduler.load_state_dict(checkpoint['lr_scheduler_state_dict'])
            
            print(f"✓ Loaded checkpoint from epoch {checkpoint['epoch']}, stage '{checkpoint['stage']}'")
            print(f"  Metrics: {checkpoint.get('metrics', {})}")
            
            return {
                'epoch': checkpoint['epoch'],
                'stage': checkpoint['stage'],
                'stage_epoch': checkpoint['stage_epoch'],
                'metrics': checkpoint.get('metrics', {})
            }
        
        except Exception as e:
            print(f"ERROR: Failed to load checkpoint: {e}")
            return None
    
    def has_checkpoint(self, checkpoint_type: str = 'resume') -> bool:
        """
        Check if a checkpoint exists
        
        Args:
            checkpoint_type: Type of checkpoint ('resume', 'latest', 'best')
        
        Returns:
            True if checkpoint exists
        """
        if checkpoint_type == 'resume':
            return self.resume_path.exists()
        elif checkpoint_type == 'latest':
            return self.latest_path.exists()
        elif checkpoint_type == 'best':
            return self.best_path.exists()
        else:
            return False
    
    def get_training_state(self) -> Optional[Dict]:
        """
        Get the last training state from metadata
        
        Returns:
            Dictionary with training state or None
        """
        if not self.metadata_path.exists():
            return None
        
        try:
            with open(self.metadata_path, 'r') as f:
                metadata = json.load(f)
            return metadata
        except Exception as e:
            print(f"WARNING: Failed to load metadata: {e}")
            return None
    
    def cleanup_old_checkpoints(self) -> None:
        """Remove all checkpoints except best and latest"""
        for checkpoint_file in self.checkpoint_dir.glob("checkpoint_epoch_*.pt"):
            if checkpoint_file not in [cp[1] for cp in self.best_checkpoints]:
                checkpoint_file.unlink()
        
        print(f"✓ Cleaned up old checkpoints, kept {len(self.best_checkpoints)} best")


def get_resume_info(checkpoint_dir: str) -> Tuple[bool, Optional[Dict]]:
    """
    Check if training can be resumed and get resume information
    
    Args:
        checkpoint_dir: Directory containing checkpoints
    
    Returns:
        Tuple of (can_resume, resume_info)
    """
    manager = CheckpointManager(checkpoint_dir)
    
    if manager.has_checkpoint('resume'):
        state = manager.get_training_state()
        return True, state
    
    return False, None


if __name__ == "__main__":
    # Test the checkpoint manager
    import tempfile
    
    print("Testing CheckpointManager...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        manager = CheckpointManager(tmpdir, keep_best_n=3)
        
        # Create a dummy model
        model = torch.nn.Linear(10, 2)
        optimizer = torch.optim.Adam(model.parameters())
        
        # Save a checkpoint
        manager.save_checkpoint(
            model=model,
            optimizer=optimizer,
            lr_scheduler=None,
            epoch=5,
            stage='training',
            stage_epoch=2,
            metrics={'loss': 0.5, 'val_loss': 0.6},
            is_best=True
        )
        
        # Load checkpoint
        state = manager.load_checkpoint(model, optimizer, checkpoint_type='best')
        
        assert state is not None
        assert state['epoch'] == 5
        assert state['stage'] == 'training'
        
        print("✓ CheckpointManager test passed!")
