"""
Training Script for Hybrid Defect Detection Model
Supports multi-stage training, automatic resume, and memory optimization
"""

import os
import sys
import yaml
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
from pathlib import Path
from typing import Dict, Tuple
import argparse

from model import build_model
from dataset import create_dataloaders
from checkpoint_manager import CheckpointManager, get_resume_info
from onnx_postprocess import ONNXPostProcessor


class FocalLoss(nn.Module):
    """
    Focal Loss for handling class imbalance
    """
    
    def __init__(self, alpha: float = 0.25, gamma: float = 2.0):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
    
    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        Args:
            inputs: Predictions (logits)
            targets: Ground truth labels
        """
        ce_loss = F.cross_entropy(inputs, targets, reduction='none')
        p_t = torch.exp(-ce_loss)
        focal_loss = self.alpha * (1 - p_t) ** self.gamma * ce_loss
        return focal_loss.mean()


class Trainer:
    """
    Main trainer class for the hybrid defect detection model
    """
    
    def __init__(self, config_path: str, resume: bool = True):
        """
        Args:
            config_path: Path to configuration file
            resume: Whether to resume from checkpoint if available
        """
        # Load configuration
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        # Setup device
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        
        if torch.cuda.is_available():
            print(f"GPU: {torch.cuda.get_device_name(0)}")
            print(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")
        
        # Create output directories
        self.checkpoint_dir = Path(self.config['output']['checkpoint_dir'])
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        self.log_dir = self.checkpoint_dir / "logs"
        self.log_dir.mkdir(exist_ok=True)
        
        # Initialize tensorboard
        self.writer = SummaryWriter(log_dir=str(self.log_dir))
        
        # Build model
        print("\nBuilding model...")
        self.model = build_model(self.config)
        self.model.to(self.device)
        
        # Count parameters
        total_params = sum(p.numel() for p in self.model.parameters())
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        print(f"Total parameters: {total_params:,}")
        print(f"Trainable parameters: {trainable_params:,}")
        
        # Create dataloaders
        print("\nCreating dataloaders...")
        self.train_loader, self.val_loader = create_dataloaders(self.config)
        print(f"Training batches: {len(self.train_loader)}")
        print(f"Validation batches: {len(self.val_loader)}")
        
        # Setup optimizer
        self.optimizer = torch.optim.Adam(
            self.model.parameters(),
            lr=self.config['training']['learning_rate']
        )
        
        # Setup learning rate scheduler
        if self.config['training']['lr_scheduler']['enabled']:
            scheduler_type = self.config['training']['lr_scheduler']['type']
            if scheduler_type == 'cosine':
                self.lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                    self.optimizer,
                    T_max=self.config['training']['epochs']
                )
            elif scheduler_type == 'step':
                self.lr_scheduler = torch.optim.lr_scheduler.StepLR(
                    self.optimizer,
                    step_size=10,
                    gamma=0.1
                )
            else:
                self.lr_scheduler = None
        else:
            self.lr_scheduler = None
        
        # Setup loss functions
        self.focal_loss = FocalLoss(
            alpha=self.config['loss']['focal_alpha'],
            gamma=self.config['loss']['focal_gamma']
        )
        
        # Setup checkpoint manager
        self.checkpoint_manager = CheckpointManager(
            checkpoint_dir=str(self.checkpoint_dir),
            keep_best_n=self.config['output']['keep_best_n']
        )
        
        # Training state
        self.current_epoch = 0
        self.current_stage = None
        self.current_stage_epoch = 0
        self.best_val_loss = float('inf')
        self.epochs_without_improvement = 0
        
        # Mixed precision training
        self.use_amp = self.config['training']['mixed_precision']
        self.scaler = torch.cuda.amp.GradScaler() if self.use_amp else None
        
        # Resume from checkpoint if available
        if resume:
            self._try_resume()
    
    def _try_resume(self):
        """Try to resume training from checkpoint"""
        can_resume, resume_info = get_resume_info(str(self.checkpoint_dir))
        
        if can_resume and resume_info:
            print(f"\n{'='*60}")
            print("Found existing checkpoint!")
            print(f"{'='*60}")
            print(f"Last epoch: {resume_info['last_epoch']}")
            print(f"Last stage: {resume_info['last_stage']}")
            print(f"Last metrics: {resume_info['last_metrics']}")
            print(f"{'='*60}\n")
            
            response = input("Resume training from checkpoint? (y/n): ").lower()
            
            if response == 'y':
                state = self.checkpoint_manager.load_checkpoint(
                    self.model,
                    self.optimizer,
                    self.lr_scheduler,
                    checkpoint_type='resume'
                )
                
                if state:
                    self.current_epoch = state['epoch'] + 1
                    self.current_stage = state['stage']
                    self.current_stage_epoch = state['stage_epoch'] + 1
                    
                    if 'val_loss' in state['metrics']:
                        self.best_val_loss = state['metrics']['val_loss']
                    
                    print(f"✓ Resumed from epoch {state['epoch']}")
                    print(f"  Continuing from stage: {self.current_stage}")
    
    def train(self):
        """Main training loop"""
        print(f"\n{'='*60}")
        print("Starting Training")
        print(f"{'='*60}\n")
        
        # Get training stages
        stages = self.config['training']['stages']
        
        # Find starting stage if resuming
        start_stage_idx = 0
        if self.current_stage:
            for idx, stage in enumerate(stages):
                if stage['name'] == self.current_stage:
                    start_stage_idx = idx
                    break
        
        # Train each stage
        for stage_idx in range(start_stage_idx, len(stages)):
            stage = stages[stage_idx]
            self.current_stage = stage['name']
            
            print(f"\n{'='*60}")
            print(f"Stage {stage_idx + 1}/{len(stages)}: {stage['name']}")
            print(f"{'='*60}")
            print(f"Epochs: {stage['epochs']}")
            print(f"Train anomaly: {stage['train_anomaly']}")
            print(f"Train segmentation: {stage['train_segmentation']}")
            print(f"Train classifier: {stage['train_classifier']}")
            print(f"Freeze backbone: {stage['freeze_backbone']}")
            print(f"{'='*60}\n")
            
            # Configure model for this stage
            self._configure_stage(stage)
            
            # Determine starting epoch for this stage
            start_epoch = self.current_stage_epoch if stage_idx == start_stage_idx else 0
            
            # Train for stage epochs
            for epoch in range(start_epoch, stage['epochs']):
                self.current_stage_epoch = epoch
                
                print(f"\nEpoch {self.current_epoch + 1} (Stage {stage['name']}, Epoch {epoch + 1}/{stage['epochs']})")
                
                # Train one epoch
                train_metrics = self._train_epoch(stage)
                
                # Validate
                val_metrics = self._validate_epoch()
                
                # Log metrics
                self._log_metrics(train_metrics, val_metrics)
                
                # Check for improvement
                is_best = val_metrics['val_loss'] < self.best_val_loss
                if is_best:
                    self.best_val_loss = val_metrics['val_loss']
                    self.epochs_without_improvement = 0
                else:
                    self.epochs_without_improvement += 1
                
                # Save checkpoint
                all_metrics = {**train_metrics, **val_metrics}
                self.checkpoint_manager.save_checkpoint(
                    model=self.model,
                    optimizer=self.optimizer,
                    lr_scheduler=self.lr_scheduler,
                    epoch=self.current_epoch,
                    stage=self.current_stage,
                    stage_epoch=self.current_stage_epoch,
                    metrics=all_metrics,
                    is_best=is_best
                )
                
                # Learning rate scheduling
                if self.lr_scheduler is not None:
                    self.lr_scheduler.step()
                
                # Early stopping check
                if self.config['training']['early_stopping']['enabled']:
                    patience = self.config['training']['early_stopping']['patience']
                    if self.epochs_without_improvement >= patience:
                        print(f"\nEarly stopping triggered after {patience} epochs without improvement")
                        break
                
                self.current_epoch += 1
            
            # Reset stage epoch counter for next stage
            self.current_stage_epoch = 0
        
        print(f"\n{'='*60}")
        print("Training Complete!")
        print(f"{'='*60}")
        print(f"Best validation loss: {self.best_val_loss:.4f}")
        print(f"Best model saved to: {self.checkpoint_manager.best_path}")
        
        self.writer.close()
    
    def _configure_stage(self, stage: Dict):
        """Configure model for a specific training stage"""
        # Freeze/unfreeze backbone
        for param in self.model.backbone.parameters():
            param.requires_grad = not stage['freeze_backbone']
        
        # Configure which heads to train
        for param in self.model.anomaly_head.parameters():
            param.requires_grad = stage['train_anomaly']
        
        for param in self.model.segmentation_head.parameters():
            param.requires_grad = stage['train_segmentation']
        
        for param in self.model.classification_head.parameters():
            param.requires_grad = stage['train_classifier']
    
    def _train_epoch(self, stage: Dict) -> Dict[str, float]:
        """Train for one epoch"""
        self.model.train()
        
        total_loss = 0.0
        total_anomaly_loss = 0.0
        total_seg_loss = 0.0
        total_cls_loss = 0.0
        
        pbar = tqdm(self.train_loader, desc="Training")
        
        for batch_idx, batch in enumerate(pbar):
            images = batch['images'].to(self.device)
            masks = batch['masks'].to(self.device)
            boxes = batch['boxes']
            labels = batch['labels']
            
            # Forward pass with mixed precision
            with torch.cuda.amp.autocast(enabled=self.use_amp):
                outputs = self.model(images, return_features=True)
                
                # Compute losses
                loss = 0.0
                loss_dict = {}
                
                # Anomaly detection loss
                if stage['train_anomaly']:
                    # Create binary anomaly target (1 where defects exist)
                    anomaly_target = (masks > 0).float().unsqueeze(1)
                    anomaly_loss = F.binary_cross_entropy(
                        outputs['anomaly_map'],
                        anomaly_target
                    )
                    loss += self.config['loss']['anomaly_weight'] * anomaly_loss
                    loss_dict['anomaly_loss'] = anomaly_loss.item()
                    total_anomaly_loss += anomaly_loss.item()
                
                # Segmentation loss
                if stage['train_segmentation']:
                    seg_loss = F.cross_entropy(outputs['seg_logits'], masks)
                    loss += self.config['loss']['segmentation_weight'] * seg_loss
                    loss_dict['seg_loss'] = seg_loss.item()
                    total_seg_loss += seg_loss.item()
                
                # Classification loss (if we have boxes)
                if stage['train_classifier']:
                    # Extract ROI features and classify
                    features = outputs['features'][max(outputs['features'].keys())]
                    
                    # Collect all boxes and labels from batch
                    all_roi_features = []
                    all_labels = []
                    
                    for b_idx in range(len(boxes)):
                        if len(boxes[b_idx]) > 0:
                            # Extract ROI features
                            roi_feats = self.model.extract_roi_features(
                                features[b_idx:b_idx+1],
                                [boxes[b_idx]]
                            )
                            
                            if len(roi_feats) > 0:
                                all_roi_features.append(roi_feats)
                                all_labels.append(labels[b_idx].to(self.device))
                    
                    if len(all_roi_features) > 0:
                        all_roi_features = torch.cat(all_roi_features, dim=0)
                        all_labels = torch.cat(all_labels, dim=0)
                        
                        # Classify
                        class_logits = self.model.classification_head(all_roi_features)
                        cls_loss = self.focal_loss(class_logits, all_labels)
                        loss += self.config['loss']['classification_weight'] * cls_loss
                        loss_dict['cls_loss'] = cls_loss.item()
                        total_cls_loss += cls_loss.item()
            
            # Backward pass
            self.optimizer.zero_grad()
            
            if self.use_amp:
                self.scaler.scale(loss).backward()
                
                # Gradient clipping
                if self.config['training']['grad_clip'] > 0:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(),
                        self.config['training']['grad_clip']
                    )
                
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                loss.backward()
                
                # Gradient clipping
                if self.config['training']['grad_clip'] > 0:
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(),
                        self.config['training']['grad_clip']
                    )
                
                self.optimizer.step()
            
            total_loss += loss.item()
            
            # Update progress bar
            pbar.set_postfix(loss_dict)
        
        # Calculate average losses
        num_batches = len(self.train_loader)
        metrics = {
            'train_loss': total_loss / num_batches,
            'train_anomaly_loss': total_anomaly_loss / num_batches if total_anomaly_loss > 0 else 0,
            'train_seg_loss': total_seg_loss / num_batches if total_seg_loss > 0 else 0,
            'train_cls_loss': total_cls_loss / num_batches if total_cls_loss > 0 else 0
        }
        
        return metrics
    
    @torch.no_grad()
    def _validate_epoch(self) -> Dict[str, float]:
        """Validate for one epoch"""
        self.model.eval()
        
        total_loss = 0.0
        total_anomaly_loss = 0.0
        total_seg_loss = 0.0
        
        pbar = tqdm(self.val_loader, desc="Validation")
        
        for batch in pbar:
            images = batch['images'].to(self.device)
            masks = batch['masks'].to(self.device)
            
            outputs = self.model(images)
            
            # Anomaly loss
            anomaly_target = (masks > 0).float().unsqueeze(1)
            anomaly_loss = F.binary_cross_entropy(
                outputs['anomaly_map'],
                anomaly_target
            )
            
            # Segmentation loss
            seg_loss = F.cross_entropy(outputs['seg_logits'], masks)
            
            # Combined loss
            loss = (
                self.config['loss']['anomaly_weight'] * anomaly_loss +
                self.config['loss']['segmentation_weight'] * seg_loss
            )
            
            total_loss += loss.item()
            total_anomaly_loss += anomaly_loss.item()
            total_seg_loss += seg_loss.item()
            
            pbar.set_postfix({
                'val_loss': loss.item(),
                'anom_loss': anomaly_loss.item(),
                'seg_loss': seg_loss.item()
            })
        
        num_batches = len(self.val_loader)
        metrics = {
            'val_loss': total_loss / num_batches,
            'val_anomaly_loss': total_anomaly_loss / num_batches,
            'val_seg_loss': total_seg_loss / num_batches
        }
        
        return metrics
    
    def _log_metrics(self, train_metrics: Dict, val_metrics: Dict):
        """Log metrics to tensorboard and console"""
        # Log to tensorboard
        for key, value in train_metrics.items():
            self.writer.add_scalar(f'train/{key}', value, self.current_epoch)
        
        for key, value in val_metrics.items():
            self.writer.add_scalar(f'val/{key}', value, self.current_epoch)
        
        # Log learning rate
        current_lr = self.optimizer.param_groups[0]['lr']
        self.writer.add_scalar('train/learning_rate', current_lr, self.current_epoch)
        
        # Print summary
        print(f"\nEpoch {self.current_epoch} Summary:")
        print(f"  Train Loss: {train_metrics['train_loss']:.4f}")
        print(f"  Val Loss: {val_metrics['val_loss']:.4f}")
        print(f"  Learning Rate: {current_lr:.6f}")
        print(f"  Best Val Loss: {self.best_val_loss:.4f}")


def main():
    parser = argparse.ArgumentParser(description='Train Hybrid Defect Detection Model')
    parser.add_argument('--config', type=str, default='config.yaml',
                        help='Path to configuration file')
    parser.add_argument('--no-resume', action='store_true',
                        help='Do not resume from checkpoint')
    
    args = parser.parse_args()
    
    # Create trainer
    trainer = Trainer(
        config_path=args.config,
        resume=not args.no_resume
    )
    
    # Start training
    try:
        trainer.train()
    except KeyboardInterrupt:
        print("\n\nTraining interrupted by user")
        print("Checkpoint saved. You can resume training by running this script again.")
    except Exception as e:
        print(f"\n\nERROR: Training failed with exception: {e}")
        print("Checkpoint saved. You can resume training after fixing the issue.")
        raise


if __name__ == "__main__":
    main()
