"""
Dataset loader for Pascal VOC format defect detection
Handles image loading, XML parsing, and data augmentation
"""

import os
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import random

import torch
from torch.utils.data import Dataset, DataLoader
import cv2
import numpy as np
import albumentations as A
from albumentations.pytorch import ToTensorV2


class PascalVOCDefectDataset(Dataset):
    """
    Dataset class for loading defect images and annotations in Pascal VOC format
    """
    
    def __init__(
        self,
        root_path: str,
        class_names: List[str],
        image_extension: str = ".png",
        label_extension: str = ".xml",
        transform: Optional[A.Compose] = None,
        is_training: bool = True
    ):
        """
        Args:
            root_path: Path to dataset folder containing images and XML files
            class_names: List of defect class names (e.g., ["chip", "check"])
            image_extension: Image file extension
            label_extension: Label file extension
            transform: Albumentations transform pipeline
            is_training: Whether this is a training dataset
        """
        self.root_path = Path(root_path)
        self.class_names = class_names
        self.class_to_idx = {name: idx for idx, name in enumerate(class_names)}
        self.image_extension = image_extension
        self.label_extension = label_extension
        self.transform = transform
        self.is_training = is_training
        
        # Find all image files
        self.image_files = self._find_image_files()
        
        print(f"Found {len(self.image_files)} images in {root_path}")
        
        # Verify that corresponding XML files exist
        self._verify_labels()
    
    def _find_image_files(self) -> List[Path]:
        """Find all image files in the dataset directory"""
        image_files = []
        for ext in [self.image_extension, self.image_extension.upper()]:
            image_files.extend(self.root_path.glob(f"*{ext}"))
        return sorted(image_files)
    
    def _verify_labels(self):
        """Verify that all images have corresponding XML label files"""
        missing_labels = []
        for img_path in self.image_files:
            xml_path = img_path.with_suffix(self.label_extension)
            if not xml_path.exists():
                missing_labels.append(img_path.name)
        
        if missing_labels:
            print(f"WARNING: {len(missing_labels)} images are missing XML labels")
            print(f"First few missing: {missing_labels[:5]}")
    
    def _parse_xml(self, xml_path: Path) -> Tuple[List[List[int]], List[int]]:
        """
        Parse Pascal VOC XML file to extract bounding boxes and class labels
        
        Returns:
            boxes: List of [xmin, ymin, xmax, ymax] coordinates
            labels: List of class indices
        """
        tree = ET.parse(xml_path)
        root = tree.getroot()
        
        boxes = []
        labels = []
        
        for obj in root.findall('object'):
            # Get class name
            class_name = obj.find('name').text
            
            # Skip if class is not in our list
            if class_name not in self.class_to_idx:
                continue
            
            # Get bounding box coordinates
            bbox = obj.find('bndbox')
            xmin = int(float(bbox.find('xmin').text))
            ymin = int(float(bbox.find('ymin').text))
            xmax = int(float(bbox.find('xmax').text))
            ymax = int(float(bbox.find('ymax').text))
            
            boxes.append([xmin, ymin, xmax, ymax])
            labels.append(self.class_to_idx[class_name])
        
        return boxes, labels
    
    def _create_segmentation_mask(
        self,
        image_shape: Tuple[int, int],
        boxes: List[List[int]],
        labels: List[int]
    ) -> np.ndarray:
        """
        Create a segmentation mask from bounding boxes
        
        Args:
            image_shape: (height, width) of the image
            boxes: List of bounding boxes
            labels: List of class labels
        
        Returns:
            mask: Segmentation mask of shape (height, width) with class indices
        """
        height, width = image_shape
        mask = np.zeros((height, width), dtype=np.int64)
        
        for box, label in zip(boxes, labels):
            xmin, ymin, xmax, ymax = box
            # Class indices start from 1 (0 is background)
            mask[ymin:ymax, xmin:xmax] = label + 1
        
        return mask
    
    def __len__(self) -> int:
        return len(self.image_files)
    
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """
        Get a single sample from the dataset
        
        Returns:
            Dictionary containing:
                - image: Tensor of shape (3, H, W)
                - boxes: Tensor of shape (N, 4) with bounding boxes
                - labels: Tensor of shape (N,) with class labels
                - mask: Tensor of shape (H, W) with segmentation mask
        """
        # Load image
        img_path = self.image_files[idx]
        image = cv2.imread(str(img_path))
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Parse XML annotations
        xml_path = img_path.with_suffix(self.label_extension)
        boxes, labels = self._parse_xml(xml_path)
        
        # Create segmentation mask
        mask = self._create_segmentation_mask(image.shape[:2], boxes, labels)
        
        # Apply augmentations
        if self.transform is not None:
            # Albumentations expects boxes in normalized format
            height, width = image.shape[:2]
            
            # Convert boxes to albumentations format
            if len(boxes) > 0:
                boxes_normalized = []
                for box in boxes:
                    xmin, ymin, xmax, ymax = box
                    boxes_normalized.append([
                        xmin / width,
                        ymin / height,
                        xmax / width,
                        ymax / height
                    ])
                
                transformed = self.transform(
                    image=image,
                    mask=mask,
                    bboxes=boxes_normalized,
                    class_labels=labels
                )
                
                image = transformed['image']
                mask = transformed['mask']
                boxes_normalized = transformed['bboxes']
                labels = transformed['class_labels']
                
                # Convert boxes back to pixel coordinates
                height, width = mask.shape
                boxes = []
                for box in boxes_normalized:
                    xmin, ymin, xmax, ymax = box
                    boxes.append([
                        int(xmin * width),
                        int(ymin * height),
                        int(xmax * width),
                        int(ymax * height)
                    ])
            else:
                # No boxes, just transform image and mask
                transformed = self.transform(image=image, mask=mask)
                image = transformed['image']
                mask = transformed['mask']
        
        # Convert to tensors
        if not isinstance(image, torch.Tensor):
            image = torch.from_numpy(image).permute(2, 0, 1).float() / 255.0
        
        boxes_tensor = torch.tensor(boxes, dtype=torch.float32) if len(boxes) > 0 else torch.zeros((0, 4), dtype=torch.float32)
        labels_tensor = torch.tensor(labels, dtype=torch.int64) if len(labels) > 0 else torch.zeros((0,), dtype=torch.int64)
        mask_tensor = torch.from_numpy(mask).long()
        
        return {
            'image': image,
            'boxes': boxes_tensor,
            'labels': labels_tensor,
            'mask': mask_tensor,
            'image_path': str(img_path)
        }


def get_transforms(config: Dict, is_training: bool = True) -> A.Compose:
    """
    Create augmentation pipeline based on configuration
    
    Args:
        config: Configuration dictionary
        is_training: Whether to apply training augmentations
    
    Returns:
        Albumentations transform pipeline
    """
    if is_training and config['augmentation']['enabled']:
        aug_config = config['augmentation']
        
        transforms = [
            A.HorizontalFlip(p=aug_config['horizontal_flip']),
            A.VerticalFlip(p=aug_config['vertical_flip']),
            A.Rotate(
                limit=aug_config['rotation'],
                border_mode=cv2.BORDER_CONSTANT,
                value=0,
                p=0.5
            ),
            A.RandomBrightnessContrast(
                brightness_limit=aug_config['brightness'],
                contrast_limit=aug_config['contrast'],
                p=0.5
            ),
            A.GaussNoise(
                var_limit=(0, aug_config['noise_std'] * 255),
                p=0.3
            ),
        ]
    else:
        # Validation transforms (no augmentation)
        transforms = []
    
    # Always normalize at the end
    transforms.append(ToTensorV2())
    
    return A.Compose(
        transforms,
        bbox_params=A.BboxParams(
            format='albumentations',
            label_fields=['class_labels'],
            min_visibility=0.3
        )
    )


def collate_fn(batch: List[Dict]) -> Dict[str, any]:
    """
    Custom collate function to handle variable number of boxes per image
    """
    images = torch.stack([item['image'] for item in batch])
    masks = torch.stack([item['mask'] for item in batch])
    
    # Keep boxes and labels as lists since they have different lengths
    boxes = [item['boxes'] for item in batch]
    labels = [item['labels'] for item in batch]
    image_paths = [item['image_path'] for item in batch]
    
    return {
        'images': images,
        'boxes': boxes,
        'labels': labels,
        'masks': masks,
        'image_paths': image_paths
    }


def create_dataloaders(config: Dict) -> Tuple[DataLoader, DataLoader]:
    """
    Create training and validation dataloaders
    
    Args:
        config: Configuration dictionary
    
    Returns:
        train_loader, val_loader
    """
    dataset_config = config['dataset']
    training_config = config['training']
    
    # Get all image files
    root_path = Path(dataset_config['root_path'])
    all_images = list(root_path.glob(f"*{dataset_config['image_extension']}"))
    
    # Split into train and validation
    random.seed(dataset_config['random_seed'])
    random.shuffle(all_images)
    
    split_idx = int(len(all_images) * dataset_config['train_split'])
    train_images = all_images[:split_idx]
    val_images = all_images[split_idx:]
    
    print(f"Dataset split: {len(train_images)} training, {len(val_images)} validation")
    
    # Create temporary directories for split datasets
    # (In practice, you might want to create symbolic links or use a different approach)
    
    # Create datasets
    train_transform = get_transforms(config, is_training=True)
    val_transform = get_transforms(config, is_training=False)
    
    train_dataset = PascalVOCDefectDataset(
        root_path=dataset_config['root_path'],
        class_names=dataset_config['classes'],
        image_extension=dataset_config['image_extension'],
        label_extension=dataset_config['label_extension'],
        transform=train_transform,
        is_training=True
    )
    
    val_dataset = PascalVOCDefectDataset(
        root_path=dataset_config['root_path'],
        class_names=dataset_config['classes'],
        image_extension=dataset_config['image_extension'],
        label_extension=dataset_config['label_extension'],
        transform=val_transform,
        is_training=False
    )
    
    # Create dataloaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=training_config['batch_size'],
        shuffle=True,
        num_workers=training_config['num_workers'],
        collate_fn=collate_fn,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=training_config['batch_size'],
        shuffle=False,
        num_workers=training_config['num_workers'],
        collate_fn=collate_fn,
        pin_memory=True
    )
    
    return train_loader, val_loader


if __name__ == "__main__":
    # Test the dataset loader
    import yaml
    
    with open('config.yaml', 'r') as f:
        config = yaml.safe_load(f)
    
    train_loader, val_loader = create_dataloaders(config)
    
    print(f"\nTesting dataset loader...")
    batch = next(iter(train_loader))
    print(f"Batch keys: {batch.keys()}")
    print(f"Images shape: {batch['images'].shape}")
    print(f"Number of samples with boxes: {sum(len(b) > 0 for b in batch['boxes'])}")
    print(f"Masks shape: {batch['masks'].shape}")
    print("Dataset loader test passed!")
