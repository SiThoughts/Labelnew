"""
ONNX-compatible post-processing operations
Implements box extraction, NMS, and classification entirely in PyTorch
for seamless ONNX export
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.ops import nms, roi_align
from typing import Tuple, List


class MorphologicalOps(nn.Module):
    """
    Morphological operations (erosion, dilation) using convolution
    ONNX-compatible implementation
    """
    
    def __init__(self, kernel_size: int = 5):
        super().__init__()
        
        self.kernel_size = kernel_size
        
        # Create morphological kernel (circular)
        kernel = self._create_circular_kernel(kernel_size)
        self.register_buffer('kernel', kernel)
    
    def _create_circular_kernel(self, size: int) -> torch.Tensor:
        """Create a circular kernel for morphological operations"""
        kernel = torch.zeros((size, size))
        center = size // 2
        
        for i in range(size):
            for j in range(size):
                if (i - center) ** 2 + (j - center) ** 2 <= (size // 2) ** 2:
                    kernel[i, j] = 1.0
        
        return kernel.unsqueeze(0).unsqueeze(0)
    
    def erode(self, x: torch.Tensor) -> torch.Tensor:
        """
        Morphological erosion
        
        Args:
            x: Binary mask of shape (B, 1, H, W)
        
        Returns:
            Eroded mask
        """
        padding = self.kernel_size // 2
        
        # Erosion: minimum in the neighborhood
        # Implemented as: 1 - max_pool(1 - x)
        x_inv = 1.0 - x
        x_dilated = F.conv2d(x_inv, self.kernel, padding=padding)
        x_eroded = 1.0 - (x_dilated >= self.kernel.sum())
        
        return x_eroded
    
    def dilate(self, x: torch.Tensor) -> torch.Tensor:
        """
        Morphological dilation
        
        Args:
            x: Binary mask of shape (B, 1, H, W)
        
        Returns:
            Dilated mask
        """
        padding = self.kernel_size // 2
        
        # Dilation: maximum in the neighborhood
        x_dilated = F.conv2d(x, self.kernel, padding=padding)
        x_dilated = (x_dilated > 0).float()
        
        return x_dilated
    
    def opening(self, x: torch.Tensor) -> torch.Tensor:
        """
        Morphological opening (erosion followed by dilation)
        Removes small noise while preserving larger structures
        """
        x = self.erode(x)
        x = self.dilate(x)
        return x
    
    def closing(self, x: torch.Tensor) -> torch.Tensor:
        """
        Morphological closing (dilation followed by erosion)
        Fills small holes while preserving boundaries
        """
        x = self.dilate(x)
        x = self.erode(x)
        return x


class BoxExtractor(nn.Module):
    """
    Extract bounding boxes from binary masks
    ONNX-compatible implementation using differentiable operations
    """
    
    def __init__(
        self,
        min_area: int = 50,
        max_area: int = 500000,
        max_proposals: int = 100
    ):
        super().__init__()
        
        self.min_area = min_area
        self.max_area = max_area
        self.max_proposals = max_proposals
    
    def forward(self, mask: torch.Tensor) -> torch.Tensor:
        """
        Extract bounding boxes from binary mask
        
        Args:
            mask: Binary mask of shape (H, W) or (1, H, W)
        
        Returns:
            Boxes tensor of shape (N, 4) in format [x1, y1, x2, y2]
        """
        if mask.dim() == 3:
            mask = mask.squeeze(0)
        
        # Find all non-zero pixels
        nonzero_indices = torch.nonzero(mask > 0.5, as_tuple=False)
        
        if len(nonzero_indices) == 0:
            # No detections
            return torch.zeros((0, 4), dtype=torch.float32, device=mask.device)
        
        # Simple approach: Use connected components approximation
        # For ONNX compatibility, we'll use a grid-based approach
        boxes = self._extract_boxes_grid_based(mask)
        
        return boxes
    
    def _extract_boxes_grid_based(self, mask: torch.Tensor) -> torch.Tensor:
        """
        Extract boxes using a grid-based approach
        This is a simplified version that works well for ONNX export
        """
        H, W = mask.shape
        
        # Find horizontal and vertical projections
        h_proj = mask.sum(dim=1)  # (H,)
        v_proj = mask.sum(dim=0)  # (W,)
        
        # Find rows and columns with non-zero values
        h_nonzero = h_proj > 0
        v_nonzero = v_proj > 0
        
        if not h_nonzero.any() or not v_nonzero.any():
            return torch.zeros((0, 4), dtype=torch.float32, device=mask.device)
        
        # Find bounding box of the entire region
        h_indices = torch.where(h_nonzero)[0]
        v_indices = torch.where(v_nonzero)[0]
        
        y1 = h_indices[0].float()
        y2 = h_indices[-1].float()
        x1 = v_indices[0].float()
        x2 = v_indices[-1].float()
        
        # For now, return a single box
        # In a more sophisticated implementation, we would use connected components
        box = torch.stack([x1, y1, x2, y2]).unsqueeze(0)
        
        return box


class ConnectedComponents(nn.Module):
    """
    Simplified connected components for ONNX export
    Uses a sliding window approach to identify separate regions
    """
    
    def __init__(self, min_area: int = 50, max_area: int = 500000):
        super().__init__()
        self.min_area = min_area
        self.max_area = max_area
    
    def forward(self, mask: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Find connected components and their bounding boxes
        
        Args:
            mask: Binary mask of shape (H, W)
        
        Returns:
            boxes: Tensor of shape (N, 4) with bounding boxes
            areas: Tensor of shape (N,) with component areas
        """
        # This is a simplified implementation for ONNX compatibility
        # A full connected components algorithm is complex to implement in pure PyTorch
        
        # For now, we'll use a grid-based approach that divides the image into regions
        H, W = mask.shape
        
        # Use morphological operations to separate components
        # Then extract boxes using contour-like approach
        
        boxes_list = []
        areas_list = []
        
        # Find all non-zero regions
        nonzero = mask > 0.5
        
        if nonzero.sum() == 0:
            return (
                torch.zeros((0, 4), dtype=torch.float32, device=mask.device),
                torch.zeros((0,), dtype=torch.float32, device=mask.device)
            )
        
        # Simple approach: scan for separate regions
        # This is a placeholder - in practice, you'd use a more sophisticated algorithm
        y_coords, x_coords = torch.where(nonzero)
        
        if len(y_coords) > 0:
            x1 = x_coords.min().float()
            x2 = x_coords.max().float()
            y1 = y_coords.min().float()
            y2 = y_coords.max().float()
            
            area = (x2 - x1 + 1) * (y2 - y1 + 1)
            
            if self.min_area <= area <= self.max_area:
                boxes_list.append(torch.tensor([x1, y1, x2, y2], device=mask.device))
                areas_list.append(area)
        
        if len(boxes_list) == 0:
            return (
                torch.zeros((0, 4), dtype=torch.float32, device=mask.device),
                torch.zeros((0,), dtype=torch.float32, device=mask.device)
            )
        
        boxes = torch.stack(boxes_list)
        areas = torch.tensor(areas_list, device=mask.device)
        
        return boxes, areas


class ONNXPostProcessor(nn.Module):
    """
    Complete post-processing pipeline for ONNX export
    Takes anomaly map and segmentation output, produces final boxes, labels, and scores
    """
    
    def __init__(self, config: dict):
        super().__init__()
        
        detection_config = config['model']['detection']
        anomaly_config = config['model']['anomaly']
        
        self.anomaly_threshold = anomaly_config['threshold']
        self.min_area = detection_config['min_area']
        self.max_area = detection_config['max_area']
        self.max_proposals = detection_config['max_proposals']
        self.nms_threshold = detection_config['nms_iou_threshold']
        self.min_confidence = detection_config['min_confidence']
        self.num_classes = len(config['dataset']['classes'])
        
        # Morphological operations for mask cleaning
        self.morph_ops = MorphologicalOps(
            kernel_size=anomaly_config['morph_kernel_size']
        )
        
        # Connected components extractor
        self.connected_components = ConnectedComponents(
            min_area=self.min_area,
            max_area=self.max_area
        )
    
    def forward(
        self,
        anomaly_map: torch.Tensor,
        seg_logits: torch.Tensor,
        features: torch.Tensor,
        classification_head: nn.Module
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Post-process model outputs to produce final detections
        
        Args:
            anomaly_map: Anomaly scores of shape (B, 1, H, W)
            seg_logits: Segmentation logits of shape (B, num_classes+1, H, W)
            features: Feature map for ROI classification
            classification_head: Classification head module
        
        Returns:
            boxes: Tensor of shape (N, 4) with bounding boxes
            labels: Tensor of shape (N,) with class labels
            scores: Tensor of shape (N,) with confidence scores
        """
        batch_size = anomaly_map.shape[0]
        
        all_boxes = []
        all_labels = []
        all_scores = []
        
        for b in range(batch_size):
            # Get single image outputs
            anom_map = anomaly_map[b, 0]  # (H, W)
            seg_log = seg_logits[b]  # (num_classes+1, H, W)
            
            # Step 1: Threshold anomaly map
            binary_mask = (anom_map > self.anomaly_threshold).float()
            
            # Step 2: Apply morphological opening to remove noise
            binary_mask = binary_mask.unsqueeze(0).unsqueeze(0)  # (1, 1, H, W)
            binary_mask = self.morph_ops.opening(binary_mask)
            binary_mask = binary_mask.squeeze(0).squeeze(0)  # (H, W)
            
            # Step 3: Get segmentation predictions
            seg_probs = F.softmax(seg_log, dim=0)  # (num_classes+1, H, W)
            seg_pred = seg_probs.argmax(dim=0)  # (H, W)
            
            # Step 4: Combine anomaly and segmentation
            # Only keep regions that are both anomalous AND classified as defects
            defect_mask = (seg_pred > 0).float()  # Exclude background (class 0)
            combined_mask = binary_mask * defect_mask
            
            # Step 5: Extract bounding boxes
            boxes, areas = self.connected_components(combined_mask)
            
            if len(boxes) == 0:
                continue
            
            # Step 6: Extract features for each box and classify
            # Scale boxes to feature map resolution
            feat_h, feat_w = features.shape[2:]
            img_h, img_w = combined_mask.shape
            
            scale_h = feat_h / img_h
            scale_w = feat_w / img_w
            
            scaled_boxes = boxes.clone()
            scaled_boxes[:, [0, 2]] *= scale_w
            scaled_boxes[:, [1, 3]] *= scale_h
            
            # Add batch index for ROI align
            batch_indices = torch.full(
                (len(scaled_boxes), 1),
                b,
                dtype=scaled_boxes.dtype,
                device=scaled_boxes.device
            )
            roi_boxes = torch.cat([batch_indices, scaled_boxes], dim=1)
            
            # Extract ROI features
            roi_features = roi_align(
                features[b:b+1],
                [roi_boxes],
                output_size=(7, 7),
                spatial_scale=1.0,
                aligned=True
            )
            
            # Classify each ROI
            class_logits = classification_head(roi_features)
            class_probs = F.softmax(class_logits, dim=1)
            class_scores, class_labels = class_probs.max(dim=1)
            
            # Step 7: Filter by confidence
            keep = class_scores >= self.min_confidence
            boxes = boxes[keep]
            class_labels = class_labels[keep]
            class_scores = class_scores[keep]
            
            if len(boxes) == 0:
                continue
            
            # Step 8: Apply NMS
            keep_indices = nms(boxes, class_scores, self.nms_threshold)
            
            # Step 9: Keep top-K proposals
            if len(keep_indices) > self.max_proposals:
                # Sort by score and keep top K
                scores_sorted, sort_indices = class_scores[keep_indices].sort(descending=True)
                keep_indices = keep_indices[sort_indices[:self.max_proposals]]
            
            final_boxes = boxes[keep_indices]
            final_labels = class_labels[keep_indices]
            final_scores = class_scores[keep_indices]
            
            all_boxes.append(final_boxes)
            all_labels.append(final_labels)
            all_scores.append(final_scores)
        
        # Concatenate results from all images in batch
        if len(all_boxes) == 0:
            return (
                torch.zeros((0, 4), dtype=torch.float32, device=anomaly_map.device),
                torch.zeros((0,), dtype=torch.int64, device=anomaly_map.device),
                torch.zeros((0,), dtype=torch.float32, device=anomaly_map.device)
            )
        
        boxes = torch.cat(all_boxes, dim=0)
        labels = torch.cat(all_labels, dim=0)
        scores = torch.cat(all_scores, dim=0)
        
        return boxes, labels, scores


class ONNXExportWrapper(nn.Module):
    """
    Wrapper for ONNX export that combines the model and post-processing
    """
    
    def __init__(self, model: nn.Module, postprocessor: ONNXPostProcessor):
        super().__init__()
        
        self.model = model
        self.postprocessor = postprocessor
    
    def forward(self, images: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Complete forward pass from images to final detections
        
        Args:
            images: Input images of shape (B, 3, H, W)
        
        Returns:
            boxes: Bounding boxes (N, 4)
            labels: Class labels (N,)
            scores: Confidence scores (N,)
        """
        # Get model outputs
        outputs = self.model(images, return_features=True)
        
        anomaly_map = outputs['anomaly_map']
        seg_logits = outputs['seg_logits']
        features = outputs['features'][max(outputs['features'].keys())]
        
        # Post-process to get final detections
        boxes, labels, scores = self.postprocessor(
            anomaly_map,
            seg_logits,
            features,
            self.model.classification_head
        )
        
        return boxes, labels, scores


if __name__ == "__main__":
    # Test the post-processing pipeline
    print("Testing ONNX post-processing modules...")
    
    # Test morphological operations
    morph = MorphologicalOps(kernel_size=5)
    test_mask = torch.rand(1, 1, 100, 100) > 0.5
    test_mask = test_mask.float()
    
    opened = morph.opening(test_mask)
    print(f"Morphological opening: input shape {test_mask.shape}, output shape {opened.shape}")
    
    # Test connected components
    cc = ConnectedComponents(min_area=50, max_area=10000)
    boxes, areas = cc(test_mask[0, 0])
    print(f"Connected components: found {len(boxes)} regions")
    
    print("Post-processing tests passed!")
