## Hybrid Defect Detection System

A state-of-the-art deep learning system for high-recall defect detection that combines anomaly detection, segmentation, and classification into a single ONNX model.

### Key Features

- **High Recall Architecture**: Combines anomaly detection (SimpleNet-inspired) with segmentation and classification for maximum defect detection
- **Single ONNX Output**: All post-processing embedded in the model - no external code needed during inference
- **Crash Recovery**: Automatic checkpoint saving and resume capability
- **Memory Optimized**: Designed for 11GB VRAM with mixed precision training
- **Class Imbalance Handling**: Focal loss and anomaly-based detection for rare defects
- **One-Click Training**: Automated setup and training with minimal user intervention

### Architecture Overview

The model consists of three main components:

1. **Anomaly Detection Head**: Identifies regions that deviate from normal patterns (high recall)
2. **Segmentation Head**: Provides pixel-level masks for defect localization
3. **Classification Head**: Classifies detected defects into specific types (chip, check, etc.)

These components work together to achieve both high recall and accurate classification.

---

## Quick Start

### 1. Setup Environment

**Option A: Using setup.bat (Recommended for Windows)**

```batch
setup.bat
```

This will:
- Create a conda environment called `customml`
- Install PyTorch with CUDA support
- Install all dependencies
- Verify the installation

**Option B: Manual Setup**

```batch
conda create -n customml python=3.10 -y
conda activate customml
conda install pytorch torchvision torchaudio pytorch-cuda=11.8 -c pytorch -c nvidia -y
pip install -r requirements.txt
```

### 2. Configure Dataset

Edit `config.yaml` and set your dataset path:

```yaml
dataset:
  root_path: "D:/path/to/your/dataset"  # Change this to your dataset folder
  classes:
    - "chip"
    - "check"
```

**Dataset Format**: Pascal VOC XML format
- Images and XML files should be in the same folder
- Each image file should have a corresponding XML file with the same name
- Example: `image001.png` → `image001.xml`

### 3. Train the Model

**Option A: One-Click Training (Recommended)**

```batch
run_training.bat
```

**Option B: Manual Training**

```batch
conda activate customml
python train.py
```

**Training Features**:
- Automatically resumes from checkpoint if training was interrupted
- Saves checkpoints every epoch
- Monitors validation loss and saves best model
- Early stopping to prevent overfitting
- TensorBoard logging for visualization

### 4. Monitor Training

View training progress in TensorBoard:

```batch
conda activate customml
tensorboard --logdir=checkpoints/logs
```

Then open your browser to `http://localhost:6006`

### 5. Export to ONNX

After training completes:

```batch
conda activate customml
python export_onnx.py
```

This creates an ONNX file with:
- **Input**: `"input"` - shape `[1, 3, 1460, 2048]`
- **Outputs**:
  - `"boxes"` - shape `[N, 4]` (x1, y1, x2, y2 format)
  - `"labels"` - shape `[N]` (class indices)
  - `"scores"` - shape `[N]` (confidence scores)

---

## Configuration Guide

The `config.yaml` file controls all aspects of training. Key settings:

### Dataset Configuration

```yaml
dataset:
  root_path: "D:/path/to/your/dataset"
  image_extension: ".png"
  label_extension: ".xml"
  classes:
    - "chip"
    - "check"
  train_split: 0.8  # 80% train, 20% validation
```

### Model Configuration

```yaml
model:
  input_size: [2048, 1460]  # MUST match your actual image size
  backbone: "resnet34"       # Options: resnet34, resnet50, efficientnet_b0
  
  detection:
    min_area: 50              # Minimum defect size in pixels
    max_area: 500000          # Maximum defect size
    max_proposals: 100        # Maximum detections per image
    nms_iou_threshold: 0.5    # NMS threshold
    min_confidence: 0.3       # Minimum confidence for output
```

### Training Configuration

```yaml
training:
  batch_size: 2              # Adjust based on your VRAM
  epochs: 100
  learning_rate: 0.0001
  mixed_precision: true      # Faster training, less memory
  grad_clip: 1.0             # Prevent exploding gradients
  
  early_stopping:
    enabled: true
    patience: 15             # Stop if no improvement for 15 epochs
```

### Multi-Stage Training

The model trains in three stages for optimal performance:

1. **Stage 1**: Anomaly detection pre-training (learns what's "normal")
2. **Stage 2**: Segmentation training (learns defect boundaries)
3. **Stage 3**: End-to-end fine-tuning (optimizes everything together)

You can customize stages in `config.yaml`:

```yaml
training:
  stages:
    - name: "anomaly_pretraining"
      epochs: 20
      train_anomaly: true
      train_segmentation: false
      train_classifier: false
    
    - name: "segmentation_training"
      epochs: 40
      train_anomaly: true
      train_segmentation: true
      train_classifier: false
    
    - name: "end_to_end_training"
      epochs: 40
      train_anomaly: true
      train_segmentation: true
      train_classifier: true
```

---

## Crash Recovery

The system automatically saves checkpoints and can resume training after:
- Crashes
- Power failures
- Manual interruption (Ctrl+C)
- Out-of-memory errors

**To resume training**: Simply run the training command again. The system will detect the checkpoint and ask if you want to resume.

```batch
run_training.bat
```

Output:
```
Found existing checkpoint!
============================================================
Last epoch: 45
Last stage: end_to_end_training
Last metrics: {'train_loss': 0.234, 'val_loss': 0.189}
============================================================

Resume training from checkpoint? (y/n):
```

---

## File Structure

```
defect_detection/
├── config.yaml                 # Main configuration file
├── setup.bat                   # Environment setup script
├── run_training.bat            # One-click training launcher
├── requirements.txt            # Python dependencies
│
├── train.py                    # Main training script
├── export_onnx.py              # ONNX export script
├── model.py                    # Model architecture
├── dataset.py                  # Dataset loader
├── checkpoint_manager.py       # Checkpoint handling
├── onnx_postprocess.py         # ONNX post-processing
│
├── checkpoints/                # Training checkpoints
│   ├── best_checkpoint.pt      # Best model
│   ├── latest_checkpoint.pt    # Latest model
│   ├── resume_checkpoint.pt    # For crash recovery
│   ├── training_metadata.json  # Training state
│   └── logs/                   # TensorBoard logs
│
└── onnx_models/                # Exported ONNX models
    └── defect_detection_model.onnx
```

---

## Troubleshooting

### Out of Memory Errors

If you get CUDA out of memory errors:

1. Reduce batch size in `config.yaml`:
   ```yaml
   training:
     batch_size: 1  # Try 1 instead of 2
   ```

2. Use a smaller backbone:
   ```yaml
   model:
     backbone: "resnet34"  # Instead of resnet50
   ```

3. Reduce image size (if possible):
   ```yaml
   model:
     input_size: [1024, 730]  # Half of original
   ```

### Training Not Resuming

If training doesn't resume automatically:

1. Check if checkpoint exists:
   ```batch
   dir checkpoints\resume_checkpoint.pt
   ```

2. Manually specify no-resume:
   ```batch
   python train.py --no-resume
   ```

### ONNX Export Fails

If ONNX export fails:

1. Try a different opset version:
   ```batch
   python export_onnx.py --opset 13
   ```

2. Skip simplification:
   ```batch
   python export_onnx.py --no-simplify
   ```

### Low Recall on Rare Defects

If the model misses rare defects (e.g., "check"):

1. Increase anomaly detection weight:
   ```yaml
   loss:
     anomaly_weight: 2.0  # Increase from 1.0
   ```

2. Lower confidence threshold:
   ```yaml
   model:
     detection:
       min_confidence: 0.2  # Lower from 0.3
   ```

3. Adjust focal loss parameters:
   ```yaml
   loss:
     focal_alpha: 0.5   # Increase from 0.25
     focal_gamma: 3.0   # Increase from 2.0
   ```

---

## Advanced Usage

### Custom Training Script

If you need more control, you can modify the training loop:

```python
from train import Trainer

# Create trainer with custom config
trainer = Trainer('config.yaml', resume=True)

# Access model, optimizer, etc.
model = trainer.model
optimizer = trainer.optimizer

# Run training
trainer.train()
```

### Inference with ONNX

After exporting to ONNX, use it for inference:

```python
import onnxruntime as ort
import numpy as np
from PIL import Image

# Load model
session = ort.InferenceSession('onnx_models/defect_detection_model.onnx')

# Prepare image
image = Image.open('test_image.png')
image = np.array(image).transpose(2, 0, 1)  # HWC to CHW
image = image[np.newaxis, :, :, :].astype(np.float32) / 255.0

# Run inference
boxes, labels, scores = session.run(None, {'input': image})

# Process results
for box, label, score in zip(boxes, labels, scores):
    x1, y1, x2, y2 = box
    class_name = ['chip', 'check'][label]
    print(f"Detected {class_name} at ({x1}, {y1}, {x2}, {y2}) with confidence {score:.2f}")
```

### Export Specific Checkpoint

To export a specific checkpoint instead of the best one:

```python
python export_onnx.py --checkpoint-dir checkpoints --output my_model.onnx
```

---

## Performance Tips

1. **Use Mixed Precision Training**: Already enabled by default, provides ~2x speedup
2. **Increase Batch Size**: If you have more VRAM, increase batch size for faster training
3. **Use Data Augmentation**: Already enabled, helps with generalization
4. **Monitor GPU Usage**: Use `nvidia-smi` to check GPU utilization
5. **Use TensorBoard**: Monitor training in real-time to catch issues early

---

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review the configuration guide
3. Check TensorBoard logs for training issues
4. Verify your dataset format matches Pascal VOC

---

## Technical Details

### Model Architecture

- **Backbone**: ResNet34/50 or EfficientNet for feature extraction
- **Anomaly Head**: SimpleNet-inspired discriminator
- **Segmentation Head**: U-Net style decoder with skip connections
- **Classification Head**: ROI-based classifier with focal loss

### Training Strategy

- **Multi-stage training**: Progressively trains different components
- **Mixed precision**: FP16 training for speed and memory efficiency
- **Gradient clipping**: Prevents exploding gradients
- **Cosine annealing**: Smooth learning rate decay
- **Early stopping**: Prevents overfitting

### ONNX Export

- **Opset 14**: Modern ONNX operators for best compatibility
- **Embedded NMS**: Non-maximum suppression inside the model
- **Dynamic outputs**: Variable number of detections
- **Optimized**: Constant folding and graph optimization

---

## License

This project is provided as-is for defect detection applications.

---

## Version History

- **v1.0**: Initial release with hybrid architecture, crash recovery, and ONNX export
