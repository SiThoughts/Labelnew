"""
Setup script for Hybrid Defect Detection System
Installs all dependencies and verifies the environment
"""

import subprocess
import sys
import os


def run_command(command, description):
    """Run a shell command and handle errors"""
    print(f"\n{'='*60}")
    print(f"{description}")
    print(f"{'='*60}")
    
    try:
        result = subprocess.run(
            command,
            shell=True,
            check=True,
            capture_output=True,
            text=True
        )
        print(result.stdout)
        return True
    except subprocess.CalledProcessError as e:
        print(f"ERROR: {e}")
        print(e.stderr)
        return False


def main():
    print("="*60)
    print("Hybrid Defect Detection - Setup Script")
    print("="*60)
    
    # Check Python version
    print(f"\n[1/3] Python version: {sys.version}")
    if sys.version_info < (3, 8):
        print("ERROR: Python 3.8 or higher is required")
        sys.exit(1)
    
    # Upgrade pip
    if not run_command(
        f"{sys.executable} -m pip install --upgrade pip",
        "[2/3] Upgrading pip..."
    ):
        print("WARNING: Failed to upgrade pip, continuing anyway...")
    
    # Install requirements
    if not run_command(
        f"{sys.executable} -m pip install -r requirements.txt",
        "[3/3] Installing required packages (this may take a few minutes)..."
    ):
        print("ERROR: Failed to install dependencies")
        sys.exit(1)
    
    # Verify PyTorch installation
    print("\n" + "="*60)
    print("Verifying PyTorch CUDA installation...")
    print("="*60)
    
    try:
        import torch
        print(f"PyTorch version: {torch.__version__}")
        print(f"CUDA available: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            print(f"CUDA version: {torch.version.cuda}")
            print(f"GPU device: {torch.cuda.get_device_name(0)}")
        else:
            print("WARNING: CUDA is not available. Training will be slow on CPU.")
    except ImportError:
        print("ERROR: Could not import PyTorch")
        sys.exit(1)
    
    # Success message
    print("\n" + "="*60)
    print("Setup completed successfully!")
    print("="*60)
    print("\nNext steps:")
    print("1. Edit config.yaml and set your dataset path")
    print("2. Run: python train.py")
    print("="*60)


if __name__ == "__main__":
    main()
