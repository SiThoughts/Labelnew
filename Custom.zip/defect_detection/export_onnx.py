"""
Export trained model to ONNX format
Matches exact specification: input="input", outputs=["boxes", "labels", "scores"]
"""

import os
import sys
import yaml
import torch
import onnx
from onnx import helper, TensorProto
import argparse
from pathlib import Path

from model import build_model
from onnx_postprocess import ONNXPostProcessor, ONNXExportWrapper


def export_to_onnx(
    model: torch.nn.Module,
    postprocessor: ONNXPostProcessor,
    output_path: str,
    input_size: tuple,
    opset_version: int = 14,
    simplify: bool = True
) -> None:
    """
    Export model to ONNX format with embedded post-processing
    
    Args:
        model: Trained PyTorch model
        postprocessor: Post-processing module
        output_path: Path to save ONNX file
        input_size: Input image size (width, height)
        opset_version: ONNX opset version
        simplify: Whether to simplify the ONNX model
    """
    print(f"\n{'='*60}")
    print("Exporting Model to ONNX")
    print(f"{'='*60}")
    
    # Set model to eval mode
    model.eval()
    postprocessor.eval()
    
    # Create wrapper that combines model and post-processing
    export_model = ONNXExportWrapper(model, postprocessor)
    export_model.eval()
    
    # Create dummy input
    width, height = input_size
    dummy_input = torch.randn(1, 3, height, width)
    
    print(f"Input shape: {dummy_input.shape}")
    print(f"Input size: {width}x{height}")
    
    # Test forward pass
    print("\nTesting forward pass...")
    with torch.no_grad():
        try:
            boxes, labels, scores = export_model(dummy_input)
            print(f"✓ Forward pass successful")
            print(f"  Output shapes: boxes={boxes.shape}, labels={labels.shape}, scores={scores.shape}")
        except Exception as e:
            print(f"ERROR: Forward pass failed: {e}")
            raise
    
    # Export to ONNX
    print(f"\nExporting to ONNX (opset {opset_version})...")
    
    try:
        torch.onnx.export(
            export_model,
            dummy_input,
            output_path,
            export_params=True,
            opset_version=opset_version,
            do_constant_folding=True,
            input_names=['input'],
            output_names=['boxes', 'labels', 'scores'],
            dynamic_axes={
                'boxes': {0: 'num_detections'},
                'labels': {0: 'num_detections'},
                'scores': {0: 'num_detections'}
            }
        )
        print(f"✓ ONNX export successful: {output_path}")
    except Exception as e:
        print(f"ERROR: ONNX export failed: {e}")
        raise
    
    # Verify the exported model
    print("\nVerifying ONNX model...")
    try:
        verify_onnx_model(output_path, input_size)
        print("✓ ONNX model verification passed")
    except Exception as e:
        print(f"WARNING: ONNX verification failed: {e}")
    
    # Simplify if requested
    if simplify:
        print("\nSimplifying ONNX model...")
        try:
            import onnxsim
            model_onnx = onnx.load(output_path)
            model_simp, check = onnxsim.simplify(model_onnx)
            
            if check:
                simplified_path = output_path.replace('.onnx', '_simplified.onnx')
                onnx.save(model_simp, simplified_path)
                print(f"✓ Simplified model saved: {simplified_path}")
            else:
                print("WARNING: Simplification check failed, keeping original")
        except ImportError:
            print("WARNING: onnxsim not installed, skipping simplification")
        except Exception as e:
            print(f"WARNING: Simplification failed: {e}")
    
    print(f"\n{'='*60}")
    print("Export Complete!")
    print(f"{'='*60}")
    print(f"Model saved to: {output_path}")
    print(f"Input name: 'input'")
    print(f"Output names: 'boxes', 'labels', 'scores'")
    print(f"{'='*60}\n")


def verify_onnx_model(model_path: str, input_size: tuple) -> None:
    """
    Verify that the ONNX model has the correct input/output format
    
    Args:
        model_path: Path to ONNX model
        input_size: Expected input size (width, height)
    """
    model = onnx.load(model_path)
    graph = model.graph
    
    # Check input
    assert len(graph.input) == 1, f"Expected 1 input, got {len(graph.input)}"
    inp = graph.input[0]
    assert inp.name == "input", f"Input name is '{inp.name}', expected 'input'"
    
    # Check input shape
    dims = [d.dim_value if d.dim_value > 0 else -1 for d in inp.type.tensor_type.shape.dim]
    width, height = input_size
    expected_dims = [1, 3, height, width]
    
    # Allow dynamic batch dimension
    if dims[0] == -1:
        dims[0] = 1
    
    print(f"  Input: name='{inp.name}', shape={dims}")
    
    # Check outputs
    output_names = [o.name for o in graph.output]
    expected_outputs = ['boxes', 'labels', 'scores']
    
    assert len(output_names) == 3, f"Expected 3 outputs, got {len(output_names)}"
    assert output_names == expected_outputs, f"Output names are {output_names}, expected {expected_outputs}"
    
    print(f"  Outputs: {output_names}")
    
    # Check output shapes
    for out in graph.output:
        dims = [d.dim_value if d.dim_value > 0 else 'dynamic' for d in out.type.tensor_type.shape.dim]
        print(f"    {out.name}: shape={dims}")


def load_best_model(config: dict, checkpoint_dir: str) -> torch.nn.Module:
    """
    Load the best trained model from checkpoint
    
    Args:
        config: Configuration dictionary
        checkpoint_dir: Directory containing checkpoints
    
    Returns:
        Loaded model
    """
    checkpoint_path = Path(checkpoint_dir) / "best_checkpoint.pt"
    
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"No checkpoint found at {checkpoint_path}")
    
    print(f"Loading model from: {checkpoint_path}")
    
    # Build model
    model = build_model(config)
    
    # Load checkpoint
    checkpoint = torch.load(checkpoint_path, map_location='cpu')
    model.load_state_dict(checkpoint['model_state_dict'])
    
    print(f"✓ Loaded checkpoint from epoch {checkpoint['epoch']}")
    print(f"  Stage: {checkpoint['stage']}")
    print(f"  Metrics: {checkpoint.get('metrics', {})}")
    
    return model


def main():
    parser = argparse.ArgumentParser(description='Export trained model to ONNX')
    parser.add_argument('--config', type=str, default='config.yaml',
                        help='Path to configuration file')
    parser.add_argument('--checkpoint-dir', type=str, default=None,
                        help='Directory containing checkpoints (default: from config)')
    parser.add_argument('--output', type=str, default=None,
                        help='Output ONNX file path (default: from config)')
    parser.add_argument('--opset', type=int, default=14,
                        help='ONNX opset version')
    parser.add_argument('--no-simplify', action='store_true',
                        help='Do not simplify the ONNX model')
    
    args = parser.parse_args()
    
    # Load configuration
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    
    # Get checkpoint directory
    checkpoint_dir = args.checkpoint_dir or config['output']['checkpoint_dir']
    
    # Get output path
    if args.output:
        output_path = args.output
    else:
        onnx_dir = Path(config['output']['onnx_dir'])
        onnx_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(onnx_dir / "defect_detection_model.onnx")
    
    # Load best model
    print("\nLoading trained model...")
    model = load_best_model(config, checkpoint_dir)
    
    # Create post-processor
    print("Creating post-processor...")
    postprocessor = ONNXPostProcessor(config)
    
    # Export to ONNX
    input_size = tuple(config['model']['input_size'])
    
    export_to_onnx(
        model=model,
        postprocessor=postprocessor,
        output_path=output_path,
        input_size=input_size,
        opset_version=args.opset,
        simplify=not args.no_simplify
    )
    
    print("\nYou can now use this ONNX model for inference!")
    print(f"Example usage:")
    print(f"  import onnxruntime as ort")
    print(f"  session = ort.InferenceSession('{output_path}')")
    print(f"  boxes, labels, scores = session.run(None, {{'input': image_array}})")


if __name__ == "__main__":
    main()
