# YOLO Tiling Pipeline for Defect Detection

A complete YOLO training pipeline with automatic tiling support for non-standard image sizes. Designed specifically for chip and check defect detection on EV (2048x1460) and SV (1024x500) images.

## 🎯 Key Features

- **Automatic Tiling**: Handles non-standard input sizes by tiling images during training and inference
- **ONNX Export**: Creates ONNX models with internal tiling logic - no preprocessing required
- **Compatible Interface**: Matches existing inference interface (`input` → `boxes`, `labels`, `scores`)
- **Optimized for Small Defects**: Preserves fine details through high-resolution tiling
- **Two Model Support**: Separate pipelines for EV and SV datasets

## 📁 Project Structure

```
yolo/
├── EV_dataset/                 # Your EV dataset
│   ├── images/
│   │   ├── train/             # EV training images (2048x1460)
│   │   └── val/               # EV validation images
│   └── labels/
│       ├── train/             # YOLO format labels
│       └── val/
├── SV_dataset/                 # Your SV dataset  
│   ├── images/
│   │   ├── train/             # SV training images (1024x500)
│   │   └── val/               # SV validation images
│   └── labels/
│       ├── train/             # YOLO format labels
│       └── val/
├── configs/
│   ├── ev_config.yaml         # EV training configuration
│   └── sv_config.yaml         # SV training configuration
├── custom_yolo.py             # Custom YOLO with tiling support
├── train_ev.py                # EV training script
├── train_sv.py                # SV training script
├── export_onnx.py             # ONNX export with tiling
├── test_onnx.py               # ONNX model testing
├── setup.py                   # Environment setup
├── requirements.txt           # Dependencies
└── README.md                  # This file
```

## 🚀 Quick Start

### 1. Setup Environment

```bash
# Run setup (creates venv and installs dependencies)
python setup.py

# Activate environment
# Windows:
activate.bat
# Linux/Mac:
source activate.sh
```

### 2. Verify Dataset Structure

Ensure your datasets follow this structure:
```
EV_dataset/
├── images/train/    # Your 2048x1460 EV images
├── images/val/      # Validation images
├── labels/train/    # YOLO format (.txt files)
└── labels/val/      # Validation labels

SV_dataset/
├── images/train/    # Your 1024x500 SV images  
├── images/val/      # Validation images
├── labels/train/    # YOLO format (.txt files)
└── labels/val/      # Validation labels
```

### 3. Train Models

```bash
# Train EV model (2048x1460 images)
python train_ev.py

# Train SV model (1024x500 images)  
python train_sv.py

# Optional: Custom parameters
python train_ev.py --epochs 200 --batch 4 --device 0
```

### 4. Export to ONNX

```bash
# Export EV model
python export_onnx.py --model runs/detect/ev_tiled/weights/best.pt --type ev --output ev_model.onnx

# Export SV model
python export_onnx.py --model runs/detect/sv_tiled/weights/best.pt --type sv --output sv_model.onnx
```

### 5. Test ONNX Models

```bash
# Test EV model
python test_onnx.py --model ev_model.onnx --type ev

# Test SV model  
python test_onnx.py --model sv_model.onnx --type sv
```

## 🔧 How It Works

### Training Phase
1. **Automatic Tiling**: Large images are automatically split into 640x640 tiles with overlap
2. **Label Adjustment**: Bounding boxes are adjusted for each tile coordinate system
3. **YOLO Training**: Standard YOLO training on tiled patches
4. **Validation**: Model performance evaluated on tiled validation set

### Inference Phase (ONNX)
1. **Input**: Original size image (2048x1460 or 1024x500)
2. **Internal Tiling**: ONNX model automatically tiles the image
3. **Detection**: Runs YOLO on each tile
4. **Merging**: Combines detections and applies NMS
5. **Output**: Final detections in original image coordinates

## 📊 Configuration

### EV Configuration (`configs/ev_config.yaml`)
- **Original Size**: 2048x1460
- **Tile Size**: 640x640
- **Overlap**: 10%
- **Batch Size**: 8 (adjust for GPU memory)
- **Epochs**: 100

### SV Configuration (`configs/sv_config.yaml`)
- **Original Size**: 1024x500
- **Tile Size**: 640x640  
- **Overlap**: 15% (higher for smaller images)
- **Batch Size**: 16
- **Epochs**: 100

## 🎛️ Advanced Usage

### Custom Training Parameters

```bash
# High-resolution training with more epochs
python train_ev.py --epochs 200 --batch 4

# Resume training from checkpoint
python train_ev.py --resume runs/detect/ev_tiled/weights/last.pt

# CPU training (if no GPU)
python train_ev.py --device cpu
```

### Custom ONNX Export

```bash
# Custom tile size and overlap
python export_onnx.py --model best.pt --type ev --tile-size 512 --overlap 0.2

# Export with custom output path
python export_onnx.py --model best.pt --type ev --output custom_model.onnx
```

## 🔍 ONNX Model Interface

The exported ONNX models are compatible with your existing inference code:

```python
import onnxruntime as ort
import numpy as np

# Load model
session = ort.InferenceSession('ev_model.onnx')

# Prepare input (your original image size)
# image: numpy array [H, W, 3] in range [0, 255]
input_tensor = image.astype(np.float32) / 255.0
input_tensor = np.transpose(input_tensor, (2, 0, 1))  # HWC to CHW
input_tensor = np.expand_dims(input_tensor, axis=0)   # Add batch dim

# Run inference (no preprocessing needed!)
outputs = session.run(['boxes', 'labels', 'scores'], {'input': input_tensor})
boxes, labels, scores = outputs

# boxes: [batch_size, max_detections, 4] - bounding boxes [x1, y1, x2, y2]
# labels: [batch_size, max_detections] - class labels (1=chip, 2=check)  
# scores: [batch_size, max_detections] - confidence scores [0, 1]
```

## 🎯 Class Mapping

- **Class 0** (YOLO) → **Class 1** (ONNX): `chip`
- **Class 1** (YOLO) → **Class 2** (ONNX): `check`

## 🔧 Troubleshooting

### Common Issues

1. **CUDA Out of Memory**
   - Reduce batch size in config files
   - Use smaller model (yolov8n.pt instead of yolov8s.pt)

2. **Poor Detection Performance**
   - Increase training epochs (200+)
   - Check dataset quality and annotations
   - Adjust tile overlap (increase for better coverage)

3. **ONNX Export Fails**
   - Ensure onnx and onnxruntime are installed
   - Try without simplification: comment out onnxsim code

4. **Slow Training**
   - Use GPU if available
   - Increase batch size (if memory allows)
   - Reduce number of workers if CPU bottleneck

### Performance Tips

1. **For Better Accuracy**:
   - Use larger models (yolov8s.pt, yolov8m.pt)
   - Increase tile overlap (0.2-0.3)
   - Train for more epochs (200+)

2. **For Faster Inference**:
   - Use smaller models (yolov8n.pt)
   - Reduce tile overlap (0.05-0.1)
   - Lower confidence threshold

## 📈 Expected Results

### Training Metrics
- **mAP50**: >0.8 for good performance
- **mAP50-95**: >0.5 for good performance
- **Precision/Recall**: >0.8 for production use

### Inference Speed
- **EV Model**: ~2-5 seconds per image (depending on GPU)
- **SV Model**: ~1-3 seconds per image
- **Tile Processing**: 6-12 tiles per EV image, 2-4 tiles per SV image

## 🛠️ System Requirements

### Minimum Requirements
- **Python**: 3.8+
- **RAM**: 16GB
- **Storage**: 50GB free space
- **GPU**: 6GB VRAM (GTX 1060 or better)

### Recommended Requirements  
- **Python**: 3.9+
- **RAM**: 32GB
- **Storage**: 100GB SSD
- **GPU**: 11GB VRAM (GTX 1080Ti or better)

## 📝 License

This project is designed for defect detection applications. Modify and use according to your needs.

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section
2. Verify dataset structure and format
3. Test with smaller batch sizes
4. Check GPU memory usage with `nvidia-smi`

---

**Happy Training! 🚀**

