"""
Test ONNX Model with Tiling
Validates that the exported ONNX model works correctly with the expected interface
"""

import numpy as np
import cv2
import onnxruntime as ort
import argparse
from pathlib import Path
import time

def test_onnx_model(onnx_path, model_type, test_image_path=None):
    """
    Test ONNX model with the expected interface
    
    Args:
        onnx_path: Path to ONNX model
        model_type: 'ev' or 'sv'
        test_image_path: Optional path to test image
    """
    
    print(f"Testing ONNX model: {onnx_path}")
    print(f"Model type: {model_type.upper()}")
    
    # Determine expected input size
    if model_type.lower() == 'ev':
        input_size = (1460, 2048)  # (height, width)
        print(f"Expected input size: 2048x1460 (WxH)")
    elif model_type.lower() == 'sv':
        input_size = (500, 1024)   # (height, width)
        print(f"Expected input size: 1024x500 (WxH)")
    else:
        raise ValueError("model_type must be 'ev' or 'sv'")
    
    # Load ONNX model
    try:
        session = ort.InferenceSession(onnx_path)
        print("✓ ONNX model loaded successfully")
    except Exception as e:
        print(f"❌ Failed to load ONNX model: {e}")
        return False
    
    # Check model inputs/outputs
    inputs = session.get_inputs()
    outputs = session.get_outputs()
    
    print(f"\nModel Information:")
    print(f"  Input name: {inputs[0].name}")
    print(f"  Input shape: {inputs[0].shape}")
    print(f"  Output names: {[output.name for output in outputs]}")
    print(f"  Output shapes: {[output.shape for output in outputs]}")
    
    # Verify interface compatibility
    expected_input_name = 'input'
    expected_output_names = ['boxes', 'labels', 'scores']
    
    if inputs[0].name != expected_input_name:
        print(f"⚠ Warning: Input name is '{inputs[0].name}', expected '{expected_input_name}'")
    
    output_names = [output.name for output in outputs]
    for expected_name in expected_output_names:
        if expected_name not in output_names:
            print(f"⚠ Warning: Output '{expected_name}' not found in model outputs")
    
    # Create test input
    if test_image_path and Path(test_image_path).exists():
        print(f"\nLoading test image: {test_image_path}")
        image = cv2.imread(test_image_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Resize to expected input size
        if image.shape[:2] != input_size:
            print(f"Resizing image from {image.shape[:2]} to {input_size}")
            image = cv2.resize(image, (input_size[1], input_size[0]))
    else:
        print(f"\nCreating synthetic test image: {input_size[1]}x{input_size[0]}")
        # Create synthetic test image
        image = np.random.randint(0, 255, (input_size[0], input_size[1], 3), dtype=np.uint8)
    
    # Prepare input tensor
    input_tensor = image.astype(np.float32) / 255.0  # Normalize to [0, 1]
    input_tensor = np.transpose(input_tensor, (2, 0, 1))  # HWC to CHW
    input_tensor = np.expand_dims(input_tensor, axis=0)  # Add batch dimension
    
    print(f"Input tensor shape: {input_tensor.shape}")
    
    # Run inference
    try:
        print("\nRunning inference...")
        start_time = time.time()
        
        outputs = session.run(['boxes', 'labels', 'scores'], {'input': input_tensor})
        
        inference_time = time.time() - start_time
        print(f"✓ Inference completed in {inference_time:.3f} seconds")
        
        # Parse outputs
        boxes, labels, scores = outputs
        
        print(f"\nInference Results:")
        print(f"  Boxes shape: {boxes.shape}")
        print(f"  Labels shape: {labels.shape}")
        print(f"  Scores shape: {scores.shape}")
        
        # Count valid detections
        valid_detections = np.sum(scores[0] > 0.25)  # Confidence threshold
        print(f"  Valid detections (conf > 0.25): {valid_detections}")
        
        if valid_detections > 0:
            print(f"  Detection details:")
            for i in range(min(5, valid_detections)):  # Show first 5 detections
                if scores[0][i] > 0.25:
                    box = boxes[0][i]
                    label = labels[0][i]
                    score = scores[0][i]
                    class_name = "chip" if label == 1 else "check" if label == 2 else f"class_{label}"
                    print(f"    Detection {i+1}: {class_name} (conf: {score:.3f}) bbox: [{box[0]:.1f}, {box[1]:.1f}, {box[2]:.1f}, {box[3]:.1f}]")
        
        # Verify output format
        batch_size, max_detections, bbox_dims = boxes.shape
        if bbox_dims != 4:
            print(f"⚠ Warning: Expected 4 bbox coordinates, got {bbox_dims}")
        
        if labels.shape != (batch_size, max_detections):
            print(f"⚠ Warning: Labels shape mismatch")
        
        if scores.shape != (batch_size, max_detections):
            print(f"⚠ Warning: Scores shape mismatch")
        
        print("\n✓ ONNX model test completed successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Inference failed: {e}")
        return False

def main():
    parser = argparse.ArgumentParser(description='Test ONNX model with tiling support')
    parser.add_argument('--model', type=str, required=True,
                       help='Path to ONNX model file')
    parser.add_argument('--type', type=str, required=True, choices=['ev', 'sv'],
                       help='Model type: ev or sv')
    parser.add_argument('--image', type=str, default=None,
                       help='Optional test image path')
    
    args = parser.parse_args()
    
    print("="*60)
    print("ONNX MODEL TESTING")
    print("="*60)
    
    success = test_onnx_model(args.model, args.type, args.image)
    
    if success:
        print("\n🎉 All tests passed! The ONNX model is ready for deployment.")
        print("\nUsage in your existing system:")
        print("```python")
        print("import onnxruntime as ort")
        print("import numpy as np")
        print("")
        print("# Load model")
        print(f"session = ort.InferenceSession('{args.model}')")
        print("")
        print("# Prepare input (your original image size)")
        print("# input_image: numpy array with shape [H, W, 3]")
        print("input_tensor = input_image.astype(np.float32) / 255.0")
        print("input_tensor = np.transpose(input_tensor, (2, 0, 1))")
        print("input_tensor = np.expand_dims(input_tensor, axis=0)")
        print("")
        print("# Run inference")
        print("outputs = session.run(['boxes', 'labels', 'scores'], {'input': input_tensor})")
        print("boxes, labels, scores = outputs")
        print("```")
    else:
        print("\n❌ Tests failed. Please check the model and try again.")

if __name__ == "__main__":
    main()

