"""
Setup Script for YOLO Tiling Pipeline
Installs dependencies and sets up the environment
"""

import subprocess
import sys
import os
from pathlib import Path

def run_command(command, description):
    """Run a command and handle errors"""
    print(f"\n{description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✓ {description} completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed:")
        print(f"Error: {e.stderr}")
        return False

def check_python_version():
    """Check if Python version is compatible"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print(f"❌ Python {version.major}.{version.minor} is not supported")
        print("Please use Python 3.8 or higher")
        return False
    
    print(f"✓ Python {version.major}.{version.minor}.{version.micro} is compatible")
    return True

def setup_virtual_environment():
    """Create and activate virtual environment"""
    venv_path = Path("venv")
    
    if venv_path.exists():
        print("✓ Virtual environment already exists")
        return True
    
    # Create virtual environment
    if not run_command(f"{sys.executable} -m venv venv", "Creating virtual environment"):
        return False
    
    return True

def install_requirements():
    """Install required packages"""
    # Determine pip command based on OS
    if os.name == 'nt':  # Windows
        pip_cmd = "venv\\Scripts\\pip"
        python_cmd = "venv\\Scripts\\python"
    else:  # Linux/Mac
        pip_cmd = "venv/bin/pip"
        python_cmd = "venv/bin/python"
    
    # Upgrade pip first
    if not run_command(f"{pip_cmd} install --upgrade pip", "Upgrading pip"):
        return False
    
    # Install PyTorch with CUDA support (for Windows with CUDA)
    if os.name == 'nt':
        torch_cmd = f"{pip_cmd} install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118"
        if not run_command(torch_cmd, "Installing PyTorch with CUDA support"):
            # Fallback to CPU version
            torch_cmd = f"{pip_cmd} install torch torchvision torchaudio"
            if not run_command(torch_cmd, "Installing PyTorch (CPU version)"):
                return False
    
    # Install other requirements
    if not run_command(f"{pip_cmd} install -r requirements.txt", "Installing requirements"):
        return False
    
    return True

def verify_installation():
    """Verify that key packages are installed correctly"""
    if os.name == 'nt':  # Windows
        python_cmd = "venv\\Scripts\\python"
    else:  # Linux/Mac
        python_cmd = "venv/bin/python"
    
    test_script = """
import torch
import ultralytics
import onnx
import cv2
import numpy as np

print(f"PyTorch version: {torch.__version__}")
print(f"CUDA available: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"CUDA version: {torch.version.cuda}")
    print(f"GPU: {torch.cuda.get_device_name(0)}")

print(f"Ultralytics version: {ultralytics.__version__}")
print(f"ONNX version: {onnx.__version__}")
print(f"OpenCV version: {cv2.__version__}")
print(f"NumPy version: {np.__version__}")

print("✓ All packages imported successfully!")
"""
    
    with open("test_installation.py", "w") as f:
        f.write(test_script)
    
    success = run_command(f"{python_cmd} test_installation.py", "Verifying installation")
    
    # Clean up test file
    if os.path.exists("test_installation.py"):
        os.remove("test_installation.py")
    
    return success

def create_activation_scripts():
    """Create convenient activation scripts"""
    
    # Windows batch file
    windows_script = """@echo off
echo Activating YOLO Tiling Pipeline environment...
call venv\\Scripts\\activate.bat
echo.
echo Environment activated! Available commands:
echo   python train_ev.py          - Train EV model
echo   python train_sv.py          - Train SV model  
echo   python export_onnx.py       - Export to ONNX
echo   python test_onnx.py         - Test ONNX model
echo.
"""
    
    with open("activate.bat", "w") as f:
        f.write(windows_script)
    
    # Linux/Mac shell script
    linux_script = """#!/bin/bash
echo "Activating YOLO Tiling Pipeline environment..."
source venv/bin/activate
echo ""
echo "Environment activated! Available commands:"
echo "  python train_ev.py          - Train EV model"
echo "  python train_sv.py          - Train SV model"
echo "  python export_onnx.py       - Export to ONNX"
echo "  python test_onnx.py         - Test ONNX model"
echo ""
"""
    
    with open("activate.sh", "w") as f:
        f.write(linux_script)
    
    # Make shell script executable
    if os.name != 'nt':
        os.chmod("activate.sh", 0o755)
    
    print("✓ Activation scripts created")

def main():
    """Main setup function"""
    print("="*60)
    print("YOLO TILING PIPELINE SETUP")
    print("="*60)
    
    # Check Python version
    if not check_python_version():
        return False
    
    # Setup virtual environment
    if not setup_virtual_environment():
        return False
    
    # Install requirements
    if not install_requirements():
        return False
    
    # Verify installation
    if not verify_installation():
        return False
    
    # Create activation scripts
    create_activation_scripts()
    
    print("\n" + "="*60)
    print("SETUP COMPLETED SUCCESSFULLY!")
    print("="*60)
    print("Next steps:")
    print("1. Activate the environment:")
    if os.name == 'nt':
        print("   activate.bat")
    else:
        print("   source activate.sh")
    print("2. Verify your dataset structure:")
    print("   - EV_dataset/images/{train,val}/")
    print("   - EV_dataset/labels/{train,val}/")
    print("   - SV_dataset/images/{train,val}/")
    print("   - SV_dataset/labels/{train,val}/")
    print("3. Start training:")
    print("   python train_ev.py")
    print("   python train_sv.py")
    print("4. Export to ONNX:")
    print("   python export_onnx.py --model path/to/best.pt --type ev")
    print("="*60)
    
    return True

if __name__ == "__main__":
    success = main()
    if not success:
        print("\n❌ Setup failed. Please check the errors above and try again.")
        sys.exit(1)
    else:
        print("\n🎉 Setup completed successfully!")

