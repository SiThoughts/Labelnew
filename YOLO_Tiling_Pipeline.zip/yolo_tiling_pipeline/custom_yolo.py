"""
Custom YOLO Implementation with Automatic Tiling
Handles non-standard input sizes by tiling images during training and inference
"""

import torch
import torch.nn as nn
import numpy as np
from ultralytics import YOLO
from ultralytics.models.yolo.detect import DetectionTrainer
from ultralytics.data import YOLODataset
from ultralytics.utils import ops
import cv2
from pathlib import Path
import yaml
from typing import List, Tuple, Dict, Any
import math

class TiledYOLODataset(YOLODataset):
    """Custom YOLO dataset that automatically tiles large images"""
    
    def __init__(self, *args, tile_size=640, overlap=0.1, **kwargs):
        self.tile_size = tile_size
        self.overlap = overlap
        self.original_shapes = {}
        super().__init__(*args, **kwargs)
    
    def get_image_and_label(self, index):
        """Override to implement tiling"""
        # Get original image and labels
        label = self.get_label_info(index)
        img = self.load_image(index)
        
        # Store original shape
        h, w = img.shape[:2]
        self.original_shapes[index] = (h, w)
        
        # Generate tiles
        tiles_data = self.create_tiles(img, label, index)
        
        # Return first tile (we'll handle multiple tiles in training loop)
        if tiles_data:
            return tiles_data[0]['image'], tiles_data[0]['label']
        else:
            # Fallback to original if no tiles
            return img, label
    
    def create_tiles(self, image, label, index):
        """Create overlapping tiles from large image"""
        h, w = image.shape[:2]
        tiles_data = []
        
        # Calculate step size with overlap
        step = int(self.tile_size * (1 - self.overlap))
        
        # Generate tile coordinates
        y_coords = list(range(0, h - self.tile_size + 1, step))
        x_coords = list(range(0, w - self.tile_size + 1, step))
        
        # Add final tiles to cover edges
        if y_coords[-1] + self.tile_size < h:
            y_coords.append(h - self.tile_size)
        if x_coords[-1] + self.tile_size < w:
            x_coords.append(w - self.tile_size)
        
        tile_id = 0
        for y in y_coords:
            for x in x_coords:
                # Extract tile
                tile_img = image[y:y+self.tile_size, x:x+self.tile_size]
                
                # Adjust labels for this tile
                tile_label = self.adjust_labels_for_tile(label, x, y, self.tile_size)
                
                if len(tile_label['bboxes']) > 0:  # Only keep tiles with annotations
                    tiles_data.append({
                        'image': tile_img,
                        'label': tile_label,
                        'tile_coords': (x, y),
                        'tile_id': f"{index}_{tile_id}"
                    })
                    tile_id += 1
        
        return tiles_data
    
    def adjust_labels_for_tile(self, label, tile_x, tile_y, tile_size):
        """Adjust bounding box coordinates for tile"""
        if 'bboxes' not in label or len(label['bboxes']) == 0:
            return {'bboxes': np.array([]), 'cls': np.array([])}
        
        bboxes = label['bboxes'].copy()
        cls = label['cls'].copy()
        
        # Convert from normalized to absolute coordinates
        h, w = label.get('orig_shape', (tile_size, tile_size))
        bboxes[:, [0, 2]] *= w  # x coordinates
        bboxes[:, [1, 3]] *= h  # y coordinates
        
        # Adjust for tile offset
        bboxes[:, [0, 2]] -= tile_x  # x coordinates
        bboxes[:, [1, 3]] -= tile_y  # y coordinates
        
        # Filter boxes that are within tile bounds
        valid_boxes = []
        valid_cls = []
        
        for i, bbox in enumerate(bboxes):
            x_center, y_center, width, height = bbox
            
            # Check if box center is within tile
            if (0 <= x_center <= tile_size and 0 <= y_center <= tile_size):
                # Clip box to tile boundaries
                x_min = max(0, x_center - width/2)
                y_min = max(0, y_center - height/2)
                x_max = min(tile_size, x_center + width/2)
                y_max = min(tile_size, y_center + height/2)
                
                # Recalculate center and size
                new_width = x_max - x_min
                new_height = y_max - y_min
                new_x_center = x_min + new_width/2
                new_y_center = y_min + new_height/2
                
                # Normalize to tile size
                new_x_center /= tile_size
                new_y_center /= tile_size
                new_width /= tile_size
                new_height /= tile_size
                
                # Only keep if box is large enough
                if new_width > 0.01 and new_height > 0.01:
                    valid_boxes.append([new_x_center, new_y_center, new_width, new_height])
                    valid_cls.append(cls[i])
        
        return {
            'bboxes': np.array(valid_boxes) if valid_boxes else np.array([]),
            'cls': np.array(valid_cls) if valid_cls else np.array([])
        }

class TiledYOLOTrainer(DetectionTrainer):
    """Custom YOLO trainer that handles tiled datasets"""
    
    def build_dataset(self, img_path, mode="train", batch=None):
        """Build dataset with tiling support"""
        gs = max(int(self.model.stride.max() if self.model else 0), 32)
        return TiledYOLODataset(
            img_path=img_path,
            imgsz=self.args.imgsz,
            batch_size=self.args.batch,
            augment=mode == "train",
            hyp=self.hyp,
            rect=False,  # Disable rectangular training for tiled images
            cache=self.args.cache or None,
            single_cls=self.args.single_cls or False,
            stride=gs,
            pad=0.0,
            prefix=f"{mode}: ",
            task=self.args.task,
            classes=self.args.classes,
            data=self.data,
            fraction=self.args.fraction if mode == "train" else 1.0,
            tile_size=640,  # Standard YOLO input size
            overlap=0.1     # 10% overlap between tiles
        )

class TiledYOLO(YOLO):
    """Custom YOLO model with tiling support"""
    
    def __init__(self, model="yolov8n.pt", task=None, verbose=True):
        super().__init__(model, task, verbose)
        self.trainer_class = TiledYOLOTrainer
    
    def train(self, trainer=None, **kwargs):
        """Train with custom tiled trainer"""
        if trainer is None:
            trainer = self.trainer_class
        return super().train(trainer=trainer, **kwargs)
    
    def predict_tiled(self, source, imgsz=(2048, 1460), tile_size=640, overlap=0.1, **kwargs):
        """
        Predict on images using tiling approach
        This method will be replaced by ONNX export for production use
        """
        if isinstance(source, (str, Path)):
            # Load image
            img = cv2.imread(str(source))
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        else:
            img = source
        
        # Resize to target size if needed
        if img.shape[:2] != imgsz:
            img = cv2.resize(img, (imgsz[1], imgsz[0]))
        
        h, w = img.shape[:2]
        step = int(tile_size * (1 - overlap))
        
        all_detections = []
        
        # Generate tiles
        y_coords = list(range(0, h - tile_size + 1, step))
        x_coords = list(range(0, w - tile_size + 1, step))
        
        # Add final tiles to cover edges
        if y_coords[-1] + tile_size < h:
            y_coords.append(h - tile_size)
        if x_coords[-1] + tile_size < w:
            x_coords.append(w - tile_size)
        
        for y in y_coords:
            for x in x_coords:
                # Extract tile
                tile = img[y:y+tile_size, x:x+tile_size]
                
                # Run prediction on tile
                results = self.predict(tile, **kwargs)
                
                # Adjust coordinates back to original image
                for result in results:
                    if result.boxes is not None:
                        boxes = result.boxes.xyxy.cpu().numpy()
                        scores = result.boxes.conf.cpu().numpy()
                        classes = result.boxes.cls.cpu().numpy()
                        
                        # Adjust coordinates
                        boxes[:, [0, 2]] += x  # x coordinates
                        boxes[:, [1, 3]] += y  # y coordinates
                        
                        for i in range(len(boxes)):
                            all_detections.append({
                                'bbox': boxes[i],
                                'score': scores[i],
                                'class': int(classes[i])
                            })
        
        # Apply NMS to merged detections
        if all_detections:
            boxes = np.array([det['bbox'] for det in all_detections])
            scores = np.array([det['score'] for det in all_detections])
            classes = np.array([det['class'] for det in all_detections])
            
            # Convert to torch tensors for NMS
            boxes_tensor = torch.from_numpy(boxes).float()
            scores_tensor = torch.from_numpy(scores).float()
            
            # Apply NMS
            keep_indices = ops.non_max_suppression(
                torch.cat([boxes_tensor, scores_tensor.unsqueeze(1), classes.unsqueeze(1)], dim=1).unsqueeze(0),
                conf_thres=kwargs.get('conf', 0.25),
                iou_thres=kwargs.get('iou', 0.45)
            )[0]
            
            if len(keep_indices) > 0:
                final_boxes = boxes[keep_indices.cpu().numpy()]
                final_scores = scores[keep_indices.cpu().numpy()]
                final_classes = classes[keep_indices.cpu().numpy()]
                
                return {
                    'boxes': final_boxes,
                    'scores': final_scores,
                    'labels': final_classes + 1  # Convert to 1-indexed for compatibility
                }
        
        return {
            'boxes': np.array([]),
            'scores': np.array([]),
            'labels': np.array([])
        }

def create_tiled_model(model_path="yolov8n.pt"):
    """Create a new tiled YOLO model"""
    return TiledYOLO(model_path)

if __name__ == "__main__":
    # Test the tiled model
    model = create_tiled_model()
    print("Tiled YOLO model created successfully!")
    print(f"Model type: {type(model)}")
    print(f"Trainer type: {model.trainer_class}")

