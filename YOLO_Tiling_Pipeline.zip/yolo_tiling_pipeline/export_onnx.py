"""
Custom ONNX Export with Internal Tiling Logic
Creates ONNX models that can handle non-standard input sizes internally
Compatible with existing inference interface: input=['input'], output=['boxes', 'labels', 'scores']
"""

import torch
import torch.nn as nn
import numpy as np
import onnx
import onnxsim
from pathlib import Path
import argparse
import yaml
from ultralytics import YOLO
from ultralytics.nn.modules import Detect
from ultralytics.utils import ops
import cv2

class TiledYOLOONNX(nn.Module):
    """
    ONNX-compatible YOLO model with internal tiling logic
    Handles non-standard input sizes by tiling internally
    """
    
    def __init__(self, yolo_model, original_size, tile_size=640, overlap=0.1, conf_thres=0.25, iou_thres=0.45):
        super().__init__()
        self.yolo_model = yolo_model.model
        self.original_size = original_size  # [height, width]
        self.tile_size = tile_size
        self.overlap = overlap
        self.conf_thres = conf_thres
        self.iou_thres = iou_thres
        
        # Calculate tiling parameters
        self.setup_tiling_params()
        
    def setup_tiling_params(self):
        """Calculate tiling parameters"""
        h, w = self.original_size
        step = int(self.tile_size * (1 - self.overlap))
        
        # Calculate tile positions
        y_coords = list(range(0, h - self.tile_size + 1, step))
        x_coords = list(range(0, w - self.tile_size + 1, step))
        
        # Add final tiles to cover edges
        if y_coords[-1] + self.tile_size < h:
            y_coords.append(h - self.tile_size)
        if x_coords[-1] + self.tile_size < w:
            x_coords.append(w - self.tile_size)
        
        # Store as tensors for ONNX compatibility
        self.register_buffer('y_coords', torch.tensor(y_coords, dtype=torch.long))
        self.register_buffer('x_coords', torch.tensor(x_coords, dtype=torch.long))
        self.num_tiles = len(y_coords) * len(x_coords)
        
    def extract_tile(self, image, x, y):
        """Extract a tile from the image"""
        return image[:, :, y:y+self.tile_size, x:x+self.tile_size]
    
    def adjust_detections(self, detections, tile_x, tile_y):
        """Adjust detection coordinates from tile to original image space"""
        if detections.shape[0] == 0:
            return detections
        
        # Adjust bounding box coordinates
        detections[:, 0] += tile_x  # x1
        detections[:, 1] += tile_y  # y1
        detections[:, 2] += tile_x  # x2
        detections[:, 3] += tile_y  # y2
        
        return detections
    
    def forward(self, x):
        """
        Forward pass with internal tiling
        Input: [batch_size, 3, height, width] - original image size
        Output: boxes, labels, scores - compatible with existing interface
        """
        batch_size = x.shape[0]
        device = x.device
        
        # Resize input to original size if needed
        if x.shape[2:] != tuple(self.original_size):
            x = torch.nn.functional.interpolate(x, size=self.original_size, mode='bilinear', align_corners=False)
        
        all_detections = []
        
        # Process each image in batch
        for b in range(batch_size):
            image = x[b:b+1]  # Keep batch dimension
            batch_detections = []
            
            # Process each tile
            for y_idx in range(len(self.y_coords)):
                for x_idx in range(len(self.x_coords)):
                    tile_y = self.y_coords[y_idx].item()
                    tile_x = self.x_coords[x_idx].item()
                    
                    # Extract tile
                    tile = self.extract_tile(image, tile_x, tile_y)
                    
                    # Run YOLO on tile
                    with torch.no_grad():
                        tile_output = self.yolo_model(tile)
                    
                    # Process YOLO output
                    if isinstance(tile_output, (list, tuple)):
                        tile_output = tile_output[0]
                    
                    # Apply NMS to tile detections
                    tile_detections = ops.non_max_suppression(
                        tile_output,
                        conf_thres=self.conf_thres,
                        iou_thres=self.iou_thres,
                        max_det=300
                    )[0]
                    
                    if tile_detections.shape[0] > 0:
                        # Adjust coordinates to original image space
                        adjusted_detections = self.adjust_detections(tile_detections.clone(), tile_x, tile_y)
                        batch_detections.append(adjusted_detections)
            
            # Merge all tile detections for this image
            if batch_detections:
                merged_detections = torch.cat(batch_detections, dim=0)
                
                # Apply final NMS to merged detections
                final_detections = ops.non_max_suppression(
                    merged_detections.unsqueeze(0),
                    conf_thres=self.conf_thres,
                    iou_thres=self.iou_thres,
                    max_det=300
                )[0]
                
                all_detections.append(final_detections)
            else:
                # No detections found
                all_detections.append(torch.zeros((0, 6), device=device))
        
        # Format output to match existing interface
        return self.format_output(all_detections, batch_size, device)
    
    def format_output(self, all_detections, batch_size, device):
        """
        Format output to match existing interface:
        boxes: [batch_size, max_detections, 4]
        labels: [batch_size, max_detections]  
        scores: [batch_size, max_detections]
        """
        max_detections = 100  # Maximum number of detections per image
        
        # Initialize output tensors
        boxes = torch.zeros((batch_size, max_detections, 4), device=device)
        labels = torch.zeros((batch_size, max_detections), dtype=torch.long, device=device)
        scores = torch.zeros((batch_size, max_detections), device=device)
        
        for b, detections in enumerate(all_detections):
            if detections.shape[0] > 0:
                num_dets = min(detections.shape[0], max_detections)
                
                # Extract boxes (x1, y1, x2, y2)
                boxes[b, :num_dets] = detections[:num_dets, :4]
                
                # Extract scores
                scores[b, :num_dets] = detections[:num_dets, 4]
                
                # Extract labels (convert to 1-indexed)
                labels[b, :num_dets] = detections[:num_dets, 5].long() + 1
        
        return boxes, labels, scores

def create_tiled_onnx_model(model_path, model_type, output_path, tile_size=640, overlap=0.1):
    """
    Create ONNX model with internal tiling logic
    
    Args:
        model_path: Path to trained YOLO model (.pt file)
        model_type: 'ev' or 'sv' to determine input size
        output_path: Path to save ONNX model
        tile_size: Size of tiles for processing
        overlap: Overlap between tiles (0.0 to 1.0)
    """
    
    # Load trained YOLO model
    yolo_model = YOLO(model_path)
    
    # Determine original image size based on model type
    if model_type.lower() == 'ev':
        original_size = [1460, 2048]  # [height, width]
    elif model_type.lower() == 'sv':
        original_size = [500, 1024]   # [height, width]
    else:
        raise ValueError("model_type must be 'ev' or 'sv'")
    
    print(f"Creating tiled ONNX model for {model_type.upper()} images")
    print(f"Original size: {original_size[1]}x{original_size[0]} (WxH)")
    print(f"Tile size: {tile_size}x{tile_size}")
    print(f"Overlap: {overlap*100:.1f}%")
    
    # Create tiled model
    tiled_model = TiledYOLOONNX(
        yolo_model=yolo_model,
        original_size=original_size,
        tile_size=tile_size,
        overlap=overlap
    )
    
    # Set to evaluation mode
    tiled_model.eval()
    
    # Create dummy input
    dummy_input = torch.randn(1, 3, original_size[0], original_size[1])
    
    print("Exporting to ONNX...")
    
    # Export to ONNX
    torch.onnx.export(
        tiled_model,
        dummy_input,
        output_path,
        export_params=True,
        opset_version=11,
        do_constant_folding=True,
        input_names=['input'],
        output_names=['boxes', 'labels', 'scores'],
        dynamic_axes={
            'input': {0: 'batch_size'},
            'boxes': {0: 'batch_size'},
            'labels': {0: 'batch_size'},
            'scores': {0: 'batch_size'}
        }
    )
    
    print(f"ONNX model saved to: {output_path}")
    
    # Simplify ONNX model
    try:
        print("Simplifying ONNX model...")
        model_onnx = onnx.load(output_path)
        model_simp, check = onnxsim.simplify(model_onnx)
        onnx.save(model_simp, output_path)
        print("✓ ONNX model simplified successfully")
    except Exception as e:
        print(f"⚠ ONNX simplification failed: {e}")
        print("Model exported but not simplified")
    
    # Verify ONNX model
    try:
        import onnxruntime as ort
        print("Verifying ONNX model...")
        
        session = ort.InferenceSession(output_path)
        
        # Check input/output shapes
        input_shape = session.get_inputs()[0].shape
        output_shapes = [output.shape for output in session.get_outputs()]
        
        print(f"✓ Input shape: {input_shape}")
        print(f"✓ Output shapes: {output_shapes}")
        
        # Test inference
        test_input = np.random.randn(1, 3, original_size[0], original_size[1]).astype(np.float32)
        outputs = session.run(['boxes', 'labels', 'scores'], {'input': test_input})
        
        print(f"✓ Test inference successful")
        print(f"  Boxes shape: {outputs[0].shape}")
        print(f"  Labels shape: {outputs[1].shape}")
        print(f"  Scores shape: {outputs[2].shape}")
        
    except ImportError:
        print("⚠ onnxruntime not available, skipping verification")
    except Exception as e:
        print(f"⚠ ONNX verification failed: {e}")
    
    return output_path

def main():
    parser = argparse.ArgumentParser(description='Export YOLO model to ONNX with tiling support')
    parser.add_argument('--model', type=str, required=True, 
                       help='Path to trained YOLO model (.pt file)')
    parser.add_argument('--type', type=str, required=True, choices=['ev', 'sv'],
                       help='Model type: ev (2048x1460) or sv (1024x500)')
    parser.add_argument('--output', type=str, default=None,
                       help='Output ONNX file path (default: auto-generated)')
    parser.add_argument('--tile-size', type=int, default=640,
                       help='Tile size for processing (default: 640)')
    parser.add_argument('--overlap', type=float, default=0.1,
                       help='Overlap between tiles (default: 0.1)')
    
    args = parser.parse_args()
    
    # Generate output path if not provided
    if args.output is None:
        model_path = Path(args.model)
        args.output = model_path.parent / f"{model_path.stem}_{args.type}_tiled.onnx"
    
    print("="*60)
    print("YOLO TO ONNX EXPORT WITH TILING")
    print("="*60)
    
    # Export model
    output_path = create_tiled_onnx_model(
        model_path=args.model,
        model_type=args.type,
        output_path=args.output,
        tile_size=args.tile_size,
        overlap=args.overlap
    )
    
    print("\n" + "="*60)
    print("EXPORT COMPLETED SUCCESSFULLY!")
    print("="*60)
    print(f"ONNX model: {output_path}")
    print(f"Model type: {args.type.upper()}")
    print(f"Compatible with existing interface:")
    print(f"  Input: 'input' - shape [batch, 3, H, W]")
    print(f"  Outputs: 'boxes', 'labels', 'scores'")
    print(f"  Internal tiling: {args.tile_size}x{args.tile_size} with {args.overlap*100:.1f}% overlap")

if __name__ == "__main__":
    main()

