"""
EV Dataset Training Script with Tiling Support
Trains YOLO model on EV images (2048x1460) using automatic tiling
"""

import os
import sys
from pathlib import Path
import yaml
import torch
from custom_yolo import TiledYOLO
import argparse

def main():
    parser = argparse.ArgumentParser(description='Train YOLO model on EV dataset with tiling')
    parser.add_argument('--config', type=str, default='configs/ev_config.yaml', 
                       help='Path to config file')
    parser.add_argument('--epochs', type=int, default=None, 
                       help='Number of training epochs (overrides config)')
    parser.add_argument('--batch', type=int, default=None, 
                       help='Batch size (overrides config)')
    parser.add_argument('--device', type=str, default=None, 
                       help='Device to use (overrides config)')
    parser.add_argument('--resume', type=str, default=None, 
                       help='Resume training from checkpoint')
    
    args = parser.parse_args()
    
    # Load configuration
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    
    # Override config with command line arguments
    if args.epochs is not None:
        config['epochs'] = args.epochs
    if args.batch is not None:
        config['batch'] = args.batch
    if args.device is not None:
        config['device'] = args.device
    
    print("="*60)
    print("EV DATASET TRAINING WITH TILING")
    print("="*60)
    print(f"Configuration: {args.config}")
    print(f"Original image size: {config['original_size']}")
    print(f"Tile size: {config['tile_size']}")
    print(f"Overlap: {config['overlap']}")
    print(f"Epochs: {config['epochs']}")
    print(f"Batch size: {config['batch']}")
    print(f"Device: {config['device']}")
    print("="*60)
    
    # Verify dataset structure
    dataset_path = Path(config['path'])
    train_images = dataset_path / config['train']
    train_labels = dataset_path / 'labels' / 'train'
    val_images = dataset_path / config['val']
    val_labels = dataset_path / 'labels' / 'val'
    
    print("Verifying dataset structure...")
    for path, name in [(train_images, "Training images"), 
                       (train_labels, "Training labels"),
                       (val_images, "Validation images"), 
                       (val_labels, "Validation labels")]:
        if path.exists():
            count = len(list(path.glob('*')))
            print(f"✓ {name}: {count} files found in {path}")
        else:
            print(f"✗ {name}: Directory not found - {path}")
            return
    
    # Check for GPU availability
    if torch.cuda.is_available():
        print(f"✓ CUDA available: {torch.cuda.get_device_name(0)}")
        print(f"✓ GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
    else:
        print("⚠ CUDA not available, using CPU")
        config['device'] = 'cpu'
    
    # Create tiled YOLO model
    print("\nInitializing Tiled YOLO model...")
    model = TiledYOLO(config['model'])
    
    # Prepare training arguments
    train_args = {
        'data': args.config,
        'epochs': config['epochs'],
        'batch': config['batch'],
        'imgsz': config['imgsz'],
        'device': config['device'],
        'workers': config['workers'],
        'project': config['project'],
        'name': config['name'],
        'lr0': config['lr0'],
        'lrf': config['lrf'],
        'momentum': config['momentum'],
        'weight_decay': config['weight_decay'],
        'warmup_epochs': config['warmup_epochs'],
        'warmup_momentum': config['warmup_momentum'],
        'warmup_bias_lr': config['warmup_bias_lr'],
        'box': config['box'],
        'cls': config['cls'],
        'dfl': config['dfl'],
        'hsv_h': config['hsv_h'],
        'hsv_s': config['hsv_s'],
        'hsv_v': config['hsv_v'],
        'degrees': config['degrees'],
        'translate': config['translate'],
        'scale': config['scale'],
        'shear': config['shear'],
        'perspective': config['perspective'],
        'flipud': config['flipud'],
        'fliplr': config['fliplr'],
        'mosaic': config['mosaic'],
        'mixup': config['mixup'],
        'val': config['val'],
        'save_period': config['save_period'],
        'patience': config['patience']
    }
    
    # Add resume if specified
    if args.resume:
        train_args['resume'] = args.resume
        print(f"Resuming training from: {args.resume}")
    
    print("\nStarting training...")
    print("Note: Training will automatically tile large images into 640x640 patches")
    print("This preserves small defect details while maintaining YOLO compatibility")
    print("-" * 60)
    
    try:
        # Start training
        results = model.train(**train_args)
        
        print("\n" + "="*60)
        print("TRAINING COMPLETED SUCCESSFULLY!")
        print("="*60)
        print(f"Best model saved to: {results.save_dir}/weights/best.pt")
        print(f"Last model saved to: {results.save_dir}/weights/last.pt")
        print(f"Training results: {results.save_dir}")
        
        # Print training metrics
        if hasattr(results, 'results_dict'):
            metrics = results.results_dict
            print("\nFinal Metrics:")
            for key, value in metrics.items():
                if isinstance(value, (int, float)):
                    print(f"  {key}: {value:.4f}")
        
        print("\nNext steps:")
        print("1. Review training results in the results directory")
        print("2. Run validation: python validate_ev.py")
        print("3. Export to ONNX: python export_onnx.py --model path/to/best.pt --type ev")
        
        return results.save_dir / 'weights' / 'best.pt'
        
    except Exception as e:
        print(f"\n❌ Training failed with error: {e}")
        print("\nTroubleshooting tips:")
        print("1. Check GPU memory (reduce batch size if needed)")
        print("2. Verify dataset paths and structure")
        print("3. Ensure YOLO dependencies are installed")
        raise

if __name__ == "__main__":
    best_model_path = main()
    print(f"\nTraining completed. Best model: {best_model_path}")

