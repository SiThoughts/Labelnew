#!/usr/bin/env python3
"""
Dataset Validation Script for YOLOv8 Defect Detection
Validates the dataset structure and provides statistics for tiny defect detection.
"""

import os
import cv2
import numpy as np
import yaml
from pathlib import Path
from collections import defaultdict
import matplotlib.pyplot as plt
from typing import Dict, List, Tuple, Optional
import json

class DatasetValidator:
    """Validates YOLO dataset structure and analyzes defect characteristics."""
    
    def __init__(self, dataset_config_path: str):
        """Initialize validator with dataset configuration."""
        self.config_path = dataset_config_path
        self.config = self._load_config()
        self.dataset_path = Path(self.config['path'])
        self.stats = defaultdict(dict)
        
    def _load_config(self) -> Dict:
        """Load dataset configuration from YAML file."""
        try:
            with open(self.config_path, 'r') as f:
                config = yaml.safe_load(f)
            return config
        except Exception as e:
            raise ValueError(f"Failed to load dataset config: {e}")
    
    def validate_structure(self) -> bool:
        """Validate the dataset directory structure."""
        print("🔍 Validating dataset structure...")
        
        # Check if root dataset path exists
        if not self.dataset_path.exists():
            print(f"❌ Dataset root path does not exist: {self.dataset_path}")
            return False
        
        # Check required directories
        required_dirs = ['images/train', 'images/val', 'images/test', 
                        'labels/train', 'labels/val', 'labels/test']
        
        missing_dirs = []
        for dir_path in required_dirs:
            full_path = self.dataset_path / dir_path
            if not full_path.exists():
                missing_dirs.append(str(full_path))
        
        if missing_dirs:
            print("❌ Missing directories:")
            for missing in missing_dirs:
                print(f"   - {missing}")
            return False
        
        print("✅ Dataset structure is valid")
        return True
    
    def analyze_images(self, split: str = 'train') -> Dict:
        """Analyze images in the specified split."""
        print(f"📊 Analyzing {split} images...")
        
        images_dir = self.dataset_path / 'images' / split
        labels_dir = self.dataset_path / 'labels' / split
        
        if not images_dir.exists():
            print(f"❌ Images directory not found: {images_dir}")
            return {}
        
        image_files = list(images_dir.glob('*.png')) + list(images_dir.glob('*.jpg')) + list(images_dir.glob('*.jpeg'))
        
        if not image_files:
            print(f"❌ No image files found in {images_dir}")
            return {}
        
        stats = {
            'total_images': len(image_files),
            'image_sizes': [],
            'defect_counts': [],
            'defect_sizes': [],
            'defect_areas_percent': [],
            'images_with_labels': 0,
            'images_without_labels': 0
        }
        
        print(f"Found {len(image_files)} images")
        
        for i, img_path in enumerate(image_files):
            if i % 100 == 0:
                print(f"Processing image {i+1}/{len(image_files)}")
            
            # Load image to get dimensions
            img = cv2.imread(str(img_path))
            if img is None:
                print(f"⚠️  Could not load image: {img_path}")
                continue
            
            h, w = img.shape[:2]
            stats['image_sizes'].append((w, h))
            
            # Check for corresponding label file
            label_path = labels_dir / (img_path.stem + '.txt')
            
            if label_path.exists():
                stats['images_with_labels'] += 1
                defects = self._parse_yolo_labels(label_path, w, h)
                stats['defect_counts'].append(len(defects))
                
                for defect in defects:
                    # Calculate defect size and area percentage
                    bbox_w, bbox_h = defect['width'] * w, defect['height'] * h
                    defect_area = bbox_w * bbox_h
                    image_area = w * h
                    area_percent = (defect_area / image_area) * 100
                    
                    stats['defect_sizes'].append((bbox_w, bbox_h))
                    stats['defect_areas_percent'].append(area_percent)
            else:
                stats['images_without_labels'] += 1
                stats['defect_counts'].append(0)
        
        self.stats[split] = stats
        return stats
    
    def _parse_yolo_labels(self, label_path: Path, img_w: int, img_h: int) -> List[Dict]:
        """Parse YOLO format labels."""
        defects = []
        
        try:
            with open(label_path, 'r') as f:
                lines = f.readlines()
            
            for line in lines:
                parts = line.strip().split()
                if len(parts) >= 5:
                    class_id = int(parts[0])
                    x_center = float(parts[1])
                    y_center = float(parts[2])
                    width = float(parts[3])
                    height = float(parts[4])
                    
                    defects.append({
                        'class_id': class_id,
                        'x_center': x_center,
                        'y_center': y_center,
                        'width': width,
                        'height': height
                    })
        except Exception as e:
            print(f"⚠️  Error parsing label file {label_path}: {e}")
        
        return defects
    
    def print_statistics(self, split: str = 'train'):
        """Print detailed statistics for the dataset split."""
        if split not in self.stats:
            print(f"❌ No statistics available for split: {split}")
            return
        
        stats = self.stats[split]
        
        print(f"\n📈 Statistics for {split} split:")
        print(f"Total images: {stats['total_images']}")
        print(f"Images with labels: {stats['images_with_labels']}")
        print(f"Images without labels: {stats['images_without_labels']}")
        
        if stats['image_sizes']:
            sizes = np.array(stats['image_sizes'])
            print(f"\nImage dimensions:")
            print(f"  Width: {sizes[:, 0].min()}-{sizes[:, 0].max()} (avg: {sizes[:, 0].mean():.1f})")
            print(f"  Height: {sizes[:, 1].min()}-{sizes[:, 1].max()} (avg: {sizes[:, 1].mean():.1f})")
            
            # Check if images match expected resolution
            expected_w, expected_h = 2048, 1460
            matching_resolution = np.sum((sizes[:, 0] == expected_w) & (sizes[:, 1] == expected_h))
            print(f"  Images matching expected resolution (2048x1460): {matching_resolution}/{len(sizes)}")
        
        if stats['defect_counts']:
            defect_counts = np.array(stats['defect_counts'])
            print(f"\nDefect statistics:")
            print(f"  Total defects: {defect_counts.sum()}")
            print(f"  Defects per image: {defect_counts.mean():.2f} ± {defect_counts.std():.2f}")
            print(f"  Max defects per image: {defect_counts.max()}")
        
        if stats['defect_areas_percent']:
            areas = np.array(stats['defect_areas_percent'])
            print(f"\nDefect area analysis:")
            print(f"  Average defect area: {areas.mean():.4f}% of image")
            print(f"  Median defect area: {np.median(areas):.4f}% of image")
            print(f"  Min defect area: {areas.min():.4f}% of image")
            print(f"  Max defect area: {areas.max():.4f}% of image")
            
            # Count tiny defects (< 0.1% of image)
            tiny_defects = np.sum(areas < 0.1)
            print(f"  Defects < 0.1% of image: {tiny_defects}/{len(areas)} ({tiny_defects/len(areas)*100:.1f}%)")
            
            # Count very tiny defects (< 0.01% of image)
            very_tiny_defects = np.sum(areas < 0.01)
            print(f"  Defects < 0.01% of image: {very_tiny_defects}/{len(areas)} ({very_tiny_defects/len(areas)*100:.1f}%)")
    
    def create_visualization(self, split: str = 'train', save_path: Optional[str] = None):
        """Create visualization plots for dataset analysis."""
        if split not in self.stats:
            print(f"❌ No statistics available for split: {split}")
            return
        
        stats = self.stats[split]
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle(f'Dataset Analysis - {split.upper()} Split', fontsize=16)
        
        # Plot 1: Defect count distribution
        if stats['defect_counts']:
            axes[0, 0].hist(stats['defect_counts'], bins=20, alpha=0.7, color='blue')
            axes[0, 0].set_title('Defects per Image Distribution')
            axes[0, 0].set_xlabel('Number of Defects')
            axes[0, 0].set_ylabel('Number of Images')
        
        # Plot 2: Defect area percentage distribution
        if stats['defect_areas_percent']:
            areas = np.array(stats['defect_areas_percent'])
            axes[0, 1].hist(areas, bins=50, alpha=0.7, color='red')
            axes[0, 1].set_title('Defect Area Distribution')
            axes[0, 1].set_xlabel('Defect Area (% of image)')
            axes[0, 1].set_ylabel('Number of Defects')
            axes[0, 1].set_xlim(0, min(1.0, areas.max()))
        
        # Plot 3: Image size distribution
        if stats['image_sizes']:
            sizes = np.array(stats['image_sizes'])
            axes[1, 0].scatter(sizes[:, 0], sizes[:, 1], alpha=0.6, color='green')
            axes[1, 0].set_title('Image Size Distribution')
            axes[1, 0].set_xlabel('Width (pixels)')
            axes[1, 0].set_ylabel('Height (pixels)')
            axes[1, 0].axvline(x=2048, color='red', linestyle='--', label='Expected width')
            axes[1, 0].axhline(y=1460, color='red', linestyle='--', label='Expected height')
            axes[1, 0].legend()
        
        # Plot 4: Defect size distribution
        if stats['defect_sizes']:
            sizes = np.array(stats['defect_sizes'])
            axes[1, 1].scatter(sizes[:, 0], sizes[:, 1], alpha=0.6, color='orange')
            axes[1, 1].set_title('Defect Size Distribution')
            axes[1, 1].set_xlabel('Defect Width (pixels)')
            axes[1, 1].set_ylabel('Defect Height (pixels)')
            axes[1, 1].set_xlim(0, min(100, sizes[:, 0].max()))
            axes[1, 1].set_ylim(0, min(100, sizes[:, 1].max()))
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"📊 Visualization saved to: {save_path}")
        else:
            plt.show()
    
    def save_report(self, output_path: str):
        """Save detailed analysis report to JSON file."""
        report = {
            'dataset_config': self.config,
            'validation_timestamp': str(np.datetime64('now')),
            'statistics': dict(self.stats)
        }
        
        # Convert numpy arrays to lists for JSON serialization
        for split_name, split_stats in report['statistics'].items():
            for key, value in split_stats.items():
                if isinstance(value, np.ndarray):
                    split_stats[key] = value.tolist()
                elif isinstance(value, list) and value and isinstance(value[0], tuple):
                    split_stats[key] = [list(item) for item in value]
        
        with open(output_path, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"📄 Analysis report saved to: {output_path}")
    
    def run_full_validation(self, output_dir: str = None):
        """Run complete dataset validation and analysis."""
        print("🚀 Starting full dataset validation...")
        
        # Validate structure
        if not self.validate_structure():
            return False
        
        # Analyze all splits
        splits = ['train', 'val', 'test']
        for split in splits:
            if (self.dataset_path / 'images' / split).exists():
                self.analyze_images(split)
                self.print_statistics(split)
        
        # Create output directory if specified
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
            
            # Save visualizations
            for split in splits:
                if split in self.stats:
                    viz_path = os.path.join(output_dir, f'{split}_analysis.png')
                    self.create_visualization(split, viz_path)
            
            # Save report
            report_path = os.path.join(output_dir, 'dataset_analysis_report.json')
            self.save_report(report_path)
        
        print("✅ Dataset validation completed successfully!")
        return True

def main():
    """Main function for command-line usage."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Validate YOLOv8 dataset for defect detection')
    parser.add_argument('--config', required=True, help='Path to dataset configuration YAML file')
    parser.add_argument('--output', help='Output directory for analysis results')
    
    args = parser.parse_args()
    
    validator = DatasetValidator(args.config)
    validator.run_full_validation(args.output)

if __name__ == '__main__':
    main()

