#!/usr/bin/env python3
"""
Data Preprocessing Utilities for YOLOv8 Defect Detection
Handles image preprocessing, augmentation, and dataset preparation for tiny defect detection.
"""

import os
import cv2
import numpy as np
from pathlib import Path
from typing import Tuple, List, Dict, Optional
import yaml
import json
from concurrent.futures import ThreadPoolExecutor
import shutil

class DefectDataPreprocessor:
    """Preprocessor for defect detection dataset with focus on tiny defects."""
    
    def __init__(self, config_path: str):
        """Initialize preprocessor with configuration."""
        self.config_path = config_path
        self.config = self._load_config()
        
    def _load_config(self) -> Dict:
        """Load configuration from YAML file."""
        with open(self.config_path, 'r') as f:
            return yaml.safe_load(f)
    
    def validate_image_resolution(self, image_path: str, expected_size: Tuple[int, int] = (2048, 1460)) -> bool:
        """Validate that image has expected resolution."""
        img = cv2.imread(image_path)
        if img is None:
            return False
        
        h, w = img.shape[:2]
        return w == expected_size[0] and h == expected_size[1]
    
    def pad_image_to_multiple(self, image: np.ndarray, multiple: int = 32) -> Tuple[np.ndarray, Dict]:
        """
        Pad image to nearest multiple of specified value.
        Returns padded image and padding information.
        """
        h, w = image.shape[:2]
        
        # Calculate padding needed
        pad_h = (multiple - h % multiple) % multiple
        pad_w = (multiple - w % multiple) % multiple
        
        # Apply padding (bottom and right)
        if len(image.shape) == 3:
            padded = cv2.copyMakeBorder(
                image, 0, pad_h, 0, pad_w, 
                cv2.BORDER_CONSTANT, value=[0, 0, 0]
            )
        else:
            padded = cv2.copyMakeBorder(
                image, 0, pad_h, 0, pad_w, 
                cv2.BORDER_CONSTANT, value=0
            )
        
        padding_info = {
            'original_size': (w, h),
            'padded_size': (w + pad_w, h + pad_h),
            'padding': (0, pad_h, 0, pad_w)  # top, bottom, left, right
        }
        
        return padded, padding_info
    
    def enhance_tiny_defects(self, image: np.ndarray, method: str = 'clahe') -> np.ndarray:
        """
        Enhance tiny defects in the image using various methods.
        
        Args:
            image: Input image
            method: Enhancement method ('clahe', 'unsharp', 'tophat', 'combined')
        """
        if method == 'clahe':
            # CLAHE (Contrast Limited Adaptive Histogram Equalization)
            if len(image.shape) == 3:
                lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                lab[:, :, 0] = clahe.apply(lab[:, :, 0])
                enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
            else:
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                enhanced = clahe.apply(image)
        
        elif method == 'unsharp':
            # Unsharp masking
            gaussian = cv2.GaussianBlur(image, (0, 0), 1.0)
            enhanced = cv2.addWeighted(image, 1.5, gaussian, -0.5, 0)
        
        elif method == 'tophat':
            # Top-hat morphological operation
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
            if len(image.shape) == 3:
                enhanced = np.zeros_like(image)
                for i in range(3):
                    enhanced[:, :, i] = cv2.morphologyEx(image[:, :, i], cv2.MORPH_TOPHAT, kernel)
            else:
                enhanced = cv2.morphologyEx(image, cv2.MORPH_TOPHAT, kernel)
        
        elif method == 'combined':
            # Combine multiple enhancement techniques
            # First apply CLAHE
            if len(image.shape) == 3:
                lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                lab[:, :, 0] = clahe.apply(lab[:, :, 0])
                enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
            else:
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                enhanced = clahe.apply(image)
            
            # Then apply unsharp masking
            gaussian = cv2.GaussianBlur(enhanced, (0, 0), 0.5)
            enhanced = cv2.addWeighted(enhanced, 1.3, gaussian, -0.3, 0)
        
        else:
            enhanced = image.copy()
        
        return enhanced
    
    def reduce_noise(self, image: np.ndarray, method: str = 'bilateral') -> np.ndarray:
        """
        Reduce noise while preserving edges and tiny defects.
        
        Args:
            image: Input image
            method: Denoising method ('bilateral', 'nlm', 'gaussian', 'median')
        """
        if method == 'bilateral':
            # Bilateral filter - preserves edges while reducing noise
            if len(image.shape) == 3:
                denoised = cv2.bilateralFilter(image, 5, 50, 50)
            else:
                denoised = cv2.bilateralFilter(image, 5, 50, 50)
        
        elif method == 'nlm':
            # Non-local means denoising
            if len(image.shape) == 3:
                denoised = cv2.fastNlMeansDenoisingColored(image, None, 3, 3, 7, 21)
            else:
                denoised = cv2.fastNlMeansDenoising(image, None, 3, 7, 21)
        
        elif method == 'gaussian':
            # Gaussian blur (mild)
            denoised = cv2.GaussianBlur(image, (3, 3), 0.5)
        
        elif method == 'median':
            # Median filter
            denoised = cv2.medianBlur(image, 3)
        
        else:
            denoised = image.copy()
        
        return denoised
    
    def preprocess_image(self, image_path: str, output_path: str, 
                        enhance: bool = True, denoise: bool = True, 
                        pad_to_multiple: int = 32) -> Dict:
        """
        Complete preprocessing pipeline for a single image.
        
        Args:
            image_path: Path to input image
            output_path: Path to save processed image
            enhance: Whether to apply defect enhancement
            denoise: Whether to apply noise reduction
            pad_to_multiple: Pad image to multiple of this value
        
        Returns:
            Dictionary with processing information
        """
        # Load image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")
        
        original_shape = image.shape
        processing_info = {
            'original_path': image_path,
            'output_path': output_path,
            'original_shape': original_shape,
            'steps_applied': []
        }
        
        # Apply noise reduction first (if enabled)
        if denoise:
            image = self.reduce_noise(image, method='bilateral')
            processing_info['steps_applied'].append('noise_reduction')
        
        # Apply defect enhancement (if enabled)
        if enhance:
            image = self.enhance_tiny_defects(image, method='clahe')
            processing_info['steps_applied'].append('defect_enhancement')
        
        # Pad to multiple (if specified)
        if pad_to_multiple > 1:
            image, padding_info = self.pad_image_to_multiple(image, pad_to_multiple)
            processing_info['padding_info'] = padding_info
            processing_info['steps_applied'].append('padding')
        
        # Save processed image
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        cv2.imwrite(output_path, image)
        
        processing_info['final_shape'] = image.shape
        return processing_info
    
    def adjust_labels_for_padding(self, label_path: str, output_label_path: str, 
                                 original_size: Tuple[int, int], 
                                 padded_size: Tuple[int, int]) -> bool:
        """
        Adjust YOLO labels for padded images.
        
        Args:
            label_path: Path to original label file
            output_label_path: Path to save adjusted labels
            original_size: (width, height) of original image
            padded_size: (width, height) of padded image
        """
        if not os.path.exists(label_path):
            return False
        
        orig_w, orig_h = original_size
        pad_w, pad_h = padded_size
        
        # Calculate scaling factors
        scale_x = orig_w / pad_w
        scale_y = orig_h / pad_h
        
        adjusted_labels = []
        
        with open(label_path, 'r') as f:
            lines = f.readlines()
        
        for line in lines:
            parts = line.strip().split()
            if len(parts) >= 5:
                class_id = int(parts[0])
                x_center = float(parts[1])
                y_center = float(parts[2])
                width = float(parts[3])
                height = float(parts[4])
                
                # Adjust coordinates for padding
                # Since we only pad bottom and right, we only need to scale
                adj_x_center = x_center * scale_x
                adj_y_center = y_center * scale_y
                adj_width = width * scale_x
                adj_height = height * scale_y
                
                adjusted_labels.append(f"{class_id} {adj_x_center:.6f} {adj_y_center:.6f} {adj_width:.6f} {adj_height:.6f}")
        
        # Save adjusted labels
        os.makedirs(os.path.dirname(output_label_path), exist_ok=True)
        with open(output_label_path, 'w') as f:
            f.write('\n'.join(adjusted_labels))
        
        return True
    
    def process_dataset_split(self, split: str, output_dir: str, 
                            enhance: bool = True, denoise: bool = True,
                            pad_to_multiple: int = 32, num_workers: int = 4) -> Dict:
        """
        Process entire dataset split with multiprocessing.
        
        Args:
            split: Dataset split ('train', 'val', 'test')
            output_dir: Output directory for processed dataset
            enhance: Whether to apply defect enhancement
            denoise: Whether to apply noise reduction
            pad_to_multiple: Pad images to multiple of this value
            num_workers: Number of worker threads
        """
        dataset_path = Path(self.config['path'])
        images_dir = dataset_path / 'images' / split
        labels_dir = dataset_path / 'labels' / split
        
        if not images_dir.exists():
            raise ValueError(f"Images directory not found: {images_dir}")
        
        # Get all image files
        image_files = list(images_dir.glob('*.png')) + list(images_dir.glob('*.jpg')) + list(images_dir.glob('*.jpeg'))
        
        if not image_files:
            raise ValueError(f"No image files found in {images_dir}")
        
        # Create output directories
        output_images_dir = Path(output_dir) / 'images' / split
        output_labels_dir = Path(output_dir) / 'labels' / split
        output_images_dir.mkdir(parents=True, exist_ok=True)
        output_labels_dir.mkdir(parents=True, exist_ok=True)
        
        processing_results = []
        
        def process_single_image(img_path):
            """Process a single image and its labels."""
            try:
                # Process image
                output_img_path = output_images_dir / img_path.name
                result = self.preprocess_image(
                    str(img_path), str(output_img_path),
                    enhance=enhance, denoise=denoise, 
                    pad_to_multiple=pad_to_multiple
                )
                
                # Process corresponding label file if it exists
                label_path = labels_dir / (img_path.stem + '.txt')
                output_label_path = output_labels_dir / (img_path.stem + '.txt')
                
                if label_path.exists() and 'padding_info' in result:
                    padding_info = result['padding_info']
                    self.adjust_labels_for_padding(
                        str(label_path), str(output_label_path),
                        padding_info['original_size'], 
                        padding_info['padded_size']
                    )
                    result['labels_adjusted'] = True
                elif label_path.exists():
                    # Copy labels without adjustment if no padding
                    shutil.copy2(str(label_path), str(output_label_path))
                    result['labels_copied'] = True
                else:
                    result['no_labels'] = True
                
                return result
                
            except Exception as e:
                return {'error': str(e), 'image_path': str(img_path)}
        
        # Process images with multiprocessing
        print(f"Processing {len(image_files)} images in {split} split...")
        
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            processing_results = list(executor.map(process_single_image, image_files))
        
        # Compile statistics
        stats = {
            'total_images': len(image_files),
            'successful': len([r for r in processing_results if 'error' not in r]),
            'errors': len([r for r in processing_results if 'error' in r]),
            'with_labels': len([r for r in processing_results if r.get('labels_adjusted') or r.get('labels_copied')]),
            'without_labels': len([r for r in processing_results if r.get('no_labels')]),
            'processing_results': processing_results
        }
        
        print(f"✅ Processed {stats['successful']}/{stats['total_images']} images successfully")
        if stats['errors'] > 0:
            print(f"⚠️  {stats['errors']} images had errors")
        
        return stats
    
    def create_processed_dataset_config(self, output_dir: str, original_config_path: str):
        """Create dataset configuration file for processed dataset."""
        # Load original config
        with open(original_config_path, 'r') as f:
            config = yaml.safe_load(f)
        
        # Update paths to point to processed dataset
        config['path'] = str(Path(output_dir).absolute())
        
        # Save new config
        config_path = Path(output_dir) / 'dataset.yaml'
        with open(config_path, 'w') as f:
            yaml.dump(config, f, default_flow_style=False)
        
        print(f"📄 Created processed dataset config: {config_path}")
        return str(config_path)

def main():
    """Main function for command-line usage."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Preprocess dataset for YOLOv8 defect detection')
    parser.add_argument('--config', required=True, help='Path to dataset configuration YAML file')
    parser.add_argument('--output', required=True, help='Output directory for processed dataset')
    parser.add_argument('--split', default='all', help='Dataset split to process (train/val/test/all)')
    parser.add_argument('--enhance', action='store_true', help='Apply defect enhancement')
    parser.add_argument('--denoise', action='store_true', help='Apply noise reduction')
    parser.add_argument('--pad-multiple', type=int, default=32, help='Pad images to multiple of this value')
    parser.add_argument('--workers', type=int, default=4, help='Number of worker threads')
    
    args = parser.parse_args()
    
    preprocessor = DefectDataPreprocessor(args.config)
    
    splits_to_process = ['train', 'val', 'test'] if args.split == 'all' else [args.split]
    
    for split in splits_to_process:
        try:
            stats = preprocessor.process_dataset_split(
                split, args.output,
                enhance=args.enhance,
                denoise=args.denoise,
                pad_to_multiple=args.pad_multiple,
                num_workers=args.workers
            )
            
            # Save processing statistics
            stats_path = Path(args.output) / f'{split}_processing_stats.json'
            with open(stats_path, 'w') as f:
                json.dump(stats, f, indent=2, default=str)
            
        except Exception as e:
            print(f"❌ Error processing {split} split: {e}")
    
    # Create processed dataset config
    preprocessor.create_processed_dataset_config(args.output, args.config)

if __name__ == '__main__':
    main()

