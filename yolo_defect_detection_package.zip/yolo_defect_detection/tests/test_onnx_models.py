#!/usr/bin/env python3
"""
ONNX Model Validation and Testing Script
Comprehensive testing suite for ONNX models with internal padding functionality.
"""

import os
import sys
import time
import cv2
import numpy as np
import onnxruntime as ort
import json
import argparse
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import matplotlib.pyplot as plt
from concurrent.futures import ThreadPoolExecutor
import psutil

class ONNXModelTester:
    """Comprehensive tester for ONNX models with internal padding."""
    
    def __init__(self, model_path: str, providers: Optional[List[str]] = None):
        """
        Initialize tester with ONNX model.
        
        Args:
            model_path: Path to ONNX model
            providers: List of execution providers (e.g., ['CUDAExecutionProvider', 'CPUExecutionProvider'])
        """
        self.model_path = model_path
        self.providers = providers or ['CUDAExecutionProvider', 'CPUExecutionProvider']
        
        # Load session
        try:
            self.session = ort.InferenceSession(model_path, providers=self.providers)
            print(f"✅ Loaded ONNX model: {model_path}")
            print(f"   Provider: {self.session.get_providers()[0]}")
        except Exception as e:
            raise ValueError(f"Failed to load ONNX model: {e}")
        
        # Get model info
        self.input_info = self.session.get_inputs()[0]
        self.output_info = self.session.get_outputs()
        
        # Determine input format
        self.input_format = self._determine_input_format()
        
        print(f"📊 Model Information:")
        print(f"   Input: {self.input_info.name}, shape: {self.input_info.shape}, type: {self.input_info.type}")
        print(f"   Input format: {self.input_format}")
        for i, output in enumerate(self.output_info):
            print(f"   Output {i}: {output.name}, shape: {output.shape}, type: {output.type}")
    
    def _determine_input_format(self) -> str:
        """Determine input format based on input shape and type."""
        shape = self.input_info.shape
        dtype = self.input_info.type
        
        if len(shape) == 4:
            if dtype == 'tensor(uint8)':
                if shape[-1] == 3:  # NHWC
                    return 'hwc_uint8'
                else:
                    return 'unknown_uint8'
            elif dtype == 'tensor(float)':
                if shape[1] == 3:  # NCHW
                    return 'nchw_float32'
                elif shape[-1] == 3:  # NHWC
                    return 'hwc_float32'
                else:
                    return 'unknown_float32'
        
        return 'unknown'
    
    def prepare_input(self, image: np.ndarray) -> np.ndarray:
        """
        Prepare input tensor based on model's expected format.
        
        Args:
            image: Input image (HWC uint8 format)
        
        Returns:
            Prepared input tensor
        """
        if self.input_format == 'hwc_uint8':
            # Model expects HWC uint8 - add batch dimension
            return image[np.newaxis, ...]
        
        elif self.input_format == 'nchw_float32':
            # Model expects NCHW float32 - convert and transpose
            if image.dtype == np.uint8:
                image = image.astype(np.float32) / 255.0
            return np.transpose(image, (2, 0, 1))[np.newaxis, ...]
        
        elif self.input_format == 'hwc_float32':
            # Model expects HWC float32 - convert and add batch
            if image.dtype == np.uint8:
                image = image.astype(np.float32) / 255.0
            return image[np.newaxis, ...]
        
        else:
            raise ValueError(f"Unsupported input format: {self.input_format}")
    
    def run_inference(self, input_tensor: np.ndarray) -> List[np.ndarray]:
        """
        Run inference on input tensor.
        
        Args:
            input_tensor: Prepared input tensor
        
        Returns:
            List of output arrays
        """
        try:
            outputs = self.session.run(None, {self.input_info.name: input_tensor})
            return outputs
        except Exception as e:
            raise RuntimeError(f"Inference failed: {e}")
    
    def test_single_image(self, image_path: str, save_results: bool = False, 
                         output_dir: Optional[str] = None) -> Dict[str, Any]:
        """
        Test model on a single image.
        
        Args:
            image_path: Path to test image
            save_results: Whether to save visualization results
            output_dir: Directory to save results
        
        Returns:
            Dictionary with test results
        """
        print(f"🧪 Testing image: {image_path}")
        
        # Load image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")
        
        # Convert BGR to RGB
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        original_shape = image.shape
        
        # Prepare input
        input_tensor = self.prepare_input(image)
        
        # Measure inference time
        start_time = time.time()
        outputs = self.run_inference(input_tensor)
        inference_time = time.time() - start_time
        
        # Analyze outputs
        results = {
            'image_path': image_path,
            'original_shape': original_shape,
            'input_shape': input_tensor.shape,
            'input_dtype': str(input_tensor.dtype),
            'inference_time': inference_time,
            'outputs': []
        }
        
        for i, output in enumerate(outputs):
            output_info = {
                'name': self.output_info[i].name,
                'shape': output.shape,
                'dtype': str(output.dtype),
                'min_value': float(np.min(output)),
                'max_value': float(np.max(output)),
                'mean_value': float(np.mean(output)),
                'num_detections': 0
            }
            
            # Count detections for boxes output
            if 'box' in self.output_info[i].name.lower() or self.output_info[i].name == 'output':
                if len(output.shape) >= 2:
                    output_info['num_detections'] = output.shape[1] if len(output.shape) == 3 else output.shape[0]
            
            results['outputs'].append(output_info)
        
        # Save visualization if requested
        if save_results and output_dir:
            self._save_detection_visualization(image, outputs, image_path, output_dir)
        
        print(f"   ✅ Inference completed in {inference_time:.4f}s")
        for i, output_info in enumerate(results['outputs']):\n            print(f\"   Output {i}: {output_info['num_detections']} detections, \"\n                  f\"range=[{output_info['min_value']:.4f}, {output_info['max_value']:.4f}]\")\n        \n        return results\n    \n    def _save_detection_visualization(self, image: np.ndarray, outputs: List[np.ndarray],\n                                    image_path: str, output_dir: str):\n        \"\"\"\n        Save visualization of detection results.\n        \n        Args:\n            image: Original image\n            outputs: Model outputs\n            image_path: Original image path\n            output_dir: Output directory\n        \"\"\"\n        try:\n            # Create output directory\n            os.makedirs(output_dir, exist_ok=True)\n            \n            # Find boxes output\n            boxes = None\n            scores = None\n            labels = None\n            \n            for i, output in enumerate(outputs):\n                output_name = self.output_info[i].name.lower()\n                if 'box' in output_name:\n                    boxes = output\n                elif 'score' in output_name:\n                    scores = output\n                elif 'label' in output_name:\n                    labels = output\n                elif output_name == 'output' and len(output.shape) == 3:\n                    # YOLOv8 format: [batch, detections, 6] where 6 = [x1,y1,x2,y2,conf,class]\n                    if output.shape[-1] >= 6:\n                        boxes = output[0, :, :4]  # x1,y1,x2,y2\n                        scores = output[0, :, 4]  # confidence\n                        if output.shape[-1] > 5:\n                            labels = output[0, :, 5]  # class\n            \n            if boxes is not None:\n                # Create visualization\n                vis_image = image.copy()\n                h, w = image.shape[:2]\n                \n                # Filter detections by confidence threshold\n                conf_threshold = 0.3\n                if scores is not None:\n                    valid_indices = scores > conf_threshold\n                    boxes = boxes[valid_indices]\n                    if labels is not None:\n                        labels = labels[valid_indices]\n                    scores = scores[valid_indices]\n                \n                # Draw bounding boxes\n                for i, box in enumerate(boxes):\n                    if len(box) >= 4:\n                        x1, y1, x2, y2 = box[:4]\n                        \n                        # Convert to pixel coordinates if normalized\n                        if np.max(box) <= 1.0:\n                            x1, x2 = x1 * w, x2 * w\n                            y1, y2 = y1 * h, y2 * h\n                        \n                        # Draw rectangle\n                        cv2.rectangle(vis_image, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)\n                        \n                        # Add label and score\n                        label_text = f\"Defect\"\n                        if scores is not None and i < len(scores):\n                            label_text += f\" {scores[i]:.2f}\"\n                        if labels is not None and i < len(labels):\n                            label_text = f\"Class {int(labels[i])} {scores[i]:.2f}\" if scores is not None else f\"Class {int(labels[i])}\"\n                        \n                        cv2.putText(vis_image, label_text, (int(x1), int(y1) - 10),\n                                  cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)\n                \n                # Save visualization\n                base_name = Path(image_path).stem\n                output_path = os.path.join(output_dir, f\"{base_name}_detection.png\")\n                vis_image_bgr = cv2.cvtColor(vis_image, cv2.COLOR_RGB2BGR)\n                cv2.imwrite(output_path, vis_image_bgr)\n                \n                print(f\"   💾 Visualization saved: {output_path}\")\n            \n        except Exception as e:\n            print(f\"   ⚠️  Failed to save visualization: {e}\")\n    \n    def benchmark_performance(self, image_size: Tuple[int, int] = (1460, 2048),\n                            num_iterations: int = 100, warmup_iterations: int = 10) -> Dict[str, float]:\n        \"\"\"\n        Benchmark model performance.\n        \n        Args:\n            image_size: Size of test images (height, width)\n            num_iterations: Number of benchmark iterations\n            warmup_iterations: Number of warmup iterations\n        \n        Returns:\n            Performance statistics\n        \"\"\"\n        print(f\"⚡ Benchmarking performance ({num_iterations} iterations)...\")\n        \n        # Create dummy input\n        if self.input_format == 'hwc_uint8':\n            dummy_image = np.random.randint(0, 255, (*image_size, 3), dtype=np.uint8)\n        else:\n            dummy_image = np.random.rand(*image_size, 3).astype(np.float32)\n        \n        input_tensor = self.prepare_input(dummy_image)\n        \n        # Warmup\n        print(f\"   Warming up ({warmup_iterations} iterations)...\")\n        for _ in range(warmup_iterations):\n            self.run_inference(input_tensor)\n        \n        # Benchmark\n        print(f\"   Running benchmark...\")\n        times = []\n        memory_usage = []\n        \n        for i in range(num_iterations):\n            # Measure memory before inference\n            process = psutil.Process()\n            mem_before = process.memory_info().rss / 1024 / 1024  # MB\n            \n            # Run inference\n            start_time = time.time()\n            outputs = self.run_inference(input_tensor)\n            end_time = time.time()\n            \n            # Measure memory after inference\n            mem_after = process.memory_info().rss / 1024 / 1024  # MB\n            \n            times.append(end_time - start_time)\n            memory_usage.append(mem_after - mem_before)\n            \n            if (i + 1) % 20 == 0:\n                print(f\"   Progress: {i + 1}/{num_iterations}\")\n        \n        # Calculate statistics\n        times = np.array(times)\n        memory_usage = np.array(memory_usage)\n        \n        stats = {\n            'mean_time': float(np.mean(times)),\n            'std_time': float(np.std(times)),\n            'min_time': float(np.min(times)),\n            'max_time': float(np.max(times)),\n            'median_time': float(np.median(times)),\n            'fps': float(1.0 / np.mean(times)),\n            'mean_memory_delta': float(np.mean(memory_usage)),\n            'max_memory_delta': float(np.max(memory_usage)),\n            'total_iterations': num_iterations,\n            'input_size': image_size,\n            'provider': self.session.get_providers()[0]\n        }\n        \n        print(f\"   ✅ Benchmark completed:\")\n        print(f\"      Mean inference time: {stats['mean_time']:.4f}s ± {stats['std_time']:.4f}s\")\n        print(f\"      FPS: {stats['fps']:.2f}\")\n        print(f\"      Memory delta: {stats['mean_memory_delta']:.2f} MB (max: {stats['max_memory_delta']:.2f} MB)\")\n        \n        return stats\n    \n    def test_input_variations(self, base_image_path: str) -> Dict[str, Any]:\n        \"\"\"\n        Test model with various input variations to check robustness.\n        \n        Args:\n            base_image_path: Path to base test image\n        \n        Returns:\n            Test results for all variations\n        \"\"\"\n        print(f\"🔬 Testing input variations...\")\n        \n        # Load base image\n        base_image = cv2.imread(base_image_path)\n        if base_image is None:\n            raise ValueError(f\"Could not load base image: {base_image_path}\")\n        \n        base_image = cv2.cvtColor(base_image, cv2.COLOR_BGR2RGB)\n        \n        variations = {\n            'original': base_image,\n            'bright': np.clip(base_image * 1.3, 0, 255).astype(np.uint8),\n            'dark': np.clip(base_image * 0.7, 0, 255).astype(np.uint8),\n            'noisy': np.clip(base_image + np.random.normal(0, 10, base_image.shape), 0, 255).astype(np.uint8),\n            'blurred': cv2.GaussianBlur(base_image, (5, 5), 1.0),\n            'contrast': np.clip((base_image - 128) * 1.5 + 128, 0, 255).astype(np.uint8)\n        }\n        \n        results = {}\n        \n        for variation_name, image in variations.items():\n            try:\n                print(f\"   Testing {variation_name}...\")\n                \n                input_tensor = self.prepare_input(image)\n                start_time = time.time()\n                outputs = self.run_inference(input_tensor)\n                inference_time = time.time() - start_time\n                \n                # Count detections\n                num_detections = 0\n                for i, output in enumerate(outputs):\n                    if 'box' in self.output_info[i].name.lower() or self.output_info[i].name == 'output':\n                        if len(output.shape) >= 2:\n                            num_detections = output.shape[1] if len(output.shape) == 3 else output.shape[0]\n                        break\n                \n                results[variation_name] = {\n                    'success': True,\n                    'inference_time': inference_time,\n                    'num_detections': num_detections,\n                    'output_shapes': [output.shape for output in outputs]\n                }\n                \n                print(f\"      ✅ {variation_name}: {num_detections} detections in {inference_time:.4f}s\")\n                \n            except Exception as e:\n                results[variation_name] = {\n                    'success': False,\n                    'error': str(e)\n                }\n                print(f\"      ❌ {variation_name}: {e}\")\n        \n        return results\n    \n    def test_batch_processing(self, image_paths: List[str], batch_size: int = 1) -> Dict[str, Any]:\n        \"\"\"\n        Test batch processing capabilities.\n        \n        Args:\n            image_paths: List of image paths to process\n            batch_size: Batch size (note: most models expect batch_size=1)\n        \n        Returns:\n            Batch processing results\n        \"\"\"\n        print(f\"📦 Testing batch processing ({len(image_paths)} images, batch_size={batch_size})...\")\n        \n        if batch_size > 1:\n            print(\"   ⚠️  Note: Most ONNX models expect batch_size=1\")\n        \n        results = {\n            'total_images': len(image_paths),\n            'batch_size': batch_size,\n            'successful_batches': 0,\n            'failed_batches': 0,\n            'total_time': 0,\n            'batch_results': []\n        }\n        \n        # Process in batches\n        for i in range(0, len(image_paths), batch_size):\n            batch_paths = image_paths[i:i + batch_size]\n            \n            try:\n                # Load and prepare batch\n                batch_images = []\n                for img_path in batch_paths:\n                    image = cv2.imread(img_path)\n                    if image is not None:\n                        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)\n                        batch_images.append(image)\n                \n                if not batch_images:\n                    continue\n                \n                # For now, process images individually (most models expect batch_size=1)\n                batch_start_time = time.time()\n                batch_outputs = []\n                \n                for image in batch_images:\n                    input_tensor = self.prepare_input(image)\n                    outputs = self.run_inference(input_tensor)\n                    batch_outputs.append(outputs)\n                \n                batch_time = time.time() - batch_start_time\n                \n                batch_result = {\n                    'batch_index': i // batch_size,\n                    'batch_paths': batch_paths,\n                    'batch_size_actual': len(batch_images),\n                    'processing_time': batch_time,\n                    'success': True\n                }\n                \n                results['batch_results'].append(batch_result)\n                results['successful_batches'] += 1\n                results['total_time'] += batch_time\n                \n                print(f\"   ✅ Batch {i//batch_size + 1}: {len(batch_images)} images in {batch_time:.4f}s\")\n                \n            except Exception as e:\n                batch_result = {\n                    'batch_index': i // batch_size,\n                    'batch_paths': batch_paths,\n                    'error': str(e),\n                    'success': False\n                }\n                \n                results['batch_results'].append(batch_result)\n                results['failed_batches'] += 1\n                \n                print(f\"   ❌ Batch {i//batch_size + 1}: {e}\")\n        \n        # Calculate summary statistics\n        if results['successful_batches'] > 0:\n            avg_batch_time = results['total_time'] / results['successful_batches']\n            total_successful_images = sum(br.get('batch_size_actual', 0) \n                                        for br in results['batch_results'] if br['success'])\n            avg_time_per_image = results['total_time'] / total_successful_images if total_successful_images > 0 else 0\n            \n            results['avg_batch_time'] = avg_batch_time\n            results['avg_time_per_image'] = avg_time_per_image\n            results['total_successful_images'] = total_successful_images\n            \n            print(f\"   📊 Summary: {total_successful_images} images processed successfully\")\n            print(f\"      Average time per image: {avg_time_per_image:.4f}s\")\n            print(f\"      Average batch time: {avg_batch_time:.4f}s\")\n        \n        return results\n    \n    def run_comprehensive_test(self, test_images_dir: str, output_dir: str,\n                             num_benchmark_iterations: int = 50) -> Dict[str, Any]:\n        \"\"\"\n        Run comprehensive test suite.\n        \n        Args:\n            test_images_dir: Directory containing test images\n            output_dir: Directory to save test results\n            num_benchmark_iterations: Number of iterations for benchmarking\n        \n        Returns:\n            Complete test results\n        \"\"\"\n        print(f\"🚀 Running comprehensive ONNX model test suite...\")\n        print(f\"   Model: {self.model_path}\")\n        print(f\"   Test images: {test_images_dir}\")\n        print(f\"   Output: {output_dir}\")\n        \n        os.makedirs(output_dir, exist_ok=True)\n        \n        # Find test images\n        test_images = []\n        for ext in ['*.png', '*.jpg', '*.jpeg']:\n            test_images.extend(Path(test_images_dir).glob(ext))\n        \n        if not test_images:\n            raise ValueError(f\"No test images found in {test_images_dir}\")\n        \n        test_images = [str(img) for img in test_images[:10]]  # Limit to 10 images\n        print(f\"   Found {len(test_images)} test images\")\n        \n        comprehensive_results = {\n            'model_path': self.model_path,\n            'model_info': {\n                'input_name': self.input_info.name,\n                'input_shape': self.input_info.shape,\n                'input_type': self.input_info.type,\n                'input_format': self.input_format,\n                'outputs': [{'name': out.name, 'shape': out.shape, 'type': out.type} \n                           for out in self.output_info],\n                'provider': self.session.get_providers()[0]\n            },\n            'test_timestamp': str(np.datetime64('now')),\n            'tests': {}\n        }\n        \n        # Test 1: Single image inference\n        print(\"\\n📸 Test 1: Single image inference\")\n        single_image_results = []\n        for img_path in test_images[:3]:  # Test first 3 images\n            result = self.test_single_image(img_path, save_results=True, output_dir=output_dir)\n            single_image_results.append(result)\n        \n        comprehensive_results['tests']['single_image'] = single_image_results\n        \n        # Test 2: Performance benchmark\n        print(\"\\n⚡ Test 2: Performance benchmark\")\n        benchmark_results = self.benchmark_performance(num_iterations=num_benchmark_iterations)\n        comprehensive_results['tests']['benchmark'] = benchmark_results\n        \n        # Test 3: Input variations\n        if test_images:\n            print(\"\\n🔬 Test 3: Input variations\")\n            variation_results = self.test_input_variations(test_images[0])\n            comprehensive_results['tests']['input_variations'] = variation_results\n        \n        # Test 4: Batch processing\n        print(\"\\n📦 Test 4: Batch processing\")\n        batch_results = self.test_batch_processing(test_images[:5])\n        comprehensive_results['tests']['batch_processing'] = batch_results\n        \n        # Save comprehensive results\n        results_path = os.path.join(output_dir, 'comprehensive_test_results.json')\n        with open(results_path, 'w') as f:\n            json.dump(comprehensive_results, f, indent=2, default=str)\n        \n        print(f\"\\n✅ Comprehensive test completed!\")\n        print(f\"📄 Results saved to: {results_path}\")\n        \n        return comprehensive_results\n\ndef main():\n    \"\"\"Main function for command-line usage.\"\"\"\n    parser = argparse.ArgumentParser(description='Test and validate ONNX models')\n    parser.add_argument('--model', required=True, help='Path to ONNX model')\n    parser.add_argument('--test-images', help='Directory containing test images')\n    parser.add_argument('--output-dir', default='./test_results', help='Output directory for results')\n    parser.add_argument('--single-image', help='Test single image')\n    parser.add_argument('--benchmark', action='store_true', help='Run performance benchmark')\n    parser.add_argument('--benchmark-iterations', type=int, default=50, help='Number of benchmark iterations')\n    parser.add_argument('--comprehensive', action='store_true', help='Run comprehensive test suite')\n    parser.add_argument('--providers', nargs='+', default=['CUDAExecutionProvider', 'CPUExecutionProvider'],\n                       help='ONNX Runtime execution providers')\n    \n    args = parser.parse_args()\n    \n    # Validate model path\n    if not os.path.exists(args.model):\n        print(f\"❌ Model file not found: {args.model}\")\n        sys.exit(1)\n    \n    try:\n        # Initialize tester\n        tester = ONNXModelTester(args.model, args.providers)\n        \n        if args.comprehensive:\n            # Run comprehensive test suite\n            if not args.test_images:\n                print(\"❌ --test-images required for comprehensive testing\")\n                sys.exit(1)\n            \n            tester.run_comprehensive_test(args.test_images, args.output_dir, args.benchmark_iterations)\n            \n        elif args.single_image:\n            # Test single image\n            result = tester.test_single_image(args.single_image, save_results=True, output_dir=args.output_dir)\n            print(f\"\\n📊 Single image test results:\")\n            print(json.dumps(result, indent=2, default=str))\n            \n        elif args.benchmark:\n            # Run benchmark only\n            stats = tester.benchmark_performance(num_iterations=args.benchmark_iterations)\n            print(f\"\\n📊 Benchmark results:\")\n            print(json.dumps(stats, indent=2))\n            \n        else:\n            print(\"❌ Please specify --single-image, --benchmark, or --comprehensive\")\n            sys.exit(1)\n        \n        print(\"🎉 Testing completed successfully!\")\n        \n    except Exception as e:\n        print(f\"❌ Testing failed: {e}\")\n        sys.exit(1)\n\nif __name__ == '__main__':\n    main()"

