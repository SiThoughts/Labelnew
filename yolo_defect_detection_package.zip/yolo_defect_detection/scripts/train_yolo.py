#!/usr/bin/env python3
"""
YOLOv8 Training Script for Tiny Defect Detection
Optimized for 2048x1460 images with defects as small as 0.1% of image area.
"""

import os
import sys
import yaml
import json
import argparse
from pathlib import Path
from typing import Dict, Optional, List
import torch
import numpy as np
from ultralytics import YOLO
from ultralytics.utils import LOGGER
import matplotlib.pyplot as plt

class TinyDefectTrainer:
    """Trainer class optimized for tiny defect detection."""
    
    def __init__(self, config_path: str, hyperparams_path: str):
        """Initialize trainer with configuration files."""
        self.config_path = config_path
        self.hyperparams_path = hyperparams_path
        self.config = self._load_yaml(config_path)
        self.hyperparams = self._load_yaml(hyperparams_path)
        
        # Set up paths
        self.dataset_path = Path(self.config['path'])
        self.project_dir = Path('runs/detect')
        
        # Training state
        self.model = None
        self.training_results = {}
        
    def _load_yaml(self, path: str) -> Dict:
        """Load YAML configuration file."""
        with open(path, 'r') as f:
            return yaml.safe_load(f)
    
    def setup_model(self, model_size: str = 'x', pretrained: bool = True) -> YOLO:
        """
        Setup YOLOv8 model optimized for tiny defect detection.
        
        Args:
            model_size: Model size ('n', 's', 'm', 'l', 'x')
            pretrained: Whether to use pretrained weights
        """
        model_name = f'yolov8{model_size}.pt' if pretrained else f'yolov8{model_size}.yaml'
        
        print(f"🔧 Setting up YOLOv8{model_size.upper()} model...")
        self.model = YOLO(model_name)
        
        # Log model information
        if hasattr(self.model.model, 'model'):
            total_params = sum(p.numel() for p in self.model.model.parameters())
            trainable_params = sum(p.numel() for p in self.model.model.parameters() if p.requires_grad)
            print(f"📊 Model parameters: {total_params:,} total, {trainable_params:,} trainable")
        
        return self.model
    
    def validate_dataset(self) -> bool:
        """Validate dataset structure and content."""
        print("🔍 Validating dataset...")
        
        # Check if dataset path exists
        if not self.dataset_path.exists():
            print(f"❌ Dataset path does not exist: {self.dataset_path}")
            return False
        
        # Check required directories
        required_dirs = ['images/train', 'images/val', 'labels/train', 'labels/val']
        for dir_name in required_dirs:
            dir_path = self.dataset_path / dir_name
            if not dir_path.exists():
                print(f"❌ Required directory missing: {dir_path}")
                return False
        
        # Count images and labels
        train_images = len(list((self.dataset_path / 'images/train').glob('*.png'))) + \
                      len(list((self.dataset_path / 'images/train').glob('*.jpg')))
        val_images = len(list((self.dataset_path / 'images/val').glob('*.png'))) + \
                    len(list((self.dataset_path / 'images/val').glob('*.jpg')))
        
        train_labels = len(list((self.dataset_path / 'labels/train').glob('*.txt')))
        val_labels = len(list((self.dataset_path / 'labels/val').glob('*.txt')))
        
        print(f"📊 Dataset statistics:")
        print(f"   Train: {train_images} images, {train_labels} labels")
        print(f"   Val: {val_images} images, {val_labels} labels")
        
        if train_images == 0 or val_images == 0:
            print("❌ No images found in dataset")
            return False
        
        print("✅ Dataset validation passed")
        return True
    
    def prepare_training_args(self, phase: str = 'phase1', custom_args: Optional[Dict] = None) -> Dict:
        """
        Prepare training arguments based on phase and hyperparameters.
        
        Args:
            phase: Training phase ('phase1' or 'phase2')
            custom_args: Custom arguments to override defaults
        """
        # Base arguments
        args = {
            'data': self.config_path,
            'epochs': 300,
            'batch': 1,  # Small batch due to high resolution
            'imgsz': [1460, 2048],  # Native resolution
            'device': 0 if torch.cuda.is_available() else 'cpu',
            'workers': 4,
            'project': 'runs/detect',
            'name': f'tiny_defect_{phase}',
            'exist_ok': True,
            'save': True,
            'save_period': 50,  # Save checkpoint every 50 epochs
            'cache': 'ram',  # Cache in RAM for faster training
            'rect': False,  # Disable rectangular training
            'cos_lr': True,  # Cosine learning rate scheduler
            'patience': 50,  # Early stopping patience
            'resume': False,  # Will be set to True for phase2
            'amp': True,  # Automatic mixed precision
            'fraction': 1.0,  # Use full dataset
            'profile': False,  # Disable profiling for speed
            'freeze': None,  # Don't freeze any layers
            'multi_scale': False,  # Disable multi-scale training for consistency
            'overlap_mask': True,  # Allow overlapping masks
            'mask_ratio': 4,  # Mask downsampling ratio
            'dropout': 0.0,  # No dropout
            'val': True,  # Enable validation
            'plots': True,  # Generate training plots
            'verbose': True,  # Verbose output
        }
        
        # Apply hyperparameters
        hyp = self.hyperparams
        
        # Optimizer settings
        args.update({
            'optimizer': hyp.get('optimizer', 'AdamW'),
            'lr0': hyp.get('lr0', 0.002),
            'lrf': hyp.get('lrf', 0.01),
            'momentum': hyp.get('momentum', 0.937),
            'weight_decay': hyp.get('weight_decay', 0.05),
        })
        
        # Loss weights
        args.update({
            'box': hyp.get('box', 8.0),
            'cls': hyp.get('cls', 0.8),
            'dfl': hyp.get('dfl', 1.8),
        })
        
        # Augmentation settings based on phase
        if phase == 'phase1':
            # Full augmentations for initial training
            phase_hyp = hyp.get('training_phases', {}).get('phase1', {})
            args.update({
                'hsv_h': hyp.get('hsv_h', 0.015),
                'hsv_s': hyp.get('hsv_s', 0.60),
                'hsv_v': hyp.get('hsv_v', 0.40),
                'degrees': hyp.get('degrees', 5.0),
                'translate': hyp.get('translate', 0.02),
                'scale': hyp.get('scale', 0.15),
                'shear': hyp.get('shear', 0.0),
                'perspective': hyp.get('perspective', 0.0),
                'flipud': hyp.get('flipud', 0.0),
                'fliplr': hyp.get('fliplr', 0.5),
                'mosaic': phase_hyp.get('mosaic', 1.0),
                'mixup': phase_hyp.get('mixup', 0.10),
                'copy_paste': phase_hyp.get('copy_paste', 0.40),
                'epochs': phase_hyp.get('epochs', 250),
            })\n        elif phase == 'phase2':\n            # Reduced augmentations for fine-tuning\n            phase_hyp = hyp.get('training_phases', {}).get('phase2', {})\n            args.update({\n                'mosaic': phase_hyp.get('mosaic', 0.0),\n                'mixup': phase_hyp.get('mixup', 0.0),\n                'copy_paste': phase_hyp.get('copy_paste', 0.0),\n                'epochs': phase_hyp.get('epochs', 50),\n                'resume': True,  # Resume from phase1\n            })\n        \n        # NMS settings\n        args.update({\n            'conf': hyp.get('conf_thres', 0.20),\n            'iou': hyp.get('iou_thres', 0.55),\n            'max_det': hyp.get('max_det', 1000),\n        })\n        \n        # Apply custom arguments\n        if custom_args:\n            args.update(custom_args)\n        \n        return args\n    \n    def train_phase1(self, custom_args: Optional[Dict] = None) -> Dict:\n        \"\"\"\n        Execute Phase 1 training: Initial training with full augmentations.\n        \"\"\"\n        print(\"🚀 Starting Phase 1 Training (Initial training with full augmentations)...\")\n        \n        if self.model is None:\n            raise ValueError(\"Model not initialized. Call setup_model() first.\")\n        \n        # Prepare training arguments\n        train_args = self.prepare_training_args('phase1', custom_args)\n        \n        print(f\"📋 Training arguments:\")\n        for key, value in train_args.items():\n            print(f\"   {key}: {value}\")\n        \n        # Start training\n        try:\n            results = self.model.train(**train_args)\n            \n            # Store results\n            self.training_results['phase1'] = {\n                'results': results,\n                'best_weights': str(self.model.trainer.best),\n                'last_weights': str(self.model.trainer.last),\n                'args': train_args\n            }\n            \n            print(\"✅ Phase 1 training completed successfully!\")\n            print(f\"📁 Best weights saved to: {self.model.trainer.best}\")\n            \n            return self.training_results['phase1']\n            \n        except Exception as e:\n            print(f\"❌ Phase 1 training failed: {e}\")\n            raise\n    \n    def train_phase2(self, phase1_weights: Optional[str] = None, custom_args: Optional[Dict] = None) -> Dict:\n        \"\"\"\n        Execute Phase 2 training: Fine-tuning with reduced augmentations.\n        \"\"\"\n        print(\"🎯 Starting Phase 2 Training (Fine-tuning with reduced augmentations)...\")\n        \n        # Load best weights from phase 1 if not provided\n        if phase1_weights is None:\n            if 'phase1' in self.training_results:\n                phase1_weights = self.training_results['phase1']['best_weights']\n            else:\n                # Try to find the latest phase1 weights\n                phase1_dir = self.project_dir / 'tiny_defect_phase1'\n                if phase1_dir.exists():\n                    weights_dir = phase1_dir / 'weights'\n                    if (weights_dir / 'best.pt').exists():\n                        phase1_weights = str(weights_dir / 'best.pt')\n        \n        if phase1_weights is None or not Path(phase1_weights).exists():\n            raise ValueError(f\"Phase 1 weights not found: {phase1_weights}\")\n        \n        print(f\"📂 Loading Phase 1 weights: {phase1_weights}\")\n        \n        # Load model with phase1 weights\n        self.model = YOLO(phase1_weights)\n        \n        # Prepare training arguments for phase 2\n        train_args = self.prepare_training_args('phase2', custom_args)\n        train_args['resume'] = False  # Don't resume, start fresh with new settings\n        \n        print(f\"📋 Phase 2 training arguments:\")\n        for key, value in train_args.items():\n            print(f\"   {key}: {value}\")\n        \n        # Start phase 2 training\n        try:\n            results = self.model.train(**train_args)\n            \n            # Store results\n            self.training_results['phase2'] = {\n                'results': results,\n                'best_weights': str(self.model.trainer.best),\n                'last_weights': str(self.model.trainer.last),\n                'args': train_args,\n                'phase1_weights': phase1_weights\n            }\n            \n            print(\"✅ Phase 2 training completed successfully!\")\n            print(f\"📁 Final best weights saved to: {self.model.trainer.best}\")\n            \n            return self.training_results['phase2']\n            \n        except Exception as e:\n            print(f\"❌ Phase 2 training failed: {e}\")\n            raise\n    \n    def validate_model(self, weights_path: Optional[str] = None, split: str = 'val') -> Dict:\n        \"\"\"\n        Validate trained model on specified dataset split.\n        \"\"\"\n        print(f\"🔍 Validating model on {split} split...\")\n        \n        if weights_path:\n            model = YOLO(weights_path)\n        elif self.model:\n            model = self.model\n        else:\n            raise ValueError(\"No model or weights specified for validation\")\n        \n        # Run validation\n        try:\n            val_results = model.val(\n                data=self.config_path,\n                split=split,\n                imgsz=[1460, 2048],\n                batch=1,\n                conf=0.001,  # Very low threshold for comprehensive analysis\n                iou=0.6,\n                max_det=1000,\n                save_json=True,\n                save_hybrid=True,\n                plots=True,\n                verbose=True\n            )\n            \n            print(\"✅ Validation completed successfully!\")\n            return val_results\n            \n        except Exception as e:\n            print(f\"❌ Validation failed: {e}\")\n            raise\n    \n    def save_training_summary(self, output_path: str):\n        \"\"\"\n        Save comprehensive training summary to JSON file.\n        \"\"\"\n        summary = {\n            'config_path': self.config_path,\n            'hyperparams_path': self.hyperparams_path,\n            'dataset_config': self.config,\n            'hyperparameters': self.hyperparams,\n            'training_results': {}\n        }\n        \n        # Add training results (excluding non-serializable objects)\n        for phase, results in self.training_results.items():\n            summary['training_results'][phase] = {\n                'best_weights': results.get('best_weights'),\n                'last_weights': results.get('last_weights'),\n                'args': results.get('args'),\n                'phase1_weights': results.get('phase1_weights')\n            }\n        \n        # Save to file\n        with open(output_path, 'w') as f:\n            json.dump(summary, f, indent=2, default=str)\n        \n        print(f\"📄 Training summary saved to: {output_path}\")\n    \n    def run_full_training(self, model_size: str = 'x', custom_args: Optional[Dict] = None) -> Dict:\n        \"\"\"\n        Run complete two-phase training pipeline.\n        \"\"\"\n        print(\"🎯 Starting complete two-phase training pipeline...\")\n        \n        # Validate dataset first\n        if not self.validate_dataset():\n            raise ValueError(\"Dataset validation failed\")\n        \n        # Setup model\n        self.setup_model(model_size=model_size, pretrained=True)\n        \n        # Phase 1: Initial training\n        phase1_results = self.train_phase1(custom_args)\n        \n        # Phase 2: Fine-tuning\n        phase2_results = self.train_phase2()\n        \n        # Final validation\n        print(\"🔍 Running final validation...\")\n        final_validation = self.validate_model(phase2_results['best_weights'])\n        \n        # Save training summary\n        summary_path = self.project_dir / 'tiny_defect_phase2' / 'training_summary.json'\n        self.save_training_summary(str(summary_path))\n        \n        print(\"🎉 Complete training pipeline finished successfully!\")\n        print(f\"📁 Final model weights: {phase2_results['best_weights']}\")\n        \n        return {\n            'phase1': phase1_results,\n            'phase2': phase2_results,\n            'final_validation': final_validation,\n            'summary_path': str(summary_path)\n        }\n\ndef main():\n    \"\"\"Main function for command-line usage.\"\"\"\n    parser = argparse.ArgumentParser(description='Train YOLOv8 for tiny defect detection')\n    parser.add_argument('--config', required=True, help='Path to dataset configuration YAML')\n    parser.add_argument('--hyperparams', required=True, help='Path to hyperparameters YAML')\n    parser.add_argument('--model-size', default='x', choices=['n', 's', 'm', 'l', 'x'], \n                       help='YOLOv8 model size')\n    parser.add_argument('--phase', choices=['phase1', 'phase2', 'full'], default='full',\n                       help='Training phase to run')\n    parser.add_argument('--weights', help='Path to weights for phase2 or validation')\n    parser.add_argument('--validate-only', action='store_true', help='Only run validation')\n    parser.add_argument('--epochs', type=int, help='Override number of epochs')\n    parser.add_argument('--batch', type=int, help='Override batch size')\n    parser.add_argument('--device', help='Training device (0, 1, cpu, etc.)')\n    \n    args = parser.parse_args()\n    \n    # Initialize trainer\n    trainer = TinyDefectTrainer(args.config, args.hyperparams)\n    \n    # Prepare custom arguments\n    custom_args = {}\n    if args.epochs:\n        custom_args['epochs'] = args.epochs\n    if args.batch:\n        custom_args['batch'] = args.batch\n    if args.device:\n        custom_args['device'] = args.device\n    \n    try:\n        if args.validate_only:\n            # Only run validation\n            if not args.weights:\n                raise ValueError(\"Weights path required for validation-only mode\")\n            trainer.validate_model(args.weights)\n            \n        elif args.phase == 'phase1':\n            # Run only phase 1\n            trainer.setup_model(model_size=args.model_size)\n            trainer.train_phase1(custom_args)\n            \n        elif args.phase == 'phase2':\n            # Run only phase 2\n            if not args.weights:\n                raise ValueError(\"Phase 1 weights required for phase 2 training\")\n            trainer.train_phase2(args.weights, custom_args)\n            \n        else:\n            # Run full training pipeline\n            trainer.run_full_training(model_size=args.model_size, custom_args=custom_args)\n            \n    except Exception as e:\n        print(f\"❌ Training failed: {e}\")\n        sys.exit(1)\n\nif __name__ == '__main__':\n    main()"

