"""
Comprehensive test suite for glass chip detection preprocessing pipeline.

This module contains unit tests and integration tests to ensure the correctness
of all preprocessing and feature extraction components.
"""

import pytest
import numpy as np
import cv2
import tempfile
import os
from pathlib import Path
from typing import Dict, Any

# Import modules to test
import sys
sys.path.append(str(Path(__file__).parent.parent))

from preproc_glass import GlassPreprocessor, preprocess_single_image
from features_glass import GlassFeatureExtractor, extract_features_from_image
from dataset_glass import GlassChipDataset, create_dataloader
from aug_glass import GlassDefectAugmentations


class TestGlassPreprocessor:
    """Test suite for GlassPreprocessor class."""
    
    @pytest.fixture
    def preprocessor(self):
        """Create a preprocessor instance for testing."""
        config = {
            'pose_normalize': True,
            'illumination_method': 'divide',
            'texture_suppress': True,
            'retinex_sigma': 60,
            'margin_px': 10,
            'min_part_area': 1000
        }
        return GlassPreprocessor(config)
    
    @pytest.fixture
    def test_image(self):
        """Create a synthetic test image."""
        # Create a 256x256 RGB image with a circular part
        image = np.zeros((256, 256, 3), dtype=np.float32)
        
        # Add a circular part in the center
        center = (128, 128)
        radius = 80
        y, x = np.ogrid[:256, :256]
        mask = (x - center[0])**2 + (y - center[1])**2 <= radius**2
        
        # Fill the part with gradient
        for i in range(3):
            image[:, :, i] = mask * (0.3 + 0.4 * (x / 256))
        
        # Add some texture (simulating polishing marks)
        for i in range(0, 256, 4):
            image[i:i+2, :, :] *= 1.1
        
        return image
    
    @pytest.fixture
    def test_image_with_defect(self):
        """Create a test image with a simulated defect."""
        image = self.test_image()
        
        # Add a simulated chip (dark notch on the edge)
        image[120:130, 200:210, :] *= 0.3
        
        return image
    
    def test_preprocessor_initialization(self):
        """Test preprocessor initialization with default config."""
        preprocessor = GlassPreprocessor()
        assert preprocessor.config is not None
        assert 'pose_normalize' in preprocessor.config
        assert 'illumination_method' in preprocessor.config
    
    def test_preprocess_image_shape(self, preprocessor, test_image):
        """Test that preprocessing maintains reasonable image dimensions."""
        processed_image, metadata = preprocessor.preprocess_image(test_image)
        
        # Check that output is valid
        assert processed_image is not None
        assert len(processed_image.shape) == 3
        assert processed_image.shape[2] == 3  # RGB
        assert processed_image.dtype == np.float32
        assert np.all(processed_image >= 0) and np.all(processed_image <= 1)
        
        # Check metadata
        assert 'original_shape' in metadata
        assert 'final_shape' in metadata
        assert metadata['original_shape'] == test_image.shape
    
    def test_preprocess_image_values(self, preprocessor, test_image):
        """Test that preprocessing produces valid value ranges."""
        processed_image, metadata = preprocessor.preprocess_image(test_image)
        
        # Values should be in [0, 1] range
        assert np.min(processed_image) >= 0
        assert np.max(processed_image) <= 1
        
        # Should not be all zeros or all ones
        assert not np.all(processed_image == 0)
        assert not np.all(processed_image == 1)
    
    def test_segmentation_success(self, preprocessor, test_image):
        """Test that part segmentation works correctly."""
        processed_image, metadata = preprocessor.preprocess_image(test_image)
        
        # Should successfully segment the circular part
        assert 'segmentation_success' in metadata
        assert 'part_area' in metadata
        
        # Part area should be reasonable (circular part with radius 80)
        expected_area = np.pi * 80**2
        actual_area = metadata['part_area']
        
        # Allow some tolerance for segmentation accuracy
        assert 0.5 * expected_area < actual_area < 1.5 * expected_area
    
    def test_pose_normalization(self, test_image):
        """Test pose normalization functionality."""
        config = {'pose_normalize': True}
        preprocessor = GlassPreprocessor(config)
        
        processed_image, metadata = preprocessor.preprocess_image(test_image)
        
        assert metadata['pose_normalized'] == True
        assert 'transform_matrix' in metadata
    
    def test_illumination_methods(self, test_image):
        """Test different illumination correction methods."""
        for method in ['divide', 'subtract']:
            config = {'illumination_method': method}
            preprocessor = GlassPreprocessor(config)
            
            processed_image, metadata = preprocessor.preprocess_image(test_image)
            
            # Should produce valid output regardless of method
            assert processed_image is not None
            assert np.all(processed_image >= 0) and np.all(processed_image <= 1)


class TestGlassFeatureExtractor:
    """Test suite for GlassFeatureExtractor class."""
    
    @pytest.fixture
    def feature_extractor(self):
        """Create a feature extractor instance for testing."""
        config = {
            'clahe_clip_limit': 3.0,
            'clahe_tile_grid_size': (40, 40),
            'retinex_sigma': 60,
            'dog_sigmas': [(2, 4), (4, 8)],
            'entropy_window_size': 11,
            'edge_band_width': 25
        }
        return GlassFeatureExtractor(config)
    
    @pytest.fixture
    def test_image(self):
        """Create a test image for feature extraction."""
        # Create a 128x128 RGB image (smaller for faster testing)
        image = np.random.rand(128, 128, 3).astype(np.float32)
        
        # Add some structure
        center = (64, 64)
        radius = 50
        y, x = np.ogrid[:128, :128]
        mask = (x - center[0])**2 + (y - center[1])**2 <= radius**2
        
        image[mask] = image[mask] * 0.8 + 0.2
        
        return image
    
    def test_feature_extraction_shape(self, feature_extractor, test_image):
        """Test that feature extraction produces correct output shape."""
        features = feature_extractor.extract_features(test_image)
        
        # Should produce 6-channel output
        assert features.shape == (test_image.shape[0], test_image.shape[1], 6)
        assert features.dtype == np.float32
    
    def test_feature_value_ranges(self, feature_extractor, test_image):
        """Test that all feature channels have valid value ranges."""
        features = feature_extractor.extract_features(test_image)
        
        # All channels should be in [0, 1] range
        for i in range(6):
            channel = features[:, :, i]
            assert np.min(channel) >= 0, f"Channel {i} has negative values"
            assert np.max(channel) <= 1, f"Channel {i} has values > 1"
    
    def test_individual_channels(self, feature_extractor, test_image):
        """Test individual channel computations."""
        features = feature_extractor.extract_features(test_image)
        
        # L_CLAHE channel (0) should have reasonable contrast
        l_clahe = features[:, :, 0]
        assert np.std(l_clahe) > 0.01, "L_CLAHE channel has too little variation"
        
        # DoG channels (1, 2) should detect edges
        dog1 = features[:, :, 1]
        dog2 = features[:, :, 2]
        assert np.max(dog1) > 0.1, "DoG_s2_4 channel shows no edge response"
        assert np.max(dog2) > 0.1, "DoG_s4_8 channel shows no edge response"
        
        # Entropy channel (3) should show texture variation
        entropy = features[:, :, 3]
        assert np.std(entropy) > 0.01, "Entropy channel has too little variation"
        
        # EdgeBandMask (4) should be binary-like
        edge_mask = features[:, :, 4]
        unique_values = np.unique(edge_mask)
        assert len(unique_values) <= 10, "EdgeBandMask should be mostly binary"
        
        # ConcavityMap (5) should be mostly zero with some features
        concavity = features[:, :, 5]
        zero_ratio = np.mean(concavity == 0)
        assert zero_ratio > 0.5, "ConcavityMap should be mostly zero"
    
    def test_edge_band_mask_properties(self, feature_extractor, test_image):
        """Test specific properties of the edge band mask."""
        features = feature_extractor.extract_features(test_image)
        edge_mask = features[:, :, 4]
        
        # Edge band should occupy reasonable percentage of image
        band_ratio = np.mean(edge_mask > 0)
        assert 0.02 <= band_ratio <= 0.15, f"Edge band ratio {band_ratio} outside expected range [0.02, 0.15]"
    
    def test_concavity_detection(self, feature_extractor):
        """Test concavity detection with synthetic notched shape."""
        # Create image with a notched circle
        image = np.zeros((128, 128, 3), dtype=np.float32)
        
        # Draw circle
        center = (64, 64)
        radius = 40
        y, x = np.ogrid[:128, :128]
        circle_mask = (x - center[0])**2 + (y - center[1])**2 <= radius**2
        image[circle_mask] = 0.7
        
        # Add a notch (concave defect)
        notch_mask = (x >= 100) & (x <= 110) & (y >= 60) & (y <= 68)
        image[notch_mask] = 0
        
        features = feature_extractor.extract_features(image)
        concavity = features[:, :, 5]
        
        # Should detect some concavity
        assert np.max(concavity) > 0.1, "Failed to detect concavity in notched shape"
        
        # Concavity should be localized
        high_concavity_ratio = np.mean(concavity > 0.5)
        assert high_concavity_ratio < 0.1, "Concavity detection too widespread"


class TestIntegration:
    """Integration tests for the complete pipeline."""
    
    def test_end_to_end_processing(self):
        """Test complete preprocessing and feature extraction pipeline."""
        # Create synthetic test image
        image = np.random.rand(200, 200, 3).astype(np.float32)
        
        # Add circular part
        center = (100, 100)
        radius = 70
        y, x = np.ogrid[:200, :200]
        mask = (x - center[0])**2 + (y - center[1])**2 <= radius**2
        image[mask] = image[mask] * 0.6 + 0.3
        
        # Process through complete pipeline
        preprocessor = GlassPreprocessor()
        feature_extractor = GlassFeatureExtractor()
        
        processed_image, metadata = preprocessor.preprocess_image(image)
        features = feature_extractor.extract_features(processed_image)
        
        # Verify complete pipeline output
        assert features.shape[2] == 6
        assert np.all(features >= 0) and np.all(features <= 1)
        assert metadata['segmentation_success'] == True
    
    def test_file_io_integration(self):
        """Test file I/O integration with temporary files."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create test image file
            test_image = (np.random.rand(100, 100, 3) * 255).astype(np.uint8)
            image_path = os.path.join(temp_dir, 'test_image.png')
            cv2.imwrite(image_path, cv2.cvtColor(test_image, cv2.COLOR_RGB2BGR))
            
            # Test feature extraction from file
            features = extract_features_from_image(image_path)
            
            assert features.shape == (100, 100, 6)
            assert features.dtype == np.float32
    
    def test_batch_processing_consistency(self):
        """Test that batch processing produces consistent results."""
        # Create multiple similar test images
        images = []
        for i in range(3):
            image = np.random.rand(100, 100, 3).astype(np.float32)
            # Add consistent structure
            image[40:60, 40:60, :] = 0.8
            images.append(image)
        
        # Process all images
        preprocessor = GlassPreprocessor()
        feature_extractor = GlassFeatureExtractor()
        
        all_features = []
        for image in images:
            processed_image, _ = preprocessor.preprocess_image(image)
            features = feature_extractor.extract_features(processed_image)
            all_features.append(features)
        
        # Check consistency across batch
        for i in range(1, len(all_features)):
            for channel in range(6):
                # Mean values should be similar across images
                mean_diff = abs(np.mean(all_features[0][:, :, channel]) - 
                              np.mean(all_features[i][:, :, channel]))
                assert mean_diff < 0.2, f"Inconsistent processing for channel {channel}"


class TestDataset:
    """Test suite for dataset functionality."""
    
    def test_dataset_creation(self):
        """Test dataset creation with synthetic data."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create synthetic images
            for i in range(3):
                image = (np.random.rand(100, 100, 3) * 255).astype(np.uint8)
                image_path = os.path.join(temp_dir, f'image_{i}.png')
                cv2.imwrite(image_path, cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
            
            # Create dataset
            dataset = GlassChipDataset(
                root=temp_dir,
                compute_on_fly=True
            )
            
            assert len(dataset) == 3
            
            # Test data loading
            sample = dataset[0]
            assert 'features' in sample
            assert sample['features'].shape[0] == 6  # 6 channels
    
    def test_dataloader_creation(self):
        """Test dataloader creation."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create synthetic images
            for i in range(2):
                image = (np.random.rand(50, 50, 3) * 255).astype(np.uint8)
                image_path = os.path.join(temp_dir, f'image_{i}.png')
                cv2.imwrite(image_path, cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
            
            # Create dataloader
            dataloader = create_dataloader(
                root=temp_dir,
                batch_size=2,
                num_workers=0,  # Use 0 for testing
                train=False,
                augment=False
            )
            
            # Test batch loading
            batch = next(iter(dataloader))
            assert 'features' in batch
            assert batch['features'].shape[0] == 2  # Batch size
            assert batch['features'].shape[1] == 6  # Channels


class TestAugmentations:
    """Test suite for augmentation functionality."""
    
    @pytest.fixture
    def augmentations(self):
        """Create augmentation pipeline for testing."""
        return GlassDefectAugmentations()
    
    @pytest.fixture
    def test_features(self):
        """Create test features for augmentation."""
        return np.random.rand(64, 64, 6).astype(np.float32)
    
    def test_augmentation_shape_preservation(self, augmentations, test_features):
        """Test that augmentations preserve feature shape."""
        aug_features, _, _, _ = augmentations.augment_features(test_features)
        
        assert aug_features.shape == test_features.shape
        assert aug_features.dtype == test_features.dtype
    
    def test_augmentation_value_ranges(self, augmentations, test_features):
        """Test that augmentations maintain valid value ranges."""
        aug_features, _, _, _ = augmentations.augment_features(test_features)
        
        # Values should remain in [0, 1] range
        assert np.all(aug_features >= 0)
        assert np.all(aug_features <= 1)
    
    def test_tta_variants(self, augmentations, test_features):
        """Test test-time augmentation variant generation."""
        variants = augmentations.create_tta_variants(test_features)
        
        assert len(variants) > 1  # Should include original + variants
        assert variants[0].shape == test_features.shape  # First should be original


class TestSyntheticDefects:
    """Test suite using synthetic defects for quantitative validation."""
    
    def create_synthetic_notched_circle(self, size: int = 128, notch_width: int = 10) -> np.ndarray:
        """Create a synthetic image with a notched circle."""
        image = np.zeros((size, size, 3), dtype=np.float32)
        
        # Create circle
        center = (size // 2, size // 2)
        radius = size // 3
        y, x = np.ogrid[:size, :size]
        circle_mask = (x - center[0])**2 + (y - center[1])**2 <= radius**2
        image[circle_mask] = 0.7
        
        # Add notch on the right edge
        notch_x = center[0] + radius - 5
        notch_y_start = center[1] - notch_width // 2
        notch_y_end = center[1] + notch_width // 2
        
        image[notch_y_start:notch_y_end, notch_x:notch_x+notch_width] = 0
        
        return image
    
    def test_concavity_detection_quantitative(self):
        """Quantitative test of concavity detection on synthetic defects."""
        feature_extractor = GlassFeatureExtractor()
        
        # Test different notch sizes
        for notch_width in [5, 10, 15]:
            image = self.create_synthetic_notched_circle(notch_width=notch_width)
            features = feature_extractor.extract_features(image)
            concavity = features[:, :, 5]
            
            # Should detect concavity proportional to notch size
            max_concavity = np.max(concavity)
            assert max_concavity > 0.05, f"Failed to detect notch of width {notch_width}"
            
            # Larger notches should generally produce stronger responses
            if notch_width >= 10:
                assert max_concavity > 0.1, f"Weak response for notch width {notch_width}"
    
    def test_edge_band_coverage(self):
        """Test edge band mask coverage on synthetic shapes."""
        feature_extractor = GlassFeatureExtractor()
        
        # Test with perfect circle
        image = np.zeros((128, 128, 3), dtype=np.float32)
        center = (64, 64)
        radius = 50
        y, x = np.ogrid[:128, :128]
        circle_mask = (x - center[0])**2 + (y - center[1])**2 <= radius**2
        image[circle_mask] = 0.7
        
        features = feature_extractor.extract_features(image)
        edge_mask = features[:, :, 4]
        
        # Edge band should form a ring around the circle
        band_ratio = np.mean(edge_mask > 0)
        
        # For a circle with radius 50 and band width 25, expect reasonable coverage
        assert 0.05 <= band_ratio <= 0.25, f"Edge band ratio {band_ratio} outside expected range"


# Pytest configuration and fixtures
@pytest.fixture(scope="session")
def test_data_dir():
    """Create temporary directory for test data."""
    with tempfile.TemporaryDirectory() as temp_dir:
        yield temp_dir


def test_pipeline_deterministic():
    """Test that the pipeline produces deterministic results."""
    # Set random seeds
    np.random.seed(42)
    
    # Create test image
    image = np.random.rand(100, 100, 3).astype(np.float32)
    
    # Process twice
    preprocessor = GlassPreprocessor()
    feature_extractor = GlassFeatureExtractor()
    
    processed1, _ = preprocessor.preprocess_image(image.copy())
    features1 = feature_extractor.extract_features(processed1)
    
    processed2, _ = preprocessor.preprocess_image(image.copy())
    features2 = feature_extractor.extract_features(processed2)
    
    # Results should be identical
    np.testing.assert_array_almost_equal(features1, features2, decimal=6)


if __name__ == "__main__":
    # Run tests when script is executed directly
    pytest.main([__file__, "-v"])

