"""
Glass Chip Detection Pipeline

A production-grade hybrid rule-based + YOLO pipeline for detecting chips and checks 
in glass parts with maximum recall.

This package combines classical computer vision techniques with deep learning to 
achieve robust defect detection by transforming RGB images into 6-channel feature 
tensors that highlight defects while suppressing background textures.
"""

__version__ = "1.0.0"
__author__ = "Glass Detection Team"
__email__ = "contact@example.com"

# Import main classes for easy access
from .preproc_glass import GlassPreprocessor
from .features_glass import GlassFeatureExtractor
from .dataset_glass import GlassChipDataset, create_dataloader
from .aug_glass import GlassDefectAugmentations

__all__ = [
    'GlassPreprocessor',
    'GlassFeatureExtractor', 
    'GlassChipDataset',
    'create_dataloader',
    'GlassDefectAugmentations'
]

