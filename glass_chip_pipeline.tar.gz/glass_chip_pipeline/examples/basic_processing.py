#!/usr/bin/env python3
"""
Basic example: Process a single image and visualize results.
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
import sys
from pathlib import Path

# Add parent directory to path to import modules
sys.path.append(str(Path(__file__).parent.parent))

from preproc_glass import GlassPreprocessor
from features_glass import GlassFeatureExtractor

def main():
    # Check if image path is provided
    if len(sys.argv) != 2:
        print("Usage: python basic_processing.py <image_path>")
        sys.exit(1)
    
    image_path = sys.argv[1]
    
    # Load image
    image = cv2.imread(image_path)
    if image is None:
        print(f"Error: Could not load image {image_path}")
        sys.exit(1)
    
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    
    # Initialize pipeline
    config = {
        'clahe_clip_limit': 3.0,
        'edge_band_width': 25,
        'texture_suppress': True,
        'pose_normalize': True
    }
    
    preprocessor = GlassPreprocessor(config)
    feature_extractor = GlassFeatureExtractor(config)
    
    # Process image
    print("Preprocessing image...")
    processed_image, metadata = preprocessor.preprocess_image(image)
    
    print("Extracting features...")
    features = feature_extractor.extract_features(processed_image)
    
    # Visualize results
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    channel_names = ['L_CLAHE', 'DoG_s2_4', 'DoG_s4_8', 'Entropy11', 'EdgeBandMask', 'ConcavityMap']
    
    for i, (ax, name) in enumerate(zip(axes.flat, channel_names)):
        ax.imshow(features[:, :, i], cmap='viridis')
        ax.set_title(name)
        ax.axis('off')
        
        # Add colorbar
        plt.colorbar(ax.images[0], ax=ax, fraction=0.046, pad=0.04)
    
    plt.tight_layout()
    
    # Save visualization
    output_path = Path(image_path).stem + '_features.png'
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"Feature visualization saved to {output_path}")
    
    plt.show()
    
    # Print processing information
    print("\nProcessing Results:")
    print("=" * 40)
    print(f"Original image shape: {metadata['original_shape']}")
    print(f"Final image shape: {metadata['final_shape']}")
    print(f"Feature tensor shape: {features.shape}")
    print(f"Pose normalized: {metadata.get('pose_normalized', 'N/A')}")
    print(f"Texture suppressed: {metadata.get('texture_suppressed', 'N/A')}")
    print(f"Segmentation successful: {metadata.get('segmentation_success', 'N/A')}")
    
    if 'part_area' in metadata:
        print(f"Part area: {metadata['part_area']} pixels")
    
    # Print channel statistics
    print("\nChannel Statistics:")
    print("-" * 30)
    for i, name in enumerate(channel_names):
        channel = features[:, :, i]
        print(f"{name}:")
        print(f"  Mean: {np.mean(channel):.4f}")
        print(f"  Std:  {np.std(channel):.4f}")
        print(f"  Min:  {np.min(channel):.4f}")
        print(f"  Max:  {np.max(channel):.4f}")
        print(f"  Non-zero ratio: {np.mean(channel > 0):.4f}")

if __name__ == "__main__":
    main()

