"""
Glass preprocessing module for pose normalization, illumination flattening, and texture suppression.

This module implements classical computer vision techniques to prepare glass images
for defect detection by normalizing pose, flattening illumination, and suppressing
directional textures that can interfere with chip/check detection.
"""

import cv2
import numpy as np
from typing import Tuple, Optional, Dict, Any
import logging
from scipy import ndimage
from skimage import filters, morphology, measure
import warnings

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore', category=UserWarning)

logger = logging.getLogger(__name__)


class GlassPreprocessor:
    """
    Main preprocessing class for glass chip detection pipeline.
    
    Implements pose normalization, illumination flattening, and texture suppression
    using classical computer vision techniques optimized for high recall.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize preprocessor with configuration.
        
        Args:
            config: Dictionary containing preprocessing parameters
        """
        self.config = config or self._default_config()
        
    def _default_config(self) -> Dict[str, Any]:
        """Default configuration parameters."""
        return {
            'pose_normalize': True,
            'illumination_method': 'divide',  # 'divide' or 'subtract'
            'texture_suppress': True,
            'retinex_sigma': 60,
            'margin_px': 10,
            'min_part_area': 1000,
            'texture_angle_bins': 180,
            'guided_filter_radius': 8,
            'guided_filter_eps': 0.01
        }
    
    def preprocess_image(self, image: np.ndarray) -> Tuple[np.ndarray, Dict[str, Any]]:
        """
        Main preprocessing pipeline.
        
        Args:
            image: Input RGB image (H, W, 3) uint8
            
        Returns:
            Tuple of (processed_image, metadata)
            - processed_image: Preprocessed image ready for feature extraction
            - metadata: Dictionary with processing statistics and parameters
        """
        metadata = {'original_shape': image.shape}
        
        # Convert to float32 and normalize
        if image.dtype == np.uint8:
            image = image.astype(np.float32) / 255.0
        
        # Handle grayscale conversion if needed
        if len(image.shape) == 2:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        elif image.shape[2] == 4:  # RGBA
            image = cv2.cvtColor(image, cv2.COLOR_RGBA2RGB)
            
        # Convert to Lab color space for processing
        lab_image = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)
        l_channel = lab_image[:, :, 0] / 100.0  # Normalize L to [0,1]
        
        # Step 1: Segment the part
        part_mask, contour = self._segment_part(l_channel)
        metadata['part_area'] = np.sum(part_mask)
        metadata['segmentation_success'] = contour is not None
        
        # Step 2: Pose normalization (if enabled and successful segmentation)
        if self.config['pose_normalize'] and contour is not None:
            image, l_channel, part_mask, transform_matrix = self._normalize_pose(
                image, l_channel, part_mask, contour
            )
            metadata['pose_normalized'] = True
            metadata['transform_matrix'] = transform_matrix
        else:
            metadata['pose_normalized'] = False
            
        # Step 3: Illumination flattening
        l_channel = self._flatten_illumination(l_channel, part_mask)
        metadata['illumination_flattened'] = True
        
        # Step 4: Texture suppression (if enabled)
        if self.config['texture_suppress']:
            l_channel, texture_angle = self._suppress_directional_texture(l_channel, part_mask)
            metadata['texture_suppressed'] = True
            metadata['dominant_texture_angle'] = texture_angle
        else:
            metadata['texture_suppressed'] = False
            
        # Reconstruct the image with processed L channel
        lab_image[:, :, 0] = l_channel * 100.0
        processed_image = cv2.cvtColor(lab_image, cv2.COLOR_LAB2RGB)
        
        # Ensure output is in valid range
        processed_image = np.clip(processed_image, 0, 1)
        
        metadata['final_shape'] = processed_image.shape
        
        return processed_image, metadata
    
    def _segment_part(self, l_channel: np.ndarray) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        """
        Segment the glass part from background using adaptive thresholding.
        
        Args:
            l_channel: L channel from Lab color space [0,1]
            
        Returns:
            Tuple of (binary_mask, largest_contour)
        """
        try:
            # Convert to uint8 for OpenCV operations
            l_uint8 = (l_channel * 255).astype(np.uint8)
            
            # Apply Gaussian blur to reduce noise
            blurred = cv2.GaussianBlur(l_uint8, (5, 5), 0)
            
            # Try Otsu thresholding first
            _, binary = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # If Otsu fails (very uniform image), try adaptive thresholding
            if np.sum(binary) < self.config['min_part_area']:
                binary = cv2.adaptiveThreshold(
                    blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                    cv2.THRESH_BINARY, 11, 2
                )
            
            # Clean up the mask with morphological operations
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
            binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
            binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel)
            
            # Find contours and select the largest one
            contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            if not contours:
                logger.warning("No contours found, using fallback segmentation")
                return self._fallback_segmentation(l_channel)
            
            # Select largest contour by area
            largest_contour = max(contours, key=cv2.contourArea)
            
            if cv2.contourArea(largest_contour) < self.config['min_part_area']:
                logger.warning("Largest contour too small, using fallback segmentation")
                return self._fallback_segmentation(l_channel)
            
            # Create clean mask from largest contour
            mask = np.zeros_like(binary)
            cv2.fillPoly(mask, [largest_contour], 255)
            
            return mask.astype(bool), largest_contour
            
        except Exception as e:
            logger.warning(f"Segmentation failed: {e}, using fallback")
            return self._fallback_segmentation(l_channel)
    
    def _fallback_segmentation(self, l_channel: np.ndarray) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        """
        Fallback segmentation using edge detection and convex hull.
        
        Args:
            l_channel: L channel from Lab color space [0,1]
            
        Returns:
            Tuple of (binary_mask, None)
        """
        # Convert to uint8
        l_uint8 = (l_channel * 255).astype(np.uint8)
        
        # Edge detection
        edges = cv2.Canny(l_uint8, 50, 150)
        
        # Dilate edges to connect nearby features
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        edges = cv2.dilate(edges, kernel, iterations=2)
        
        # Find contours and create convex hull
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        if contours:
            # Combine all edge points
            all_points = np.vstack(contours)
            hull = cv2.convexHull(all_points)
            
            # Create mask from convex hull
            mask = np.zeros_like(edges)
            cv2.fillPoly(mask, [hull], 255)
            
            return mask.astype(bool), None
        else:
            # Ultimate fallback: use entire image
            logger.warning("Complete segmentation failure, using entire image")
            return np.ones_like(l_channel, dtype=bool), None
    
    def _normalize_pose(self, image: np.ndarray, l_channel: np.ndarray, 
                       part_mask: np.ndarray, contour: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Normalize pose by rotating to canonical orientation and cropping.
        
        Args:
            image: RGB image [0,1]
            l_channel: L channel [0,1]
            part_mask: Binary mask of the part
            contour: Contour points of the part
            
        Returns:
            Tuple of (rotated_image, rotated_l_channel, rotated_mask, transform_matrix)
        """
        # Find minimum area rectangle
        rect = cv2.minAreaRect(contour)
        center, (width, height), angle = rect
        
        # Determine rotation angle to make the part canonical
        # Rotate so that the longer side is horizontal
        if width < height:
            angle += 90
            
        # Get rotation matrix
        rows, cols = image.shape[:2]
        rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
        
        # Apply rotation
        rotated_image = cv2.warpAffine(image, rotation_matrix, (cols, rows), 
                                     flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
        rotated_l_channel = cv2.warpAffine(l_channel, rotation_matrix, (cols, rows),
                                         flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
        rotated_mask = cv2.warpAffine(part_mask.astype(np.uint8), rotation_matrix, (cols, rows),
                                    flags=cv2.INTER_NEAREST) > 0
        
        # Find bounding box of rotated part
        coords = np.column_stack(np.where(rotated_mask))
        if len(coords) > 0:
            y_min, x_min = coords.min(axis=0)
            y_max, x_max = coords.max(axis=0)
            
            # Add margin
            margin = self.config['margin_px']
            y_min = max(0, y_min - margin)
            x_min = max(0, x_min - margin)
            y_max = min(rows, y_max + margin)
            x_max = min(cols, x_max + margin)
            
            # Crop to bounding box
            rotated_image = rotated_image[y_min:y_max, x_min:x_max]
            rotated_l_channel = rotated_l_channel[y_min:y_max, x_min:x_max]
            rotated_mask = rotated_mask[y_min:y_max, x_min:x_max]
            
            # Update transform matrix to include cropping
            crop_matrix = np.array([[1, 0, -x_min], [0, 1, -y_min]], dtype=np.float32)
            transform_matrix = np.vstack([rotation_matrix, [0, 0, 1]])
            crop_matrix_3x3 = np.vstack([crop_matrix, [0, 0, 1]])
            transform_matrix = crop_matrix_3x3 @ transform_matrix
        else:
            transform_matrix = np.vstack([rotation_matrix, [0, 0, 1]])
        
        return rotated_image, rotated_l_channel, rotated_mask, transform_matrix[:2]
    
    def _flatten_illumination(self, l_channel: np.ndarray, part_mask: np.ndarray) -> np.ndarray:
        """
        Flatten illumination using large Gaussian background estimation.
        
        Args:
            l_channel: L channel [0,1]
            part_mask: Binary mask of the part
            
        Returns:
            Illumination-corrected L channel
        """
        # Create background estimation using large Gaussian blur
        sigma = self.config['retinex_sigma']
        background = cv2.GaussianBlur(l_channel, (0, 0), sigma)
        
        # Apply illumination correction
        if self.config['illumination_method'] == 'divide':
            # Retinex-style division
            corrected = l_channel / (background + 1e-6)
        else:
            # Subtraction method
            corrected = l_channel - background + 0.5
        
        # Normalize to [0,1] within the part mask
        if np.any(part_mask):
            part_pixels = corrected[part_mask]
            if len(part_pixels) > 0:
                min_val, max_val = np.percentile(part_pixels, [1, 99])
                if max_val > min_val:
                    corrected = (corrected - min_val) / (max_val - min_val)
        
        # Clip to valid range
        corrected = np.clip(corrected, 0, 1)
        
        return corrected
    
    def _suppress_directional_texture(self, l_channel: np.ndarray, 
                                    part_mask: np.ndarray) -> Tuple[np.ndarray, float]:
        """
        Suppress directional textures (like polishing marks) using gradient analysis.
        
        Args:
            l_channel: L channel [0,1]
            part_mask: Binary mask of the part
            
        Returns:
            Tuple of (texture_suppressed_image, dominant_angle)
        """
        # Compute gradients
        grad_x = cv2.Sobel(l_channel, cv2.CV_64F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(l_channel, cv2.CV_64F, 0, 1, ksize=3)
        
        # Compute gradient magnitude and direction
        magnitude = np.sqrt(grad_x**2 + grad_y**2)
        direction = np.arctan2(grad_y, grad_x) * 180 / np.pi
        
        # Only consider gradients within the part mask
        if np.any(part_mask):
            masked_direction = direction[part_mask & (magnitude > np.percentile(magnitude, 75))]
            
            if len(masked_direction) > 0:
                # Find dominant direction using histogram
                hist, bin_edges = np.histogram(masked_direction, bins=self.config['texture_angle_bins'])
                dominant_angle = bin_edges[np.argmax(hist)]
                
                # Create directional filter kernel
                kernel_size = 15
                kernel = self._create_directional_kernel(kernel_size, dominant_angle)
                
                # Apply morphological opening along dominant direction
                suppressed = cv2.morphologyEx(l_channel, cv2.MORPH_OPEN, kernel)
                
                # Blend original and suppressed based on gradient strength
                alpha = np.clip(magnitude / (np.percentile(magnitude, 95) + 1e-6), 0, 1)
                result = alpha * l_channel + (1 - alpha) * suppressed
                
                return result, dominant_angle
        
        # If no dominant direction found, return original
        return l_channel, 0.0
    
    def _create_directional_kernel(self, size: int, angle_deg: float) -> np.ndarray:
        """
        Create a directional morphological kernel.
        
        Args:
            size: Kernel size
            angle_deg: Angle in degrees
            
        Returns:
            Binary kernel for morphological operations
        """
        kernel = np.zeros((size, size), dtype=np.uint8)
        center = size // 2
        
        # Convert angle to radians
        angle_rad = np.radians(angle_deg)
        
        # Create line kernel along the specified direction
        for i in range(size):
            for j in range(size):
                # Distance from center
                dx = j - center
                dy = i - center
                
                # Project onto the direction vector
                projection = abs(dx * np.cos(angle_rad) + dy * np.sin(angle_rad))
                perpendicular = abs(-dx * np.sin(angle_rad) + dy * np.cos(angle_rad))
                
                # Include pixel if it's close to the line
                if projection <= size//2 and perpendicular <= 1:
                    kernel[i, j] = 1
        
        return kernel


def preprocess_single_image(image_path: str, config: Optional[Dict[str, Any]] = None) -> Tuple[np.ndarray, Dict[str, Any]]:
    """
    Convenience function to preprocess a single image.
    
    Args:
        image_path: Path to input image
        config: Optional configuration dictionary
        
    Returns:
        Tuple of (processed_image, metadata)
    """
    # Load image
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Could not load image: {image_path}")
    
    # Convert BGR to RGB
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    # Create preprocessor and process
    preprocessor = GlassPreprocessor(config)
    return preprocessor.preprocess_image(image)


if __name__ == "__main__":
    # Example usage
    import sys
    
    if len(sys.argv) != 2:
        print("Usage: python preproc_glass.py <image_path>")
        sys.exit(1)
    
    image_path = sys.argv[1]
    processed_image, metadata = preprocess_single_image(image_path)
    
    print("Preprocessing completed:")
    for key, value in metadata.items():
        print(f"  {key}: {value}")

