#!/usr/bin/env python3
"""
Visualization and QA preview utility for glass chip detection pipeline.

This script generates comprehensive preview images showing all 6 feature channels
along with the original image and part mask for quality assurance.
"""

import os
import sys
import argparse
import logging
from pathlib import Path
from typing import Dict, Any, Optional, Tuple

import cv2
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Rectangle
import seaborn as sns

# Import our modules
from preproc_glass import GlassPreprocessor
from features_glass import GlassFeatureExtractor

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class GlassVisualizationTool:
    """
    Comprehensive visualization tool for glass chip detection pipeline.
    
    Generates detailed preview images showing all processing stages and
    feature channels for quality assurance and debugging.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize visualization tool.
        
        Args:
            config: Configuration dictionary for preprocessing
        """
        self.config = config or {}
        self.preprocessor = GlassPreprocessor(self.config)
        self.feature_extractor = GlassFeatureExtractor(self.config)
        
        # Channel information
        self.channel_info = {
            0: {'name': 'L_CLAHE', 'description': 'Enhanced L channel with CLAHE + Retinex', 'cmap': 'gray'},
            1: {'name': 'DoG_s2_4', 'description': 'Difference of Gaussians (σ=2,4)', 'cmap': 'hot'},
            2: {'name': 'DoG_s4_8', 'description': 'Difference of Gaussians (σ=4,8)', 'cmap': 'hot'},
            3: {'name': 'Entropy11', 'description': 'Local entropy (11×11 window)', 'cmap': 'viridis'},
            4: {'name': 'EdgeBandMask', 'description': 'Edge band mask (15-30px)', 'cmap': 'binary'},
            5: {'name': 'ConcavityMap', 'description': 'Edge concavity/deviation map', 'cmap': 'plasma'}
        }
    
    def create_comprehensive_preview(self, image_path: str, output_path: str, 
                                   features: Optional[np.ndarray] = None) -> str:
        """
        Create a comprehensive preview showing all processing stages.
        
        Args:
            image_path: Path to input image
            output_path: Path to save preview image
            features: Optional precomputed features (if None, will compute)
            
        Returns:
            Path to generated preview image
        """
        # Load and process image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")
        
        # Convert BGR to RGB and normalize
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        
        # Preprocess image
        processed_image, metadata = self.preprocessor.preprocess_image(image_rgb)
        
        # Extract features if not provided
        if features is None:
            features = self.feature_extractor.extract_features(processed_image)
        
        # Create the comprehensive preview
        fig = plt.figure(figsize=(20, 12))
        gs = gridspec.GridSpec(3, 4, figure=fig, hspace=0.3, wspace=0.3)
        
        # Original image
        ax1 = fig.add_subplot(gs[0, 0])
        ax1.imshow(image_rgb)
        ax1.set_title('Original Image', fontsize=12, fontweight='bold')
        ax1.axis('off')
        
        # Processed image
        ax2 = fig.add_subplot(gs[0, 1])
        ax2.imshow(processed_image)
        ax2.set_title('Preprocessed Image', fontsize=12, fontweight='bold')
        ax2.axis('off')
        
        # Feature channels (2x3 grid)
        for i in range(6):
            row = (i // 2) + 1  # Start from row 1
            col = (i % 2) * 2   # Columns 0, 2
            
            ax = fig.add_subplot(gs[row, col:col+2])
            
            channel = features[:, :, i]
            info = self.channel_info[i]
            
            im = ax.imshow(channel, cmap=info['cmap'], vmin=0, vmax=1)
            ax.set_title(f"{info['name']}\n{info['description']}", 
                        fontsize=10, fontweight='bold')
            ax.axis('off')
            
            # Add colorbar
            plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        
        # Add metadata text
        metadata_text = self._format_metadata(metadata)
        fig.text(0.02, 0.02, metadata_text, fontsize=8, verticalalignment='bottom',
                bbox=dict(boxstyle='round', facecolor='lightgray', alpha=0.8))
        
        # Add statistics
        stats_text = self._format_channel_statistics(features)
        fig.text(0.98, 0.02, stats_text, fontsize=8, verticalalignment='bottom',
                horizontalalignment='right',
                bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.8))
        
        # Save the figure
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        logger.info(f"Comprehensive preview saved to {output_path}")
        return output_path
    
    def create_channel_grid(self, features: np.ndarray, output_path: str) -> str:
        """
        Create a simple 2x3 grid showing all 6 channels.
        
        Args:
            features: 6-channel feature array (H, W, 6)
            output_path: Path to save grid image
            
        Returns:
            Path to generated grid image
        """
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))
        fig.suptitle('Glass Chip Detection - Feature Channels', fontsize=16, fontweight='bold')
        
        for i in range(6):
            row = i // 3
            col = i % 3
            ax = axes[row, col]
            
            channel = features[:, :, i]
            info = self.channel_info[i]
            
            im = ax.imshow(channel, cmap=info['cmap'], vmin=0, vmax=1)
            ax.set_title(info['name'], fontsize=12, fontweight='bold')
            ax.axis('off')
            
            # Add colorbar
            plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        logger.info(f"Channel grid saved to {output_path}")
        return output_path
    
    def create_defect_overlay(self, image: np.ndarray, features: np.ndarray, 
                            masks: Optional[np.ndarray] = None, 
                            output_path: str = None) -> str:
        """
        Create an overlay showing potential defect regions.
        
        Args:
            image: Original RGB image
            features: 6-channel features
            masks: Optional ground truth masks
            output_path: Path to save overlay image
            
        Returns:
            Path to generated overlay image
        """
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        fig.suptitle('Defect Detection Overlay', fontsize=16, fontweight='bold')
        
        # Original image
        axes[0, 0].imshow(image)
        axes[0, 0].set_title('Original Image')
        axes[0, 0].axis('off')
        
        # Edge band mask overlay
        edge_mask = features[:, :, 4]  # EdgeBandMask channel
        overlay1 = image.copy()
        overlay1[:, :, 0] = np.where(edge_mask > 0.5, 1.0, overlay1[:, :, 0])
        axes[0, 1].imshow(overlay1)
        axes[0, 1].set_title('Edge Band Overlay')
        axes[0, 1].axis('off')
        
        # Concavity map overlay
        concavity = features[:, :, 5]  # ConcavityMap channel
        axes[1, 0].imshow(image)
        im = axes[1, 0].imshow(concavity, alpha=0.6, cmap='hot', vmin=0, vmax=1)
        axes[1, 0].set_title('Concavity Map Overlay')
        axes[1, 0].axis('off')
        plt.colorbar(im, ax=axes[1, 0])
        
        # Combined defect probability
        # Combine DoG responses and concavity for defect probability
        dog_combined = np.maximum(features[:, :, 1], features[:, :, 2])
        defect_prob = (dog_combined + concavity) / 2
        
        axes[1, 1].imshow(image)
        im = axes[1, 1].imshow(defect_prob, alpha=0.6, cmap='plasma', vmin=0, vmax=1)
        axes[1, 1].set_title('Combined Defect Probability')
        axes[1, 1].axis('off')
        plt.colorbar(im, ax=axes[1, 1])
        
        # Add ground truth masks if available
        if masks is not None:
            for i, mask in enumerate(masks):
                # Add mask contours to all subplots
                contours, _ = cv2.findContours(
                    (mask * 255).astype(np.uint8), 
                    cv2.RETR_EXTERNAL, 
                    cv2.CHAIN_APPROX_SIMPLE
                )
                
                for ax in axes.flat:
                    for contour in contours:
                        # Convert contour to matplotlib format
                        contour = contour.reshape(-1, 2)
                        ax.plot(contour[:, 0], contour[:, 1], 'lime', linewidth=2, alpha=0.8)
        
        plt.tight_layout()
        
        if output_path:
            plt.savefig(output_path, dpi=150, bbox_inches='tight')
            plt.close()
            logger.info(f"Defect overlay saved to {output_path}")
            return output_path
        else:
            plt.show()
            return ""
    
    def create_statistics_plot(self, features: np.ndarray, output_path: str) -> str:
        """
        Create statistical plots for all channels.
        
        Args:
            features: 6-channel feature array
            output_path: Path to save statistics plot
            
        Returns:
            Path to generated plot
        """
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        fig.suptitle('Channel Statistics', fontsize=16, fontweight='bold')
        
        for i in range(6):
            row = i // 3
            col = i % 3
            ax = axes[row, col]
            
            channel = features[:, :, i]
            info = self.channel_info[i]
            
            # Create histogram
            ax.hist(channel.flatten(), bins=50, alpha=0.7, density=True)
            ax.set_title(f"{info['name']} Distribution")
            ax.set_xlabel('Value')
            ax.set_ylabel('Density')
            ax.grid(True, alpha=0.3)
            
            # Add statistics text
            stats_text = f"Mean: {np.mean(channel):.3f}\n"
            stats_text += f"Std: {np.std(channel):.3f}\n"
            stats_text += f"Min: {np.min(channel):.3f}\n"
            stats_text += f"Max: {np.max(channel):.3f}\n"
            stats_text += f"Non-zero: {np.mean(channel > 0):.3f}"
            
            ax.text(0.02, 0.98, stats_text, transform=ax.transAxes,
                   verticalalignment='top', fontsize=8,
                   bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        logger.info(f"Statistics plot saved to {output_path}")
        return output_path
    
    def _format_metadata(self, metadata: Dict[str, Any]) -> str:
        """Format preprocessing metadata for display."""
        text = "Preprocessing Metadata:\n"
        text += f"Original shape: {metadata.get('original_shape', 'N/A')}\n"
        text += f"Final shape: {metadata.get('final_shape', 'N/A')}\n"
        text += f"Part area: {metadata.get('part_area', 'N/A')}\n"
        text += f"Pose normalized: {metadata.get('pose_normalized', 'N/A')}\n"
        text += f"Texture suppressed: {metadata.get('texture_suppressed', 'N/A')}\n"
        text += f"Segmentation success: {metadata.get('segmentation_success', 'N/A')}\n"
        
        if 'dominant_texture_angle' in metadata:
            text += f"Texture angle: {metadata['dominant_texture_angle']:.1f}°\n"
        
        return text
    
    def _format_channel_statistics(self, features: np.ndarray) -> str:
        """Format channel statistics for display."""
        text = "Channel Statistics:\n"
        
        for i in range(6):
            channel = features[:, :, i]
            info = self.channel_info[i]
            
            text += f"\n{info['name']}:\n"
            text += f"  Mean: {np.mean(channel):.3f}\n"
            text += f"  Std: {np.std(channel):.3f}\n"
            text += f"  Range: [{np.min(channel):.3f}, {np.max(channel):.3f}]\n"
            text += f"  Non-zero: {np.mean(channel > 0):.3f}\n"
        
        return text


def process_single_image(image_path: str, output_dir: str, config: Optional[Dict[str, Any]] = None):
    """
    Process a single image and generate all visualization outputs.
    
    Args:
        image_path: Path to input image
        output_dir: Output directory for visualizations
        config: Optional configuration dictionary
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    image_name = Path(image_path).stem
    
    # Create visualization tool
    viz_tool = GlassVisualizationTool(config)
    
    # Load and process image
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Could not load image: {image_path}")
    
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    
    # Process through pipeline
    processed_image, metadata = viz_tool.preprocessor.preprocess_image(image_rgb)
    features = viz_tool.feature_extractor.extract_features(processed_image)
    
    # Generate visualizations
    comprehensive_path = output_path / f"{image_name}_comprehensive.png"
    viz_tool.create_comprehensive_preview(image_path, str(comprehensive_path), features)
    
    grid_path = output_path / f"{image_name}_channels.png"
    viz_tool.create_channel_grid(features, str(grid_path))
    
    overlay_path = output_path / f"{image_name}_overlay.png"
    viz_tool.create_defect_overlay(image_rgb, features, output_path=str(overlay_path))
    
    stats_path = output_path / f"{image_name}_statistics.png"
    viz_tool.create_statistics_plot(features, str(stats_path))
    
    logger.info(f"All visualizations generated for {image_name}")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Generate visualization previews for glass chip detection pipeline"
    )
    
    parser.add_argument(
        '--input', required=True,
        help='Input image path or directory'
    )
    parser.add_argument(
        '--output', required=True,
        help='Output directory for visualizations'
    )
    parser.add_argument(
        '--config', type=str,
        help='Path to configuration YAML file'
    )
    parser.add_argument(
        '--type', choices=['comprehensive', 'channels', 'overlay', 'statistics', 'all'],
        default='all', help='Type of visualization to generate'
    )
    
    args = parser.parse_args()
    
    # Load configuration if provided
    config = None
    if args.config and os.path.exists(args.config):
        import yaml
        with open(args.config, 'r') as f:
            config = yaml.safe_load(f)
    
    # Process input
    input_path = Path(args.input)
    
    if input_path.is_file():
        # Single image
        process_single_image(str(input_path), args.output, config)
    elif input_path.is_dir():
        # Directory of images
        image_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif'}
        image_paths = []
        
        for ext in image_extensions:
            image_paths.extend(input_path.glob(f"*{ext}"))
            image_paths.extend(input_path.glob(f"*{ext.upper()}"))
        
        if not image_paths:
            logger.error(f"No images found in {input_path}")
            sys.exit(1)
        
        logger.info(f"Processing {len(image_paths)} images")
        
        for image_path in image_paths:
            try:
                process_single_image(str(image_path), args.output, config)
            except Exception as e:
                logger.error(f"Failed to process {image_path}: {e}")
    else:
        logger.error(f"Input path does not exist: {input_path}")
        sys.exit(1)
    
    logger.info("Visualization generation completed")


if __name__ == "__main__":
    main()

