"""
PyTorch Dataset class for glass chip detection with 6-channel feature inputs.

This module provides a PyTorch Dataset that loads preprocessed 6-channel feature tensors
and corresponding annotations for training YOLO models on glass defect detection.
"""

import os
import json
import cv2
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from typing import Dict, List, Tuple, Optional, Union, Any
import logging
from pathlib import Path
import yaml
from PIL import Image
import albumentations as A
from albumentations.pytorch import ToTensorV2

from preproc_glass import GlassPreprocessor
from features_glass import GlassFeatureExtractor

logger = logging.getLogger(__name__)


class GlassChipDataset(Dataset):
    """
    PyTorch Dataset for glass chip detection with 6-channel inputs.
    
    Supports loading preprocessed feature tensors or computing them on-the-fly.
    Handles COCO and YOLOv8 annotation formats for both bounding boxes and segmentation masks.
    """
    
    def __init__(
        self,
        root: str,
        ann_path: Optional[str] = None,
        channel_dir: Optional[str] = None,
        train: bool = True,
        augment: bool = False,
        config: Optional[Dict[str, Any]] = None,
        compute_on_fly: bool = False
    ):
        """
        Initialize dataset.
        
        Args:
            root: Root directory containing images
            ann_path: Path to annotation file (COCO JSON or YOLOv8 format)
            channel_dir: Directory containing preprocessed 6-channel .npy files
            train: Whether this is training set (affects augmentations)
            augment: Whether to apply data augmentations
            config: Configuration dictionary for preprocessing
            compute_on_fly: If True, compute features on-the-fly instead of loading from channel_dir
        """
        self.root = Path(root)
        self.ann_path = ann_path
        self.channel_dir = Path(channel_dir) if channel_dir else None
        self.train = train
        self.augment = augment and train
        self.compute_on_fly = compute_on_fly
        self.config = config or {}
        
        # Initialize preprocessors if computing on-the-fly
        if self.compute_on_fly:
            self.preprocessor = GlassPreprocessor(self.config)
            self.feature_extractor = GlassFeatureExtractor(self.config)
        
        # Load image paths
        self.image_paths = self._load_image_paths()
        
        # Load annotations if provided
        self.annotations = self._load_annotations() if ann_path else {}
        
        # Setup augmentations
        self.transform = self._setup_augmentations() if self.augment else None
        
        logger.info(f"Loaded {len(self.image_paths)} images from {root}")
        if self.annotations:
            logger.info(f"Loaded annotations for {len(self.annotations)} images")
    
    def _load_image_paths(self) -> List[Path]:
        """Load all image paths from root directory."""
        image_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif'}
        image_paths = []
        
        for ext in image_extensions:
            image_paths.extend(self.root.glob(f"*{ext}"))
            image_paths.extend(self.root.glob(f"*{ext.upper()}"))
        
        return sorted(image_paths)
    
    def _load_annotations(self) -> Dict[str, Any]:
        """Load annotations from file."""
        if not self.ann_path or not os.path.exists(self.ann_path):
            return {}
        
        try:
            if self.ann_path.endswith('.json'):
                return self._load_coco_annotations()
            else:
                return self._load_yolo_annotations()
        except Exception as e:
            logger.warning(f"Failed to load annotations: {e}")
            return {}
    
    def _load_coco_annotations(self) -> Dict[str, Any]:
        """Load COCO format annotations."""
        with open(self.ann_path, 'r') as f:
            coco_data = json.load(f)
        
        # Create mapping from image_id to annotations
        annotations = {}
        
        # Create image_id to filename mapping
        image_map = {img['id']: img['file_name'] for img in coco_data['images']}
        
        # Group annotations by image
        for ann in coco_data['annotations']:
            image_id = ann['image_id']
            filename = image_map.get(image_id)
            
            if filename:
                if filename not in annotations:
                    annotations[filename] = []
                
                # Convert COCO format to our internal format
                if 'segmentation' in ann and ann['segmentation']:
                    # Segmentation mask
                    mask_data = {
                        'type': 'mask',
                        'segmentation': ann['segmentation'],
                        'bbox': ann['bbox'],
                        'category_id': ann['category_id']
                    }
                else:
                    # Bounding box only
                    mask_data = {
                        'type': 'bbox',
                        'bbox': ann['bbox'],
                        'category_id': ann['category_id']
                    }
                
                annotations[filename].append(mask_data)
        
        return annotations
    
    def _load_yolo_annotations(self) -> Dict[str, Any]:
        """Load YOLOv8 format annotations."""
        annotations = {}
        ann_dir = Path(self.ann_path)
        
        # Look for .txt files with same names as images
        for image_path in self.image_paths:
            ann_file = ann_dir / f"{image_path.stem}.txt"
            
            if ann_file.exists():
                annotations[image_path.name] = self._parse_yolo_annotation(ann_file)
        
        return annotations
    
    def _parse_yolo_annotation(self, ann_file: Path) -> List[Dict[str, Any]]:
        """Parse a single YOLO annotation file."""
        annotations = []
        
        try:
            with open(ann_file, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 5:
                        class_id = int(parts[0])
                        x_center = float(parts[1])
                        y_center = float(parts[2])
                        width = float(parts[3])
                        height = float(parts[4])
                        
                        # Check if this is segmentation format (more than 5 values)
                        if len(parts) > 5:
                            # Segmentation points
                            points = [float(x) for x in parts[1:]]
                            annotations.append({
                                'type': 'mask',
                                'points': points,
                                'category_id': class_id
                            })
                        else:
                            # Bounding box format
                            annotations.append({
                                'type': 'bbox',
                                'bbox': [x_center, y_center, width, height],
                                'category_id': class_id
                            })
        except Exception as e:
            logger.warning(f"Failed to parse annotation file {ann_file}: {e}")
        
        return annotations
    
    def _setup_augmentations(self) -> A.Compose:
        """Setup augmentation pipeline."""
        transforms = [
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.5),
            A.Rotate(limit=5, p=0.3),
            A.RandomBrightnessContrast(
                brightness_limit=0.15,
                contrast_limit=0.15,
                p=0.3
            ),
            A.GaussianBlur(blur_limit=(1, 3), p=0.2),
        ]
        
        return A.Compose(
            transforms,
            bbox_params=A.BboxParams(format='coco', label_fields=['class_labels']),
            additional_targets={'mask': 'mask'}
        )
    
    def __len__(self) -> int:
        """Return dataset size."""
        return len(self.image_paths)
    
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """
        Get a single item from the dataset.
        
        Args:
            idx: Index of the item
            
        Returns:
            Dictionary containing:
            - 'features': 6-channel feature tensor (C, H, W)
            - 'masks': Binary masks for defects (if available)
            - 'bboxes': Bounding boxes (if available)
            - 'labels': Class labels
            - 'image_path': Path to original image
        """
        image_path = self.image_paths[idx]
        
        # Load or compute 6-channel features
        if self.compute_on_fly:
            features = self._compute_features_on_fly(image_path)
        else:
            features = self._load_precomputed_features(image_path)
        
        # Load annotations for this image
        image_name = image_path.name
        anns = self.annotations.get(image_name, [])
        
        # Process annotations
        masks, bboxes, labels = self._process_annotations(anns, features.shape[:2])
        
        # Apply augmentations if enabled
        if self.transform and len(anns) > 0:
            features, masks, bboxes, labels = self._apply_augmentations(
                features, masks, bboxes, labels
            )
        
        # Convert to tensors
        features_tensor = torch.from_numpy(features).permute(2, 0, 1).float()  # (C, H, W)
        
        result = {
            'features': features_tensor,
            'image_path': str(image_path)
        }
        
        if masks is not None:
            result['masks'] = torch.from_numpy(masks).float()
        
        if bboxes is not None:
            result['bboxes'] = torch.from_numpy(bboxes).float()
        
        if labels is not None:
            result['labels'] = torch.from_numpy(labels).long()
        
        return result
    
    def _compute_features_on_fly(self, image_path: Path) -> np.ndarray:
        """Compute 6-channel features on-the-fly."""
        # Load image
        image = cv2.imread(str(image_path))
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")
        
        # Convert BGR to RGB and normalize
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        
        # Preprocess image
        processed_image, _ = self.preprocessor.preprocess_image(image)
        
        # Extract features
        features = self.feature_extractor.extract_features(processed_image)
        
        return features
    
    def _load_precomputed_features(self, image_path: Path) -> np.ndarray:
        """Load precomputed 6-channel features from .npy file."""
        if not self.channel_dir:
            raise ValueError("channel_dir must be provided to load precomputed features")
        
        feature_path = self.channel_dir / f"{image_path.stem}.npy"
        
        if not feature_path.exists():
            raise FileNotFoundError(f"Feature file not found: {feature_path}")
        
        features = np.load(feature_path)
        
        if features.shape[2] != 6:
            raise ValueError(f"Expected 6 channels, got {features.shape[2]} in {feature_path}")
        
        return features
    
    def _process_annotations(self, anns: List[Dict[str, Any]], 
                           image_shape: Tuple[int, int]) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], Optional[np.ndarray]]:
        """Process annotations into masks, bboxes, and labels."""
        if not anns:
            return None, None, None
        
        h, w = image_shape
        masks = []
        bboxes = []
        labels = []
        
        for ann in anns:
            if ann['type'] == 'mask':
                # Create mask from segmentation
                if 'segmentation' in ann:
                    # COCO format segmentation
                    mask = self._create_mask_from_coco_segmentation(ann['segmentation'], (h, w))
                elif 'points' in ann:
                    # YOLO format segmentation
                    mask = self._create_mask_from_yolo_points(ann['points'], (h, w))
                else:
                    continue
                
                masks.append(mask)
                
                # Extract bounding box from mask
                bbox = self._extract_bbox_from_mask(mask)
                bboxes.append(bbox)
                
            elif ann['type'] == 'bbox':
                # Create mask from bounding box
                bbox = ann['bbox']
                
                if len(bbox) == 4:
                    if 'segmentation' in ann or 'points' in ann:
                        # COCO format: [x, y, width, height]
                        x, y, w_box, h_box = bbox
                        mask = np.zeros((h, w), dtype=np.uint8)
                        x1, y1 = int(x), int(y)
                        x2, y2 = int(x + w_box), int(y + h_box)
                        mask[y1:y2, x1:x2] = 1
                    else:
                        # YOLO format: [x_center, y_center, width, height] (normalized)
                        x_center, y_center, w_norm, h_norm = bbox
                        x_center *= w
                        y_center *= h
                        w_box = w_norm * w
                        h_box = h_norm * h
                        
                        x1 = int(x_center - w_box / 2)
                        y1 = int(y_center - h_box / 2)
                        x2 = int(x_center + w_box / 2)
                        y2 = int(y_center + h_box / 2)
                        
                        mask = np.zeros((h, w), dtype=np.uint8)
                        mask[max(0, y1):min(h, y2), max(0, x1):min(w, x2)] = 1
                        
                        # Convert back to COCO format for consistency
                        bbox = [x1, y1, x2 - x1, y2 - y1]
                
                masks.append(mask)
                bboxes.append(bbox)
            
            labels.append(ann['category_id'])
        
        if masks:
            masks = np.stack(masks, axis=0)
            bboxes = np.array(bboxes)
            labels = np.array(labels)
            return masks, bboxes, labels
        
        return None, None, None
    
    def _create_mask_from_coco_segmentation(self, segmentation: List, image_shape: Tuple[int, int]) -> np.ndarray:
        """Create binary mask from COCO segmentation format."""
        h, w = image_shape
        mask = np.zeros((h, w), dtype=np.uint8)
        
        for seg in segmentation:
            if isinstance(seg, list) and len(seg) >= 6:
                # Polygon format
                points = np.array(seg).reshape(-1, 2).astype(np.int32)
                cv2.fillPoly(mask, [points], 1)
        
        return mask
    
    def _create_mask_from_yolo_points(self, points: List[float], image_shape: Tuple[int, int]) -> np.ndarray:
        """Create binary mask from YOLO segmentation points."""
        h, w = image_shape
        mask = np.zeros((h, w), dtype=np.uint8)
        
        if len(points) >= 6 and len(points) % 2 == 0:
            # Convert normalized coordinates to pixel coordinates
            pixel_points = []
            for i in range(0, len(points), 2):
                x = int(points[i] * w)
                y = int(points[i + 1] * h)
                pixel_points.append([x, y])
            
            pixel_points = np.array(pixel_points, dtype=np.int32)
            cv2.fillPoly(mask, [pixel_points], 1)
        
        return mask
    
    def _extract_bbox_from_mask(self, mask: np.ndarray) -> List[int]:
        """Extract bounding box from binary mask."""
        coords = np.column_stack(np.where(mask > 0))
        
        if len(coords) > 0:
            y_min, x_min = coords.min(axis=0)
            y_max, x_max = coords.max(axis=0)
            return [x_min, y_min, x_max - x_min, y_max - y_min]
        
        return [0, 0, 0, 0]
    
    def _apply_augmentations(self, features: np.ndarray, masks: Optional[np.ndarray], 
                           bboxes: Optional[np.ndarray], labels: Optional[np.ndarray]) -> Tuple[np.ndarray, Optional[np.ndarray], Optional[np.ndarray], Optional[np.ndarray]]:
        """Apply augmentations to features and annotations."""
        if self.transform is None or masks is None:
            return features, masks, bboxes, labels
        
        try:
            # Use first channel as image for augmentation
            image = features[:, :, 0]
            
            # Prepare data for albumentations
            aug_data = {
                'image': image,
                'bboxes': bboxes.tolist() if bboxes is not None else [],
                'class_labels': labels.tolist() if labels is not None else []
            }
            
            # Add masks as additional targets
            for i, mask in enumerate(masks):
                aug_data[f'mask_{i}'] = mask
            
            # Apply augmentations
            augmented = self.transform(**aug_data)
            
            # Extract augmented data
            aug_image = augmented['image']
            aug_bboxes = np.array(augmented['bboxes']) if augmented['bboxes'] else bboxes
            aug_labels = np.array(augmented['class_labels']) if augmented['class_labels'] else labels
            
            # Extract augmented masks
            aug_masks = []
            for i in range(len(masks)):
                aug_masks.append(augmented[f'mask_{i}'])
            aug_masks = np.stack(aug_masks, axis=0) if aug_masks else masks
            
            # Apply same transformation to all feature channels
            # This is a simplified approach - in practice, you might want channel-specific augmentations
            aug_features = features.copy()
            aug_features[:, :, 0] = aug_image
            
            return aug_features, aug_masks, aug_bboxes, aug_labels
            
        except Exception as e:
            logger.warning(f"Augmentation failed: {e}, returning original data")
            return features, masks, bboxes, labels


def create_dataloader(
    root: str,
    ann_path: Optional[str] = None,
    channel_dir: Optional[str] = None,
    batch_size: int = 4,
    shuffle: bool = True,
    num_workers: int = 4,
    train: bool = True,
    augment: bool = False,
    config: Optional[Dict[str, Any]] = None
) -> DataLoader:
    """
    Create a DataLoader for glass chip detection.
    
    Args:
        root: Root directory containing images
        ann_path: Path to annotation file
        channel_dir: Directory containing preprocessed features
        batch_size: Batch size
        shuffle: Whether to shuffle data
        num_workers: Number of worker processes
        train: Whether this is training set
        augment: Whether to apply augmentations
        config: Configuration dictionary
        
    Returns:
        PyTorch DataLoader
    """
    dataset = GlassChipDataset(
        root=root,
        ann_path=ann_path,
        channel_dir=channel_dir,
        train=train,
        augment=augment,
        config=config
    )
    
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=True,
        collate_fn=collate_fn
    )


def collate_fn(batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
    """Custom collate function for variable-size annotations."""
    features = torch.stack([item['features'] for item in batch])
    image_paths = [item['image_path'] for item in batch]
    
    result = {
        'features': features,
        'image_paths': image_paths
    }
    
    # Handle variable-size annotations
    if 'masks' in batch[0]:
        masks = [item['masks'] for item in batch if 'masks' in item]
        if masks:
            result['masks'] = masks
    
    if 'bboxes' in batch[0]:
        bboxes = [item['bboxes'] for item in batch if 'bboxes' in item]
        if bboxes:
            result['bboxes'] = bboxes
    
    if 'labels' in batch[0]:
        labels = [item['labels'] for item in batch if 'labels' in item]
        if labels:
            result['labels'] = labels
    
    return result


if __name__ == "__main__":
    # Example usage
    import argparse
    
    parser = argparse.ArgumentParser(description="Test GlassChipDataset")
    parser.add_argument("--root", required=True, help="Root directory with images")
    parser.add_argument("--ann_path", help="Path to annotation file")
    parser.add_argument("--channel_dir", help="Directory with preprocessed features")
    parser.add_argument("--batch_size", type=int, default=2, help="Batch size")
    
    args = parser.parse_args()
    
    # Create dataset and dataloader
    dataloader = create_dataloader(
        root=args.root,
        ann_path=args.ann_path,
        channel_dir=args.channel_dir,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,  # Use 0 for debugging
        train=True,
        augment=False
    )
    
    # Test loading a batch
    for batch_idx, batch in enumerate(dataloader):
        print(f"Batch {batch_idx}:")
        print(f"  Features shape: {batch['features'].shape}")
        print(f"  Image paths: {batch['image_paths']}")
        
        if 'masks' in batch:
            print(f"  Number of mask sets: {len(batch['masks'])}")
        
        if 'bboxes' in batch:
            print(f"  Number of bbox sets: {len(batch['bboxes'])}")
        
        if batch_idx >= 2:  # Only test a few batches
            break

