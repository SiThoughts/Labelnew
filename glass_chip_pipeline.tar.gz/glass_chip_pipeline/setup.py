#!/usr/bin/env python3
"""
Setup script for Glass Chip Detection Pipeline.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
readme_path = Path(__file__).parent / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""

# Read requirements
requirements_path = Path(__file__).parent / "requirements.txt"
if requirements_path.exists():
    with open(requirements_path, 'r') as f:
        requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]
else:
    requirements = [
        'opencv-python>=4.8.0',
        'numpy>=1.24.0',
        'scipy>=1.10.0',
        'scikit-image>=0.20.0',
        'matplotlib>=3.7.0',
        'seaborn>=0.12.0',
        'pandas>=2.0.0',
        'pillow>=9.5.0',
        'tqdm>=4.65.0',
        'pyyaml>=6.0',
        'pytest>=7.3.0',
    ]

setup(
    name="glass-chip-pipeline",
    version="1.0.0",
    author="Glass Detection Team",
    author_email="contact@example.com",
    description="Hybrid rule-based + YOLO pipeline for glass chip and check detection",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-org/glass-chip-pipeline",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Image Processing",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.10",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.3.0",
            "pytest-cov>=4.1.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
        ],
        "yolo": [
            "torch>=2.0.0",
            "torchvision>=0.15.0",
            "ultralytics>=8.0.0",
        ],
        "augmentation": [
            "albumentations>=1.3.0",
        ],
        "all": [
            "torch>=2.0.0",
            "torchvision>=0.15.0",
            "ultralytics>=8.0.0",
            "albumentations>=1.3.0",
            "pytest>=7.3.0",
            "pytest-cov>=4.1.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
        ]
    },
    entry_points={
        "console_scripts": [
            "prep-glass=prep_glass:main",
            "viz-preview=viz_preview:main",
            "report-stats=report_stats:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["*.yaml", "*.yml", "*.json", "*.md", "*.txt"],
    },
    project_urls={
        "Bug Reports": "https://github.com/your-org/glass-chip-pipeline/issues",
        "Source": "https://github.com/your-org/glass-chip-pipeline",
        "Documentation": "https://github.com/your-org/glass-chip-pipeline/blob/main/README.md",
    },
)

