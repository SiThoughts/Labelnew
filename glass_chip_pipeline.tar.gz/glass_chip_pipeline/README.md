# Glass Chip Detection Pipeline

A production-grade hybrid rule-based + YOLO pipeline for detecting chips and checks in glass parts with maximum recall. This pipeline combines classical computer vision techniques with deep learning to achieve robust defect detection.

## Overview

This pipeline transforms RGB images of glass parts into 6-channel feature tensors that highlight defects while suppressing background textures. The approach is specifically designed for maximum recall in Stage-1 detection, making subtle chips and checks highly learnable for YOLO/Mask-RCNN models.

### Key Features

- **Hybrid Approach**: Combines classical computer vision with deep learning
- **Maximum Recall**: Optimized for catching all defects in Stage-1
- **6-Channel Features**: Engineered feature channels that highlight defects
- **Production Ready**: Multiprocessing, comprehensive logging, and robust error handling
- **Configurable**: Extensive configuration options for different glass types
- **Quality Assurance**: Built-in visualization and statistical analysis tools

## Architecture

### Feature Channels

The pipeline generates 6 specialized feature channels:

1. **L_CLAHE**: Enhanced L channel with CLAHE and Retinex normalization
2. **DoG_s2_4**: Difference of Gaussians (σ=2,4) for fine edge detection
3. **DoG_s4_8**: Difference of Gaussians (σ=4,8) for coarse edge detection  
4. **Entropy11**: Local entropy (11×11 window) for texture analysis
5. **EdgeBandMask**: Binary mask for edge band region (15-30px from contour)
6. **ConcavityMap**: Edge deviation/concavity detection for chip identification

### Processing Pipeline

1. **Preprocessing**:
   - Pose normalization (rotation and cropping)
   - Illumination flattening (Retinex-style correction)
   - Directional texture suppression

2. **Feature Extraction**:
   - Multi-scale edge detection
   - Local texture analysis
   - Geometric defect detection

3. **YOLO Integration**:
   - 6-channel model patching
   - Custom dataset handling
   - Defect-preserving augmentations

## Installation

### Requirements

- Python 3.10+
- OpenCV 4.8+
- PyTorch 2.0+
- NumPy, SciPy, scikit-image
- matplotlib, seaborn (for visualization)
- ultralytics (for YOLO integration)

### Setup

```bash
# Clone or download the pipeline
cd glass_chip_pipeline

# Install dependencies
pip install -r requirements.txt

# Verify installation
python -m pytest tests/ -v
```

## Quick Start

### Basic Usage

```bash
# Process a directory of images
python prep_glass.py \
  --input_dir /path/to/images \
  --output_dir /path/to/output \
  --num_workers 8

# Generate visualization previews
python viz_preview.py \
  --input /path/to/images \
  --output /path/to/previews

# Generate statistical report
python report_stats.py \
  --feature_dir /path/to/output/features \
  --output_dir /path/to/reports
```

### Python API

```python
from preproc_glass import GlassPreprocessor
from features_glass import GlassFeatureExtractor
import cv2
import numpy as np

# Load and preprocess image
image = cv2.imread('glass_part.jpg')
image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0

# Initialize pipeline
preprocessor = GlassPreprocessor()
feature_extractor = GlassFeatureExtractor()

# Process image
processed_image, metadata = preprocessor.preprocess_image(image)
features = feature_extractor.extract_features(processed_image)

# features is now a (H, W, 6) array ready for YOLO training
print(f"Generated features shape: {features.shape}")
```

## Configuration

### Command Line Options

```bash
python prep_glass.py \
  --input_dir /path/to/images \
  --output_dir /path/to/output \
  --band_px 25 \                    # Edge band width
  --clahe_clip 3.0 \               # CLAHE clip limit
  --clahe_grid 40 \                # CLAHE tile size
  --retinex_sigma 60 \             # Retinex blur sigma
  --dog_sigmas 2 4 4 8 \           # DoG sigma values
  --entropy_win 11 \               # Entropy window size
  --texture_suppress on \          # Enable texture suppression
  --pose_normalize on \            # Enable pose normalization
  --num_workers 8                  # Parallel processing
```

### Configuration File

Create a `config.yaml` file:

```yaml
# Preprocessing parameters
pose_normalize: true
illumination_method: 'divide'  # or 'subtract'
texture_suppress: true
retinex_sigma: 60
margin_px: 10

# Feature extraction parameters
clahe_clip_limit: 3.0
clahe_tile_grid_size: [40, 40]
dog_sigmas: [[2, 4], [4, 8]]
entropy_window_size: 11
edge_band_width: 25
concavity_smooth_sigma: 5

# Output parameters
generate_previews: true
```

Use with: `python prep_glass.py --config config.yaml --input_dir ... --output_dir ...`

## YOLO Integration

### Patching YOLOv8 for 6-Channel Input

```python
from patch_yolov8_firstconv import patch_yolo_model

# Patch a YOLOv8 model to accept 6 channels
patched_model_path = patch_yolo_model(
    model_path='yolov8n.pt',
    output_path='yolov8n_6channel.pt',
    input_channels=6,
    method='average'  # or 'replicate', 'random'
)
```

### Training with 6-Channel Features

```python
from dataset_glass import create_dataloader
from ultralytics import YOLO

# Create data loaders
train_loader = create_dataloader(
    root='train_images/',
    channel_dir='train_features/',  # Preprocessed features
    ann_path='annotations.json',    # COCO or YOLO format
    batch_size=16,
    augment=True
)

# Load patched model and train
model = YOLO('yolov8n_6channel.pt')
results = model.train(
    data=train_loader,
    epochs=100,
    imgsz=640,
    device='cuda'
)
```

## Parameter Tuning Guide

### For Different Chip Sizes

| Chip Size | DoG Sigmas | Edge Band | Entropy Window |
|-----------|------------|-----------|----------------|
| Small (2-5px) | [1,2], [2,4] | 15px | 7×7 |
| Medium (5-10px) | [2,4], [4,8] | 25px | 11×11 |
| Large (10-20px) | [4,8], [8,16] | 35px | 15×15 |

### For Different Glass Types

**Polished Glass** (strong directional texture):
- `texture_suppress: true`
- `retinex_sigma: 80`
- Higher CLAHE clip limit (4.0-5.0)

**Rough Glass** (uniform texture):
- `texture_suppress: false`
- `retinex_sigma: 40`
- Lower CLAHE clip limit (2.0-3.0)

**Curved Parts**:
- `pose_normalize: false`
- Larger `margin_px` (20-30)
- Wider edge band (30-40px)

## Output Structure

```
output_dir/
├── config.yaml              # Saved configuration
├── features/                 # 6-channel .npy files
│   ├── image1.npy
│   ├── image2.npy
│   └── ...
├── previews/                 # QA visualization images
│   ├── image1_preview.png
│   ├── image2_preview.png
│   └── ...
├── processing_stats.csv      # Per-image statistics
└── summary_report.txt        # Processing summary
```

## Quality Assurance

### Visualization Tools

```bash
# Generate comprehensive previews
python viz_preview.py --input image.jpg --output previews/ --type all

# Generate statistical analysis
python report_stats.py --feature_dir features/ --output_dir reports/
```

### Key Quality Metrics

- **Edge Band Coverage**: Should be 2-15% of image pixels
- **Concavity Detection**: >0.5% non-zero pixels on edges with defects
- **Channel Consistency**: Low variance in statistics across similar images
- **SNR Analysis**: High signal-to-noise ratio in defect regions

## Troubleshooting

### Common Issues

**Segmentation Failures**:
- Reduce `min_part_area` for small parts
- Try different illumination methods
- Check image quality and contrast

**Poor Concavity Detection**:
- Increase `concavity_smooth_sigma` for noisy edges
- Adjust `edge_band_width` for part size
- Verify part segmentation quality

**Inconsistent Results**:
- Enable `pose_normalize` for varying orientations
- Increase `retinex_sigma` for uneven illumination
- Check for proper image preprocessing

### Performance Optimization

**Speed**:
- Use more workers: `--num_workers 16`
- Disable previews: `--no_previews`
- Reduce image resolution if acceptable

**Memory**:
- Process in smaller batches
- Reduce `clahe_tile_grid_size`
- Use fewer workers on memory-constrained systems

## Testing

Run the comprehensive test suite:

```bash
# Run all tests
python -m pytest tests/ -v

# Run specific test categories
python -m pytest tests/test_preproc.py::TestGlassPreprocessor -v
python -m pytest tests/test_preproc.py::TestSyntheticDefects -v

# Run with coverage
python -m pytest tests/ --cov=. --cov-report=html
```

## Advanced Usage

### Custom Feature Channels

Extend the `GlassFeatureExtractor` class to add custom channels:

```python
class CustomFeatureExtractor(GlassFeatureExtractor):
    def extract_features(self, image, part_mask=None):
        # Get standard 6 channels
        features = super().extract_features(image, part_mask)
        
        # Add custom channel (e.g., Gabor filter response)
        custom_channel = self._compute_gabor_response(image)
        
        # Combine into 7-channel output
        extended_features = np.concatenate([
            features, 
            custom_channel[:, :, np.newaxis]
        ], axis=2)
        
        return extended_features
```

### Batch Processing with Custom Logic

```python
from pathlib import Path
import multiprocessing as mp

def process_batch(image_paths, output_dir, config):
    """Custom batch processing with specific logic."""
    preprocessor = GlassPreprocessor(config)
    feature_extractor = GlassFeatureExtractor(config)
    
    for image_path in image_paths:
        # Custom preprocessing logic here
        image = load_and_validate_image(image_path)
        
        if meets_quality_criteria(image):
            processed_image, metadata = preprocessor.preprocess_image(image)
            features = feature_extractor.extract_features(processed_image)
            
            # Custom post-processing
            features = apply_custom_filters(features, metadata)
            
            # Save with custom naming
            save_path = output_dir / f"processed_{image_path.stem}.npy"
            np.save(save_path, features)
```

## Contributing

### Development Setup

```bash
# Install development dependencies
pip install -r requirements.txt
pip install pytest pytest-cov black flake8

# Run code formatting
black glass_chip_pipeline/
flake8 glass_chip_pipeline/

# Run tests before committing
python -m pytest tests/ -v
```

### Adding New Features

1. Implement feature in appropriate module
2. Add comprehensive tests
3. Update documentation
4. Ensure backward compatibility
5. Add configuration options if needed

## License

This project is licensed under the MIT License. See LICENSE file for details.

## Citation

If you use this pipeline in your research, please cite:

```bibtex
@software{glass_chip_pipeline,
  title={Glass Chip Detection Pipeline: Hybrid Rule-Based + YOLO Approach},
  author={Your Name},
  year={2024},
  url={https://github.com/your-repo/glass-chip-pipeline}
}
```

## Support

For questions, issues, or feature requests:

1. Check the troubleshooting section above
2. Search existing issues on GitHub
3. Create a new issue with detailed description
4. Include sample images and configuration if possible

---

**Note**: This pipeline is designed for maximum recall in defect detection. For production deployment, consider adding a Stage-2 classifier to reduce false positives while maintaining the high recall achieved by this Stage-1 system.



## Examples

### Example 1: Basic Processing

```python
#!/usr/bin/env python3
"""
Basic example: Process a single image and visualize results.
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
from preproc_glass import GlassPreprocessor
from features_glass import GlassFeatureExtractor

# Load image
image_path = 'sample_glass_part.jpg'
image = cv2.imread(image_path)
image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0

# Initialize pipeline
config = {
    'clahe_clip_limit': 3.0,
    'edge_band_width': 25,
    'texture_suppress': True
}

preprocessor = GlassPreprocessor(config)
feature_extractor = GlassFeatureExtractor(config)

# Process image
processed_image, metadata = preprocessor.preprocess_image(image)
features = feature_extractor.extract_features(processed_image)

# Visualize results
fig, axes = plt.subplots(2, 3, figsize=(15, 10))
channel_names = ['L_CLAHE', 'DoG_s2_4', 'DoG_s4_8', 'Entropy11', 'EdgeBandMask', 'ConcavityMap']

for i, (ax, name) in enumerate(zip(axes.flat, channel_names)):
    ax.imshow(features[:, :, i], cmap='viridis')
    ax.set_title(name)
    ax.axis('off')

plt.tight_layout()
plt.savefig('feature_visualization.png')
plt.show()

print(f"Processing metadata: {metadata}")
print(f"Feature shape: {features.shape}")
```

### Example 2: Batch Processing with Custom Configuration

```python
#!/usr/bin/env python3
"""
Batch processing example with custom configuration for different glass types.
"""

import os
from pathlib import Path
import yaml
from prep_glass import GlassPreprocessingPipeline

# Define configurations for different glass types
configs = {
    'polished_glass': {
        'texture_suppress': True,
        'retinex_sigma': 80,
        'clahe_clip_limit': 4.0,
        'edge_band_width': 20,
        'dog_sigmas': [[2, 4], [4, 8]]
    },
    'rough_glass': {
        'texture_suppress': False,
        'retinex_sigma': 40,
        'clahe_clip_limit': 2.5,
        'edge_band_width': 30,
        'dog_sigmas': [[3, 6], [6, 12]]
    },
    'curved_parts': {
        'pose_normalize': False,
        'margin_px': 30,
        'edge_band_width': 35,
        'min_part_area': 500
    }
}

# Process different glass types
for glass_type, config in configs.items():
    print(f"Processing {glass_type}...")
    
    input_dir = f'data/{glass_type}_images'
    output_dir = f'output/{glass_type}_features'
    
    if os.path.exists(input_dir):
        pipeline = GlassPreprocessingPipeline(config)
        stats = pipeline.process_directory(input_dir, output_dir, num_workers=4)
        
        print(f"  Processed: {stats['processed_images']} images")
        print(f"  Failed: {stats['failed_images']} images")
        print(f"  Time: {stats['total_processing_time']:.2f} seconds")
    else:
        print(f"  Directory {input_dir} not found, skipping...")
```

### Example 3: YOLO Training Pipeline

```python
#!/usr/bin/env python3
"""
Complete YOLO training pipeline example.
"""

import torch
from ultralytics import YOLO
from dataset_glass import create_dataloader
from patch_yolov8_firstconv import patch_yolo_model
import yaml

# Configuration
config = {
    'train_images': 'data/train/images',
    'train_features': 'data/train/features',
    'train_annotations': 'data/train/annotations.json',
    'val_images': 'data/val/images',
    'val_features': 'data/val/features',
    'val_annotations': 'data/val/annotations.json',
    'model_path': 'yolov8n.pt',
    'output_model': 'yolov8n_glass_6ch.pt'
}

def main():
    # Step 1: Patch YOLOv8 model for 6-channel input
    print("Patching YOLOv8 model for 6-channel input...")
    patched_model = patch_yolo_model(
        model_path=config['model_path'],
        output_path=config['output_model'],
        input_channels=6,
        method='average'
    )
    
    # Step 2: Create data loaders
    print("Creating data loaders...")
    train_loader = create_dataloader(
        root=config['train_images'],
        channel_dir=config['train_features'],
        ann_path=config['train_annotations'],
        batch_size=16,
        shuffle=True,
        augment=True,
        train=True
    )
    
    val_loader = create_dataloader(
        root=config['val_images'],
        channel_dir=config['val_features'],
        ann_path=config['val_annotations'],
        batch_size=16,
        shuffle=False,
        augment=False,
        train=False
    )
    
    # Step 3: Initialize and train model
    print("Starting training...")
    model = YOLO(patched_model)
    
    # Training configuration
    train_config = {
        'epochs': 100,
        'batch': 16,
        'imgsz': 640,
        'device': 'cuda' if torch.cuda.is_available() else 'cpu',
        'workers': 8,
        'project': 'glass_chip_detection',
        'name': '6channel_yolo_v1',
        'save_period': 10,
        'patience': 20,
        'val': True,
        'plots': True,
        'verbose': True
    }
    
    # Start training
    results = model.train(**train_config)
    
    # Step 4: Evaluate model
    print("Evaluating model...")
    metrics = model.val()
    
    print(f"Training completed!")
    print(f"mAP50: {metrics.box.map50:.3f}")
    print(f"mAP50-95: {metrics.box.map:.3f}")
    
    return results, metrics

if __name__ == "__main__":
    results, metrics = main()
```

### Example 4: Real-time Inference

```python
#!/usr/bin/env python3
"""
Real-time inference example for glass chip detection.
"""

import cv2
import numpy as np
import torch
from ultralytics import YOLO
from preproc_glass import GlassPreprocessor
from features_glass import GlassFeatureExtractor

class GlassChipDetector:
    """Real-time glass chip detector."""
    
    def __init__(self, model_path: str, config: dict = None):
        """Initialize detector with trained model."""
        self.model = YOLO(model_path)
        self.preprocessor = GlassPreprocessor(config)
        self.feature_extractor = GlassFeatureExtractor(config)
        
    def detect_chips(self, image: np.ndarray, confidence: float = 0.5):
        """Detect chips in a single image."""
        # Preprocess image
        processed_image, metadata = self.preprocessor.preprocess_image(image)
        
        # Extract features
        features = self.feature_extractor.extract_features(processed_image)
        
        # Convert to tensor format expected by YOLO
        features_tensor = torch.from_numpy(features).permute(2, 0, 1).unsqueeze(0)
        
        # Run inference
        results = self.model(features_tensor, conf=confidence)
        
        # Process results
        detections = []
        for result in results:
            if result.boxes is not None:
                boxes = result.boxes.xyxy.cpu().numpy()
                scores = result.boxes.conf.cpu().numpy()
                classes = result.boxes.cls.cpu().numpy()
                
                for box, score, cls in zip(boxes, scores, classes):
                    detections.append({
                        'bbox': box,
                        'confidence': score,
                        'class': int(cls),
                        'type': 'chip' if cls == 0 else 'check'
                    })
        
        return detections, metadata
    
    def visualize_detections(self, image: np.ndarray, detections: list):
        """Visualize detections on image."""
        vis_image = image.copy()
        
        for det in detections:
            bbox = det['bbox'].astype(int)
            conf = det['confidence']
            det_type = det['type']
            
            # Draw bounding box
            color = (0, 255, 0) if det_type == 'chip' else (255, 0, 0)
            cv2.rectangle(vis_image, (bbox[0], bbox[1]), (bbox[2], bbox[3]), color, 2)
            
            # Add label
            label = f"{det_type}: {conf:.2f}"
            cv2.putText(vis_image, label, (bbox[0], bbox[1]-10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        return vis_image

def main():
    """Main inference loop."""
    # Initialize detector
    detector = GlassChipDetector('yolov8n_glass_6ch.pt')
    
    # Process video or image sequence
    cap = cv2.VideoCapture(0)  # Use webcam or video file
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        # Convert BGR to RGB and normalize
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        
        # Detect chips
        detections, metadata = detector.detect_chips(image, confidence=0.3)
        
        # Visualize results
        vis_frame = detector.visualize_detections(frame, detections)
        
        # Display
        cv2.imshow('Glass Chip Detection', vis_frame)
        
        # Print detection summary
        if detections:
            print(f"Found {len(detections)} defects:")
            for i, det in enumerate(detections):
                print(f"  {i+1}: {det['type']} (conf: {det['confidence']:.3f})")
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
```

### Example 5: Custom Feature Analysis

```python
#!/usr/bin/env python3
"""
Custom feature analysis example for understanding channel responses.
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from features_glass import GlassFeatureExtractor
import cv2

def analyze_channel_responses(image_path: str, defect_regions: list = None):
    """Analyze how different channels respond to defects."""
    
    # Load image
    image = cv2.imread(image_path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    
    # Extract features
    extractor = GlassFeatureExtractor()
    features = extractor.extract_features(image)
    
    channel_names = ['L_CLAHE', 'DoG_s2_4', 'DoG_s4_8', 'Entropy11', 'EdgeBandMask', 'ConcavityMap']
    
    # Analyze each channel
    analysis_results = {}
    
    for i, name in enumerate(channel_names):
        channel = features[:, :, i]
        
        # Basic statistics
        stats_dict = {
            'mean': np.mean(channel),
            'std': np.std(channel),
            'min': np.min(channel),
            'max': np.max(channel),
            'entropy': stats.entropy(np.histogram(channel, bins=50)[0] + 1e-10),
            'dynamic_range': np.max(channel) - np.min(channel)
        }
        
        # Spatial analysis
        grad_x = cv2.Sobel(channel, cv2.CV_64F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(channel, cv2.CV_64F, 0, 1, ksize=3)
        gradient_magnitude = np.sqrt(grad_x**2 + grad_y**2)
        
        stats_dict['avg_gradient'] = np.mean(gradient_magnitude)
        stats_dict['edge_strength'] = np.percentile(gradient_magnitude, 95)
        
        # Defect region analysis (if provided)
        if defect_regions:
            defect_responses = []
            background_responses = []
            
            for region in defect_regions:
                x1, y1, x2, y2 = region
                defect_patch = channel[y1:y2, x1:x2]
                defect_responses.extend(defect_patch.flatten())
            
            # Sample background regions
            h, w = channel.shape
            for _ in range(len(defect_regions) * 5):  # 5x more background samples
                x1 = np.random.randint(0, w-20)
                y1 = np.random.randint(0, h-20)
                bg_patch = channel[y1:y1+20, x1:x1+20]
                background_responses.extend(bg_patch.flatten())
            
            if defect_responses and background_responses:
                # Compute SNR
                defect_mean = np.mean(defect_responses)
                background_mean = np.mean(background_responses)
                background_std = np.std(background_responses)
                
                snr = (defect_mean - background_mean) / (background_std + 1e-10)
                stats_dict['snr'] = snr
                
                # Statistical significance test
                t_stat, p_value = stats.ttest_ind(defect_responses, background_responses)
                stats_dict['t_statistic'] = t_stat
                stats_dict['p_value'] = p_value
        
        analysis_results[name] = stats_dict
    
    return analysis_results, features

def plot_channel_analysis(analysis_results: dict, features: np.ndarray):
    """Plot comprehensive channel analysis."""
    
    # Create figure with subplots
    fig = plt.figure(figsize=(20, 15))
    
    # Plot 1: Channel images
    for i, (name, _) in enumerate(analysis_results.items()):
        ax = plt.subplot(4, 6, i+1)
        plt.imshow(features[:, :, i], cmap='viridis')
        plt.title(name)
        plt.axis('off')
    
    # Plot 2: Statistics comparison
    ax = plt.subplot(4, 2, 3)
    metrics = ['mean', 'std', 'dynamic_range', 'avg_gradient']
    channel_names = list(analysis_results.keys())
    
    data = np.array([[analysis_results[ch][metric] for metric in metrics] 
                     for ch in channel_names])
    
    sns.heatmap(data, xticklabels=metrics, yticklabels=channel_names, 
                annot=True, fmt='.3f', cmap='viridis', ax=ax)
    ax.set_title('Channel Statistics Heatmap')
    
    # Plot 3: SNR comparison (if available)
    ax = plt.subplot(4, 2, 4)
    snr_values = [analysis_results[ch].get('snr', 0) for ch in channel_names]
    
    bars = ax.bar(channel_names, snr_values)
    ax.set_title('Signal-to-Noise Ratio by Channel')
    ax.set_ylabel('SNR')
    ax.tick_params(axis='x', rotation=45)
    
    # Color bars based on SNR value
    for bar, snr in zip(bars, snr_values):
        if snr > 2:
            bar.set_color('green')
        elif snr > 1:
            bar.set_color('orange')
        else:
            bar.set_color('red')
    
    # Plot 4: Distribution analysis
    for i, (name, _) in enumerate(analysis_results.items()):
        ax = plt.subplot(4, 6, 13+i)
        channel_data = features[:, :, i].flatten()
        
        # Sample for histogram
        sample_size = min(10000, len(channel_data))
        sample_data = np.random.choice(channel_data, sample_size, replace=False)
        
        ax.hist(sample_data, bins=50, alpha=0.7, density=True)
        ax.set_title(f'{name} Distribution')
        ax.set_xlabel('Value')
        ax.set_ylabel('Density')
    
    plt.tight_layout()
    plt.savefig('channel_analysis.png', dpi=150, bbox_inches='tight')
    plt.show()

# Example usage
if __name__ == "__main__":
    # Analyze a sample image
    image_path = 'sample_glass_with_defects.jpg'
    
    # Define known defect regions (x1, y1, x2, y2)
    defect_regions = [
        (150, 100, 170, 120),  # Chip location 1
        (200, 180, 215, 195),  # Chip location 2
    ]
    
    # Run analysis
    results, features = analyze_channel_responses(image_path, defect_regions)
    
    # Print results
    print("Channel Analysis Results:")
    print("=" * 50)
    
    for channel, stats in results.items():
        print(f"\n{channel}:")
        for metric, value in stats.items():
            if isinstance(value, float):
                print(f"  {metric}: {value:.4f}")
            else:
                print(f"  {metric}: {value}")
    
    # Plot analysis
    plot_channel_analysis(results, features)
```

These examples demonstrate the full capabilities of the glass chip detection pipeline, from basic processing to advanced analysis and real-time inference. Each example is self-contained and can be adapted for specific use cases.

