# Quick Start Guide

## Installation (One-Time Setup)

1. **Install Python** (if not already installed)
   - Download from https://www.python.org/downloads/
   - Version 3.7 or higher required
   - Make sure to check "Add Python to PATH" during installation

2. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

## Running the Analysis

### Option 1: Using the Run Script (Easiest)

**Windows:**
```cmd
run_analysis.bat "C:\path\to\your\slices"
```

**Linux/Mac:**
```bash
./run_analysis.sh /path/to/your/slices
```

### Option 2: Direct Python Command

```bash
python analyze_glass.py --input_folder ./slices --output_folder ./results
```

## What You Need

- A folder containing your PNG slice images
- At least 2GB of free RAM
- 5-30 minutes of processing time (depending on image resolution)

## What You Get

After analysis completes, check the output folder for:

1. **blooms_detected.json** - All detected blooms with positions and depths
2. **surface_detection.png** - Visual verification of surface extraction
3. **bloom_depth_distribution.png** - Histogram of bloom depths
4. **surface_top.npy** and **surface_bottom.npy** - Raw surface data

## First Time? Start Here

1. Copy your PNG slices into a folder (e.g., `./my_slices`)
2. Run the analysis using one of the methods above
3. Check `surface_detection.png` to verify surfaces were detected correctly
4. Open `blooms_detected.json` to see all detected blooms
5. If results aren't perfect, adjust parameters in `config.json` and re-run

## Common Adjustments

### Surfaces look too jagged
- Increase `smoothness_weight` in config.json (try 2.0 or 3.0)

### Missing some blooms
- Decrease `bloom_threshold` (try 80 or 60)
- Decrease `min_bloom_volume` (try 3)

### Too many false positives
- Increase `bloom_threshold` (try 120 or 150)
- Increase `min_bloom_volume` (try 10 or 20)

### Surfaces jump between slices
- Increase `temporal_smoothing_sigma` (try 5.0 or 7.0)

## Need Help?

1. Check the full README.md for detailed documentation
2. Look at the Troubleshooting section
3. Verify your PNG files are in the correct folder
4. Make sure images are grayscale darkfield images

## Example Workflow

```bash
# 1. Put your slices in a folder
mkdir my_glass_scan
# (copy your PNG files here)

# 2. Run analysis
python analyze_glass.py --input_folder my_glass_scan --output_folder results

# 3. Check results
cd results
# Open blooms_detected.json
# View surface_detection.png
# View bloom_depth_distribution.png

# 4. If needed, adjust config.json and re-run
```

That's it! The system handles everything else automatically.
