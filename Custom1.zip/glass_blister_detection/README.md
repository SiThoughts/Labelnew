# Glass Blister Detection System

A robust, non-ML system for detecting blisters (blooms) in glass objects using darkfield imaging. This system uses Dynamic Programming for surface extraction and 3D volumetric analysis for defect detection.

## Features

- **Robust Surface Detection:** Handles fragmented, curved, and interrupted surface lines
- **Automatic Gap Bridging:** DP algorithm interpolates across missing line segments
- **Obstacle Handling:** Correctly follows surface curves around physical features (buttons, edges, etc.)
- **3D Analysis:** Leverages all 900 slices for accurate depth measurement
- **No Machine Learning:** Classical computer vision approach, no training or annotation required
- **Easy to Use:** Simply point to a folder of PNG slices

## How It Works

### 1. Dynamic Programming Surface Extraction
For each slice, the algorithm:
- Computes edge strength (vertical gradient) to find horizontal lines
- Uses DP to find the globally optimal path for top and bottom surfaces
- Automatically bridges gaps in fragmented lines
- Follows curves smoothly using a smoothness constraint
- Enforces separation constraint to keep surfaces at realistic distance

### 2. Temporal Smoothing
- Smooths surface positions across all 900 slices
- Leverages high overlap between consecutive frames
- Creates continuous 3D surface maps

### 3. 3D Bloom Detection
- Builds 3D voxel volume from all slices
- Creates mask of glass interior between surfaces
- Detects bright spots (blooms) inside the glass
- Measures depth from each bloom to nearest surface

### 4. Depth Calculation
For each bloom:
- Finds its 3D center position (x, y, z)
- Looks up local surface positions at that (x, z) location
- Calculates distance along Y-axis from bloom to top/bottom surfaces
- Reports depth as both absolute pixels and percentage of glass thickness

## Installation

### Requirements
- Python 3.7 or higher
- pip package manager

### Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

That's it! No training, no model downloads, no GPU required.

## Usage

### Basic Usage

```bash
python analyze_glass.py --input_folder ./my_slices --output_folder ./results
```

### With Custom Configuration

```bash
python analyze_glass.py --input_folder ./my_slices --output_folder ./results --config my_config.json
```

### Input Requirements

- **Format:** PNG images
- **Naming:** Any naming scheme (files will be sorted alphabetically)
- **Organization:** All slices in a single folder
- **Quantity:** Works with any number of slices (optimized for ~900)

### Output

The system creates the following outputs in the specified output folder:

1. **blooms_detected.json** - Complete bloom data:
   ```json
   {
     "id": 1,
     "x": 245,
     "y": 156,
     "z": 423,
     "volume_voxels": 127,
     "intensity_mean": 187.3,
     "intensity_max": 255,
     "depth_from_top_px": 45,
     "depth_from_bottom_px": 89,
     "thickness_px": 134,
     "depth_percent": 33.6,
     "classification": "interior"
   }
   ```

2. **surface_top.npy** - NumPy array of top surface positions [n_slices × width]

3. **surface_bottom.npy** - NumPy array of bottom surface positions [n_slices × width]

4. **surface_detection.png** - Visualization showing detected surfaces on sample slices

5. **bloom_depth_distribution.png** - Histogram of bloom depths

## Configuration

Edit `config.json` to tune the detection parameters:

### Preprocessing Parameters

- **crop_pixels** (default: 120): Pixels to crop from left/right edges to remove vertical artifacts
- **median_kernel_size** (default: 5): Kernel size for noise reduction (must be odd)
- **clahe_clip_limit** (default: 2.0): Contrast enhancement strength
- **clahe_tile_size** (default: [8, 8]): Tile size for local contrast enhancement

### Surface Extraction Parameters

- **smoothness_weight** (default: 1.0): Higher = smoother curves, less sensitive to noise
- **max_vertical_jump** (default: 50): Maximum allowed vertical jump between adjacent pixels
- **min_thickness** (default: 10): Minimum expected glass thickness in pixels
- **max_thickness** (default: 200): Maximum expected glass thickness in pixels
- **temporal_smoothing_sigma** (default: 3.0): Smoothing strength across slices

### Bloom Detection Parameters

- **bloom_threshold** (default: 100): Brightness threshold for bloom detection (0-255)
- **min_bloom_volume** (default: 5): Minimum bloom size in voxels to be considered valid
- **surface_proximity_threshold** (default: 3): Distance in pixels to classify bloom as "on surface"

## Handling Challenging Cases

### Fragmented Lines
- **Problem:** Surface lines have gaps or are broken
- **Solution:** DP automatically interpolates across gaps using smoothness constraint
- **Tuning:** Increase `smoothness_weight` for more aggressive gap bridging

### Curved Lines (Obstacles)
- **Problem:** Physical features (buttons, edges) cause lines to curve
- **Solution:** DP follows curves naturally; separation constraint keeps top/bottom together
- **Tuning:** Increase `max_vertical_jump` if curves are very steep

### First 100-120 Slices
- **Problem:** Object gradually enters frame
- **Solution:** These slices help establish initial surface positions and are used in temporal smoothing
- **No action needed:** System automatically handles partial object visibility

### Noisy Images
- **Problem:** Salt-and-pepper noise or low contrast
- **Solution:** Median filter + CLAHE preprocessing
- **Tuning:** Increase `median_kernel_size` (e.g., 7 or 9) for noisier images

### False Positives
- **Problem:** Detecting non-bloom bright spots
- **Solution:** Adjust threshold and minimum volume
- **Tuning:** 
  - Increase `bloom_threshold` to detect only brighter spots
  - Increase `min_bloom_volume` to filter out small artifacts

## Performance

- **Processing Time:** ~15-30 minutes for 900 slices on a modern CPU
- **Memory Usage:** ~2-4 GB RAM depending on image resolution
- **Accuracy:** Sub-pixel surface localization, robust to gaps and curves

## Troubleshooting

### "No PNG files found"
- Check that your input folder path is correct
- Ensure files have `.png` extension (case-sensitive on Linux)

### Surfaces look incorrect
- Check `surface_detection.png` visualization
- Try adjusting `smoothness_weight` (higher = smoother)
- Verify `min_thickness` and `max_thickness` match your glass

### Too many false positives
- Increase `bloom_threshold`
- Increase `min_bloom_volume`
- Check if surfaces are correctly detected first

### Surfaces jump around between slices
- Increase `temporal_smoothing_sigma`
- Check if `max_vertical_jump` is too large

## Technical Details

### Algorithm: Dynamic Programming for Optimal Path Finding

The core algorithm treats each image as a graph where pixels are nodes. It finds the minimum-cost path from left to right edge, where:

**Cost = Data Cost + Smoothness Cost**

- **Data Cost:** Inverse of edge strength (strong edges = low cost)
- **Smoothness Cost:** Penalty for large vertical jumps between adjacent pixels

The algorithm guarantees finding the globally optimal path, unlike greedy methods that can get stuck in local minima.

### Why This Works for Fragmented Lines

When a line has a gap:
1. The algorithm reaches the gap with a certain trajectory
2. It continues forward, trying all possible y-positions
3. The smoothness penalty favors paths that continue the previous trajectory
4. When the line reappears, the algorithm naturally reconnects to it
5. The global optimization ensures this is the best possible interpolation

### Why This Works for Curved Lines

When a line curves (e.g., around an oval button):
1. The algorithm follows the bright edge pixels of the curve
2. The smoothness constraint prevents sudden jumps
3. The separation constraint ensures top and bottom curves stay together
4. Temporal smoothing across 900 slices creates a smooth 3D curved surface

## Citation

This system is based on established techniques from medical imaging:

- Dynamic Programming for boundary detection: Amini et al. (1990)
- Optimal surface detection: Li et al. (2006)
- Multiple surface segmentation: Yin et al. (2010)

## License

This software is provided as-is for research and industrial use.
