#!/bin/bash
# Glass Blister Detection - Linux/Mac Shell Script
# Usage: ./run_analysis.sh /path/to/slices

echo "===================================="
echo "Glass Blister Detection System"
echo "===================================="
echo ""

if [ -z "$1" ]; then
    echo "ERROR: Please provide the path to your slices folder"
    echo "Usage: ./run_analysis.sh /path/to/slices"
    echo ""
    exit 1
fi

INPUT_FOLDER="$1"
OUTPUT_FOLDER="results_$(date +%Y%m%d_%H%M%S)"

echo "Input folder: $INPUT_FOLDER"
echo "Output folder: $OUTPUT_FOLDER"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3.7 or higher"
    exit 1
fi

# Check if dependencies are installed
echo "Checking dependencies..."
if ! python3 -c "import numpy" &> /dev/null; then
    echo "Installing dependencies..."
    pip3 install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo "ERROR: Failed to install dependencies"
        exit 1
    fi
fi

echo ""
echo "Starting analysis..."
echo ""

python3 analyze_glass.py --input_folder "$INPUT_FOLDER" --output_folder "$OUTPUT_FOLDER"

if [ $? -ne 0 ]; then
    echo ""
    echo "ERROR: Analysis failed"
    exit 1
fi

echo ""
echo "===================================="
echo "Analysis Complete!"
echo "Results saved to: $OUTPUT_FOLDER"
echo "===================================="
echo ""
