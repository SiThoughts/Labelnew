"""
Glass Blister Detection System
Main analysis script for detecting blisters in glass from darkfield imaging slices.

Usage:
    python analyze_glass.py --input_folder ./slices --output_folder ./results
"""

import numpy as np
import cv2
from pathlib import Path
import json
from scipy import ndimage
from scipy.ndimage import gaussian_filter1d, label
import argparse
from tqdm import tqdm
import matplotlib.pyplot as plt


class GlassBlisterDetector:
    """
    Detects blisters in glass using dynamic programming for surface extraction
    and 3D volumetric analysis for defect detection.
    """
    
    def __init__(self, config):
        self.config = config
        self.slices = []
        self.y_top = None
        self.y_bottom = None
        self.volume = None
        
    def load_slices(self, input_folder):
        """Load all PNG slices from the input folder."""
        print("Loading image slices...")
        slice_files = sorted(Path(input_folder).glob("*.png"))
        
        if len(slice_files) == 0:
            raise ValueError(f"No PNG files found in {input_folder}")
        
        print(f"Found {len(slice_files)} slices")
        
        for slice_file in tqdm(slice_files, desc="Loading"):
            img = cv2.imread(str(slice_file), cv2.IMREAD_GRAYSCALE)
            if img is None:
                print(f"Warning: Could not load {slice_file}")
                continue
            self.slices.append(img)
        
        print(f"Successfully loaded {len(self.slices)} slices")
        return len(self.slices)
    
    def preprocess_slice(self, img):
        """Preprocess a single slice: crop, denoise, enhance contrast."""
        # Crop left and right edges
        crop = self.config['crop_pixels']
        img_cropped = img[:, crop:-crop]
        
        # Median filter for noise reduction
        img_denoised = cv2.medianBlur(img_cropped, self.config['median_kernel_size'])
        
        # CLAHE for contrast enhancement
        clahe = cv2.createCLAHE(
            clipLimit=self.config['clahe_clip_limit'],
            tileGridSize=self.config['clahe_tile_size']
        )
        img_enhanced = clahe.apply(img_denoised)
        
        return img_enhanced
    
    def compute_boundary_likelihood(self, img):
        """
        Compute boundary likelihood map using vertical gradient.
        Returns a cost map where edges have LOW cost.
        """
        # Compute vertical gradient (Sobel in Y direction)
        grad_y = cv2.Sobel(img, cv2.CV_64F, 0, 1, ksize=3)
        grad_magnitude = np.abs(grad_y)
        
        # Normalize to 0-255 range
        grad_normalized = cv2.normalize(grad_magnitude, None, 0, 255, cv2.NORM_MINMAX)
        
        # Convert to cost: high gradient = low cost
        max_grad = grad_normalized.max()
        cost_map = max_grad - grad_normalized
        
        return cost_map
    
    def extract_surface_dp(self, cost_map, search_range=None, y_constraint=None):
        """
        Extract optimal surface using dynamic programming.
        
        Args:
            cost_map: 2D array where low values indicate likely surface positions
            search_range: (y_min, y_max) to restrict search space
            y_constraint: If provided, array of y positions from previous surface
                         to enforce separation constraint
        
        Returns:
            Array of y-coordinates representing the surface
        """
        height, width = cost_map.shape
        
        # Determine search range
        if search_range is None:
            y_min, y_max = 0, height
        else:
            y_min, y_max = search_range
        
        # Initialize DP table
        # dp[x][y] = minimum cost to reach position (x, y)
        dp = np.full((width, height), np.inf)
        parent = np.zeros((width, height), dtype=int)
        
        # Initialize first column
        dp[0, y_min:y_max] = cost_map[y_min:y_max, 0]
        
        # Smoothness parameter
        lambda_smooth = self.config['smoothness_weight']
        max_jump = self.config['max_vertical_jump']
        
        # Forward pass: fill DP table
        for x in range(1, width):
            for y in range(y_min, y_max):
                # Apply separation constraint if provided
                if y_constraint is not None:
                    y_ref = y_constraint[x]
                    d_min = self.config['min_thickness']
                    d_max = self.config['max_thickness']
                    if not (y_ref + d_min <= y <= y_ref + d_max):
                        continue
                
                # Find best previous y position
                y_prev_min = max(y_min, y - max_jump)
                y_prev_max = min(y_max, y + max_jump + 1)
                
                for y_prev in range(y_prev_min, y_prev_max):
                    # Cost = previous cost + data cost + smoothness cost
                    smoothness_cost = lambda_smooth * abs(y - y_prev)
                    total_cost = dp[x-1, y_prev] + cost_map[y, x] + smoothness_cost
                    
                    if total_cost < dp[x, y]:
                        dp[x, y] = total_cost
                        parent[x, y] = y_prev
        
        # Backtrack to find optimal path
        surface = np.zeros(width, dtype=int)
        
        # Find minimum cost in last column
        valid_y = np.where(dp[-1, y_min:y_max] < np.inf)[0]
        if len(valid_y) == 0:
            print("Warning: No valid path found, using middle of search range")
            surface[-1] = (y_min + y_max) // 2
        else:
            surface[-1] = y_min + valid_y[np.argmin(dp[-1, y_min + valid_y])]
        
        # Backtrack
        for x in range(width - 2, -1, -1):
            surface[x] = parent[x + 1, surface[x + 1]]
        
        return surface
    
    def extract_surfaces_all_slices(self):
        """Extract top and bottom surfaces for all slices."""
        print("\nExtracting surfaces from all slices...")
        
        n_slices = len(self.slices)
        first_slice = self.preprocess_slice(self.slices[0])
        width = first_slice.shape[1]
        
        # Initialize surface arrays
        self.y_top = np.zeros((n_slices, width), dtype=int)
        self.y_bottom = np.zeros((n_slices, width), dtype=int)
        
        for z in tqdm(range(n_slices), desc="Processing slices"):
            # Preprocess
            img = self.preprocess_slice(self.slices[z])
            height = img.shape[0]
            
            # Compute boundary likelihood
            cost_map = self.compute_boundary_likelihood(img)
            
            # Extract top surface (search in upper portion of image)
            top_search_range = (0, int(height * 0.7))
            self.y_top[z] = self.extract_surface_dp(cost_map, search_range=top_search_range)
            
            # Extract bottom surface (with separation constraint from top)
            self.y_bottom[z] = self.extract_surface_dp(
                cost_map,
                y_constraint=self.y_top[z]
            )
        
        print("Surface extraction complete")
    
    def smooth_surfaces_temporal(self):
        """Apply temporal smoothing across z-axis to reduce jitter."""
        print("\nApplying temporal smoothing...")
        
        sigma = self.config['temporal_smoothing_sigma']
        
        # Smooth each x position across all z slices
        for x in range(self.y_top.shape[1]):
            self.y_top[:, x] = gaussian_filter1d(self.y_top[:, x], sigma=sigma)
            self.y_bottom[:, x] = gaussian_filter1d(self.y_bottom[:, x], sigma=sigma)
        
        # Convert back to integers
        self.y_top = self.y_top.astype(int)
        self.y_bottom = self.y_bottom.astype(int)
        
        print("Temporal smoothing complete")
    
    def build_3d_volume(self):
        """Build 3D voxel volume from preprocessed slices."""
        print("\nBuilding 3D volume...")
        
        n_slices = len(self.slices)
        first_slice = self.preprocess_slice(self.slices[0])
        height, width = first_slice.shape
        
        self.volume = np.zeros((n_slices, height, width), dtype=np.uint8)
        
        for z in tqdm(range(n_slices), desc="Building volume"):
            self.volume[z] = self.preprocess_slice(self.slices[z])
        
        print("3D volume construction complete")
    
    def create_glass_mask(self):
        """Create 3D mask representing the interior of the glass."""
        print("\nCreating glass interior mask...")
        
        n_slices, height, width = self.volume.shape
        glass_mask = np.zeros_like(self.volume, dtype=bool)
        
        for z in range(n_slices):
            for x in range(width):
                y_top = self.y_top[z, x]
                y_bottom = self.y_bottom[z, x]
                
                # Mark voxels between surfaces as interior
                if y_bottom > y_top:
                    glass_mask[z, y_top:y_bottom, x] = True
        
        print("Glass mask created")
        return glass_mask
    
    def detect_blooms(self, glass_mask):
        """Detect blooms (bright spots) inside the glass."""
        print("\nDetecting blooms...")
        
        # Threshold to find bright voxels
        threshold = self.config['bloom_threshold']
        bright_voxels = self.volume > threshold
        
        # Isolate blooms inside glass
        bloom_voxels = bright_voxels & glass_mask
        
        # 3D connected component analysis
        labeled_blooms, num_blooms = label(bloom_voxels)
        
        print(f"Found {num_blooms} potential blooms")
        
        # Extract bloom properties
        blooms = []
        min_volume = self.config['min_bloom_volume']
        
        for bloom_id in range(1, num_blooms + 1):
            bloom_mask = (labeled_blooms == bloom_id)
            volume = np.sum(bloom_mask)
            
            # Filter by minimum volume
            if volume < min_volume:
                continue
            
            # Calculate centroid
            z_coords, y_coords, x_coords = np.where(bloom_mask)
            x_center = int(np.mean(x_coords))
            y_center = int(np.mean(y_coords))
            z_center = int(np.mean(z_coords))
            
            # Calculate depth
            y_top_local = self.y_top[z_center, x_center]
            y_bottom_local = self.y_bottom[z_center, x_center]
            
            thickness = y_bottom_local - y_top_local
            depth_from_top = y_center - y_top_local
            depth_from_bottom = y_bottom_local - y_center
            
            if thickness > 0:
                depth_percent = (depth_from_top / thickness) * 100
            else:
                depth_percent = 0
            
            # Calculate intensity
            intensity_mean = np.mean(self.volume[bloom_mask])
            intensity_max = np.max(self.volume[bloom_mask])
            
            # Classify as surface or interior
            surface_threshold = self.config['surface_proximity_threshold']
            if depth_from_top < surface_threshold or depth_from_bottom < surface_threshold:
                classification = "surface"
            else:
                classification = "interior"
            
            blooms.append({
                'id': bloom_id,
                'x': x_center,
                'y': y_center,
                'z': z_center,
                'volume_voxels': int(volume),
                'intensity_mean': float(intensity_mean),
                'intensity_max': float(intensity_max),
                'depth_from_top_px': int(depth_from_top),
                'depth_from_bottom_px': int(depth_from_bottom),
                'thickness_px': int(thickness),
                'depth_percent': float(depth_percent),
                'classification': classification
            })
        
        print(f"Detected {len(blooms)} blooms after filtering")
        return blooms
    
    def save_results(self, blooms, output_folder):
        """Save detection results and visualizations."""
        output_path = Path(output_folder)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Save bloom data as JSON
        results_file = output_path / "blooms_detected.json"
        with open(results_file, 'w') as f:
            json.dump(blooms, f, indent=2)
        print(f"\nResults saved to {results_file}")
        
        # Save surface data
        np.save(output_path / "surface_top.npy", self.y_top)
        np.save(output_path / "surface_bottom.npy", self.y_bottom)
        print(f"Surface data saved to {output_path}")
        
        # Create visualization
        self.visualize_results(blooms, output_path)
    
    def visualize_results(self, blooms, output_path):
        """Create visualization of detected surfaces and blooms."""
        print("\nGenerating visualizations...")
        
        # Plot surfaces for a few representative slices
        slice_indices = [0, len(self.slices)//4, len(self.slices)//2, 
                        3*len(self.slices)//4, len(self.slices)-1]
        
        fig, axes = plt.subplots(1, len(slice_indices), figsize=(20, 4))
        
        for idx, z in enumerate(slice_indices):
            img = self.preprocess_slice(self.slices[z])
            axes[idx].imshow(img, cmap='gray')
            axes[idx].plot(range(len(self.y_top[z])), self.y_top[z], 'r-', linewidth=2, label='Top')
            axes[idx].plot(range(len(self.y_bottom[z])), self.y_bottom[z], 'b-', linewidth=2, label='Bottom')
            axes[idx].set_title(f'Slice {z}')
            axes[idx].legend()
            axes[idx].axis('off')
        
        plt.tight_layout()
        plt.savefig(output_path / 'surface_detection.png', dpi=150, bbox_inches='tight')
        plt.close()
        
        # Plot bloom depth distribution
        if len(blooms) > 0:
            depths = [b['depth_percent'] for b in blooms]
            
            plt.figure(figsize=(10, 6))
            plt.hist(depths, bins=20, edgecolor='black')
            plt.xlabel('Depth from Top Surface (%)')
            plt.ylabel('Number of Blooms')
            plt.title('Distribution of Bloom Depths')
            plt.grid(True, alpha=0.3)
            plt.savefig(output_path / 'bloom_depth_distribution.png', dpi=150, bbox_inches='tight')
            plt.close()
        
        print(f"Visualizations saved to {output_path}")
    
    def run(self, input_folder, output_folder):
        """Run the complete analysis pipeline."""
        print("="*60)
        print("Glass Blister Detection System")
        print("="*60)
        
        # Load slices
        self.load_slices(input_folder)
        
        # Extract surfaces
        self.extract_surfaces_all_slices()
        
        # Smooth surfaces temporally
        self.smooth_surfaces_temporal()
        
        # Build 3D volume
        self.build_3d_volume()
        
        # Create glass mask
        glass_mask = self.create_glass_mask()
        
        # Detect blooms
        blooms = self.detect_blooms(glass_mask)
        
        # Save results
        self.save_results(blooms, output_folder)
        
        print("\n" + "="*60)
        print("Analysis complete!")
        print(f"Total blooms detected: {len(blooms)}")
        print(f"Results saved to: {output_folder}")
        print("="*60)
        
        return blooms


def main():
    parser = argparse.ArgumentParser(description='Glass Blister Detection System')
    parser.add_argument('--input_folder', type=str, required=True,
                       help='Path to folder containing PNG slices')
    parser.add_argument('--output_folder', type=str, default='./results',
                       help='Path to output folder for results')
    parser.add_argument('--config', type=str, default='config.json',
                       help='Path to configuration file')
    
    args = parser.parse_args()
    
    # Load configuration
    config_path = Path(args.config)
    if config_path.exists():
        with open(config_path, 'r') as f:
            config = json.load(f)
        print(f"Loaded configuration from {config_path}")
    else:
        # Use default configuration
        config = {
            'crop_pixels': 120,
            'median_kernel_size': 5,
            'clahe_clip_limit': 2.0,
            'clahe_tile_size': (8, 8),
            'smoothness_weight': 1.0,
            'max_vertical_jump': 50,
            'min_thickness': 10,
            'max_thickness': 200,
            'temporal_smoothing_sigma': 3.0,
            'bloom_threshold': 100,
            'min_bloom_volume': 5,
            'surface_proximity_threshold': 3
        }
        print("Using default configuration")
    
    # Run analysis
    detector = GlassBlisterDetector(config)
    detector.run(args.input_folder, args.output_folder)


if __name__ == "__main__":
    main()
