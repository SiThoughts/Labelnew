#!/bin/bash
# Portable PLC Monitor Launcher
# This script ensures the PLC monitor runs with minimal system dependencies

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Set up environment to minimize system dependencies
export LD_LIBRARY_PATH="$SCRIPT_DIR:$LD_LIBRARY_PATH"

# Check if we're running on a compatible system
if ! command -v ldd >/dev/null 2>&1; then
    echo "Warning: ldd not found. This may indicate an incompatible system."
fi

# Check GLIBC version compatibility
GLIBC_VERSION=$(ldd --version 2>&1 | head -n1 | grep -o '[0-9]\+\.[0-9]\+' | head -n1)
if [ -n "$GLIBC_VERSION" ]; then
    echo "Detected GLIBC version: $GLIBC_VERSION"
    # Check if GLIBC is at least 2.17 (minimum for this executable)
    if [ "$(printf '%s\n' "2.17" "$GLIBC_VERSION" | sort -V | head -n1)" != "2.17" ]; then
        echo "Warning: GLIBC version $GLIBC_VERSION may be too old. Minimum required: 2.17"
        echo "The application may not work on this system."
    fi
fi

echo "Starting PLC Monitor..."
echo "Working directory: $SCRIPT_DIR"

# Run the PLC monitor executable
exec "$SCRIPT_DIR/plc_monitor_portable_final" "$@"

