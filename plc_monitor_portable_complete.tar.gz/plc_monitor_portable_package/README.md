# Portable PLC Monitor

This is a standalone PLC monitoring application that requires minimal system dependencies.

## Features
- Monitor PLC tags in real-time
- Configurable scan rates
- Support for Allen-Bradley PLCs via Ethernet/IP
- No installation required
- Minimal system dependencies

## System Requirements
- Linux x86_64 system
- GLIBC 2.17 or newer (most modern Linux distributions)
- Network access to PLC

## Usage

### Quick Start
1. Extract this package to any directory
2. Run: `./run_plc_monitor.sh`
3. Follow the interactive setup prompts

### With Configuration File
1. Create a configuration file (see example below)
2. Run: `./run_plc_monitor.sh config.json`

### Configuration File Format
```json
{
  "plc_ip": "192.168.1.10",
  "tags": [
    "Program:MainProgram.Tag1",
    "Program:MainProgram.Tag2",
    "Program:MainProgram.Status"
  ],
  "scan_rate": 1.0,
  "timeout": 5.0
}
```

## Troubleshooting

### GLIBC Version Issues
If you get errors about GLIBC version, your system may be too old. The application requires GLIBC 2.17 or newer.

### Network Issues
- Ensure the PLC IP address is correct
- Check network connectivity to the PLC
- Verify firewall settings allow communication on the required ports

### Permission Issues
If you get permission denied errors:
```bash
chmod +x run_plc_monitor.sh
chmod +x plc_monitor_portable_final
```

## Files Included
- `plc_monitor_portable_final` - Main executable
- `run_plc_monitor.sh` - Launcher script
- `README.md` - This documentation

## Support
This is a portable version of the PLC Monitor application. For issues related to PLC communication, refer to the pylogix documentation.

## Version
Portable PLC Monitor v1.0
Built with PyInstaller for maximum compatibility

