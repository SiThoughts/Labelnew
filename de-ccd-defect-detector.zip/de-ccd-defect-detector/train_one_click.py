"""
One-Click Training Launcher for DE-CCD Defect Detection System

This script provides a simple, one-click interface to train the DE-CCD model
for detecting chip and check defects in EV images.

Usage:
    python train_one_click.py
    
Or with custom image type:
    python train_one_click.py --image-type EV
"""
import os
import sys
import argparse
import time
from datetime import datetime

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.train import DECCDTrainer
from src.export_onnx import main as export_onnx_main


def print_banner():
    """Print welcome banner."""
    banner = """
    ╔═══════════════════════════════════════════════════════════════╗
    ║                                                               ║
    ║          DE-CCD Defect Detection System                      ║
    ║          Dual-Encoder Cross-Consistency Detection            ║
    ║          One-Click Training Launcher                         ║
    ║                                                               ║
    ║          Detecting: Chip & Check Defects                     ║
    ║          Architecture: Dual ResNet50 + Faster R-CNN          ║
    ║                                                               ║
    ╚═══════════════════════════════════════════════════════════════╝
    """
    print(banner)


def check_environment():
    """Check if the environment is properly set up."""
    print("\n[1/5] Checking environment...")
    
    # Check Python version
    python_version = sys.version_info
    if python_version.major < 3 or (python_version.major == 3 and python_version.minor < 8):
        print("✗ Python 3.8 or higher is required")
        return False
    print(f"✓ Python {python_version.major}.{python_version.minor}.{python_version.micro}")
    
    # Check PyTorch
    try:
        import torch
        print(f"✓ PyTorch {torch.__version__}")
        
        # Check CUDA
        if torch.cuda.is_available():
            print(f"✓ CUDA available: {torch.cuda.get_device_name(0)}")
            print(f"  CUDA version: {torch.version.cuda}")
        else:
            print("⚠ CUDA not available - training will use CPU (slower)")
    except ImportError:
        print("✗ PyTorch not installed")
        print("  Please run: pip install -r requirements.txt")
        return False
    
    # Check other dependencies
    required_packages = ['albumentations', 'onnx', 'onnxruntime']
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✓ {package}")
        except ImportError:
            missing_packages.append(package)
            print(f"✗ {package} not installed")
    
    if missing_packages:
        print(f"\n✗ Missing packages: {', '.join(missing_packages)}")
        print("  Please run: pip install -r requirements.txt")
        return False
    
    return True


def check_data(image_type='EV'):
    """Check if data directory exists and contains images."""
    print(f"\n[2/5] Checking data for {image_type} images...")
    
    from src.config_handler import ConfigHandler
    
    try:
        config_handler = ConfigHandler('config.xml')
        image_settings = config_handler.get_image_type_settings(image_type)
        ref_libs = image_settings['ref_libs']
        
        total_images = 0
        total_xmls = 0
        
        for ref_lib in ref_libs:
            if not os.path.exists(ref_lib):
                print(f"⚠ Data directory not found: {ref_lib}")
                print(f"  Please ensure your data is located at: {ref_lib}")
                return False
            
            # Count images and XMLs
            img_extensions = ['.png', '.jpg', '.bmp', '..png']
            
            for root, dirs, files in os.walk(ref_lib):
                for f in files:
                    if any(f.lower().endswith(ext) for ext in img_extensions):
                        if image_type.lower() in f.lower():
                            total_images += 1
                    if f.endswith('.xml'):
                        total_xmls += 1
        
        if total_images == 0:
            print(f"✗ No {image_type} images found in data directory")
            return False
        
        if total_xmls == 0:
            print(f"✗ No XML annotation files found")
            return False
        
        print(f"✓ Found {total_images} {image_type} images")
        print(f"✓ Found {total_xmls} XML annotation files")
        
        return True
        
    except Exception as e:
        print(f"✗ Error checking data: {e}")
        return False


def train_model(image_type='EV'):
    """Train the model."""
    print(f"\n[3/5] Training DE-CCD model for {image_type} images...")
    print("This may take several hours depending on your hardware.\n")
    
    start_time = time.time()
    
    try:
        # Create trainer
        trainer = DECCDTrainer('config.xml')
        
        # Train
        model, results_dir = trainer.train(image_type)
        
        elapsed_time = time.time() - start_time
        hours = int(elapsed_time // 3600)
        minutes = int((elapsed_time % 3600) // 60)
        
        print(f"\n✓ Training completed in {hours}h {minutes}m")
        print(f"✓ Results saved to: {results_dir}")
        
        return model, results_dir
        
    except Exception as e:
        print(f"\n✗ Training failed: {e}")
        import traceback
        traceback.print_exc()
        return None, None


def export_model(model_path, results_dir, image_type='EV'):
    """Export model to ONNX."""
    print(f"\n[4/5] Exporting model to ONNX format...")
    
    try:
        onnx_path = export_onnx_main(model_path, results_dir, image_type)
        print(f"✓ ONNX model exported to: {onnx_path}")
        return onnx_path
    except Exception as e:
        print(f"✗ ONNX export failed: {e}")
        import traceback
        traceback.print_exc()
        return None


def generate_report(results_dir):
    """Generate a summary report."""
    print(f"\n[5/5] Generating summary report...")
    
    report_path = os.path.join(results_dir, 'training_report.txt')
    
    try:
        with open(report_path, 'w') as f:
            f.write("="*60 + "\n")
            f.write("DE-CCD Training Report\n")
            f.write("="*60 + "\n\n")
            
            f.write(f"Training Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Results Directory: {results_dir}\n\n")
            
            f.write("Architecture: Dual-Encoder Cross-Consistency Detection\n")
            f.write("  - Encoder 1: ResNet50\n")
            f.write("  - Encoder 2: ResNet50\n")
            f.write("  - Anomaly Map Generator\n")
            f.write("  - Feature Fusion Neck\n")
            f.write("  - Faster R-CNN Detection Head\n\n")
            
            f.write("Files Generated:\n")
            f.write("-" * 60 + "\n")
            
            # List all files in results directory
            for filename in os.listdir(results_dir):
                filepath = os.path.join(results_dir, filename)
                if os.path.isfile(filepath):
                    size = os.path.getsize(filepath) / (1024 * 1024)  # MB
                    f.write(f"  - {filename} ({size:.2f} MB)\n")
            
            f.write("\n" + "="*60 + "\n")
            f.write("Training Complete!\n")
            f.write("="*60 + "\n")
        
        print(f"✓ Report saved to: {report_path}")
        
    except Exception as e:
        print(f"⚠ Could not generate report: {e}")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description='One-Click Training for DE-CCD Defect Detection'
    )
    parser.add_argument(
        '--image-type',
        type=str,
        default='EV',
        choices=['EV', 'SV'],
        help='Type of images to train on (default: EV)'
    )
    parser.add_argument(
        '--skip-checks',
        action='store_true',
        help='Skip environment and data checks'
    )
    
    args = parser.parse_args()
    
    # Print banner
    print_banner()
    
    # Run checks
    if not args.skip_checks:
        if not check_environment():
            print("\n✗ Environment check failed. Please fix the issues and try again.")
            sys.exit(1)
        
        if not check_data(args.image_type):
            print("\n✗ Data check failed. Please ensure your data is properly set up.")
            sys.exit(1)
    
    print("\n" + "="*60)
    print("All checks passed! Starting training...")
    print("="*60)
    
    # Train model
    model, results_dir = train_model(args.image_type)
    
    if model is None or results_dir is None:
        print("\n✗ Training failed. Please check the error messages above.")
        sys.exit(1)
    
    # Export to ONNX
    best_model_path = os.path.join(results_dir, 'best_model.pt')
    onnx_path = export_model(best_model_path, results_dir, args.image_type)
    
    if onnx_path is None:
        print("\n⚠ ONNX export failed, but PyTorch model is available.")
    
    # Generate report
    generate_report(results_dir)
    
    # Final summary
    print("\n" + "="*60)
    print("🎉 ONE-CLICK TRAINING COMPLETE! 🎉")
    print("="*60)
    print(f"\nResults Location: {results_dir}")
    print("\nGenerated Files:")
    print(f"  • best_model.pt       - Best model (lowest validation loss)")
    print(f"  • best_f1_model.pt    - Best model (highest F1 score)")
    print(f"  • best_model.onnx     - ONNX model for deployment")
    print(f"  • training_curves.png - Training progress visualization")
    print(f"  • f1_score.png        - F1 score over epochs")
    print(f"  • training_report.txt - Detailed training report")
    print("\nDE-CCD Architecture Highlights:")
    print("  • Dual encoders for cross-consistency checking")
    print("  • Anomaly map generation from feature differences")
    print("  • Feature fusion for enhanced detection")
    print("  • Better at detecting unknown/novel defects")
    print("\nNext Steps:")
    print("  1. Review the training curves to assess model performance")
    print("  2. Use best_model.onnx for inference in your application")
    print("  3. If precision/recall < 90%, consider:")
    print("     - Training for more epochs")
    print("     - Adding more training data")
    print("     - Adjusting hyperparameters in config.xml")
    print("\n" + "="*60 + "\n")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n✗ Training interrupted by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n✗ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
