"""
Main training script for DE-CCD defect detection system.
"""
import os
import sys
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.config_handler import ConfigHandler
from src.dataset import DefectDetectionDataset, collate_fn
from src.model import DECCD
from src.loss import DECCDLoss, DECCDLossWithFocal
from src.train_utils import (
    MetricsTracker, plot_training_curves, plot_confusion_matrix,
    save_checkpoint, print_metrics
)
from src.data_preparation import split_data, verify_dataset, print_dataset_stats


class DECCDTrainer:
    """
    Trainer class for DE-CCD model.
    """
    
    def __init__(self, config_path='config.xml'):
        """
        Initialize the trainer.
        
        Args:
            config_path: Path to configuration XML file
        """
        # Load configuration
        self.config_handler = ConfigHandler(config_path)
        self.config = self.config_handler.get_config()
        
        # Setup device
        self.device = self._setup_device()
        
        # Initialize tracking variables
        self.best_val_loss = float('inf')
        self.best_f1_score = 0.0
        self.train_metrics_history = []
        self.val_metrics_history = []
    
    def _setup_device(self):
        """Setup CUDA device."""
        if torch.cuda.is_available():
            device_id = self.config['general']['cuda_device_id']
            device = torch.device(f'cuda:{device_id}')
            print(f"Using CUDA device: {device_id}")
            print(f"GPU: {torch.cuda.get_device_name(device_id)}")
        else:
            device = torch.device('cpu')
            print("CUDA not available. Using CPU.")
        
        return device
    
    def prepare_data(self, image_type='EV'):
        """
        Prepare training and validation datasets.
        
        Args:
            image_type: Type of images to process (EV or SV)
        
        Returns:
            Tuple of (train_loader, val_loader)
        """
        print(f"\n{'='*60}")
        print(f"Preparing {image_type} data...")
        print(f"{'='*60}\n")
        
        # Get image type settings
        image_settings = self.config_handler.get_image_type_settings(image_type)
        
        results_dir = image_settings['results_dir']
        ref_libs = image_settings['ref_libs']
        image_size = image_settings['image_size']
        
        # Create results directory
        os.makedirs(results_dir, exist_ok=True)
        
        # Split data into train/validation
        split_ratio = self.config['general']['split_ratio']
        train_dir, val_dir = split_data(ref_libs, results_dir, split_ratio, image_type)
        
        # Verify datasets
        print("\nVerifying training dataset...")
        train_stats = verify_dataset(train_dir, self.config['class_map'])
        print_dataset_stats(train_stats)
        
        print("Verifying validation dataset...")
        val_stats = verify_dataset(val_dir, self.config['class_map'])
        print_dataset_stats(val_stats)
        
        # Create datasets
        train_dataset = DefectDetectionDataset(
            train_dir,
            self.config['class_map'],
            image_size=image_size,
            train=True,
            augment_config=self.config.get('augmentation', {})
        )
        
        val_dataset = DefectDetectionDataset(
            val_dir,
            self.config['class_map'],
            image_size=image_size,
            train=False,
            augment_config=None
        )
        
        # Create data loaders
        batch_size = self.config['general']['batch']
        num_workers = self.config['general']['workers']
        
        train_loader = DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers,
            collate_fn=collate_fn,
            pin_memory=True if torch.cuda.is_available() else False
        )
        
        val_loader = DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            collate_fn=collate_fn,
            pin_memory=True if torch.cuda.is_available() else False
        )
        
        return train_loader, val_loader, results_dir
    
    def build_model(self):
        """
        Build and initialize the DE-CCD model.
        
        Returns:
            DE-CCD model
        """
        print(f"\n{'='*60}")
        print("Building DE-CCD model...")
        print(f"{'='*60}\n")
        
        backbone = self.config['general'].get('encoder1_backbone', 'resnet50')
        num_classes = self.config['general']['num_classes']
        pretrained = self.config['general']['pretrained']
        
        # Create model
        model = DECCD(
            num_classes=num_classes,
            backbone_name=backbone,
            pretrained=pretrained
        )
        
        # Move to device
        model = model.to(self.device)
        
        # Count parameters
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        
        print(f"Total parameters: {total_params:,}")
        print(f"Trainable parameters: {trainable_params:,}")
        print(f"Dual encoders: {backbone}")
        
        return model
    
    def train_epoch(self, model, train_loader, optimizer, criterion):
        """
        Train for one epoch.
        
        Args:
            model: The model to train
            train_loader: Training data loader
            optimizer: Optimizer
            criterion: Loss function
        
        Returns:
            Metrics for the epoch
        """
        model.train()
        metrics_tracker = MetricsTracker()
        
        pbar = tqdm(train_loader, desc='Training')
        
        for batch_idx, (images, targets) in enumerate(pbar):
            # Move data to device
            images = [img.to(self.device) for img in images]
            targets = [{k: v.to(self.device) for k, v in t.items()} for t in targets]
            
            try:
                # Forward pass
                detection_output, anomaly_map = model(images, targets)
                
                # Get features for consistency loss
                with torch.no_grad():
                    images_tensor = torch.stack(images)
                    features1, features2 = model.dual_encoder(images_tensor)
                
                # Calculate loss
                total_loss, det_loss, anom_loss, cons_loss = criterion(
                    detection_output, anomaly_map, targets, features1, features2
                )
                
                # Backward pass
                optimizer.zero_grad()
                total_loss.backward()
                optimizer.step()
                
                # Update metrics
                anomaly_labels = torch.stack([t.get('has_defects', torch.tensor([0.0])) for t in targets])
                anomaly_scores = torch.nn.functional.adaptive_avg_pool2d(anomaly_map, 1).squeeze()
                if anomaly_scores.dim() == 0:
                    anomaly_scores = anomaly_scores.unsqueeze(0)
                
                metrics_tracker.update(
                    anomaly_scores.unsqueeze(1),
                    anomaly_labels,
                    total_loss.item(),
                    det_loss.item() if isinstance(det_loss, torch.Tensor) else det_loss,
                    anom_loss.item()
                )
                
                # Update progress bar
                pbar.set_postfix({
                    'loss': f'{total_loss.item():.4f}',
                    'det': f'{det_loss.item() if isinstance(det_loss, torch.Tensor) else det_loss:.4f}',
                    'anom': f'{anom_loss.item():.4f}'
                })
                
            except Exception as e:
                print(f"\nError in batch {batch_idx}: {e}")
                continue
        
        # Compute epoch metrics
        metrics = metrics_tracker.compute_metrics()
        
        return metrics
    
    @torch.no_grad()
    def validate_epoch(self, model, val_loader, criterion):
        """
        Validate for one epoch.
        
        Args:
            model: The model to validate
            val_loader: Validation data loader
            criterion: Loss function
        
        Returns:
            Metrics for the epoch
        """
        model.eval()
        metrics_tracker = MetricsTracker()
        
        pbar = tqdm(val_loader, desc='Validation')
        
        for batch_idx, (images, targets) in enumerate(pbar):
            # Move data to device
            images = [img.to(self.device) for img in images]
            targets = [{k: v.to(self.device) for k, v in t.items()} for t in targets]
            
            try:
                # Forward pass
                detection_output, anomaly_map = model(images, targets)
                
                # Get features for consistency loss
                images_tensor = torch.stack(images)
                features1, features2 = model.dual_encoder(images_tensor)
                
                # Calculate loss
                total_loss, det_loss, anom_loss, cons_loss = criterion(
                    detection_output, anomaly_map, targets, features1, features2
                )
                
                # Update metrics
                anomaly_labels = torch.stack([t.get('has_defects', torch.tensor([0.0])) for t in targets])
                anomaly_scores = torch.nn.functional.adaptive_avg_pool2d(anomaly_map, 1).squeeze()
                if anomaly_scores.dim() == 0:
                    anomaly_scores = anomaly_scores.unsqueeze(0)
                
                metrics_tracker.update(
                    anomaly_scores.unsqueeze(1),
                    anomaly_labels,
                    total_loss.item(),
                    det_loss.item() if isinstance(det_loss, torch.Tensor) else det_loss,
                    anom_loss.item()
                )
                
                # Update progress bar
                pbar.set_postfix({
                    'loss': f'{total_loss.item():.4f}'
                })
                
            except Exception as e:
                print(f"\nError in batch {batch_idx}: {e}")
                continue
        
        # Compute epoch metrics
        metrics = metrics_tracker.compute_metrics()
        
        return metrics
    
    def train(self, image_type='EV'):
        """
        Main training loop.
        
        Args:
            image_type: Type of images to train on (EV or SV)
        """
        print(f"\n{'='*60}")
        print(f"Starting DE-CCD Training for {image_type} images")
        print(f"{'='*60}\n")
        
        # Prepare data
        train_loader, val_loader, results_dir = self.prepare_data(image_type)
        
        # Build model
        model = self.build_model()
        
        # Setup optimizer
        lr = self.config['general']['learning_rate']
        weight_decay = self.config['general']['weight_decay']
        momentum = self.config['general']['momentum']
        
        optimizer = optim.SGD(
            model.parameters(),
            lr=lr,
            momentum=momentum,
            weight_decay=weight_decay
        )
        
        # Setup learning rate scheduler
        scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=30, gamma=0.1)
        
        # Setup loss function
        anomaly_weight = self.config['general'].get('anomaly_weight', 0.3)
        consistency_weight = self.config.get('dual_encoder', {}).get('consistency_loss_weight', 0.2)
        
        criterion = DECCDLoss(
            anomaly_weight=anomaly_weight,
            consistency_weight=consistency_weight
        )
        
        # Training loop
        num_epochs = self.config['general']['epochs']
        
        for epoch in range(1, num_epochs + 1):
            print(f"\nEpoch {epoch}/{num_epochs}")
            print("-" * 60)
            
            # Train
            train_metrics = self.train_epoch(model, train_loader, optimizer, criterion)
            print_metrics(epoch, 'Train', train_metrics)
            
            # Validate
            val_metrics = self.validate_epoch(model, val_loader, criterion)
            print_metrics(epoch, 'Validation', val_metrics)
            
            # Save metrics history
            self.train_metrics_history.append(train_metrics)
            self.val_metrics_history.append(val_metrics)
            
            # Save best model based on validation loss
            val_loss = val_metrics['avg_losses']['total']
            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
                best_model_path = os.path.join(results_dir, 'best_model.pt')
                torch.save(model.state_dict(), best_model_path)
                print(f"✓ Saved best model (loss: {val_loss:.4f})")
            
            # Save best model based on F1 score
            val_f1 = val_metrics['f1']
            if val_f1 > self.best_f1_score:
                self.best_f1_score = val_f1
                best_f1_model_path = os.path.join(results_dir, 'best_f1_model.pt')
                torch.save(model.state_dict(), best_f1_model_path)
                print(f"✓ Saved best F1 model (F1: {val_f1:.4f})")
            
            # Save latest model
            latest_model_path = os.path.join(results_dir, 'latest_model.pt')
            torch.save(model.state_dict(), latest_model_path)
            
            # Update learning rate
            scheduler.step()
            
            # Plot training curves
            plot_training_curves(
                self.train_metrics_history,
                self.val_metrics_history,
                results_dir
            )
            
            # Plot confusion matrix
            cm_path = os.path.join(results_dir, f'confusion_matrix_epoch_{epoch}.png')
            plot_confusion_matrix(val_metrics['confusion_matrix'], cm_path)
        
        print(f"\n{'='*60}")
        print("Training Complete!")
        print(f"{'='*60}")
        print(f"Best validation loss: {self.best_val_loss:.4f}")
        print(f"Best F1 score: {self.best_f1_score:.4f}")
        print(f"Results saved to: {results_dir}")
        print(f"{'='*60}\n")
        
        return model, results_dir


def main(image_type='EV'):
    """
    Main entry point for training.
    
    Args:
        image_type: Type of images to train on (EV or SV)
    """
    # Create trainer
    trainer = DECCDTrainer('config.xml')
    
    # Train model
    model, results_dir = trainer.train(image_type)
    
    return model, results_dir


if __name__ == '__main__':
    # Check command line arguments
    image_type = 'EV'
    if len(sys.argv) > 1:
        image_type = sys.argv[1].upper()
    
    main(image_type)
