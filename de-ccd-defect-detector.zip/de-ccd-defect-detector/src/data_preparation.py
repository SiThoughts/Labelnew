"""
Data preparation utilities for splitting datasets into train and validation sets.
"""
import os
import shutil
import numpy as np
from tqdm import tqdm


def split_data(ref_libs, results_dir, ratio, image_type):
    """
    Split data from multiple reference libraries into train and validation sets.
    
    Args:
        ref_libs: List of reference library directories
        results_dir: Directory to save the split data
        ratio: Train/validation split ratio (e.g., 0.85 for 85% train, 15% val)
        image_type: Type of images to process (EV or SV)
    
    Returns:
        Tuple of (train_dir, valid_dir)
    """
    train_dir = os.path.join(results_dir, "train")
    valid_dir = os.path.join(results_dir, "valid")
    
    # Check if split already exists
    if os.path.isdir(train_dir) and os.path.isdir(valid_dir):
        train_count = len([f for f in os.listdir(train_dir) if f.endswith('.xml')])
        valid_count = len([f for f in os.listdir(valid_dir) if f.endswith('.xml')])
        
        if train_count > 0 and valid_count > 0:
            print(f"Data split already exists: {train_count} train, {valid_count} validation samples")
            return train_dir, valid_dir
    
    # Create directories
    os.makedirs(train_dir, exist_ok=True)
    os.makedirs(valid_dir, exist_ok=True)
    
    # Collect all image files from all reference libraries
    img_exts = ['.jpg', '.png', '.bmp', '..png']
    img_files = []
    xml_files = []
    
    for ref_lib_dir in ref_libs:
        if not os.path.isdir(ref_lib_dir):
            print(f"Warning: Reference library {ref_lib_dir} does not exist. Skipping.")
            continue
        
        print(f"Scanning {ref_lib_dir} for {image_type} images...")
        
        # Filter images based on image type (EV or SV)
        for root, dirs, files in os.walk(ref_lib_dir):
            for f in files:
                # Check if it's an image file
                if any(f.lower().endswith(ext) for ext in img_exts):
                    # Check if it matches the image type
                    if image_type.lower() in f.lower():
                        img_path = os.path.join(root, f)
                        
                        # Find corresponding XML
                        base_name = os.path.splitext(f)[0]
                        if f.endswith('..png'):
                            base_name = f[:-5]  # Remove ..png
                        
                        xml_path = os.path.join(root, base_name + '.xml')
                        
                        # Handle the case where XML might have different extension handling
                        if not os.path.exists(xml_path):
                            # Try without the extra dot
                            xml_path = xml_path.replace('..', '.')
                        
                        if os.path.exists(xml_path):
                            img_files.append(img_path)
                            xml_files.append(xml_path)
    
    if not img_files:
        raise ValueError(f"No {image_type} images found in the reference libraries.")
    
    print(f"Found {len(img_files)} {image_type} images with annotations")
    
    # Create train/validation split
    indices = list(range(len(img_files)))
    split = int(np.floor(ratio * len(img_files)))
    
    # Shuffle with a fixed seed for reproducibility
    np.random.seed(42)
    np.random.shuffle(indices)
    
    train_indices, val_indices = indices[:split], indices[split:]
    
    print(f"Splitting data: {len(train_indices)} train, {len(val_indices)} validation")
    
    # Copy training files
    for t in tqdm(train_indices, desc=f"Copying {image_type} images to train directory"):
        img_src = img_files[t]
        xml_src = xml_files[t]
        
        img_dst = os.path.join(train_dir, os.path.basename(img_src))
        xml_dst = os.path.join(train_dir, os.path.basename(xml_src))
        
        shutil.copy2(img_src, img_dst)
        shutil.copy2(xml_src, xml_dst)
    
    # Copy validation files
    for v in tqdm(val_indices, desc=f"Copying {image_type} images to valid directory"):
        img_src = img_files[v]
        xml_src = xml_files[v]
        
        img_dst = os.path.join(valid_dir, os.path.basename(img_src))
        xml_dst = os.path.join(valid_dir, os.path.basename(xml_src))
        
        shutil.copy2(img_src, img_dst)
        shutil.copy2(xml_src, xml_dst)
    
    print(f"Data preparation complete!")
    print(f"  Train: {train_dir}")
    print(f"  Valid: {valid_dir}")
    
    return train_dir, valid_dir


def verify_dataset(data_dir, class_mapping):
    """
    Verify that the dataset is properly formatted and contains valid annotations.
    
    Args:
        data_dir: Directory containing the dataset
        class_mapping: Dictionary mapping class names to IDs
    
    Returns:
        Dictionary with dataset statistics
    """
    from src.xml_parser import XMLAnnotationParser
    
    parser = XMLAnnotationParser(class_mapping)
    
    stats = {
        'total_images': 0,
        'total_annotations': 0,
        'class_counts': {name: 0 for name in class_mapping.keys()},
        'images_with_defects': 0,
        'images_without_defects': 0,
        'errors': []
    }
    
    # Count image files
    img_exts = ['.jpg', '.png', '.bmp', '..png']
    
    for filename in os.listdir(data_dir):
        if any(filename.lower().endswith(ext) for ext in img_exts):
            stats['total_images'] += 1
            
            # Find corresponding XML
            base_name = os.path.splitext(filename)[0]
            if filename.endswith('..png'):
                base_name = filename[:-5]
            
            xml_path = os.path.join(data_dir, base_name + '.xml')
            
            if os.path.exists(xml_path):
                try:
                    annotation = parser.parse_annotation(xml_path)
                    num_objects = len(annotation['labels'])
                    stats['total_annotations'] += num_objects
                    
                    if num_objects > 0:
                        stats['images_with_defects'] += 1
                        
                        # Count by class
                        for label in annotation['labels']:
                            for class_name, class_id in class_mapping.items():
                                if label == class_id:
                                    stats['class_counts'][class_name] += 1
                    else:
                        stats['images_without_defects'] += 1
                
                except Exception as e:
                    stats['errors'].append(f"Error parsing {xml_path}: {e}")
            else:
                stats['errors'].append(f"No XML found for {filename}")
    
    return stats


def print_dataset_stats(stats):
    """
    Print dataset statistics in a readable format.
    
    Args:
        stats: Dictionary with dataset statistics from verify_dataset
    """
    print("\n" + "="*60)
    print("DATASET STATISTICS")
    print("="*60)
    print(f"Total Images: {stats['total_images']}")
    print(f"Total Annotations: {stats['total_annotations']}")
    print(f"Images with Defects: {stats['images_with_defects']}")
    print(f"Images without Defects: {stats['images_without_defects']}")
    print("\nClass Distribution:")
    for class_name, count in stats['class_counts'].items():
        print(f"  {class_name}: {count}")
    
    if stats['errors']:
        print(f"\nWarnings/Errors: {len(stats['errors'])}")
        for error in stats['errors'][:5]:  # Show first 5 errors
            print(f"  - {error}")
        if len(stats['errors']) > 5:
            print(f"  ... and {len(stats['errors']) - 5} more")
    
    print("="*60 + "\n")
