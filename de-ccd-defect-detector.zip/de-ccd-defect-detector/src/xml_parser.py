"""
XML annotation parser for Pascal VOC format.
Handles parsing of XML annotation files containing bounding box information.
"""
import xml.etree.ElementTree as ET
import os


class XMLAnnotationParser:
    """
    Parser for Pascal VOC format XML annotation files.
    """
    
    def __init__(self, class_mapping):
        """
        Initialize the XML parser.
        
        Args:
            class_mapping: Dictionary mapping class names to integer IDs
        """
        self.class_mapping = class_mapping
    
    def parse_annotation(self, xml_path):
        """
        Parse an XML annotation file.
        
        Args:
            xml_path: Path to the XML annotation file
        
        Returns:
            Dictionary containing:
                - boxes: List of bounding boxes [xmin, ymin, xmax, ymax]
                - labels: List of class labels
                - image_path: Path to the corresponding image
                - width: Image width
                - height: Image height
        """
        if not os.path.exists(xml_path):
            raise FileNotFoundError(f"XML file not found: {xml_path}")
        
        tree = ET.parse(xml_path)
        root = tree.getroot()
        
        # Get image information
        filename = root.find('filename')
        if filename is not None:
            image_filename = filename.text
        else:
            # If filename is not in XML, derive from XML filename
            image_filename = os.path.splitext(os.path.basename(xml_path))[0]
            # Try common image extensions
            for ext in ['.png', '.jpg', '.bmp', '..png']:
                potential_path = os.path.join(os.path.dirname(xml_path), 
                                             image_filename + ext)
                if os.path.exists(potential_path):
                    image_filename = image_filename + ext
                    break
        
        # Get image size
        size = root.find('size')
        if size is not None:
            width = int(size.find('width').text)
            height = int(size.find('height').text)
        else:
            # Default size if not specified
            width = 2048
            height = 1460
        
        # Parse all objects
        boxes = []
        labels = []
        
        for obj in root.findall('object'):
            # Get class name
            name_elem = obj.find('name')
            if name_elem is None:
                continue
            
            class_name = name_elem.text.strip().lower()
            
            # Handle variations of class names (chip/chips, check/checks)
            if 'chip' in class_name:
                class_name = 'chip'
            elif 'check' in class_name:
                class_name = 'check'
            
            # Skip if class is not in mapping
            if class_name not in self.class_mapping:
                print(f"Warning: Class '{class_name}' not in class mapping. Skipping.")
                continue
            
            label = self.class_mapping[class_name]
            
            # Get bounding box
            bndbox = obj.find('bndbox')
            if bndbox is None:
                continue
            
            xmin = float(bndbox.find('xmin').text)
            ymin = float(bndbox.find('ymin').text)
            xmax = float(bndbox.find('xmax').text)
            ymax = float(bndbox.find('ymax').text)
            
            # Validate bounding box
            if xmax <= xmin or ymax <= ymin:
                print(f"Warning: Invalid bounding box in {xml_path}: "
                      f"[{xmin}, {ymin}, {xmax}, {ymax}]. Skipping.")
                continue
            
            boxes.append([xmin, ymin, xmax, ymax])
            labels.append(label)
        
        return {
            'boxes': boxes,
            'labels': labels,
            'image_filename': image_filename,
            'width': width,
            'height': height
        }
    
    def parse_directory(self, directory):
        """
        Parse all XML files in a directory.
        
        Args:
            directory: Path to directory containing XML files
        
        Returns:
            List of parsed annotations
        """
        annotations = []
        
        for filename in os.listdir(directory):
            if filename.endswith('.xml'):
                xml_path = os.path.join(directory, filename)
                try:
                    annotation = self.parse_annotation(xml_path)
                    annotations.append(annotation)
                except Exception as e:
                    print(f"Error parsing {xml_path}: {e}")
        
        return annotations
