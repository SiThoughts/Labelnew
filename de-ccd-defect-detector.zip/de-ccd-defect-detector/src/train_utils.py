"""
Training utilities including metrics, evaluation, and logging.
"""
import torch
import numpy as np
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix
import matplotlib.pyplot as plt
import os


class MetricsTracker:
    """
    Tracks and computes metrics during training and validation.
    """
    
    def __init__(self):
        """Initialize the metrics tracker."""
        self.reset()
    
    def reset(self):
        """Reset all metrics."""
        self.predictions = []
        self.targets = []
        self.losses = {
            'total': [],
            'detection': [],
            'one_class': []
        }
    
    def update(self, preds, targets, total_loss, det_loss, oc_loss):
        """
        Update metrics with a batch of predictions.
        
        Args:
            preds: Predicted probabilities [batch_size, 1]
            targets: Ground truth labels [batch_size, 1]
            total_loss: Total loss value
            det_loss: Detection loss value
            oc_loss: One-class loss value
        """
        # Convert to numpy
        preds_np = torch.sigmoid(preds).cpu().detach().numpy()
        targets_np = targets.cpu().detach().numpy()
        
        self.predictions.extend(preds_np.flatten())
        self.targets.extend(targets_np.flatten())
        
        # Track losses
        self.losses['total'].append(total_loss)
        self.losses['detection'].append(det_loss)
        self.losses['one_class'].append(oc_loss)
    
    def compute_metrics(self, threshold=0.5):
        """
        Compute precision, recall, and F1 score.
        
        Args:
            threshold: Classification threshold
        
        Returns:
            Dictionary with metrics
        """
        preds_binary = (np.array(self.predictions) >= threshold).astype(int)
        targets_binary = np.array(self.targets).astype(int)
        
        precision = precision_score(targets_binary, preds_binary, zero_division=0)
        recall = recall_score(targets_binary, preds_binary, zero_division=0)
        f1 = f1_score(targets_binary, preds_binary, zero_division=0)
        
        # Compute confusion matrix
        cm = confusion_matrix(targets_binary, preds_binary)
        
        # Average losses
        avg_losses = {
            'total': np.mean(self.losses['total']),
            'detection': np.mean(self.losses['detection']),
            'one_class': np.mean(self.losses['one_class'])
        }
        
        return {
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'confusion_matrix': cm,
            'avg_losses': avg_losses
        }
    
    def get_average_loss(self):
        """Get average total loss."""
        return np.mean(self.losses['total']) if self.losses['total'] else float('inf')


def plot_training_curves(train_metrics_history, val_metrics_history, save_dir):
    """
    Plot training and validation curves.
    
    Args:
        train_metrics_history: List of training metrics per epoch
        val_metrics_history: List of validation metrics per epoch
        save_dir: Directory to save plots
    """
    os.makedirs(save_dir, exist_ok=True)
    
    epochs = range(1, len(train_metrics_history) + 1)
    
    # Plot losses
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # Total loss
    axes[0, 0].plot(epochs, [m['avg_losses']['total'] for m in train_metrics_history], 
                    label='Train', marker='o')
    axes[0, 0].plot(epochs, [m['avg_losses']['total'] for m in val_metrics_history], 
                    label='Validation', marker='s')
    axes[0, 0].set_xlabel('Epoch')
    axes[0, 0].set_ylabel('Total Loss')
    axes[0, 0].set_title('Total Loss')
    axes[0, 0].legend()
    axes[0, 0].grid(True)
    
    # Detection loss
    axes[0, 1].plot(epochs, [m['avg_losses']['detection'] for m in train_metrics_history], 
                    label='Train', marker='o')
    axes[0, 1].plot(epochs, [m['avg_losses']['detection'] for m in val_metrics_history], 
                    label='Validation', marker='s')
    axes[0, 1].set_xlabel('Epoch')
    axes[0, 1].set_ylabel('Detection Loss')
    axes[0, 1].set_title('Detection Loss')
    axes[0, 1].legend()
    axes[0, 1].grid(True)
    
    # One-class loss
    axes[1, 0].plot(epochs, [m['avg_losses']['one_class'] for m in train_metrics_history], 
                    label='Train', marker='o')
    axes[1, 0].plot(epochs, [m['avg_losses']['one_class'] for m in val_metrics_history], 
                    label='Validation', marker='s')
    axes[1, 0].set_xlabel('Epoch')
    axes[1, 0].set_ylabel('One-Class Loss')
    axes[1, 0].set_title('One-Class Classification Loss')
    axes[1, 0].legend()
    axes[1, 0].grid(True)
    
    # Precision and Recall
    axes[1, 1].plot(epochs, [m['precision'] for m in train_metrics_history], 
                    label='Train Precision', marker='o')
    axes[1, 1].plot(epochs, [m['precision'] for m in val_metrics_history], 
                    label='Val Precision', marker='s')
    axes[1, 1].plot(epochs, [m['recall'] for m in train_metrics_history], 
                    label='Train Recall', marker='^')
    axes[1, 1].plot(epochs, [m['recall'] for m in val_metrics_history], 
                    label='Val Recall', marker='v')
    axes[1, 1].set_xlabel('Epoch')
    axes[1, 1].set_ylabel('Score')
    axes[1, 1].set_title('Precision and Recall')
    axes[1, 1].legend()
    axes[1, 1].grid(True)
    
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, 'training_curves.png'), dpi=300)
    plt.close()
    
    # Plot F1 score separately
    plt.figure(figsize=(10, 6))
    plt.plot(epochs, [m['f1'] for m in train_metrics_history], 
             label='Train F1', marker='o')
    plt.plot(epochs, [m['f1'] for m in val_metrics_history], 
             label='Validation F1', marker='s')
    plt.xlabel('Epoch')
    plt.ylabel('F1 Score')
    plt.title('F1 Score Over Training')
    plt.legend()
    plt.grid(True)
    plt.savefig(os.path.join(save_dir, 'f1_score.png'), dpi=300)
    plt.close()


def plot_confusion_matrix(cm, save_path):
    """
    Plot confusion matrix.
    
    Args:
        cm: Confusion matrix
        save_path: Path to save the plot
    """
    fig, ax = plt.subplots(figsize=(8, 6))
    
    im = ax.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
    ax.figure.colorbar(im, ax=ax)
    
    # Labels
    classes = ['Normal', 'Defect']
    ax.set(xticks=np.arange(cm.shape[1]),
           yticks=np.arange(cm.shape[0]),
           xticklabels=classes,
           yticklabels=classes,
           title='Confusion Matrix',
           ylabel='True label',
           xlabel='Predicted label')
    
    # Rotate the tick labels
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")
    
    # Add text annotations
    thresh = cm.max() / 2.
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, format(cm[i, j], 'd'),
                   ha="center", va="center",
                   color="white" if cm[i, j] > thresh else "black")
    
    fig.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close()


def save_checkpoint(model, optimizer, epoch, metrics, save_path):
    """
    Save a training checkpoint.
    
    Args:
        model: The model to save
        optimizer: The optimizer state
        epoch: Current epoch number
        metrics: Current metrics
        save_path: Path to save the checkpoint
    """
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'metrics': metrics
    }
    torch.save(checkpoint, save_path)


def load_checkpoint(model, optimizer, checkpoint_path):
    """
    Load a training checkpoint.
    
    Args:
        model: The model to load weights into
        optimizer: The optimizer to load state into
        checkpoint_path: Path to the checkpoint file
    
    Returns:
        Tuple of (start_epoch, metrics)
    """
    checkpoint = torch.load(checkpoint_path)
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    
    return checkpoint['epoch'], checkpoint['metrics']


def print_metrics(epoch, phase, metrics):
    """
    Print metrics in a formatted way.
    
    Args:
        epoch: Current epoch
        phase: 'Train' or 'Validation'
        metrics: Dictionary of metrics
    """
    print(f"\n{'='*60}")
    print(f"Epoch {epoch} - {phase}")
    print(f"{'='*60}")
    print(f"Total Loss:      {metrics['avg_losses']['total']:.4f}")
    print(f"Detection Loss:  {metrics['avg_losses']['detection']:.4f}")
    print(f"One-Class Loss:  {metrics['avg_losses']['one_class']:.4f}")
    print(f"Precision:       {metrics['precision']:.4f}")
    print(f"Recall:          {metrics['recall']:.4f}")
    print(f"F1 Score:        {metrics['f1']:.4f}")
    print(f"{'='*60}\n")
