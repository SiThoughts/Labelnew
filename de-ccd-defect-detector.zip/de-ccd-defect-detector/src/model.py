"""
DE-CCD: Dual-Encoder Cross-Consistency Detection
A detection model with two encoders that compute feature differences for anomaly detection.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models
from torchvision.models.detection import FasterRCNN
from torchvision.models.detection.rpn import AnchorGenerator
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor


class DualEncoder(nn.Module):
    """
    Dual encoder module with two parallel backbones.
    Extracts features from two different perspectives for cross-consistency checking.
    """
    
    def __init__(self, backbone_name='resnet50', pretrained=True):
        """
        Initialize dual encoder.
        
        Args:
            backbone_name: Name of the backbone architecture
            pretrained: Whether to use pretrained weights
        """
        super().__init__()
        
        # Create two encoders with the same architecture
        self.encoder1 = self._create_encoder(backbone_name, pretrained)
        self.encoder2 = self._create_encoder(backbone_name, pretrained)
        
        # Get feature dimensions
        self.feature_dims = self._get_feature_dims(backbone_name)
    
    def _create_encoder(self, backbone_name, pretrained):
        """Create a single encoder backbone."""
        if backbone_name == 'resnet50':
            backbone = models.resnet50(pretrained=pretrained)
            # Remove the final classification layers
            modules = list(backbone.children())[:-2]  # Remove avgpool and fc
            encoder = nn.Sequential(*modules)
        elif backbone_name == 'resnet34':
            backbone = models.resnet34(pretrained=pretrained)
            modules = list(backbone.children())[:-2]
            encoder = nn.Sequential(*modules)
        elif backbone_name == 'resnet101':
            backbone = models.resnet101(pretrained=pretrained)
            modules = list(backbone.children())[:-2]
            encoder = nn.Sequential(*modules)
        else:
            raise ValueError(f"Unsupported backbone: {backbone_name}")
        
        return encoder
    
    def _get_feature_dims(self, backbone_name):
        """Get the output feature dimensions for the backbone."""
        dims = {
            'resnet50': 2048,
            'resnet34': 512,
            'resnet101': 2048
        }
        return dims.get(backbone_name, 2048)
    
    def forward(self, x):
        """
        Forward pass through both encoders.
        
        Args:
            x: Input tensor [B, 3, H, W]
        
        Returns:
            Tuple of (features1, features2) from both encoders
        """
        features1 = self.encoder1(x)
        features2 = self.encoder2(x)
        
        return features1, features2


class AnomalyMapGenerator(nn.Module):
    """
    Generates anomaly maps by computing cross-consistency between dual encoder features.
    """
    
    def __init__(self, feature_dim):
        """
        Initialize anomaly map generator.
        
        Args:
            feature_dim: Dimension of input features
        """
        super().__init__()
        
        # Projection layers to align features
        self.proj1 = nn.Conv2d(feature_dim, feature_dim // 2, kernel_size=1)
        self.proj2 = nn.Conv2d(feature_dim, feature_dim // 2, kernel_size=1)
        
        # Anomaly map generation
        self.anomaly_conv = nn.Sequential(
            nn.Conv2d(feature_dim // 2, 128, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 1, kernel_size=1),
            nn.Sigmoid()
        )
    
    def forward(self, features1, features2):
        """
        Generate anomaly map from feature differences.
        
        Args:
            features1: Features from encoder 1 [B, C, H, W]
            features2: Features from encoder 2 [B, C, H, W]
        
        Returns:
            Anomaly map [B, 1, H, W]
        """
        # Project features to same dimension
        feat1_proj = self.proj1(features1)
        feat2_proj = self.proj2(features2)
        
        # Compute absolute difference
        diff = torch.abs(feat1_proj - feat2_proj)
        
        # Generate anomaly map
        anomaly_map = self.anomaly_conv(diff)
        
        return anomaly_map


class FeatureFusionNeck(nn.Module):
    """
    Fuses encoder features with anomaly map for enhanced detection.
    """
    
    def __init__(self, feature_dim, anomaly_channels=1):
        """
        Initialize feature fusion neck.
        
        Args:
            feature_dim: Dimension of encoder features
            anomaly_channels: Number of anomaly map channels
        """
        super().__init__()
        
        # Fusion layers
        self.fusion_conv = nn.Sequential(
            nn.Conv2d(feature_dim * 2 + anomaly_channels, feature_dim, 
                     kernel_size=3, padding=1),
            nn.BatchNorm2d(feature_dim),
            nn.ReLU(inplace=True),
            nn.Conv2d(feature_dim, feature_dim, kernel_size=3, padding=1),
            nn.BatchNorm2d(feature_dim),
            nn.ReLU(inplace=True)
        )
        
        # Output channels for detection
        self.out_channels = feature_dim
    
    def forward(self, features1, features2, anomaly_map):
        """
        Fuse features with anomaly map.
        
        Args:
            features1: Features from encoder 1
            features2: Features from encoder 2
            anomaly_map: Anomaly map
        
        Returns:
            Fused features
        """
        # Resize anomaly map to match feature size
        if anomaly_map.shape[2:] != features1.shape[2:]:
            anomaly_map = F.interpolate(
                anomaly_map, 
                size=features1.shape[2:],
                mode='bilinear',
                align_corners=False
            )
        
        # Concatenate all features
        combined = torch.cat([features1, features2, anomaly_map], dim=1)
        
        # Fuse features
        fused = self.fusion_conv(combined)
        
        return fused


class DECCD(nn.Module):
    """
    Dual-Encoder Cross-Consistency Detection model.
    
    Architecture:
    1. Dual encoders extract features independently
    2. Cross-consistency module generates anomaly map
    3. Feature fusion neck combines all information
    4. Detection head predicts bounding boxes and classes
    """
    
    def __init__(self, num_classes=3, backbone_name='resnet50', pretrained=True):
        """
        Initialize DE-CCD model.
        
        Args:
            num_classes: Number of detection classes (including background)
            backbone_name: Backbone architecture name
            pretrained: Whether to use pretrained weights
        """
        super().__init__()
        
        self.num_classes = num_classes
        
        # Dual encoder
        self.dual_encoder = DualEncoder(backbone_name, pretrained)
        feature_dim = self.dual_encoder.feature_dims
        
        # Anomaly map generator
        self.anomaly_generator = AnomalyMapGenerator(feature_dim)
        
        # Feature fusion neck
        self.fusion_neck = FeatureFusionNeck(feature_dim)
        
        # Create detection head using Faster R-CNN
        # We'll use the fused features as the backbone output
        self._build_detection_head(feature_dim)
    
    def _build_detection_head(self, feature_dim):
        """Build the detection head."""
        # Create a custom backbone that outputs our fused features
        class CustomBackbone(nn.Module):
            def __init__(self, out_channels):
                super().__init__()
                self.out_channels = out_channels
            
            def forward(self, x):
                # x is already the fused features
                return {'0': x}
        
        backbone = CustomBackbone(feature_dim)
        
        # Anchor generator
        anchor_generator = AnchorGenerator(
            sizes=((32, 64, 128, 256, 512),),
            aspect_ratios=((0.5, 1.0, 2.0),)
        )
        
        # ROI pooler
        roi_pooler = torch.ops.torchvision.ops.MultiScaleRoIAlign(
            featmap_names=['0'],
            output_size=7,
            sampling_ratio=2
        )
        
        # Create Faster R-CNN
        self.detector = FasterRCNN(
            backbone,
            num_classes=self.num_classes,
            rpn_anchor_generator=anchor_generator,
            box_roi_pool=roi_pooler
        )
    
    def forward(self, images, targets=None):
        """
        Forward pass of DE-CCD.
        
        Args:
            images: Input images [B, 3, H, W] or list of images
            targets: Optional targets for training
        
        Returns:
            During training: (detection_losses, anomaly_map)
            During inference: (detections, anomaly_map)
        """
        # Handle list input
        if isinstance(images, list):
            images = torch.stack(images)
        
        # Extract features from both encoders
        features1, features2 = self.dual_encoder(images)
        
        # Generate anomaly map
        anomaly_map = self.anomaly_generator(features1, features2)
        
        # Fuse features
        fused_features = self.fusion_neck(features1, features2, anomaly_map)
        
        # Prepare for detection head
        # The detector expects a list of images
        image_list = [img for img in images]
        
        # Override the backbone forward to use our fused features
        original_backbone_forward = self.detector.backbone.forward
        
        def custom_forward(x):
            return {'0': fused_features}
        
        self.detector.backbone.forward = custom_forward
        
        # Run detection
        if self.training and targets is not None:
            detection_output = self.detector(image_list, targets)
        else:
            detection_output = self.detector(image_list)
        
        # Restore original forward
        self.detector.backbone.forward = original_backbone_forward
        
        return detection_output, anomaly_map
    
    def get_anomaly_score(self, anomaly_map):
        """
        Compute overall anomaly score from anomaly map.
        
        Args:
            anomaly_map: Anomaly map [B, 1, H, W]
        
        Returns:
            Anomaly scores [B]
        """
        # Global average pooling
        scores = F.adaptive_avg_pool2d(anomaly_map, 1).squeeze()
        return scores


class DECCDWrapper(nn.Module):
    """
    Wrapper for ONNX export.
    """
    
    def __init__(self, deccd_model):
        """
        Initialize wrapper.
        
        Args:
            deccd_model: Trained DE-CCD model
        """
        super().__init__()
        self.model = deccd_model
        self.model.eval()
    
    def forward(self, x):
        """
        Forward pass for ONNX export.
        
        Args:
            x: Input tensor [B, 3, H, W]
        
        Returns:
            Tuple of (boxes, labels, scores)
        """
        # Get model outputs
        detection_output, anomaly_map = self.model(x)
        
        # Process detection output
        if isinstance(detection_output, list) and len(detection_output) > 0:
            detection = detection_output[0]
            
            boxes = detection['boxes']
            labels = detection['labels']
            scores = detection['scores']
        else:
            # Fallback for empty detections
            boxes = torch.zeros((0, 4))
            labels = torch.zeros((0,), dtype=torch.int64)
            scores = torch.zeros((0,))
        
        return boxes, labels, scores
