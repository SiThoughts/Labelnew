import os
import sys
import torch
import yaml
from pathlib import Path
import argparse
from datetime import datetime
import shutil

def check_gpu_availability():
    """Check if GPU is available for training."""
    if torch.cuda.is_available():
        gpu_count = torch.cuda.device_count()
        gpu_name = torch.cuda.get_device_name(0)
        print(f"GPU available: {gpu_name}")
        print(f"Number of GPUs: {gpu_count}")
        return True
    else:
        print("Warning: No GPU detected. Training will use CPU (much slower)")
        return False

def setup_yolo_environment():
    """Setup YOLO environment and install requirements if needed."""
    try:
        from ultralytics import YOLO
        print("YOLOv8 (ultralytics) is already installed")
        return True
    except ImportError:
        print("YOLOv8 not found. Please install it using:")
        print("pip install ultralytics")
        return False

class DefectDetectionTrainer:
    """Trainer class for defect detection models."""
    
    def __init__(self, model_type: str, dataset_path: str):
        self.model_type = model_type
        self.dataset_path = dataset_path
        self.model = None
        
        # Training parameters
        self.epochs = 100
        self.batch_size = 16
        self.image_size = 640
        self.learning_rate = 0.01
        self.patience = 20  # Early stopping patience
        
        # Create output directory
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.output_dir = f"training_results_{model_type}_{timestamp}"
        os.makedirs(self.output_dir, exist_ok=True)
        
        print(f"Training output will be saved to: {self.output_dir}")
    
    def load_model(self, pretrained_model: str = "yolov8n.pt"):
        """Load YOLO model for training."""
        try:
            from ultralytics import YOLO
            self.model = YOLO(pretrained_model)
            print(f"Loaded pretrained model: {pretrained_model}")
            return True
        except Exception as e:
            print(f"Error loading model: {str(e)}")
            return False
    
    def validate_dataset(self):
        """Validate that the dataset is properly formatted."""
        dataset_yaml = os.path.join(self.dataset_path, 'dataset.yaml')
        
        if not os.path.exists(dataset_yaml):
            print(f"Error: Dataset configuration file not found: {dataset_yaml}")
            return False
        
        # Check if required directories exist
        required_dirs = ['images/train', 'labels/train', 'images/val', 'labels/val']
        for dir_name in required_dirs:
            dir_path = os.path.join(self.dataset_path, dir_name)
            if not os.path.exists(dir_path):
                print(f"Warning: Directory not found: {dir_path}")
            else:
                file_count = len([f for f in os.listdir(dir_path) if os.path.isfile(os.path.join(dir_path, f))])
                print(f"Found {file_count} files in {dir_name}")
        
        return True
    
    def train_model(self):
        """Train the YOLO model."""
        if not self.model:
            print("Error: Model not loaded. Call load_model() first.")
            return False
        
        if not self.validate_dataset():
            print("Error: Dataset validation failed.")
            return False
        
        dataset_yaml = os.path.join(self.dataset_path, 'dataset.yaml')
        
        print(f"\nStarting training for {self.model_type} model...")
        print(f"Dataset: {dataset_yaml}")
        print(f"Epochs: {self.epochs}")
        print(f"Batch size: {self.batch_size}")
        print(f"Image size: {self.image_size}")
        print(f"Learning rate: {self.learning_rate}")
        
        try:
            # Train the model
            results = self.model.train(
                data=dataset_yaml,
                epochs=self.epochs,
                batch=self.batch_size,
                imgsz=self.image_size,
                lr0=self.learning_rate,
                patience=self.patience,
                save=True,
                save_period=10,  # Save checkpoint every 10 epochs
                project=self.output_dir,
                name='train',
                exist_ok=True,
                pretrained=True,
                optimizer='AdamW',
                verbose=True,
                seed=42,
                deterministic=True,
                single_cls=False,
                rect=False,
                cos_lr=True,
                close_mosaic=10,
                resume=False,
                amp=True,  # Automatic Mixed Precision
                fraction=1.0,
                profile=False,
                freeze=None,
                multi_scale=False,
                overlap_mask=True,
                mask_ratio=4,
                dropout=0.0,
                val=True,
                split='val',
                save_json=True,
                save_hybrid=False,
                conf=None,
                iou=0.7,
                max_det=300,
                half=False,
                dnn=False,
                plots=True,
                source=None,
                vid_stride=1,
                stream_buffer=False,
                visualize=False,
                augment=False,
                agnostic_nms=False,
                classes=None,
                retina_masks=False,
                embed=None,
                show=False,
                save_frames=False,
                save_txt=False,
                save_conf=False,
                save_crop=False,
                show_labels=True,
                show_conf=True,
                show_boxes=True,
                line_width=None,
            )
            
            print(f"\nTraining completed successfully!")
            
            # Copy best model to output directory
            best_model_path = os.path.join(self.output_dir, 'train', 'weights', 'best.pt')
            if os.path.exists(best_model_path):
                final_model_path = os.path.join(self.output_dir, f'{self.model_type}_best_model.pt')
                shutil.copy2(best_model_path, final_model_path)
                print(f"Best model saved to: {final_model_path}")
            
            return True
            
        except Exception as e:
            print(f"Error during training: {str(e)}")
            return False
    
    def evaluate_model(self):
        """Evaluate the trained model on test set."""
        best_model_path = os.path.join(self.output_dir, f'{self.model_type}_best_model.pt')
        
        if not os.path.exists(best_model_path):
            print("Error: Trained model not found. Train the model first.")
            return False
        
        try:
            from ultralytics import YOLO
            model = YOLO(best_model_path)
            
            dataset_yaml = os.path.join(self.dataset_path, 'dataset.yaml')
            
            print(f"\nEvaluating {self.model_type} model...")
            
            # Run validation
            results = model.val(
                data=dataset_yaml,
                split='test',
                save_json=True,
                save_hybrid=False,
                conf=0.001,
                iou=0.6,
                max_det=300,
                half=False,
                device=None,
                dnn=False,
                plots=True,
                rect=False,
                save_txt=False,
                save_conf=False,
                save_crop=False,
                show_labels=True,
                show_conf=True,
                show_boxes=True,
                verbose=True,
                project=self.output_dir,
                name='evaluation',
                exist_ok=True
            )
            
            print(f"Evaluation completed. Results saved to: {self.output_dir}/evaluation")
            return True
            
        except Exception as e:
            print(f"Error during evaluation: {str(e)}")
            return False

def main():
    """Main training function."""
    parser = argparse.ArgumentParser(description='Train YOLO model for defect detection')
    parser.add_argument('--model_type', type=str, required=True, choices=['EV', 'SV'],
                       help='Model type to train (EV or SV)')
    parser.add_argument('--dataset_path', type=str, required=True,
                       help='Path to the prepared dataset directory')
    parser.add_argument('--epochs', type=int, default=100,
                       help='Number of training epochs (default: 100)')
    parser.add_argument('--batch_size', type=int, default=16,
                       help='Batch size for training (default: 16)')
    parser.add_argument('--image_size', type=int, default=640,
                       help='Input image size (default: 640)')
    parser.add_argument('--learning_rate', type=float, default=0.01,
                       help='Learning rate (default: 0.01)')
    parser.add_argument('--pretrained_model', type=str, default='yolov8n.pt',
                       help='Pretrained model to use (default: yolov8n.pt)')
    parser.add_argument('--evaluate', action='store_true',
                       help='Run evaluation after training')
    
    args = parser.parse_args()
    
    print("Defect Detection Model Training")
    print("=" * 40)
    print(f"Model Type: {args.model_type}")
    print(f"Dataset Path: {args.dataset_path}")
    
    # Check GPU availability
    gpu_available = check_gpu_availability()
    
    # Setup YOLO environment
    if not setup_yolo_environment():
        print("Please install required dependencies and try again.")
        sys.exit(1)
    
    # Validate dataset path
    if not os.path.exists(args.dataset_path):
        print(f"Error: Dataset path does not exist: {args.dataset_path}")
        sys.exit(1)
    
    # Initialize trainer
    trainer = DefectDetectionTrainer(args.model_type, args.dataset_path)
    
    # Set training parameters from command line arguments
    trainer.epochs = args.epochs
    trainer.batch_size = args.batch_size
    trainer.image_size = args.image_size
    trainer.learning_rate = args.learning_rate
    
    # Load model
    if not trainer.load_model(args.pretrained_model):
        print("Failed to load model. Exiting.")
        sys.exit(1)
    
    # Train model
    if trainer.train_model():
        print(f"\n{args.model_type} model training completed successfully!")
        
        # Run evaluation if requested
        if args.evaluate:
            trainer.evaluate_model()
        
        print(f"\nTraining results saved to: {trainer.output_dir}")
        print(f"Best model: {trainer.output_dir}/{args.model_type}_best_model.pt")
    else:
        print("Training failed. Please check the error messages above.")
        sys.exit(1)

if __name__ == "__main__":
    main()

