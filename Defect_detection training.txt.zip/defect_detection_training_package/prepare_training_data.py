import os
import shutil
from pathlib import Path
from xml_parser import AnnotationParser
from typing import List, Dict, Tuple
import random

class TrainingDataPreparator:
    """Prepares training data for YOLO model training."""
    
    def __init__(self):
        self.parser = AnnotationParser()
        self.class_mapping = {'chip': 0, 'check': 1}
        
        # Data source paths
        self.training_sources = [
            r"D:\LIDS Data\Photomask\DSO",
            r"D:\LIDS Data\Photomask\DS2_Sort2"
        ]
        
        self.validation_source = r"D:\LIDS Data\Photomask\MSA_Sort3"
    
    def collect_data_from_folder(self, folder_path: str, subfolder: str) -> List[Tuple[str, str]]:
        """
        Collect image and XML pairs from a specific folder.
        
        Args:
            folder_path: Base folder path
            subfolder: Subfolder name ('EV' or 'SV')
            
        Returns:
            List of (image_path, xml_path) tuples
        """
        data_pairs = []
        target_folder = os.path.join(folder_path, subfolder)
        
        if not os.path.exists(target_folder):
            print(f"Warning: Folder {target_folder} does not exist")
            return data_pairs
        
        # Find all XML files
        xml_files = []
        for file in os.listdir(target_folder):
            if file.lower().endswith('.xml'):
                xml_files.append(os.path.join(target_folder, file))
        
        print(f"Found {len(xml_files)} XML files in {target_folder}")
        
        # For each XML file, find matching image
        for xml_path in xml_files:
            image_path = self.parser.find_matching_image(xml_path, target_folder)
            if image_path:
                data_pairs.append((image_path, xml_path))
            else:
                print(f"Warning: No matching image found for {xml_path}")
        
        print(f"Successfully paired {len(data_pairs)} image-annotation pairs from {target_folder}")
        return data_pairs
    
    def prepare_yolo_dataset(self, data_pairs: List[Tuple[str, str]], output_dir: str, split_name: str):
        """
        Prepare YOLO format dataset from image-annotation pairs.
        
        Args:
            data_pairs: List of (image_path, xml_path) tuples
            output_dir: Output directory for the dataset
            split_name: Name of the split ('train', 'val', 'test')
        """
        images_dir = os.path.join(output_dir, 'images', split_name)
        labels_dir = os.path.join(output_dir, 'labels', split_name)
        
        os.makedirs(images_dir, exist_ok=True)
        os.makedirs(labels_dir, exist_ok=True)
        
        successful_pairs = 0
        
        for image_path, xml_path in data_pairs:
            # Parse XML annotation
            annotation = self.parser.parse_xml_file(xml_path)
            if annotation is None:
                continue
            
            # Skip if no valid objects found
            if not annotation['objects']:
                print(f"Warning: No valid objects found in {xml_path}")
                continue
            
            # Convert to YOLO format
            yolo_lines = self.parser.convert_to_yolo_format(annotation, self.class_mapping)
            if not yolo_lines:
                continue
            
            # Copy image file
            image_filename = os.path.basename(image_path)
            target_image_path = os.path.join(images_dir, image_filename)
            shutil.copy2(image_path, target_image_path)
            
            # Create label file
            label_filename = os.path.splitext(image_filename)[0] + '.txt'
            label_path = os.path.join(labels_dir, label_filename)
            
            with open(label_path, 'w') as f:
                f.write('\n'.join(yolo_lines))
            
            successful_pairs += 1
        
        print(f"Successfully processed {successful_pairs} pairs for {split_name} split")
        return successful_pairs
    
    def create_dataset_yaml(self, output_dir: str, model_type: str):
        """
        Create YAML configuration file for the dataset.
        
        Args:
            output_dir: Dataset output directory
            model_type: Type of model ('EV' or 'SV')
        """
        yaml_content = f"""# Dataset configuration for {model_type} defect detection
path: {output_dir}
train: images/train
val: images/val
test: images/test

# Classes
nc: 2  # number of classes
names: ['chip', 'check']  # class names
"""
        
        yaml_path = os.path.join(output_dir, 'dataset.yaml')
        with open(yaml_path, 'w') as f:
            f.write(yaml_content)
        
        print(f"Created dataset configuration: {yaml_path}")
    
    def prepare_model_data(self, model_type: str, output_base_dir: str):
        """
        Prepare complete dataset for a specific model type.
        
        Args:
            model_type: 'EV' or 'SV'
            output_base_dir: Base directory for output
        """
        print(f"\n=== Preparing {model_type} Model Data ===")
        
        output_dir = os.path.join(output_base_dir, f"{model_type}_dataset")
        
        # Collect training data from multiple sources
        all_training_pairs = []
        for source_path in self.training_sources:
            pairs = self.collect_data_from_folder(source_path, model_type)
            all_training_pairs.extend(pairs)
        
        print(f"Total training pairs for {model_type}: {len(all_training_pairs)}")
        
        # Collect validation/test data
        validation_pairs = self.collect_data_from_folder(self.validation_source, model_type)
        print(f"Total validation pairs for {model_type}: {len(validation_pairs)}")
        
        if not all_training_pairs:
            print(f"Error: No training data found for {model_type} model")
            return
        
        if not validation_pairs:
            print(f"Warning: No validation data found for {model_type} model")
        
        # Split validation data into val and test (50-50 split)
        random.shuffle(validation_pairs)
        split_point = len(validation_pairs) // 2
        val_pairs = validation_pairs[:split_point]
        test_pairs = validation_pairs[split_point:]
        
        # Prepare YOLO datasets
        train_count = self.prepare_yolo_dataset(all_training_pairs, output_dir, 'train')
        val_count = self.prepare_yolo_dataset(val_pairs, output_dir, 'val')
        test_count = self.prepare_yolo_dataset(test_pairs, output_dir, 'test')
        
        # Create dataset configuration
        self.create_dataset_yaml(output_dir, model_type)
        
        print(f"\n{model_type} Dataset Summary:")
        print(f"  Training samples: {train_count}")
        print(f"  Validation samples: {val_count}")
        print(f"  Test samples: {test_count}")
        print(f"  Dataset location: {output_dir}")
        
        return output_dir

def main():
    """Main function to prepare both EV and SV datasets."""
    print("Defect Detection Dataset Preparation")
    print("=" * 40)
    
    # Set random seed for reproducible splits
    random.seed(42)
    
    # Create output directory
    output_base = "defect_detection_datasets"
    os.makedirs(output_base, exist_ok=True)
    
    preparator = TrainingDataPreparator()
    
    # Prepare both datasets
    ev_dataset_path = preparator.prepare_model_data('EV', output_base)
    sv_dataset_path = preparator.prepare_model_data('SV', output_base)
    
    print("\n" + "=" * 40)
    print("Dataset preparation completed!")
    print(f"EV dataset: {ev_dataset_path}")
    print(f"SV dataset: {sv_dataset_path}")
    print("\nYou can now proceed with model training.")

if __name__ == "__main__":
    main()

