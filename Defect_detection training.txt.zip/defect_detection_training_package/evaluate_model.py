#!/usr/bin/env python3
"""
Model evaluation script for defect detection models.
Provides detailed performance metrics and analysis.
"""

import os
import sys
import argparse
import json
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
from typing import Dict, List, Tuple

def check_dependencies():
    """Check if required dependencies are installed."""
    try:
        from ultralytics import YOLO
        import torch
        import matplotlib.pyplot as plt
        return True
    except ImportError as e:
        print(f"Missing dependency: {e}")
        print("Please install required packages using: pip install -r requirements.txt")
        return False

class ModelEvaluator:
    """Model evaluation class for defect detection."""
    
    def __init__(self, model_path: str, dataset_path: str):
        """
        Initialize the model evaluator.
        
        Args:
            model_path: Path to the trained model
            dataset_path: Path to the dataset directory
        """
        self.model_path = model_path
        self.dataset_path = dataset_path
        self.model = None
        self.class_names = ['chip', 'check']
        
        self.load_model()
    
    def load_model(self):
        """Load the trained model."""
        try:
            from ultralytics import YOLO
            
            if not os.path.exists(self.model_path):
                raise FileNotFoundError(f"Model file not found: {self.model_path}")
            
            self.model = YOLO(self.model_path)
            print(f"Model loaded: {self.model_path}")
            
        except Exception as e:
            print(f"Error loading model: {str(e)}")
            sys.exit(1)
    
    def run_validation(self, split: str = 'test') -> Dict:
        """
        Run validation on the specified dataset split.
        
        Args:
            split: Dataset split to evaluate ('val', 'test')
            
        Returns:
            Dictionary containing validation results
        """
        dataset_yaml = os.path.join(self.dataset_path, 'dataset.yaml')
        
        if not os.path.exists(dataset_yaml):
            raise FileNotFoundError(f"Dataset configuration not found: {dataset_yaml}")
        
        print(f"Running validation on {split} split...")
        
        try:
            # Run validation
            results = self.model.val(
                data=dataset_yaml,
                split=split,
                save_json=True,
                save_hybrid=False,
                conf=0.001,  # Low confidence to get all detections
                iou=0.6,
                max_det=300,
                half=False,
                device=None,
                dnn=False,
                plots=True,
                rect=False,
                save_txt=False,
                save_conf=False,
                save_crop=False,
                show_labels=True,
                show_conf=True,
                show_boxes=True,
                verbose=True
            )
            
            return results
            
        except Exception as e:
            print(f"Error during validation: {str(e)}")
            return None
    
    def extract_metrics(self, results) -> Dict:
        """
        Extract key metrics from validation results.
        
        Args:
            results: Validation results from YOLO
            
        Returns:
            Dictionary containing extracted metrics
        """
        if results is None:
            return None
        
        try:
            metrics = {
                'mAP50': float(results.box.map50),  # mAP at IoU=0.5
                'mAP50_95': float(results.box.map),  # mAP at IoU=0.5:0.95
                'precision': float(results.box.mp),  # Mean precision
                'recall': float(results.box.mr),     # Mean recall
                'f1_score': 2 * (results.box.mp * results.box.mr) / (results.box.mp + results.box.mr) if (results.box.mp + results.box.mr) > 0 else 0.0
            }
            
            # Per-class metrics if available
            if hasattr(results.box, 'ap_class_index') and results.box.ap_class_index is not None:
                class_metrics = {}
                for i, class_idx in enumerate(results.box.ap_class_index):
                    class_name = self.class_names[int(class_idx)] if int(class_idx) < len(self.class_names) else f"class_{int(class_idx)}"
                    class_metrics[class_name] = {
                        'ap50': float(results.box.ap50[i]) if i < len(results.box.ap50) else 0.0,
                        'ap50_95': float(results.box.ap[i]) if i < len(results.box.ap) else 0.0
                    }
                metrics['per_class'] = class_metrics
            
            return metrics
            
        except Exception as e:
            print(f"Error extracting metrics: {str(e)}")
            return None
    
    def create_performance_report(self, metrics: Dict, output_dir: str):
        """
        Create a detailed performance report.
        
        Args:
            metrics: Extracted metrics dictionary
            output_dir: Directory to save the report
        """
        if metrics is None:
            print("No metrics available for report generation")
            return
        
        os.makedirs(output_dir, exist_ok=True)
        
        # Create text report
        report_path = os.path.join(output_dir, 'performance_report.txt')
        
        with open(report_path, 'w') as f:
            f.write("Defect Detection Model Performance Report\n")
            f.write("=" * 45 + "\n\n")
            
            f.write(f"Model: {os.path.basename(self.model_path)}\n")
            f.write(f"Dataset: {self.dataset_path}\n\n")
            
            f.write("Overall Metrics:\n")
            f.write("-" * 16 + "\n")
            f.write(f"mAP@0.5:      {metrics['mAP50']:.4f}\n")
            f.write(f"mAP@0.5:0.95: {metrics['mAP50_95']:.4f}\n")
            f.write(f"Precision:    {metrics['precision']:.4f}\n")
            f.write(f"Recall:       {metrics['recall']:.4f}\n")
            f.write(f"F1-Score:     {metrics['f1_score']:.4f}\n\n")
            
            if 'per_class' in metrics:
                f.write("Per-Class Metrics:\n")
                f.write("-" * 18 + "\n")
                for class_name, class_metrics in metrics['per_class'].items():
                    f.write(f"{class_name.upper()}:\n")
                    f.write(f"  AP@0.5:      {class_metrics['ap50']:.4f}\n")
                    f.write(f"  AP@0.5:0.95: {class_metrics['ap50_95']:.4f}\n")
                f.write("\n")
            
            # Performance interpretation
            f.write("Performance Interpretation:\n")
            f.write("-" * 27 + "\n")
            
            if metrics['mAP50'] >= 0.8:
                f.write("• Excellent detection performance (mAP@0.5 ≥ 0.8)\n")
            elif metrics['mAP50'] >= 0.6:
                f.write("• Good detection performance (mAP@0.5 ≥ 0.6)\n")
            elif metrics['mAP50'] >= 0.4:
                f.write("• Moderate detection performance (mAP@0.5 ≥ 0.4)\n")
            else:
                f.write("• Poor detection performance (mAP@0.5 < 0.4)\n")
                f.write("  Consider collecting more training data or adjusting model parameters.\n")
            
            if metrics['precision'] > metrics['recall']:
                f.write("• Model tends to be conservative (higher precision than recall)\n")
                f.write("  Few false positives, but may miss some defects\n")
            elif metrics['recall'] > metrics['precision']:
                f.write("• Model tends to be sensitive (higher recall than precision)\n")
                f.write("  Catches most defects, but may have false alarms\n")
            else:
                f.write("• Balanced precision and recall\n")
        
        print(f"Performance report saved: {report_path}")
        
        # Create metrics visualization
        self.create_metrics_visualization(metrics, output_dir)
        
        # Save metrics as JSON
        json_path = os.path.join(output_dir, 'metrics.json')
        with open(json_path, 'w') as f:
            json.dump(metrics, f, indent=2)
        print(f"Metrics JSON saved: {json_path}")
    
    def create_metrics_visualization(self, metrics: Dict, output_dir: str):
        """
        Create visualization of model metrics.
        
        Args:
            metrics: Metrics dictionary
            output_dir: Output directory
        """
        try:
            # Create figure with subplots
            fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(12, 10))
            fig.suptitle('Model Performance Metrics', fontsize=16, fontweight='bold')
            
            # Overall metrics bar chart
            overall_metrics = ['mAP@0.5', 'mAP@0.5:0.95', 'Precision', 'Recall', 'F1-Score']
            overall_values = [metrics['mAP50'], metrics['mAP50_95'], 
                            metrics['precision'], metrics['recall'], metrics['f1_score']]
            
            bars1 = ax1.bar(overall_metrics, overall_values, color=['#2E8B57', '#4682B4', '#DAA520', '#DC143C', '#9932CC'])
            ax1.set_title('Overall Performance Metrics')
            ax1.set_ylabel('Score')
            ax1.set_ylim(0, 1)
            ax1.tick_params(axis='x', rotation=45)
            
            # Add value labels on bars
            for bar, value in zip(bars1, overall_values):
                ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01, 
                        f'{value:.3f}', ha='center', va='bottom', fontweight='bold')
            
            # Per-class metrics if available
            if 'per_class' in metrics and metrics['per_class']:
                classes = list(metrics['per_class'].keys())
                ap50_values = [metrics['per_class'][cls]['ap50'] for cls in classes]
                ap50_95_values = [metrics['per_class'][cls]['ap50_95'] for cls in classes]
                
                x = np.arange(len(classes))
                width = 0.35
                
                bars2 = ax2.bar(x - width/2, ap50_values, width, label='AP@0.5', color='#2E8B57')
                bars3 = ax2.bar(x + width/2, ap50_95_values, width, label='AP@0.5:0.95', color='#4682B4')
                
                ax2.set_title('Per-Class Average Precision')
                ax2.set_ylabel('Average Precision')
                ax2.set_xlabel('Class')
                ax2.set_xticks(x)
                ax2.set_xticklabels(classes)
                ax2.legend()
                ax2.set_ylim(0, 1)
                
                # Add value labels
                for bars in [bars2, bars3]:
                    for bar in bars:
                        height = bar.get_height()
                        ax2.text(bar.get_x() + bar.get_width()/2, height + 0.01,
                                f'{height:.3f}', ha='center', va='bottom', fontsize=9)
            else:
                ax2.text(0.5, 0.5, 'No per-class metrics available', 
                        ha='center', va='center', transform=ax2.transAxes, fontsize=12)
                ax2.set_title('Per-Class Metrics')
            
            # Precision-Recall balance
            pr_labels = ['Precision', 'Recall']
            pr_values = [metrics['precision'], metrics['recall']]
            colors = ['#DAA520', '#DC143C']
            
            wedges, texts, autotexts = ax3.pie(pr_values, labels=pr_labels, colors=colors, 
                                              autopct='%1.3f', startangle=90)
            ax3.set_title('Precision vs Recall Balance')
            
            # Performance gauge
            performance_score = metrics['f1_score']
            
            # Create a simple gauge visualization
            theta = np.linspace(0, np.pi, 100)
            r = np.ones_like(theta)
            
            ax4.plot(theta, r, 'k-', linewidth=2)
            ax4.fill_between(theta, 0, r, alpha=0.3, color='lightgray')
            
            # Color zones
            zones = [(0, np.pi/4, 'red', 'Poor'), (np.pi/4, np.pi/2, 'orange', 'Fair'), 
                    (np.pi/2, 3*np.pi/4, 'yellow', 'Good'), (3*np.pi/4, np.pi, 'green', 'Excellent')]
            
            for start, end, color, label in zones:
                zone_theta = np.linspace(start, end, 25)
                zone_r = np.ones_like(zone_theta)
                ax4.fill_between(zone_theta, 0, zone_r, alpha=0.6, color=color)
            
            # Performance indicator
            perf_angle = performance_score * np.pi
            ax4.plot([perf_angle, perf_angle], [0, 1], 'k-', linewidth=4)
            ax4.plot(perf_angle, 1, 'ko', markersize=8)
            
            ax4.set_xlim(0, np.pi)
            ax4.set_ylim(0, 1.2)
            ax4.set_title(f'F1-Score Gauge: {performance_score:.3f}')
            ax4.set_xticks([0, np.pi/4, np.pi/2, 3*np.pi/4, np.pi])
            ax4.set_xticklabels(['0.0', '0.25', '0.5', '0.75', '1.0'])
            ax4.set_yticks([])
            
            plt.tight_layout()
            
            # Save visualization
            viz_path = os.path.join(output_dir, 'performance_visualization.png')
            plt.savefig(viz_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            print(f"Performance visualization saved: {viz_path}")
            
        except Exception as e:
            print(f"Error creating visualization: {str(e)}")

def main():
    """Main evaluation function."""
    parser = argparse.ArgumentParser(description='Evaluate defect detection model')
    parser.add_argument('--model', type=str, required=True,
                       help='Path to trained model (.pt file)')
    parser.add_argument('--dataset', type=str, required=True,
                       help='Path to dataset directory')
    parser.add_argument('--split', type=str, default='test', choices=['val', 'test'],
                       help='Dataset split to evaluate (default: test)')
    parser.add_argument('--output', type=str, default='evaluation_results',
                       help='Output directory for results (default: evaluation_results)')
    
    args = parser.parse_args()
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Validate inputs
    if not os.path.exists(args.model):
        print(f"Error: Model file not found: {args.model}")
        sys.exit(1)
    
    if not os.path.exists(args.dataset):
        print(f"Error: Dataset directory not found: {args.dataset}")
        sys.exit(1)
    
    print("Model Evaluation")
    print("=" * 20)
    print(f"Model: {args.model}")
    print(f"Dataset: {args.dataset}")
    print(f"Split: {args.split}")
    
    # Initialize evaluator
    evaluator = ModelEvaluator(args.model, args.dataset)
    
    # Run validation
    results = evaluator.run_validation(args.split)
    
    if results is None:
        print("Evaluation failed")
        sys.exit(1)
    
    # Extract metrics
    metrics = evaluator.extract_metrics(results)
    
    if metrics is None:
        print("Failed to extract metrics")
        sys.exit(1)
    
    # Create performance report
    evaluator.create_performance_report(metrics, args.output)
    
    print(f"\nEvaluation completed!")
    print(f"Results saved to: {args.output}")
    
    # Print summary
    print(f"\nSummary:")
    print(f"  mAP@0.5: {metrics['mAP50']:.4f}")
    print(f"  Precision: {metrics['precision']:.4f}")
    print(f"  Recall: {metrics['recall']:.4f}")
    print(f"  F1-Score: {metrics['f1_score']:.4f}")

if __name__ == "__main__":
    main()

