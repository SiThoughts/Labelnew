#!/usr/bin/env python3
"""
Inference script for defect detection models.
Use this script to run predictions on new images using trained models.
"""

import os
import sys
import argparse
from pathlib import Path
import cv2
import numpy as np
from typing import List, Dict, Tuple

def check_dependencies():
    """Check if required dependencies are installed."""
    try:
        from ultralytics import YOLO
        import torch
        return True
    except ImportError as e:
        print(f"Missing dependency: {e}")
        print("Please install required packages using: pip install -r requirements.txt")
        return False

class DefectDetector:
    """Defect detection inference class."""
    
    def __init__(self, model_path: str, confidence_threshold: float = 0.5):
        """
        Initialize the defect detector.
        
        Args:
            model_path: Path to the trained YOLO model (.pt file)
            confidence_threshold: Minimum confidence for detections
        """
        self.model_path = model_path
        self.confidence_threshold = confidence_threshold
        self.model = None
        self.class_names = ['chip', 'check']
        
        self.load_model()
    
    def load_model(self):
        """Load the trained YOLO model."""
        try:
            from ultralytics import YOLO
            
            if not os.path.exists(self.model_path):
                raise FileNotFoundError(f"Model file not found: {self.model_path}")
            
            self.model = YOLO(self.model_path)
            print(f"Model loaded successfully: {self.model_path}")
            
        except Exception as e:
            print(f"Error loading model: {str(e)}")
            sys.exit(1)
    
    def predict_image(self, image_path: str) -> Dict:
        """
        Run prediction on a single image.
        
        Args:
            image_path: Path to the input image
            
        Returns:
            Dictionary containing prediction results
        """
        if not os.path.exists(image_path):
            print(f"Error: Image file not found: {image_path}")
            return None
        
        try:
            # Run inference
            results = self.model(image_path, conf=self.confidence_threshold)
            
            # Extract predictions
            predictions = []
            if len(results) > 0 and results[0].boxes is not None:
                boxes = results[0].boxes
                
                for i in range(len(boxes)):
                    # Get bounding box coordinates
                    x1, y1, x2, y2 = boxes.xyxy[i].cpu().numpy()
                    
                    # Get confidence and class
                    confidence = float(boxes.conf[i].cpu().numpy())
                    class_id = int(boxes.cls[i].cpu().numpy())
                    class_name = self.class_names[class_id] if class_id < len(self.class_names) else f"class_{class_id}"
                    
                    predictions.append({
                        'class': class_name,
                        'confidence': confidence,
                        'bbox': [float(x1), float(y1), float(x2), float(y2)]
                    })
            
            return {
                'image_path': image_path,
                'predictions': predictions,
                'num_detections': len(predictions)
            }
            
        except Exception as e:
            print(f"Error processing image {image_path}: {str(e)}")
            return None
    
    def predict_batch(self, image_paths: List[str]) -> List[Dict]:
        """
        Run predictions on multiple images.
        
        Args:
            image_paths: List of image file paths
            
        Returns:
            List of prediction results
        """
        results = []
        
        for image_path in image_paths:
            print(f"Processing: {image_path}")
            result = self.predict_image(image_path)
            if result:
                results.append(result)
        
        return results
    
    def visualize_predictions(self, image_path: str, output_path: str = None) -> str:
        """
        Create visualization of predictions on an image.
        
        Args:
            image_path: Path to input image
            output_path: Path to save visualization (optional)
            
        Returns:
            Path to the saved visualization
        """
        if not os.path.exists(image_path):
            print(f"Error: Image file not found: {image_path}")
            return None
        
        try:
            # Load image
            image = cv2.imread(image_path)
            if image is None:
                print(f"Error: Could not load image: {image_path}")
                return None
            
            # Get predictions
            predictions = self.predict_image(image_path)
            if not predictions or not predictions['predictions']:
                print(f"No detections found in {image_path}")
                # Still save the original image
                if output_path is None:
                    output_path = f"output_{os.path.basename(image_path)}"
                cv2.imwrite(output_path, image)
                return output_path
            
            # Draw bounding boxes and labels
            for pred in predictions['predictions']:
                x1, y1, x2, y2 = [int(coord) for coord in pred['bbox']]
                class_name = pred['class']
                confidence = pred['confidence']
                
                # Choose color based on class
                color = (0, 255, 0) if class_name == 'chip' else (0, 0, 255)  # Green for chip, Red for check
                
                # Draw bounding box
                cv2.rectangle(image, (x1, y1), (x2, y2), color, 2)
                
                # Draw label
                label = f"{class_name}: {confidence:.2f}"
                label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
                
                # Draw label background
                cv2.rectangle(image, (x1, y1 - label_size[1] - 10), 
                            (x1 + label_size[0], y1), color, -1)
                
                # Draw label text
                cv2.putText(image, label, (x1, y1 - 5), 
                          cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            
            # Save visualization
            if output_path is None:
                output_path = f"output_{os.path.basename(image_path)}"
            
            cv2.imwrite(output_path, image)
            print(f"Visualization saved: {output_path}")
            
            return output_path
            
        except Exception as e:
            print(f"Error creating visualization: {str(e)}")
            return None

def find_images_in_directory(directory: str) -> List[str]:
    """Find all image files in a directory."""
    image_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif'}
    image_paths = []
    
    for root, dirs, files in os.walk(directory):
        for file in files:
            if Path(file).suffix.lower() in image_extensions:
                image_paths.append(os.path.join(root, file))
    
    return sorted(image_paths)

def main():
    """Main inference function."""
    parser = argparse.ArgumentParser(description='Run defect detection inference')
    parser.add_argument('--model', type=str, required=True,
                       help='Path to trained model (.pt file)')
    parser.add_argument('--input', type=str, required=True,
                       help='Path to input image or directory')
    parser.add_argument('--output', type=str, default='inference_results',
                       help='Output directory for results (default: inference_results)')
    parser.add_argument('--confidence', type=float, default=0.5,
                       help='Confidence threshold (default: 0.5)')
    parser.add_argument('--visualize', action='store_true',
                       help='Create visualization images')
    parser.add_argument('--save_txt', action='store_true',
                       help='Save predictions to text files')
    
    args = parser.parse_args()
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Validate model file
    if not os.path.exists(args.model):
        print(f"Error: Model file not found: {args.model}")
        sys.exit(1)
    
    # Validate input
    if not os.path.exists(args.input):
        print(f"Error: Input path not found: {args.input}")
        sys.exit(1)
    
    # Create output directory
    os.makedirs(args.output, exist_ok=True)
    
    # Initialize detector
    detector = DefectDetector(args.model, args.confidence)
    
    # Get input images
    if os.path.isfile(args.input):
        image_paths = [args.input]
    else:
        image_paths = find_images_in_directory(args.input)
        if not image_paths:
            print(f"No image files found in: {args.input}")
            sys.exit(1)
    
    print(f"Found {len(image_paths)} image(s) to process")
    
    # Run inference
    all_results = []
    for image_path in image_paths:
        print(f"\nProcessing: {image_path}")
        
        # Get predictions
        result = detector.predict_image(image_path)
        if result:
            all_results.append(result)
            
            # Print results
            if result['num_detections'] > 0:
                print(f"  Found {result['num_detections']} defect(s):")
                for pred in result['predictions']:
                    print(f"    - {pred['class']}: {pred['confidence']:.3f}")
            else:
                print("  No defects detected")
            
            # Create visualization if requested
            if args.visualize:
                output_name = f"vis_{os.path.basename(image_path)}"
                output_path = os.path.join(args.output, output_name)
                detector.visualize_predictions(image_path, output_path)
            
            # Save predictions to text file if requested
            if args.save_txt:
                txt_name = f"{os.path.splitext(os.path.basename(image_path))[0]}.txt"
                txt_path = os.path.join(args.output, txt_name)
                
                with open(txt_path, 'w') as f:
                    for pred in result['predictions']:
                        # Convert to YOLO format for consistency
                        x1, y1, x2, y2 = pred['bbox']
                        # Note: This assumes we know the image dimensions
                        # For proper YOLO format, we'd need to normalize by image size
                        f.write(f"{pred['class']} {pred['confidence']:.6f} {x1} {y1} {x2} {y2}\n")
    
    # Summary
    print(f"\n{'='*50}")
    print(f"Inference completed!")
    print(f"Processed {len(all_results)} images")
    
    total_detections = sum(r['num_detections'] for r in all_results)
    print(f"Total defects detected: {total_detections}")
    
    if args.visualize or args.save_txt:
        print(f"Results saved to: {args.output}")

if __name__ == "__main__":
    main()

