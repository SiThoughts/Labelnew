#!/usr/bin/env python3
"""
Convenience script to train the EV defect detection model.
This script automatically sets up the training for EV images.
"""

import os
import sys
import subprocess
from pathlib import Path

def main():
    """Train the EV model with predefined settings."""
    
    # Default dataset path (adjust if needed)
    dataset_path = "defect_detection_datasets/EV_dataset"
    
    # Check if dataset exists
    if not os.path.exists(dataset_path):
        print(f"Error: EV dataset not found at {dataset_path}")
        print("Please run 'python prepare_training_data.py' first to prepare the datasets.")
        sys.exit(1)
    
    # Training parameters optimized for defect detection
    training_args = [
        sys.executable, "train_yolo_model.py",
        "--model_type", "EV",
        "--dataset_path", dataset_path,
        "--epochs", "150",
        "--batch_size", "16",
        "--image_size", "640",
        "--learning_rate", "0.01",
        "--pretrained_model", "yolov8n.pt",
        "--evaluate"
    ]
    
    print("Starting EV Model Training")
    print("=" * 30)
    print(f"Dataset: {dataset_path}")
    print("Training parameters:")
    print("  - Epochs: 150")
    print("  - Batch size: 16")
    print("  - Image size: 640x640")
    print("  - Learning rate: 0.01")
    print("  - Base model: YOLOv8n")
    print("  - Evaluation: Enabled")
    print()
    
    try:
        # Run training
        result = subprocess.run(training_args, check=True)
        print("\nEV model training completed successfully!")
        
    except subprocess.CalledProcessError as e:
        print(f"\nTraining failed with exit code {e.returncode}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nTraining interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\nUnexpected error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()

