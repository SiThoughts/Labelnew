import xml.etree.ElementTree as ET
import os
from typing import List, Dict, Tuple, Optional

class AnnotationParser:
    """Parser for XML annotation files in Pascal VOC format."""
    
    def __init__(self):
        self.supported_classes = ['chip', 'check']
    
    def parse_xml_file(self, xml_path: str) -> Optional[Dict]:
        """
        Parse a single XML annotation file.
        
        Args:
            xml_path: Path to the XML file
            
        Returns:
            Dictionary containing parsed annotation data or None if parsing fails
        """
        try:
            tree = ET.parse(xml_path)
            root = tree.getroot()
            
            # Extract basic image information
            filename_elem = root.find('filename')
            if filename_elem is not None:
                filename = filename_elem.text
            else:
                # Fallback: use XML filename with image extension
                filename = os.path.splitext(os.path.basename(xml_path))[0] + '.png'
            
            size_elem = root.find('size')
            if size_elem is not None:
                width = int(size_elem.find('width').text)
                height = int(size_elem.find('height').text)
            else:
                # Default values if size not found
                width, height = 2048, 1460
            
            # Extract object annotations
            objects = []
            for obj in root.findall('object'):
                name_elem = obj.find('name')
                if name_elem is None:
                    continue
                    
                class_name = name_elem.text.lower()
                if class_name not in self.supported_classes:
                    continue
                
                bbox_elem = obj.find('bndbox')
                if bbox_elem is None:
                    continue
                
                try:
                    xmin = int(float(bbox_elem.find('xmin').text))
                    ymin = int(float(bbox_elem.find('ymin').text))
                    xmax = int(float(bbox_elem.find('xmax').text))
                    ymax = int(float(bbox_elem.find('ymax').text))
                    
                    # Validate bounding box
                    if xmin >= xmax or ymin >= ymax:
                        continue
                    
                    objects.append({
                        'class': class_name,
                        'bbox': [xmin, ymin, xmax, ymax]
                    })
                except (ValueError, AttributeError):
                    continue
            
            return {
                'filename': filename,
                'width': width,
                'height': height,
                'objects': objects
            }
            
        except Exception as e:
            print(f"Error parsing {xml_path}: {str(e)}")
            return None
    
    def convert_to_yolo_format(self, annotation: Dict, class_mapping: Dict[str, int]) -> List[str]:
        """
        Convert annotation to YOLO format.
        
        Args:
            annotation: Parsed annotation dictionary
            class_mapping: Mapping from class names to class indices
            
        Returns:
            List of YOLO format strings
        """
        yolo_lines = []
        width = annotation['width']
        height = annotation['height']
        
        for obj in annotation['objects']:
            class_name = obj['class']
            if class_name not in class_mapping:
                continue
            
            class_id = class_mapping[class_name]
            xmin, ymin, xmax, ymax = obj['bbox']
            
            # Convert to YOLO format (normalized center coordinates and dimensions)
            x_center = (xmin + xmax) / 2.0 / width
            y_center = (ymin + ymax) / 2.0 / height
            bbox_width = (xmax - xmin) / width
            bbox_height = (ymax - ymin) / height
            
            yolo_lines.append(f"{class_id} {x_center:.6f} {y_center:.6f} {bbox_width:.6f} {bbox_height:.6f}")
        
        return yolo_lines
    
    def find_matching_image(self, xml_path: str, image_dir: str) -> Optional[str]:
        """
        Find the matching image file for an XML annotation.
        
        Args:
            xml_path: Path to the XML file
            image_dir: Directory containing images
            
        Returns:
            Path to matching image file or None if not found
        """
        xml_basename = os.path.splitext(os.path.basename(xml_path))[0]
        
        # Common image extensions
        image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif']
        
        for ext in image_extensions:
            image_path = os.path.join(image_dir, xml_basename + ext)
            if os.path.exists(image_path):
                return image_path
        
        # If exact match not found, try to find any image with similar name
        for filename in os.listdir(image_dir):
            name, ext = os.path.splitext(filename)
            if ext.lower() in [e.lower() for e in image_extensions]:
                if xml_basename.lower() in name.lower() or name.lower() in xml_basename.lower():
                    return os.path.join(image_dir, filename)
        
        return None

