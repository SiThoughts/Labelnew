"""
STEP 3: Train Verifier CNN

Trains a lightweight CNN classifier to verify detector outputs:
- Input: 128x128 crops from detector
- Output: 3 classes (background, chip, check)
- Uses balanced loss to handle class imbalance

Output: Trained verifier model (.pth file)
"""

import os
import sys
import argparse
import json
from pathlib import Path
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
import torchvision.models as models
from tqdm import tqdm
import numpy as np
from PIL import Image
from sklearn.metrics import classification_report, confusion_matrix


class VerifierDataset(Dataset):
    """Dataset for verifier training"""
    
    def __init__(self, dataset_dir, transform=None):
        self.dataset_dir = Path(dataset_dir)
        self.transform = transform
        
        # Load dataset
        with open(self.dataset_dir / 'dataset.json', 'r') as f:
            self.samples = json.load(f)
        
        # Load metadata
        with open(self.dataset_dir / 'metadata.json', 'r') as f:
            self.metadata = json.load(f)
        
        print(f"Loaded {len(self.samples)} samples")
        print(f"  Positive: {self.metadata['positive_samples']}")
        print(f"  Negative: {self.metadata['negative_samples']}")
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        sample = self.samples[idx]
        
        # Load crop
        crop_path = self.dataset_dir / sample['crop_path']
        image = Image.open(crop_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
        
        label = sample['label']
        
        return image, label


class VerifierCNN(nn.Module):
    """
    Lightweight CNN for verification
    Based on MobileNetV2 (fast, small)
    """
    
    def __init__(self, num_classes=3, pretrained=True):
        super().__init__()
        
        # Use MobileNetV2 as backbone
        self.backbone = models.mobilenet_v2(pretrained=pretrained)
        
        # Replace classifier
        in_features = self.backbone.classifier[1].in_features
        self.backbone.classifier = nn.Sequential(
            nn.Dropout(0.2),
            nn.Linear(in_features, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.2),
            nn.Linear(256, num_classes)
        )
    
    def forward(self, x):
        return self.backbone(x)


def train_verifier(dataset_dir, output_dir, image_type, epochs=50, 
                   batch_size=32, lr=0.001, device='cuda'):
    """
    Train verifier CNN
    
    Args:
        dataset_dir: Path to verifier dataset
        output_dir: Where to save model
        image_type: 'EV', 'BV', or 'TV'
        epochs: Training epochs
        batch_size: Batch size
        lr: Learning rate
        device: 'cuda' or 'cpu'
    
    Returns:
        Path to trained model
    """
    
    print(f"\n{'='*70}")
    print(f"TRAINING VERIFIER CNN - {image_type}")
    print(f"{'='*70}\n")
    
    # Setup device
    device = torch.device(device if torch.cuda.is_available() else 'cpu')
    print(f"Device: {device}")
    
    # Data transforms
    train_transform = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.RandomVerticalFlip(),
        transforms.RandomRotation(10),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                           std=[0.229, 0.224, 0.225])
    ])
    
    val_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                           std=[0.229, 0.224, 0.225])
    ])
    
    # Load dataset
    full_dataset = VerifierDataset(dataset_dir, transform=train_transform)
    
    # Split train/val (80/20)
    train_size = int(0.8 * len(full_dataset))
    val_size = len(full_dataset) - train_size
    train_dataset, val_dataset = torch.utils.data.random_split(
        full_dataset, [train_size, val_size],
        generator=torch.Generator().manual_seed(42)
    )
    
    # Update val dataset transform
    val_dataset.dataset.transform = val_transform
    
    # Create dataloaders
    train_loader = DataLoader(
        train_dataset, 
        batch_size=batch_size, 
        shuffle=True, 
        num_workers=4,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset, 
        batch_size=batch_size, 
        shuffle=False, 
        num_workers=4,
        pin_memory=True
    )
    
    print(f"\nDataset split:")
    print(f"  Train: {train_size} samples")
    print(f"  Val: {val_size} samples")
    
    # Create model
    model = VerifierCNN(num_classes=3, pretrained=True)
    model = model.to(device)
    
    # Compute class weights for balanced loss
    labels = [s['label'] for s in full_dataset.samples]
    class_counts = np.bincount(labels)
    class_weights = 1.0 / class_counts
    class_weights = class_weights / class_weights.sum() * len(class_weights)
    class_weights = torch.FloatTensor(class_weights).to(device)
    
    print(f"\nClass weights (for balanced loss):")
    for i, w in enumerate(class_weights):
        class_name = ['background', 'chip', 'check'][i]
        print(f"  {class_name}: {w:.3f}")
    
    # Loss and optimizer
    criterion = nn.CrossEntropyLoss(weight=class_weights)
    optimizer = optim.Adam(model.parameters(), lr=lr)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=5, verbose=True
    )
    
    # Training loop
    best_val_loss = float('inf')
    best_model_path = None
    
    print(f"\nStarting training...")
    print(f"  Epochs: {epochs}")
    print(f"  Batch size: {batch_size}")
    print(f"  Learning rate: {lr}\n")
    
    for epoch in range(epochs):
        # Train
        model.train()
        train_loss = 0.0
        train_correct = 0
        train_total = 0
        
        pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{epochs} [Train]")
        for images, labels in pbar:
            images = images.to(device)
            labels = labels.to(device)
            
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
            _, predicted = outputs.max(1)
            train_total += labels.size(0)
            train_correct += predicted.eq(labels).sum().item()
            
            pbar.set_postfix({
                'loss': f'{loss.item():.4f}',
                'acc': f'{100.*train_correct/train_total:.2f}%'
            })
        
        train_loss /= len(train_loader)
        train_acc = 100. * train_correct / train_total
        
        # Validate
        model.eval()
        val_loss = 0.0
        val_correct = 0
        val_total = 0
        
        with torch.no_grad():
            pbar = tqdm(val_loader, desc=f"Epoch {epoch+1}/{epochs} [Val]")
            for images, labels in pbar:
                images = images.to(device)
                labels = labels.to(device)
                
                outputs = model(images)
                loss = criterion(outputs, labels)
                
                val_loss += loss.item()
                _, predicted = outputs.max(1)
                val_total += labels.size(0)
                val_correct += predicted.eq(labels).sum().item()
                
                pbar.set_postfix({
                    'loss': f'{loss.item():.4f}',
                    'acc': f'{100.*val_correct/val_total:.2f}%'
                })
        
        val_loss /= len(val_loader)
        val_acc = 100. * val_correct / val_total
        
        # Print epoch summary
        print(f"\nEpoch {epoch+1}/{epochs}:")
        print(f"  Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%")
        print(f"  Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.2f}%")
        
        # Learning rate scheduling
        scheduler.step(val_loss)
        
        # Save best model
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            model_dir = Path(output_dir) / f'{image_type}_verifier'
            model_dir.mkdir(parents=True, exist_ok=True)
            best_model_path = model_dir / 'best_verifier.pth'
            
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_loss': val_loss,
                'val_acc': val_acc,
            }, best_model_path)
            
            print(f"  ✓ Best model saved: {best_model_path}")
        
        print()
    
    print(f"\n{'='*70}")
    print(f"✓ VERIFIER TRAINING COMPLETE")
    print(f"{'='*70}")
    print(f"Best model: {best_model_path}")
    print(f"Best val loss: {best_val_loss:.4f}")
    print(f"{'='*70}\n")
    
    return str(best_model_path)


def main():
    parser = argparse.ArgumentParser(description='Step 3: Train Verifier CNN')
    parser.add_argument('--dataset_dir', type=str, required=True,
                       help='Path to verifier dataset directory')
    parser.add_argument('--image_type', type=str, required=True,
                       choices=['EV', 'BV', 'TV'],
                       help='Image type')
    parser.add_argument('--output_dir', type=str, default='./results',
                       help='Output directory')
    parser.add_argument('--epochs', type=int, default=50,
                       help='Training epochs (default: 50)')
    parser.add_argument('--batch_size', type=int, default=32,
                       help='Batch size (default: 32)')
    parser.add_argument('--lr', type=float, default=0.001,
                       help='Learning rate (default: 0.001)')
    parser.add_argument('--device', type=str, default='cuda',
                       choices=['cuda', 'cpu'],
                       help='Device (default: cuda)')
    
    args = parser.parse_args()
    
    verifier_path = train_verifier(
        dataset_dir=args.dataset_dir,
        output_dir=args.output_dir,
        image_type=args.image_type,
        epochs=args.epochs,
        batch_size=args.batch_size,
        lr=args.lr,
        device=args.device
    )
    
    print("\n" + "="*70)
    print("STEP 3 COMPLETE!")
    print("="*70)
    print(f"Verifier model: {verifier_path}")
    print(f"\nNext: Run step4_export_composite_onnx.py")
    print("="*70 + "\n")


if __name__ == '__main__':
    main()
