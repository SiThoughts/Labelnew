"""
STEP 2: Generate Verifier Dataset

Runs trained YOLO detector on all images and creates a dataset of crops for the verifier:
- Positive samples: YOLO detections that match ground truth (IoU >= 0.5)
- Negative samples: YOLO false positives + all detections from defect-free images

Output: Verifier dataset (crops + labels)
"""

import os
import sys
import argparse
import yaml
from pathlib import Path
import torch
from ultralytics import YOLO
import xml.etree.ElementTree as ET
from tqdm import tqdm
import numpy as np
from PIL import Image
import cv2
import json


def load_voc_annotations(xml_path):
    """
    Load Pascal VOC annotations
    
    Returns:
        List of (class_name, xmin, ymin, xmax, ymax)
    """
    tree = ET.parse(xml_path)
    root = tree.getroot()
    
    annotations = []
    for obj in root.findall('object'):
        class_name = obj.find('name').text.lower()
        bbox = obj.find('bndbox')
        xmin = float(bbox.find('xmin').text)
        ymin = float(bbox.find('ymin').text)
        xmax = float(bbox.find('xmax').text)
        ymax = float(bbox.find('ymax').text)
        annotations.append((class_name, xmin, ymin, xmax, ymax))
    
    return annotations


def compute_iou(box1, box2):
    """
    Compute IoU between two boxes
    box format: (xmin, ymin, xmax, ymax)
    """
    x1_min, y1_min, x1_max, y1_max = box1
    x2_min, y2_min, x2_max, y2_max = box2
    
    # Intersection
    inter_xmin = max(x1_min, x2_min)
    inter_ymin = max(y1_min, y2_min)
    inter_xmax = min(x1_max, x2_max)
    inter_ymax = min(y1_max, y2_max)
    
    if inter_xmax < inter_xmin or inter_ymax < inter_ymin:
        return 0.0
    
    inter_area = (inter_xmax - inter_xmin) * (inter_ymax - inter_ymin)
    
    # Union
    box1_area = (x1_max - x1_min) * (y1_max - y1_min)
    box2_area = (x2_max - x2_min) * (y2_max - y2_min)
    union_area = box1_area + box2_area - inter_area
    
    return inter_area / union_area if union_area > 0 else 0.0


def extract_crop(image, box, crop_size=128, padding=0.1):
    """
    Extract crop from image with padding
    
    Args:
        image: PIL Image or numpy array
        box: (xmin, ymin, xmax, ymax)
        crop_size: Output size (square)
        padding: Padding ratio (0.1 = 10% on each side)
    
    Returns:
        Cropped and resized image (crop_size x crop_size)
    """
    if isinstance(image, Image.Image):
        image = np.array(image)
    
    h, w = image.shape[:2]
    xmin, ymin, xmax, ymax = box
    
    # Add padding
    box_w = xmax - xmin
    box_h = ymax - ymin
    pad_w = box_w * padding
    pad_h = box_h * padding
    
    xmin = max(0, xmin - pad_w)
    ymin = max(0, ymin - pad_h)
    xmax = min(w, xmax + pad_w)
    ymax = min(h, ymax + pad_h)
    
    # Crop
    crop = image[int(ymin):int(ymax), int(xmin):int(xmax)]
    
    if crop.size == 0:
        # Fallback: create blank image
        crop = np.zeros((crop_size, crop_size, 3), dtype=np.uint8)
    else:
        # Resize
        crop = cv2.resize(crop, (crop_size, crop_size))
    
    return crop


def generate_verifier_dataset(detector_path, data_dir, image_type, output_dir,
                               conf_thresh=0.001, iou_thresh=0.5, crop_size=128):
    """
    Generate verifier dataset from detector outputs
    
    Args:
        detector_path: Path to trained YOLO detector (.pt)
        data_dir: Path to d-Photomask-merlin directory
        image_type: 'EV', 'BV', or 'TV'
        output_dir: Where to save verifier dataset
        conf_thresh: YOLO confidence threshold (low for recall)
        iou_thresh: IoU threshold for positive matching
        crop_size: Size of extracted crops
    
    Returns:
        Path to verifier dataset directory
    """
    
    print(f"\n{'='*70}")
    print(f"GENERATING VERIFIER DATASET - {image_type}")
    print(f"{'='*70}\n")
    
    # Load detector
    print(f"Loading detector: {detector_path}")
    model = YOLO(detector_path)
    
    # Class mapping
    class_map = {'chip': 0, 'check': 1}
    class_names = ['chip', 'check']
    
    # Create output directories
    ver_dir = Path(output_dir) / 'verifier_dataset' / image_type
    crops_dir = ver_dir / 'crops'
    crops_dir.mkdir(parents=True, exist_ok=True)
    
    # Find all images
    img_exts = ['.png', '.jpg', '.bmp']
    all_files = []
    
    data_path = Path(data_dir)
    for folder in ['EV', 'BV', 'TV']:
        folder_path = data_path / folder
        if not folder_path.exists():
            continue
        
        for img_file in folder_path.iterdir():
            if img_file.suffix.lower() not in img_exts:
                continue
            
            if image_type.upper() not in img_file.name.upper():
                continue
            
            xml_file = img_file.with_suffix('.xml')
            if xml_file.exists():
                all_files.append((img_file, xml_file))
    
    print(f"Found {len(all_files)} {image_type} images")
    
    # Process all images
    dataset = []
    positive_count = 0
    negative_count = 0
    defect_free_count = 0
    
    print(f"\nRunning detector and extracting crops...")
    print(f"  Conf threshold: {conf_thresh}")
    print(f"  IoU threshold: {iou_thresh}")
    print(f"  Crop size: {crop_size}x{crop_size}\n")
    
    for img_path, xml_path in tqdm(all_files):
        # Load image
        image = Image.open(img_path).convert('RGB')
        img_array = np.array(image)
        
        # Load ground truth
        gt_annotations = load_voc_annotations(xml_path)
        is_defect_free = len(gt_annotations) == 0
        
        if is_defect_free:
            defect_free_count += 1
        
        # Run detector
        results = model.predict(
            img_array,
            conf=conf_thresh,
            iou=0.7,
            max_det=300,
            verbose=False
        )
        
        if len(results) == 0 or results[0].boxes is None:
            continue
        
        boxes = results[0].boxes
        
        # Process each detection
        for i in range(len(boxes)):
            box_xyxy = boxes.xyxy[i].cpu().numpy()
            box_conf = boxes.conf[i].cpu().item()
            box_cls = int(boxes.cls[i].cpu().item())
            
            xmin, ymin, xmax, ymax = box_xyxy
            pred_class = class_names[box_cls]
            
            # Extract crop
            crop = extract_crop(img_array, (xmin, ymin, xmax, ymax), crop_size)
            
            # Determine label
            if is_defect_free:
                # All detections from defect-free images are negatives
                label = 0  # background
                is_positive = False
            else:
                # Match with ground truth
                best_iou = 0.0
                best_gt_class = None
                
                for gt_class, gt_xmin, gt_ymin, gt_xmax, gt_ymax in gt_annotations:
                    iou = compute_iou((xmin, ymin, xmax, ymax), 
                                     (gt_xmin, gt_ymin, gt_xmax, gt_ymax))
                    
                    if iou > best_iou and gt_class == pred_class:
                        best_iou = iou
                        best_gt_class = gt_class
                
                if best_iou >= iou_thresh:
                    # True positive
                    label = class_map[best_gt_class] + 1  # 1=chip, 2=check
                    is_positive = True
                else:
                    # False positive
                    label = 0  # background
                    is_positive = False
            
            # Save crop
            crop_filename = f"{img_path.stem}_{i}_label{label}.png"
            crop_path = crops_dir / crop_filename
            cv2.imwrite(str(crop_path), cv2.cvtColor(crop, cv2.COLOR_RGB2BGR))
            
            # Add to dataset
            dataset.append({
                'crop_path': str(crop_path.relative_to(ver_dir)),
                'label': label,
                'class_name': class_names[label-1] if label > 0 else 'background',
                'confidence': float(box_conf),
                'source_image': img_path.name,
                'is_defect_free_source': is_defect_free
            })
            
            if is_positive:
                positive_count += 1
            else:
                negative_count += 1
    
    # Save dataset metadata
    metadata = {
        'image_type': image_type,
        'crop_size': crop_size,
        'total_crops': len(dataset),
        'positive_samples': positive_count,
        'negative_samples': negative_count,
        'defect_free_images': defect_free_count,
        'conf_thresh': conf_thresh,
        'iou_thresh': iou_thresh,
        'class_names': ['background', 'chip', 'check']
    }
    
    metadata_path = ver_dir / 'metadata.json'
    with open(metadata_path, 'w') as f:
        json.dump(metadata, f, indent=2)
    
    # Save dataset list
    dataset_path = ver_dir / 'dataset.json'
    with open(dataset_path, 'w') as f:
        json.dump(dataset, f, indent=2)
    
    print(f"\n{'='*70}")
    print(f"✓ VERIFIER DATASET GENERATED")
    print(f"{'='*70}")
    print(f"Total crops: {len(dataset)}")
    print(f"  Positive (chip/check): {positive_count}")
    print(f"  Negative (background): {negative_count}")
    print(f"  From defect-free images: {defect_free_count}")
    print(f"\nDataset saved to: {ver_dir}")
    print(f"  Crops: {crops_dir}")
    print(f"  Metadata: {metadata_path}")
    print(f"  Dataset list: {dataset_path}")
    print(f"{'='*70}\n")
    
    return str(ver_dir)


def main():
    parser = argparse.ArgumentParser(description='Step 2: Generate Verifier Dataset')
    parser.add_argument('--detector_path', type=str, required=True,
                       help='Path to trained YOLO detector (.pt)')
    parser.add_argument('--data_dir', type=str, required=True,
                       help='Path to d-Photomask-merlin directory')
    parser.add_argument('--image_type', type=str, required=True,
                       choices=['EV', 'BV', 'TV'],
                       help='Image type')
    parser.add_argument('--output_dir', type=str, default='./results',
                       help='Output directory')
    parser.add_argument('--conf_thresh', type=float, default=0.001,
                       help='YOLO confidence threshold (default: 0.001)')
    parser.add_argument('--iou_thresh', type=float, default=0.5,
                       help='IoU threshold for positive matching (default: 0.5)')
    parser.add_argument('--crop_size', type=int, default=128,
                       help='Crop size (default: 128)')
    
    args = parser.parse_args()
    
    verifier_dataset_dir = generate_verifier_dataset(
        detector_path=args.detector_path,
        data_dir=args.data_dir,
        image_type=args.image_type,
        output_dir=args.output_dir,
        conf_thresh=args.conf_thresh,
        iou_thresh=args.iou_thresh,
        crop_size=args.crop_size
    )
    
    print("\n" + "="*70)
    print("STEP 2 COMPLETE!")
    print("="*70)
    print(f"Verifier dataset: {verifier_dataset_dir}")
    print(f"\nNext: Run step3_train_verifier.py")
    print("="*70 + "\n")


if __name__ == '__main__':
    main()
