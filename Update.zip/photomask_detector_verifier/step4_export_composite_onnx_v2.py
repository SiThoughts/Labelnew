"""
STEP 4: Export Composite ONNX (ONNX-SAFE VERSION)

This version uses ONLY ONNX-compatible operations:
- torchvision.ops.nms (ONNX-compatible)
- torchvision.ops.roi_align (ONNX-compatible)
- Standard tensor operations

NO Ultralytics-specific functions that might not export!

Fuses YOLO detector + Verifier CNN into a single ONNX file:
1. YOLO raw output → decode boxes
2. Apply confidence threshold
3. NMS using torchvision.ops.nms (ONNX-safe!)
4. ROIAlign extracts crops (ONNX-safe!)
5. Verifier classifies each crop
6. Fusion: filter and rescore
7. Output: boxes, labels, scores

FIXES:
- Correct ROIAlign usage
- Custom YOLO decoding (no Ultralytics dependencies)
- ONNX-safe NMS using torchvision.ops.nms
"""

import os
import sys
import argparse
from pathlib import Path
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.ops as ops
from ultralytics import YOLO
import numpy as np
from PIL import Image
import onnx
import onnxruntime as ort


# Import verifier model
sys.path.append(str(Path(__file__).parent))
from step3_train_verifier import VerifierCNN


def decode_yolo_output(pred, conf_thresh=0.001):
    """
    Decode YOLO raw output to boxes
    
    Args:
        pred: YOLO raw output [1, num_anchors, 4+nc]
              where 4 = (x_center, y_center, width, height) normalized
              nc = number of classes
    
    Returns:
        boxes: [N, 4] (x1, y1, x2, y2) in pixel coordinates
        scores: [N] confidence scores
        labels: [N] class IDs
    """
    
    # pred shape: [1, num_anchors, 4+nc]
    # For 2 classes (chip, check): [1, num_anchors, 6]
    
    batch_size = pred.shape[0]
    assert batch_size == 1, "Only batch_size=1 supported"
    
    pred = pred[0]  # [num_anchors, 4+nc]
    
    # Split into box coords and class scores
    box_xywh = pred[:, :4]  # [num_anchors, 4] (x_center, y_center, w, h)
    class_scores = pred[:, 4:]  # [num_anchors, nc]
    
    # Get best class for each anchor
    class_conf, class_id = class_scores.max(dim=1)  # [num_anchors]
    
    # Apply confidence threshold
    mask = class_conf > conf_thresh
    
    if mask.sum() == 0:
        # No detections
        empty = torch.zeros((0, 4), dtype=pred.dtype, device=pred.device)
        empty_scores = torch.zeros((0,), dtype=pred.dtype, device=pred.device)
        empty_labels = torch.zeros((0,), dtype=torch.int64, device=pred.device)
        return empty, empty_scores, empty_labels
    
    # Filter by confidence
    box_xywh = box_xywh[mask]  # [N, 4]
    scores = class_conf[mask]  # [N]
    labels = class_id[mask]  # [N]
    
    # Convert xywh to xyxy
    # Note: YOLO outputs are typically normalized [0, 1]
    # We need to convert to pixel coordinates
    # This requires knowing the image size, which we'll handle in the forward pass
    
    return box_xywh, scores, labels


class DetectorVerifierComposite(nn.Module):
    """
    Composite model: YOLO Detector + Verifier CNN (ONNX-SAFE VERSION)
    
    Uses ONLY ONNX-compatible operations
    """
    
    def __init__(self, detector_path, verifier_path, 
                 crop_size=128, conf_thresh=0.001, iou_thresh=0.7,
                 ver_thresh=0.01, max_det=300):
        super().__init__()
        
        # Load detector (YOLO model only, no wrapper)
        print(f"Loading detector: {detector_path}")
        yolo = YOLO(detector_path)
        self.detector = yolo.model.eval()
        
        # Load verifier
        print(f"Loading verifier: {verifier_path}")
        checkpoint = torch.load(verifier_path, map_location='cpu')
        self.verifier = VerifierCNN(num_classes=3, pretrained=False)
        self.verifier.load_state_dict(checkpoint['model_state_dict'])
        self.verifier.eval()
        
        # Freeze both models
        for param in self.detector.parameters():
            param.requires_grad = False
        for param in self.verifier.parameters():
            param.requires_grad = False
        
        # Parameters
        self.crop_size = crop_size
        self.conf_thresh = conf_thresh
        self.iou_thresh = iou_thresh
        self.ver_thresh = ver_thresh
        self.max_det = max_det
        
        # Normalization for verifier (ImageNet stats)
        self.register_buffer('norm_mean', torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer('norm_std', torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))
    
    def forward(self, x):
        """
        Forward pass with ONNX-safe operations
        
        Args:
            x: [1, 3, H, W] input image (RGB, [0, 1] normalized)
        
        Returns:
            boxes: [N, 4] (x1, y1, x2, y2)
            labels: [N] (class IDs: 1=chip, 2=check)
            scores: [N] (confidence scores)
        """
        
        batch_size, _, img_h, img_w = x.shape
        
        # 1. Run YOLO detector
        preds = self.detector(x)
        
        # Handle different YOLO output formats
        if isinstance(preds, (list, tuple)):
            preds = preds[0]
        
        # Expected format: [1, num_anchors, 4+nc]
        # For YOLOv8 with 2 classes: [1, num_anchors, 6]
        
        # If output is [1, 6, num_anchors], transpose
        if preds.dim() == 3 and preds.shape[1] < preds.shape[2]:
            preds = preds.permute(0, 2, 1)  # [1, num_anchors, 6]
        
        # Decode YOLO output
        # preds: [1, num_anchors, 4+nc]
        box_xywh = preds[0, :, :4]  # [num_anchors, 4] (x_center, y_center, w, h) normalized
        class_scores = preds[0, :, 4:]  # [num_anchors, nc]
        
        # Get best class and confidence
        class_conf, class_id = class_scores.max(dim=1)  # [num_anchors]
        
        # Apply confidence threshold
        mask = class_conf > self.conf_thresh
        
        if mask.sum() == 0:
            # No detections
            empty_boxes = torch.zeros((0, 4), dtype=torch.float32, device=x.device)
            empty_labels = torch.zeros((0,), dtype=torch.int64, device=x.device)
            empty_scores = torch.zeros((0,), dtype=torch.float32, device=x.device)
            return empty_boxes, empty_labels, empty_scores
        
        # Filter by confidence
        box_xywh_filtered = box_xywh[mask]  # [M, 4]
        scores_filtered = class_conf[mask]  # [M]
        labels_filtered = class_id[mask]  # [M]
        
        # Convert normalized xywh to pixel xyxy
        x_center = box_xywh_filtered[:, 0] * img_w
        y_center = box_xywh_filtered[:, 1] * img_h
        width = box_xywh_filtered[:, 2] * img_w
        height = box_xywh_filtered[:, 3] * img_h
        
        x1 = x_center - width / 2
        y1 = y_center - height / 2
        x2 = x_center + width / 2
        y2 = y_center + height / 2
        
        boxes_xyxy = torch.stack([x1, y1, x2, y2], dim=1)  # [M, 4]
        
        # Clamp to image bounds
        boxes_xyxy[:, 0::2] = boxes_xyxy[:, 0::2].clamp(0, img_w)
        boxes_xyxy[:, 1::2] = boxes_xyxy[:, 1::2].clamp(0, img_h)
        
        # 2. Apply NMS per class (ONNX-safe!)
        # We need to do NMS separately for each class
        keep_indices = []
        
        for class_idx in range(class_scores.shape[1]):
            # Get boxes for this class
            class_mask = labels_filtered == class_idx
            if class_mask.sum() == 0:
                continue
            
            class_boxes = boxes_xyxy[class_mask]
            class_scores_val = scores_filtered[class_mask]
            
            # Apply NMS using torchvision.ops.nms (ONNX-compatible!)
            keep = ops.nms(class_boxes, class_scores_val, self.iou_thresh)
            
            # Convert local indices to global indices
            global_indices = torch.where(class_mask)[0][keep]
            keep_indices.append(global_indices)
        
        if len(keep_indices) == 0:
            # No detections after NMS
            empty_boxes = torch.zeros((0, 4), dtype=torch.float32, device=x.device)
            empty_labels = torch.zeros((0,), dtype=torch.int64, device=x.device)
            empty_scores = torch.zeros((0,), dtype=torch.float32, device=x.device)
            return empty_boxes, empty_labels, empty_scores
        
        # Combine all kept indices
        keep_all = torch.cat(keep_indices)
        
        # Limit to max_det
        if keep_all.shape[0] > self.max_det:
            # Sort by score and keep top max_det
            _, top_indices = scores_filtered[keep_all].topk(self.max_det)
            keep_all = keep_all[top_indices]
        
        # Apply NMS filtering
        boxes_nms = boxes_xyxy[keep_all]
        scores_nms = scores_filtered[keep_all]
        labels_nms = labels_filtered[keep_all]
        
        # 3. Extract crops using ROIAlign (FIXED!)
        num_boxes = boxes_nms.shape[0]
        
        # ROIAlign expects boxes in format [batch_idx, x1, y1, x2, y2]
        batch_indices = torch.zeros((num_boxes, 1), dtype=boxes_nms.dtype, device=boxes_nms.device)
        boxes_with_batch = torch.cat([batch_indices, boxes_nms], dim=1)  # [N, 5]
        
        # FIXED: Pass boxes_with_batch directly
        crops = ops.roi_align(
            x,  # [1, 3, H, W]
            boxes_with_batch,  # [N, 5] - CORRECT!
            output_size=(self.crop_size, self.crop_size),
            spatial_scale=1.0,
            sampling_ratio=2
        )  # [N, 3, crop_size, crop_size]
        
        # 4. Normalize crops for verifier
        crops_normalized = (crops - self.norm_mean) / self.norm_std
        
        # 5. Run verifier
        verifier_logits = self.verifier(crops_normalized)  # [N, 3]
        verifier_probs = F.softmax(verifier_logits, dim=1)  # [N, 3]
        
        # Get verifier predictions
        ver_scores, ver_classes = verifier_probs.max(dim=1)  # [N]
        
        # 6. Fusion: Filter out background
        valid_mask = ver_classes > 0  # Keep chip (1) and check (2)
        
        if valid_mask.sum() == 0:
            # All filtered by verifier
            empty_boxes = torch.zeros((0, 4), dtype=torch.float32, device=x.device)
            empty_labels = torch.zeros((0,), dtype=torch.int64, device=x.device)
            empty_scores = torch.zeros((0,), dtype=torch.float32, device=x.device)
            return empty_boxes, empty_labels, empty_scores
        
        # Final outputs
        final_boxes = boxes_nms[valid_mask]
        final_labels = ver_classes[valid_mask]
        final_scores = scores_nms[valid_mask] * ver_scores[valid_mask]
        
        # Apply verifier threshold
        if self.ver_thresh > 0:
            score_mask = final_scores > self.ver_thresh
            final_boxes = final_boxes[score_mask]
            final_labels = final_labels[score_mask]
            final_scores = final_scores[score_mask]
        
        return final_boxes, final_labels, final_scores


def export_composite_onnx(detector_path, verifier_path, output_path, 
                          image_size=(1024, 500), crop_size=128,
                          conf_thresh=0.001, iou_thresh=0.7, 
                          ver_thresh=0.01, max_det=300):
    """
    Export composite model to ONNX (ONNX-safe version)
    
    Args:
        detector_path: Path to YOLO detector (.pt)
        verifier_path: Path to verifier (.pth)
        output_path: Where to save ONNX
        image_size: (width, height) for ONNX input
        crop_size: Crop size for verifier
        conf_thresh: Detector confidence threshold
        iou_thresh: NMS IoU threshold
        ver_thresh: Verifier threshold
        max_det: Max detections
    
    Returns:
        Path to exported ONNX
    """
    
    print(f"\n{'='*70}")
    print(f"EXPORTING COMPOSITE ONNX (ONNX-SAFE VERSION)")
    print(f"{'='*70}\n")
    
    # Create composite model
    composite = DetectorVerifierComposite(
        detector_path=detector_path,
        verifier_path=verifier_path,
        crop_size=crop_size,
        conf_thresh=conf_thresh,
        iou_thresh=iou_thresh,
        ver_thresh=ver_thresh,
        max_det=max_det
    )
    
    composite.eval()
    composite.cpu()
    
    # Create dummy input
    img_w, img_h = image_size
    dummy_input = torch.randn(1, 3, img_h, img_w, dtype=torch.float32)
    
    print(f"Model configuration:")
    print(f"  Input size: {img_w}x{img_h}")
    print(f"  Crop size: {crop_size}x{crop_size}")
    print(f"  Detector conf threshold: {conf_thresh}")
    print(f"  NMS IoU threshold: {iou_thresh}")
    print(f"  Max detections: {max_det}")
    print(f"  Verifier threshold: {ver_thresh}")
    
    # Test forward pass
    print(f"\nTesting forward pass...")
    with torch.no_grad():
        boxes, labels, scores = composite(dummy_input)
    
    print(f"  Output shapes:")
    print(f"    boxes: {boxes.shape}")
    print(f"    labels: {labels.shape}")
    print(f"    scores: {scores.shape}")
    
    # Export to ONNX
    print(f"\nExporting to ONNX: {output_path}")
    
    try:
        torch.onnx.export(
            composite,
            dummy_input,
            output_path,
            input_names=['input'],
            output_names=['boxes', 'labels', 'scores'],
            dynamic_axes={
                'boxes': {0: 'num_boxes'},
                'labels': {0: 'num_boxes'},
                'scores': {0: 'num_boxes'}
            },
            opset_version=11,
            do_constant_folding=True,
            verbose=False
        )
        
        print(f"✓ ONNX export complete: {output_path}")
    
    except Exception as e:
        print(f"✗ ONNX export failed: {e}")
        import traceback
        traceback.print_exc()
        raise
    
    # Validate ONNX
    print(f"\nValidating ONNX...")
    try:
        onnx_model = onnx.load(output_path)
        onnx.checker.check_model(onnx_model)
        print(f"✓ ONNX model is valid")
    except Exception as e:
        print(f"✗ ONNX validation failed: {e}")
        raise
    
    # Smoke test with ONNX Runtime
    print(f"\nSmoke test with ONNX Runtime...")
    try:
        sess = ort.InferenceSession(output_path, providers=['CPUExecutionProvider'])
        
        # Test input
        test_img = np.random.rand(1, 3, img_h, img_w).astype(np.float32)
        outputs = sess.run(['boxes', 'labels', 'scores'], {'input': test_img})
        
        print(f"✓ ONNX Runtime test passed")
        print(f"  boxes: {outputs[0].shape}")
        print(f"  labels: {outputs[1].shape}")
        print(f"  scores: {outputs[2].shape}")
    
    except Exception as e:
        print(f"✗ ONNX Runtime test failed: {e}")
        raise
    
    # Get file size
    file_size_mb = Path(output_path).stat().st_size / (1024 * 1024)
    print(f"\nONNX file size: {file_size_mb:.2f} MB")
    
    print(f"\n{'='*70}")
    print(f"✓ COMPOSITE ONNX EXPORT COMPLETE")
    print(f"{'='*70}")
    print(f"Output: {output_path}")
    print(f"Size: {file_size_mb:.2f} MB")
    print(f"Interface:")
    print(f"  Input: 'input' [{1}, {3}, {img_h}, {img_w}]")
    print(f"  Outputs:")
    print(f"    'boxes': [N, 4] (x1, y1, x2, y2)")
    print(f"    'labels': [N] (1=chip, 2=check)")
    print(f"    'scores': [N] (confidence)")
    print(f"\nONNX-SAFE OPERATIONS USED:")
    print(f"  ✓ torchvision.ops.nms (ONNX-compatible)")
    print(f"  ✓ torchvision.ops.roi_align (ONNX-compatible)")
    print(f"  ✓ Standard tensor operations only")
    print(f"  ✓ No Ultralytics-specific functions")
    print(f"{'='*70}\n")
    
    return output_path


def main():
    parser = argparse.ArgumentParser(description='Step 4: Export Composite ONNX (ONNX-Safe)')
    parser.add_argument('--detector_path', type=str, required=True,
                       help='Path to YOLO detector (.pt)')
    parser.add_argument('--verifier_path', type=str, required=True,
                       help='Path to verifier (.pth)')
    parser.add_argument('--output_path', type=str, required=True,
                       help='Output ONNX path')
    parser.add_argument('--image_type', type=str, required=True,
                       choices=['EV', 'BV', 'TV'],
                       help='Image type (determines size)')
    parser.add_argument('--conf_thresh', type=float, default=0.001,
                       help='Detector confidence threshold (default: 0.001)')
    parser.add_argument('--iou_thresh', type=float, default=0.7,
                       help='NMS IoU threshold (default: 0.7)')
    parser.add_argument('--ver_thresh', type=float, default=0.01,
                       help='Verifier threshold (default: 0.01)')
    parser.add_argument('--max_det', type=int, default=300,
                       help='Max detections (default: 300)')
    parser.add_argument('--crop_size', type=int, default=128,
                       help='Crop size (default: 128)')
    
    args = parser.parse_args()
    
    # Determine image size
    if args.image_type.upper() == 'EV':
        image_size = (2048, 1460)  # width, height
    else:  # BV/TV
        image_size = (1024, 500)
    
    onnx_path = export_composite_onnx(
        detector_path=args.detector_path,
        verifier_path=args.verifier_path,
        output_path=args.output_path,
        image_size=image_size,
        crop_size=args.crop_size,
        conf_thresh=args.conf_thresh,
        iou_thresh=args.iou_thresh,
        ver_thresh=args.ver_thresh,
        max_det=args.max_det
    )
    
    print("\n" + "="*70)
    print("STEP 4 COMPLETE!")
    print("="*70)
    print(f"Composite ONNX: {onnx_path}")
    print(f"\nYour model is ready for deployment!")
    print(f"\nONNX-safe implementation:")
    print(f"  ✓ ROIAlign usage corrected")
    print(f"  ✓ Custom YOLO decoding (no Ultralytics dependencies)")
    print(f"  ✓ NMS using torchvision.ops.nms (ONNX-compatible)")
    print("="*70 + "\n")


if __name__ == '__main__':
    main()
