"""
ONE-CLICK TRAINING: Complete Detector + Verifier Pipeline

Runs all 4 steps automatically:
1. Train YOLO detector (high recall)
2. Generate verifier dataset from detector outputs
3. Train verifier CNN
4. Export composite ONNX

Usage:
    python train_all.py --data_dir /path/to/d-Photomask-merlin --image_type EV

Output: Single ONNX file with detector + verifier fused
"""

import os
import sys
import argparse
import subprocess
from pathlib import Path
import time


def run_step(step_name, command, description):
    """Run a training step"""
    
    print("\n" + "="*70)
    print(f"STEP: {step_name}")
    print("="*70)
    print(f"Description: {description}")
    print(f"Command: {' '.join(command)}")
    print("="*70 + "\n")
    
    start_time = time.time()
    
    try:
        result = subprocess.run(command, check=True)
        elapsed = time.time() - start_time
        
        print(f"\n✓ {step_name} completed in {elapsed/60:.1f} minutes\n")
        return True, elapsed
    
    except subprocess.CalledProcessError as e:
        elapsed = time.time() - start_time
        print(f"\n✗ {step_name} failed after {elapsed/60:.1f} minutes")
        print(f"Error: {e}\n")
        return False, elapsed


def train_complete_pipeline(data_dir, image_type, output_dir='./results',
                            detector_epochs=100, verifier_epochs=50,
                            batch_detector=16, batch_verifier=32,
                            device=0, conf_export=0.001, ver_thresh=0.01):
    """
    Run complete training pipeline
    
    Args:
        data_dir: Path to d-Photomask-merlin
        image_type: 'EV', 'BV', or 'TV'
        output_dir: Output directory
        detector_epochs: Epochs for detector training
        verifier_epochs: Epochs for verifier training
        batch_detector: Batch size for detector
        batch_verifier: Batch size for verifier
        device: CUDA device
        conf_export: Confidence threshold for ONNX export
        ver_thresh: Verifier threshold for ONNX export
    
    Returns:
        Path to final ONNX file
    """
    
    print("\n" + "#"*70)
    print(f"# COMPLETE TRAINING PIPELINE - {image_type}")
    print("#"*70)
    print(f"Data: {data_dir}")
    print(f"Output: {output_dir}")
    print(f"Detector epochs: {detector_epochs}")
    print(f"Verifier epochs: {verifier_epochs}")
    print("#"*70 + "\n")
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Track timing
    timings = {}
    
    # Step 1: Train detector
    step1_cmd = [
        sys.executable,
        'step1_train_detector.py',
        '--data_dir', data_dir,
        '--image_type', image_type,
        '--output_dir', output_dir,
        '--epochs', str(detector_epochs),
        '--batch', str(batch_detector),
        '--device', str(device)
    ]
    
    success, elapsed = run_step(
        "Step 1: Train Detector",
        step1_cmd,
        "Train YOLO detector optimized for high recall"
    )
    
    if not success:
        print("Pipeline failed at Step 1")
        return None
    
    timings['detector'] = elapsed
    
    # Find detector path
    detector_path = Path(output_dir) / f'{image_type}_detector' / 'weights' / 'best.pt'
    if not detector_path.exists():
        print(f"Error: Detector not found at {detector_path}")
        return None
    
    # Step 2: Generate verifier dataset
    step2_cmd = [
        sys.executable,
        'step2_generate_verifier_data.py',
        '--detector_path', str(detector_path),
        '--data_dir', data_dir,
        '--image_type', image_type,
        '--output_dir', output_dir,
        '--conf_thresh', str(conf_export)
    ]
    
    success, elapsed = run_step(
        "Step 2: Generate Verifier Dataset",
        step2_cmd,
        "Run detector on all images and create verifier training data"
    )
    
    if not success:
        print("Pipeline failed at Step 2")
        return None
    
    timings['verifier_data'] = elapsed
    
    # Find verifier dataset path
    verifier_dataset_dir = Path(output_dir) / 'verifier_dataset' / image_type
    if not verifier_dataset_dir.exists():
        print(f"Error: Verifier dataset not found at {verifier_dataset_dir}")
        return None
    
    # Step 3: Train verifier
    step3_cmd = [
        sys.executable,
        'step3_train_verifier.py',
        '--dataset_dir', str(verifier_dataset_dir),
        '--image_type', image_type,
        '--output_dir', output_dir,
        '--epochs', str(verifier_epochs),
        '--batch_size', str(batch_verifier),
        '--device', 'cuda' if device >= 0 else 'cpu'
    ]
    
    success, elapsed = run_step(
        "Step 3: Train Verifier",
        step3_cmd,
        "Train CNN classifier to verify detector outputs"
    )
    
    if not success:
        print("Pipeline failed at Step 3")
        return None
    
    timings['verifier'] = elapsed
    
    # Find verifier path
    verifier_path = Path(output_dir) / f'{image_type}_verifier' / 'best_verifier.pth'
    if not verifier_path.exists():
        print(f"Error: Verifier not found at {verifier_path}")
        return None
    
    # Step 4: Export composite ONNX
    onnx_output = Path(output_dir) / f'{image_type}_composite.onnx'
    
    step4_cmd = [
        sys.executable,
        'step4_export_composite_onnx_v2.py',  # Use ONNX-safe version
        '--detector_path', str(detector_path),
        '--verifier_path', str(verifier_path),
        '--output_path', str(onnx_output),
        '--image_type', image_type,
        '--conf_thresh', str(conf_export),
        '--ver_thresh', str(ver_thresh)
    ]
    
    success, elapsed = run_step(
        "Step 4: Export Composite ONNX",
        step4_cmd,
        "Fuse detector + verifier into single ONNX file"
    )
    
    if not success:
        print("Pipeline failed at Step 4")
        return None
    
    timings['export'] = elapsed
    
    # Summary
    total_time = sum(timings.values())
    
    print("\n" + "="*70)
    print("PIPELINE COMPLETE!")
    print("="*70)
    print(f"\nTiming breakdown:")
    print(f"  Detector training: {timings['detector']/60:.1f} minutes")
    print(f"  Verifier data generation: {timings['verifier_data']/60:.1f} minutes")
    print(f"  Verifier training: {timings['verifier']/60:.1f} minutes")
    print(f"  ONNX export: {timings['export']/60:.1f} minutes")
    print(f"  TOTAL: {total_time/60:.1f} minutes ({total_time/3600:.2f} hours)")
    
    print(f"\nOutput files:")
    print(f"  Detector: {detector_path}")
    print(f"  Verifier: {verifier_path}")
    print(f"  ONNX: {onnx_output}")
    
    print(f"\nFinal ONNX model: {onnx_output}")
    print(f"  Size: {onnx_output.stat().st_size / (1024*1024):.2f} MB")
    print(f"  Interface:")
    if image_type.upper() == 'EV':
        print(f"    Input: 'input' [1, 3, 1460, 2048]")
    else:
        print(f"    Input: 'input' [1, 3, 500, 1024]")
    print(f"    Outputs:")
    print(f"      'boxes': [N, 4] (x1, y1, x2, y2)")
    print(f"      'labels': [N] (1=chip, 2=check)")
    print(f"      'scores': [N] (confidence)")
    
    print("\n" + "="*70)
    print("✓ READY FOR DEPLOYMENT!")
    print("="*70 + "\n")
    
    return str(onnx_output)


def main():
    parser = argparse.ArgumentParser(
        description='One-Click Training: Complete Detector + Verifier Pipeline'
    )
    
    parser.add_argument('--data_dir', type=str, required=True,
                       help='Path to d-Photomask-merlin directory')
    parser.add_argument('--image_type', type=str, required=True,
                       choices=['EV', 'BV', 'TV'],
                       help='Image type to train on')
    parser.add_argument('--output_dir', type=str, default='./results',
                       help='Output directory (default: ./results)')
    
    # Detector options
    parser.add_argument('--detector_epochs', type=int, default=100,
                       help='Detector training epochs (default: 100)')
    parser.add_argument('--batch_detector', type=int, default=16,
                       help='Detector batch size (default: 16)')
    
    # Verifier options
    parser.add_argument('--verifier_epochs', type=int, default=50,
                       help='Verifier training epochs (default: 50)')
    parser.add_argument('--batch_verifier', type=int, default=32,
                       help='Verifier batch size (default: 32)')
    
    # Export options
    parser.add_argument('--conf_export', type=float, default=0.001,
                       help='Detector confidence threshold for export (default: 0.001)')
    parser.add_argument('--ver_thresh', type=float, default=0.01,
                       help='Verifier threshold for export (default: 0.01)')
    
    # Hardware
    parser.add_argument('--device', type=int, default=0,
                       help='CUDA device (default: 0)')
    
    args = parser.parse_args()
    
    onnx_path = train_complete_pipeline(
        data_dir=args.data_dir,
        image_type=args.image_type,
        output_dir=args.output_dir,
        detector_epochs=args.detector_epochs,
        verifier_epochs=args.verifier_epochs,
        batch_detector=args.batch_detector,
        batch_verifier=args.batch_verifier,
        device=args.device,
        conf_export=args.conf_export,
        ver_thresh=args.ver_thresh
    )
    
    if onnx_path:
        print(f"\n✓ Success! Your ONNX model is ready: {onnx_path}\n")
    else:
        print(f"\n✗ Pipeline failed. Check logs above for details.\n")
        sys.exit(1)


if __name__ == '__main__':
    main()
