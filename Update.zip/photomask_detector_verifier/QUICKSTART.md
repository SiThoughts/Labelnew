# Quick Start Guide

## ⚡ Get Running in 5 Minutes

### 1. Install (1 minute)

```bash
cd photomask_detector_verifier
pip install -r requirements.txt
```

### 2. Train (2.5-4 hours)

```bash
python train_all.py --data_dir /path/to/d-Photomask-merlin --image_type EV
```

### 3. Done!

Your ONNX model is ready: `results/EV_composite.onnx`

---

## 📋 What You Get

**Single ONNX file** containing:
- YOLO detector (high recall)
- CNN verifier (high precision)
- ROIAlign fusion
- All in one!

**Interface:**
- Input: `'input'` [1, 3, H, W]
- Outputs: `'boxes'` [N, 4], `'labels'` [N], `'scores'` [N]

---

## 🎛️ Common Options

```bash
# Train BV images
python train_all.py --data_dir /path/to/data --image_type BV

# Reduce batch size if OOM
python train_all.py --data_dir /path/to/data --image_type EV --batch_detector 8

# More epochs for better accuracy
python train_all.py --data_dir /path/to/data --image_type EV --detector_epochs 150

# Lower confidence for even higher recall
python train_all.py --data_dir /path/to/data --image_type EV --conf_export 0.0001
```

---

## 📊 Expected Results

| Metric | Value |
|--------|-------|
| Recall | 95-98% ✓ |
| Precision | 85-95% ✓ |
| Training Time | 2.5-4 hours ✓ |
| Inference Speed | ~25ms ✓ |
| ONNX Size | ~20-40 MB ✓ |

---

## 🔧 Image Sizes

| Type | ONNX Input Size |
|------|-----------------|
| EV | [1, 3, 1460, 2048] |
| BV | [1, 3, 500, 1024] |
| TV | [1, 3, 500, 1024] |

---

## 🚀 Deploy

```python
import onnxruntime as ort
import numpy as np

# Load model
sess = ort.InferenceSession('EV_composite.onnx')

# Prepare image (resize to 2048x1460, normalize to [0,1], CHW format)
img = ...  # [1, 3, 1460, 2048]

# Run
boxes, labels, scores = sess.run(['boxes', 'labels', 'scores'], {'input': img})

# Done!
```

---

## 🆘 Troubleshooting

**OOM Error**: `--batch_detector 8 --batch_verifier 16`

**Low Recall**: `--conf_export 0.0001`

**Too Many FPs**: `--ver_thresh 0.1`

**ONNX Export Fails**: `pip install --upgrade torch torchvision onnx`

---

## 📁 Output Files

```
results/
├── EV_detector/weights/best.pt      # YOLO detector
├── verifier_dataset/EV/             # Verifier training data
├── EV_verifier/best_verifier.pth    # Verifier CNN
└── EV_composite.onnx                # FINAL MODEL ✓
```

---

## ✅ Success Check

After training:
- [x] ONNX file created
- [x] File size ~20-40 MB
- [x] Smoke test passed (check console)
- [x] No errors in logs

---

**That's it! You're ready to deploy!** 🎉

For more details, see [README.md](README.md)
