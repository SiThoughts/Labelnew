"""
STEP 1: Train YOLO Detector (High Recall)

Trains YOLOv8 detector optimized for maximum recall
- Low confidence threshold (0.001)
- High classification loss weight
- Aggressive augmentation
- Handles defect-free images

Output: Trained YOLO model (.pt file)
"""

import os
import sys
import argparse
import yaml
import shutil
import glob
from pathlib import Path
import torch
from ultralytics import YOLO
import xml.etree.ElementTree as ET
from tqdm import tqdm
import numpy as np
from PIL import Image


def create_yolo_dataset(data_dir, image_type, output_dir):
    """
    Convert Pascal VOC to YOLO format
    
    Args:
        data_dir: Path to d-Photomask-merlin directory
        image_type: 'EV', 'BV', or 'TV'
        output_dir: Where to create YOLO dataset
    
    Returns:
        Path to dataset.yaml
    """
    
    print(f"\n{'='*70}")
    print(f"CREATING YOLO DATASET - {image_type}")
    print(f"{'='*70}\n")
    
    # Create YOLO dataset structure
    yolo_dir = Path(output_dir) / 'yolo_dataset' / image_type
    train_img_dir = yolo_dir / 'images' / 'train'
    val_img_dir = yolo_dir / 'images' / 'val'
    train_lbl_dir = yolo_dir / 'labels' / 'train'
    val_lbl_dir = yolo_dir / 'labels' / 'val'
    
    for d in [train_img_dir, val_img_dir, train_lbl_dir, val_lbl_dir]:
        d.mkdir(parents=True, exist_ok=True)
    
    # Find all images
    img_exts = ['.png', '.jpg', '.bmp']
    all_files = []
    
    data_path = Path(data_dir)
    for folder in ['EV', 'BV', 'TV']:
        folder_path = data_path / folder
        if not folder_path.exists():
            continue
        
        for img_file in folder_path.iterdir():
            if img_file.suffix.lower() not in img_exts:
                continue
            
            # Check if this is the right image type
            if image_type.upper() not in img_file.name.upper():
                continue
            
            xml_file = img_file.with_suffix('.xml')
            if xml_file.exists():
                all_files.append((img_file, xml_file))
    
    if len(all_files) == 0:
        raise ValueError(f"No {image_type} images found in {data_dir}")
    
    print(f"Found {len(all_files)} {image_type} images")
    
    # Split train/val (80/20)
    np.random.seed(42)
    np.random.shuffle(all_files)
    split_idx = int(len(all_files) * 0.8)
    train_files = all_files[:split_idx]
    val_files = all_files[split_idx:]
    
    # Class mapping
    class_map = {'chip': 0, 'check': 1}
    
    def convert_voc_to_yolo(xml_path, img_width, img_height):
        """Convert Pascal VOC bbox to YOLO format"""
        tree = ET.parse(xml_path)
        root = tree.getroot()
        
        labels = []
        for obj in root.findall('object'):
            class_name = obj.find('name').text.lower()
            if class_name not in class_map:
                continue
            
            class_id = class_map[class_name]
            bbox = obj.find('bndbox')
            xmin = float(bbox.find('xmin').text)
            ymin = float(bbox.find('ymin').text)
            xmax = float(bbox.find('xmax').text)
            ymax = float(bbox.find('ymax').text)
            
            # Convert to YOLO format (x_center, y_center, width, height) normalized
            x_center = ((xmin + xmax) / 2) / img_width
            y_center = ((ymin + ymax) / 2) / img_height
            width = (xmax - xmin) / img_width
            height = (ymax - ymin) / img_height
            
            labels.append(f"{class_id} {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}")
        
        return labels
    
    # Process training files
    print("Converting training data...")
    defect_free_count = 0
    for img_path, xml_path in tqdm(train_files):
        # Copy image
        shutil.copy(img_path, train_img_dir / img_path.name)
        
        # Convert and save labels
        img = Image.open(img_path)
        labels = convert_voc_to_yolo(xml_path, img.width, img.height)
        
        if len(labels) == 0:
            defect_free_count += 1
        
        # Save YOLO label file (even if empty for defect-free images)
        label_file = train_lbl_dir / f"{img_path.stem}.txt"
        with open(label_file, 'w') as f:
            f.write('\n'.join(labels))
    
    print(f"  Defect-free images: {defect_free_count} (used as negatives)")
    
    # Process validation files
    print("Converting validation data...")
    for img_path, xml_path in tqdm(val_files):
        shutil.copy(img_path, val_img_dir / img_path.name)
        
        img = Image.open(img_path)
        labels = convert_voc_to_yolo(xml_path, img.width, img.height)
        
        label_file = val_lbl_dir / f"{img_path.stem}.txt"
        with open(label_file, 'w') as f:
            f.write('\n'.join(labels))
    
    # Create dataset.yaml
    dataset_yaml = {
        'path': str(yolo_dir.absolute()),
        'train': 'images/train',
        'val': 'images/val',
        'nc': 2,
        'names': ['chip', 'check']
    }
    
    yaml_path = yolo_dir / 'dataset.yaml'
    with open(yaml_path, 'w') as f:
        yaml.dump(dataset_yaml, f)
    
    print(f"\n✓ Dataset created: {yaml_path}")
    print(f"  Train: {len(train_files)} images ({defect_free_count} defect-free)")
    print(f"  Val: {len(val_files)} images")
    
    return str(yaml_path)


def train_yolo_detector(data_yaml, output_dir, image_type, epochs=100, 
                        imgsz=(512, 1024), batch=16, device=0):
    """
    Train YOLO detector with high-recall optimization
    
    Args:
        data_yaml: Path to dataset.yaml
        output_dir: Where to save model
        image_type: 'EV', 'BV', or 'TV'
        epochs: Training epochs
        imgsz: (height, width) for training
        batch: Batch size
        device: CUDA device
    
    Returns:
        Path to best.pt model
    """
    
    print(f"\n{'='*70}")
    print(f"TRAINING YOLO DETECTOR - {image_type}")
    print(f"OPTIMIZED FOR MAXIMUM RECALL")
    print(f"{'='*70}\n")
    
    # Load base model
    model = YOLO('yolov8s.pt')
    
    # Training arguments optimized for RECALL
    train_args = {
        'data': data_yaml,
        'epochs': epochs,
        'imgsz': list(imgsz),  # [height, width]
        'batch': batch,
        'device': device,
        'project': output_dir,
        'name': f'{image_type}_detector',
        'exist_ok': True,
        
        # Optimizer
        'optimizer': 'AdamW',
        'lr0': 0.001,
        'lrf': 0.01,
        'momentum': 0.937,
        'weight_decay': 0.0005,
        
        # Augmentation (aggressive for robustness)
        'hsv_h': 0.015,
        'hsv_s': 0.7,
        'hsv_v': 0.4,
        'degrees': 10.0,
        'translate': 0.1,
        'scale': 0.5,
        'flipud': 0.5,
        'fliplr': 0.5,
        'mosaic': 1.0,
        'mixup': 0.1,
        'copy_paste': 0.1,  # Important for defects!
        
        # Loss weights (HIGH for recall)
        'box': 7.5,
        'cls': 5.0,  # HIGH classification weight
        'dfl': 1.5,
        
        # Detection settings (LOW threshold for recall)
        'conf': 0.001,  # VERY LOW - catch everything
        'iou': 0.7,     # Relaxed NMS
        'max_det': 300, # Allow many detections
        
        # Training
        'patience': 50,
        'save': True,
        'cache': False,
        'workers': 8,
        'verbose': True,
    }
    
    print(f"Configuration:")
    print(f"  Epochs: {epochs}")
    print(f"  Image size: {imgsz[1]}x{imgsz[0]}")
    print(f"  Batch: {batch}")
    print(f"  Conf threshold: {train_args['conf']} (VERY LOW for recall)")
    print(f"  Cls loss weight: {train_args['cls']} (HIGH for recall)")
    print(f"  Max detections: {train_args['max_det']}")
    print(f"\nStarting training...\n")
    
    # Train
    results = model.train(**train_args)
    
    # Get best model
    best_pt = Path(output_dir) / f'{image_type}_detector' / 'weights' / 'best.pt'
    
    if not best_pt.exists():
        # Fallback search
        maybe = glob.glob(os.path.join(output_dir, f'{image_type}_detector', "**", "best.pt"), recursive=True)
        best_pt = Path(maybe[0]) if maybe else None
    
    if not best_pt or not best_pt.exists():
        raise FileNotFoundError("Could not locate best.pt after training")
    
    print(f"\n{'='*70}")
    print(f"✓ DETECTOR TRAINING COMPLETE")
    print(f"{'='*70}")
    print(f"Model: {best_pt}")
    print(f"{'='*70}\n")
    
    return str(best_pt)


def main():
    parser = argparse.ArgumentParser(description='Step 1: Train YOLO Detector')
    parser.add_argument('--data_dir', type=str, required=True,
                       help='Path to d-Photomask-merlin directory')
    parser.add_argument('--image_type', type=str, required=True,
                       choices=['EV', 'BV', 'TV'],
                       help='Image type to train on')
    parser.add_argument('--output_dir', type=str, default='./results',
                       help='Output directory')
    parser.add_argument('--epochs', type=int, default=100,
                       help='Training epochs (default: 100)')
    parser.add_argument('--batch', type=int, default=16,
                       help='Batch size (default: 16)')
    parser.add_argument('--device', type=int, default=0,
                       help='CUDA device')
    
    args = parser.parse_args()
    
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Determine training image size (maintains aspect ratio)
    if args.image_type.upper() == 'EV':
        train_size = (896, 1280)  # height, width
    else:  # BV/TV
        train_size = (512, 1024)
    
    # Step 1: Create dataset
    print("\n" + "="*70)
    print("STEP 1A: DATASET PREPARATION")
    print("="*70)
    data_yaml = create_yolo_dataset(args.data_dir, args.image_type, args.output_dir)
    
    # Step 2: Train detector
    print("\n" + "="*70)
    print("STEP 1B: TRAIN DETECTOR")
    print("="*70)
    detector_path = train_yolo_detector(
        data_yaml=data_yaml,
        output_dir=args.output_dir,
        image_type=args.image_type,
        epochs=args.epochs,
        imgsz=train_size,
        batch=args.batch,
        device=args.device
    )
    
    print("\n" + "="*70)
    print("STEP 1 COMPLETE!")
    print("="*70)
    print(f"Detector model: {detector_path}")
    print(f"\nNext: Run step2_generate_verifier_data.py")
    print("="*70 + "\n")


if __name__ == '__main__':
    main()
