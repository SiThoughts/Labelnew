# DemoMCF PLC Sender - Portable Version

**ZERO SYSTEM INTERACTION - COMPLETELY STANDALONE**

This portable executable reads tag values from `demomcf.txt` and sends them to your PLC when triggered. No installation, no dependencies, no system modifications required.

## What It Does

1. **Reads** the `demomcf.txt` file containing tag:value pairs
2. **Parses** tags like `C1_X: -3.031`, `C1_Y: 2.595`, etc.
3. **Sends** these values to your PLC at 192.168.1.10 when triggered
4. **Handles** dynamic tag additions/removals automatically

## System Requirements

- **Linux x86_64** (Ubuntu 20.04.4 LTS ✓)
- **GLIBC 2.17+** (Your system has 2.31 ✓)
- **Network access** to PLC
- **NO other requirements** - completely self-contained

## Usage Options

### 1. Run Once (Send values immediately)
```bash
./demomcf_plc_sender --once
```

### 2. Interactive Mode (Manual trigger)
```bash
./demomcf_plc_sender
# Press Enter to send values, 'q' to quit
```

### 3. Auto Monitor (Send when file changes)
```bash
./demomcf_plc_sender --monitor
```

### 4. Custom File Path
```bash
./demomcf_plc_sender --file /path/to/your/demomcf.txt
```

### 5. Custom PLC IP
```bash
./demomcf_plc_sender --ip 192.168.1.20
```

## Default Paths

- **DemoMCF file**: `/home/lcvs/.lcvs/halcon_scripts/demomcf.txt`
- **PLC IP**: `192.168.1.10`

## DemoMCF File Format

The application expects this format (same as your current file):
```
C1_X: -3.031
C1_Y: 2.595
C1_ID: 3.779
C2_X: 2.792
C2_Y: 2.101
C2_ID: 3.753
C3_X: 2.287
C3_Y: -2.653
C3_ID: 3.646
C4_X: -2.518
C4_Y: -2.227
C4_ID: 3.753
H1_Y: 5.958
S_00: 14.833
```

## Features

✅ **Zero System Interaction** - No files modified outside this folder  
✅ **No Dependencies** - Everything bundled inside  
✅ **No Installation** - Just extract and run  
✅ **Dynamic Tags** - Handles tag additions/removals automatically  
✅ **Multiple Modes** - Once, interactive, or auto-monitor  
✅ **Error Handling** - Clear status messages  
✅ **Compatible** - Works on your Ubuntu 20.04.4 LTS  

## Example Output

```
DemoMCF PLC Sender v1.0 - Completely Portable
==================================================
NO SYSTEM DEPENDENCIES - FULLY SELF-CONTAINED
==================================================
DemoMCF PLC Sender initialized
PLC IP: 192.168.1.10
DemoMCF file path: /home/lcvs/.lcvs/halcon_scripts/demomcf.txt

=== DemoMCF PLC Sender - Single Run ===
✓ Connected to PLC at 192.168.1.10
✓ Read 14 tags from demomcf.txt

Sending 14 tags to PLC...
--------------------------------------------------
✓ C1_X: -3.031
✓ C1_Y: 2.595
✓ C1_ID: 3.779
✓ C2_X: 2.792
✓ C2_Y: 2.101
✓ C2_ID: 3.753
✓ C3_X: 2.287
✓ C3_Y: -2.653
✓ C3_ID: 3.646
✓ C4_X: -2.518
✓ C4_Y: -2.227
✓ C4_ID: 3.753
✓ H1_Y: 5.958
✓ S_00: 14.833
--------------------------------------------------
Results: 14 successful, 0 errors
✓ PLC connection closed
```

## Troubleshooting

### File Not Found
- Check that `/home/lcvs/.lcvs/halcon_scripts/demomcf.txt` exists
- Or use `--file` option to specify different path

### PLC Connection Issues
- Verify PLC IP address is correct
- Check network connectivity: `ping 192.168.1.10`
- Ensure PLC is powered on and accessible
- Use `--ip` option for different PLC address

### Permission Issues
```bash
chmod +x demomcf_plc_sender
```

## Files Included

- `demomcf_plc_sender` - Main executable (6MB)
- `sample_demomcf.txt` - Example file format
- `README.md` - This documentation

## Safety

- **No system files modified**
- **No packages installed**
- **No root access required**
- **Delete folder to completely remove**

## Version

DemoMCF PLC Sender v1.0 - Completely Portable  
Built specifically for your demomcf.txt → PLC workflow  
Compatible with Ubuntu 20.04.4 LTS and newer

