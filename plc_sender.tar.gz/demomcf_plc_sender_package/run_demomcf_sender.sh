#!/bin/bash
# DemoMCF PLC Sender Launcher
# Ensures compatibility and provides helpful information

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "DemoMCF PLC Sender - Portable Launcher"
echo "======================================"

# Check GLIBC version compatibility
GLIBC_VERSION=$(ldd --version 2>&1 | head -n1 | grep -o '[0-9]\+\.[0-9]\+' | head -n1)
if [ -n "$GLIBC_VERSION" ]; then
    echo "✓ GLIBC version: $GLIBC_VERSION"
    if [ "$(printf '%s\n' "2.17" "$GLIBC_VERSION" | sort -V | head -n1)" != "2.17" ]; then
        echo "⚠ Warning: GLIBC version may be too old (need 2.17+)"
    fi
else
    echo "⚠ Could not detect GLIBC version"
fi

echo "✓ Working directory: $SCRIPT_DIR"
echo "✓ Executable: demomcf_plc_sender"
echo ""

# Run the executable with all passed arguments
exec "$SCRIPT_DIR/demomcf_plc_sender" "$@"

