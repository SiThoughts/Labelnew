import onnxruntime as ort, numpy as np, cv2, sys
onnx_path = "model.onnx"
img_path  = sys.argv[1] if len(sys.argv)>1 else None
assert img_path, "Usage: python infer_onnx.py <path_to_image_2048x1460>"

img = cv2.imread(img_path)
assert img is not None, f"Failed to read {img_path}"
h,w = img.shape[:2]
assert (w,h)==(2048,1460), f"Image must be exactly 2048x1460, got {(w,h)}"

blob = img[:,:,::-1].transpose(2,0,1)[None].astype(np.float32)/255.0
sess = ort.InferenceSession(onnx_path, providers=['CUDAExecutionProvider','CPUExecutionProvider'])
out = sess.run(None, {"images": blob})
for i,o in enumerate(out):
    arr = np.array(o)
    print(f"out[{i}] shape:", arr.shape, "dtype:", arr.dtype)
print("Inference OK")

