from ultralytics import YOLO
m = YOLO("models/yolov8s-p2.yaml")  # our file
print("model.stride:", m.model.stride)  # expects tensor([4., 8., 16., 32.])
s = list(map(int, m.model.stride.tolist()))
assert 4 in s, f"P2 (stride-4) missing! strides={s}"
print("OK: P2 present (stride-4 head enabled).")

