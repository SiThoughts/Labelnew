import os, glob
root = r"D:\Photomask\yolo\EV_dataset"
req = [
    ("images/train", True), ("images/val", True),
    ("labels/train", True), ("labels/val", True),
]
for sub, must in req:
    p = os.path.join(root, sub)
    assert os.path.isdir(p), f"Missing dir: {p}"

def pairs(img_dir, lbl_dir):
    imgs = sorted(glob.glob(os.path.join(img_dir, "*.*")))
    miss = []
    for im in imgs:
        stem = os.path.splitext(os.path.basename(im))[0]
        lbl = os.path.join(lbl_dir, stem + ".txt")
        if not os.path.isfile(lbl): miss.append(stem)
    return imgs, miss

for split in ("train","val"):
    imgs, miss = pairs(os.path.join(root,"images",split),
                       os.path.join(root,"labels",split))
    assert imgs, f"No images in {split}"
    assert not miss, f"Unpaired images in {split}: {miss[:10]} (and more)"

# Label format & class ids
for split in ("train","val"):
    for f in glob.glob(os.path.join(root,"labels",split,"*.txt")):
        with open(f,"r") as fh:
            for ln in fh:
                pts = ln.strip().split()
                assert len(pts)==5, f"Bad line in {f}: {ln}"
                c = int(float(pts[0]))
                assert c in (0,1), f"class must be 0/1 in {f}: {ln}"
                x,y,w,h = map(float, pts[1:])
                for v in (x,y,w,h):
                    assert 0.0 <= v <= 1.0, f"norm coord out of range in {f}: {ln}"
print("DATASET CHECKS PASSED")

