# YOLOv8-P2 Training Package for 2048x1460 Images

This package contains everything needed to train a YOLOv8-P2 model with fixed input size 2048x1460 for detecting chip and check objects in photomask images.

## Hard Constraints (DO NOT CHANGE)

- **Exact input size**: [1,3,1460,2048] (NCHW format)
- **Single output**: model.onnx with NonMaxSuppression inside the graph
- **Dataset location**: D:/Photomask/yolo/EV_dataset
- **Classes**: 0=chip, 1=check (nc=2)
- **GPU memory**: ~11 GB (use batch=1, accumulate=2)

## Quick Start

1. **Setup Environment**
   ```cmd
   setup_environment.bat
   conda activate yv8p2
   ```

2. **Verify Dataset**
   ```cmd
   python check_dataset.py
   ```
   Must print: "DATASET CHECKS PASSED"

3. **Verify P2 Model**
   ```cmd
   python check_stride.py
   ```
   Must show stride-4 head enabled

4. **Train Model**
   ```cmd
   train.bat
   ```
   Creates: runs/detect/ev_yv8sP2_2048x1460/weights/best.pt

5. **Validate Model**
   ```cmd
   validate.bat
   ```

6. **Export to ONNX**
   ```cmd
   export.bat
   ```
   Creates: model.onnx

7. **Verify ONNX**
   ```cmd
   python verify_onnx.py
   ```
   Must print: "OK: model.onnx is fixed [1,3,1460,2048] and NMS is present."

8. **Test Inference**
   ```cmd
   python infer_onnx.py D:\Photomask\yolo\EV_dataset\images\val\ANY_FILE.png
   ```

## File Structure

```
yolov8_p2_training_package/
├── README.md                    # This file
├── ev_data.yaml                 # Dataset configuration
├── models/
│   └── yolov8s-p2.yaml         # YOLOv8-P2 model architecture
├── setup_environment.bat       # Environment setup
├── train.bat                   # Training script
├── validate.bat                # Validation script
├── export.bat                  # ONNX export script
├── check_dataset.py            # Dataset verification
├── check_stride.py             # P2 stride verification
├── verify_onnx.py              # ONNX verification
└── infer_onnx.py               # ONNX inference test
```

## Expected Dataset Structure

```
D:/Photomask/yolo/EV_dataset/
├── images/
│   ├── train/          # Training images
│   └── val/            # Validation images
└── labels/
    ├── train/          # Training labels (YOLO format)
    └── val/            # Validation labels (YOLO format)
```

## Why YOLOv8-P2?

- **P2 head (stride-4)**: Specifically designed for small/hairline object detection
- **Higher resolution features**: Preserves fine details at 1/4 scale
- **Official Ultralytics variant**: Based on documented yolov8-p2.yaml
- **Proven for tiny objects**: Used in production for small feature detection

## Training Parameters Explained

- `imgsz=2048,1460`: Fixed input size (DO NOT CHANGE)
- `batch=1`: Fits 11GB GPU memory
- `accumulate=2`: Effective batch size = 2
- `amp=True`: Automatic Mixed Precision for memory efficiency
- `rect=True`: Rectangular training for efficiency
- `cos_lr=True`: Cosine learning rate schedule
- `patience=50`: Early stopping patience

## Export Parameters Explained

- `format=onnx`: ONNX format for deployment
- `opset=12`: ONNX opset version
- `dynamic=False`: Fixed input shape
- `nms=True`: Include NonMaxSuppression in graph
- `simplify=False`: Keep all operations for compatibility

## Common Issues & Solutions

### 1. Wrong Input Shape in ONNX
**Problem**: Exported ONNX has input [1,3,1536,1536]
**Solution**: Re-export with correct imgsz:
```cmd
yolo export model=runs/detect/ev_yv8sP2_2048x1460/weights/best.pt format=onnx imgsz=2048,1460 dynamic=False nms=True
```

### 2. No NMS in ONNX Graph
**Problem**: NonMaxSuppression not found in graph
**Solution**: Re-export with nms=True:
```cmd
yolo export ... nms=True
```

### 3. P2 Head Missing
**Problem**: model.stride doesn't include 4
**Solution**: Check models/yolov8s-p2.yaml and retrain

### 4. CUDA Out of Memory
**Problem**: GPU OOM during training
**Solution**: Increase accumulate parameter:
```cmd
# In train.bat, change:
accumulate=4  # or 8
# Keep batch=1 and imgsz=2048,1460
```

### 5. Windows Path Issues
**Problem**: Path errors in YAML/CLI
**Solution**: Always use forward slashes:
```yaml
path: D:/Photomask/yolo/EV_dataset  # Correct
path: D:\Photomask\yolo\EV_dataset  # Wrong
```

## Verification Checklist

Before considering training complete, ensure:

- [ ] `python check_dataset.py` → "DATASET CHECKS PASSED"
- [ ] `python check_stride.py` → Shows stride-4 head
- [ ] Training completes without OOM errors
- [ ] `runs/detect/ev_yv8sP2_2048x1460/weights/best.pt` exists
- [ ] Validation runs without shape errors
- [ ] `model.onnx` is created
- [ ] `python verify_onnx.py` → "OK: model.onnx is fixed [1,3,1460,2048] and NMS is present."
- [ ] `python infer_onnx.py <test_image>` → Prints output shapes

## Performance Expectations

- **Training time**: ~2-8 hours (depends on dataset size)
- **Memory usage**: ~10GB GPU memory
- **Model size**: ~20-40MB (ONNX)
- **Inference speed**: ~50-200ms per image (GPU)

## Next Steps After Success

If this baseline works well, consider:

1. **Larger model**: Try yolov8m-p2.yaml (if GPU memory allows)
2. **P6 variant**: Add P6 head for even larger objects
3. **YOLOv9**: Switch to YOLOv9-C with P2 head
4. **Ensemble**: Combine multiple models

## Support

If you encounter issues not covered here:

1. Check CUDA/driver installation
2. Verify dataset paths and format
3. Ensure conda environment is activated
4. Check GPU memory usage
5. Review training logs for errors

## Technical Details

- **Framework**: Ultralytics YOLOv8
- **Model variant**: Small P2 (yolov8s-p2)
- **Detection heads**: P2, P3, P4, P5 (strides 4, 8, 16, 32)
- **Input format**: RGB, normalized [0,1]
- **Output format**: ONNX with in-graph NMS
- **Classes**: Binary (chip=0, check=1)

