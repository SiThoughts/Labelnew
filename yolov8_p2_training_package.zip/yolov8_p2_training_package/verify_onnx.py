import onnx
m = onnx.load("model.onnx")
g = m.graph
# Input
assert len(g.input)==1, f"Expected 1 input, got {len(g.input)}"
vi = g.input[0]
dims = [d.dim_value for d in vi.type.tensor_type.shape.dim]
assert dims == [1,3,1460,2048], f"Bad input shape: {dims}"
# NMS presence
ops = [n.op_type for n in g.node]
assert "NonMaxSuppression" in ops, "NonMaxSuppression not found in graph"
print("OK: model.onnx is fixed [1,3,1460,2048] and NMS is present.")

