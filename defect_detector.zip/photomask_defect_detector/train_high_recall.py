"""
Lightweight High-Recall Defect Detection Training Script
Optimized for photomask defect detection with maximum recall
"""

import os
import sys
import shutil
import math
import numpy as np
from tqdm import tqdm
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import torchvision
from torchvision.models.detection import FasterRCNN
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision.models.detection.rpn import AnchorGenerator, RPNHead
from torchvision.models.detection.roi_heads import RoIHeads
import torchvision.transforms as T
from PIL import Image
import xml.etree.ElementTree as ET
import json
import time
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')


class PhotomaskDataset(Dataset):
    """Dataset for photomask defect detection with Pascal VOC annotations"""
    
    def __init__(self, root_dir, transforms=None, image_type='EV'):
        self.root_dir = root_dir
        self.transforms = transforms
        self.image_type = image_type.upper()
        
        # Find all images matching the image type
        img_exts = ['.jpg', '.png', '.bmp']
        self.imgs = []
        self.annotations = []
        
        for f in os.listdir(root_dir):
            if any(f.lower().endswith(ext) for ext in img_exts):
                if self.image_type.lower() in f.lower():
                    img_path = os.path.join(root_dir, f)
                    xml_path = os.path.splitext(img_path)[0] + '.xml'
                    if os.path.exists(xml_path):
                        self.imgs.append(img_path)
                        self.annotations.append(xml_path)
        
        print(f"Found {len(self.imgs)} {self.image_type} images with annotations")
    
    def __len__(self):
        return len(self.imgs)
    
    def parse_voc_xml(self, xml_path):
        """Parse Pascal VOC XML annotation"""
        tree = ET.parse(xml_path)
        root = tree.getroot()
        
        boxes = []
        labels = []
        
        for obj in root.findall('object'):
            name = obj.find('name').text
            bbox = obj.find('bndbox')
            xmin = float(bbox.find('xmin').text)
            ymin = float(bbox.find('ymin').text)
            xmax = float(bbox.find('xmax').text)
            ymax = float(bbox.find('ymax').text)
            
            boxes.append([xmin, ymin, xmax, ymax])
            labels.append(1)  # All defects are class 1 (background is 0)
        
        return boxes, labels
    
    def __getitem__(self, idx):
        img_path = self.imgs[idx]
        xml_path = self.annotations[idx]
        
        # Load image
        img = Image.open(img_path).convert('RGB')
        
        # Parse annotations
        boxes, labels = self.parse_voc_xml(xml_path)
        
        boxes = torch.as_tensor(boxes, dtype=torch.float32)
        labels = torch.as_tensor(labels, dtype=torch.int64)
        
        target = {}
        target['boxes'] = boxes
        target['labels'] = labels
        target['image_id'] = torch.tensor([idx])
        target['area'] = (boxes[:, 3] - boxes[:, 1]) * (boxes[:, 2] - boxes[:, 0])
        target['iscrowd'] = torch.zeros((len(boxes),), dtype=torch.int64)
        
        if self.transforms:
            img = self.transforms(img)
        
        return img, target


def get_high_recall_model(num_classes, backbone_type='mobilenet'):
    """
    Create a lightweight model optimized for high recall
    Uses MobileNetV3 for speed and custom anchors for small defects
    """
    
    # Ultra-small anchors for tiny defects - KEY FOR RECALL
    anchor_sizes = ((8, 16, 32, 64, 128),)  # Added very small anchors
    aspect_ratios = ((0.5, 1.0, 2.0),) * len(anchor_sizes)
    anchor_generator = AnchorGenerator(sizes=anchor_sizes, aspect_ratios=aspect_ratios)
    
    if backbone_type == 'mobilenet':
        # Lightweight MobileNetV3 backbone for speed
        backbone = torchvision.models.mobilenet_v3_large(pretrained=True).features
        backbone.out_channels = 960
        
        # Custom RoI pooler
        roi_pooler = torchvision.ops.MultiScaleRoIAlign(
            featmap_names=['0'],
            output_size=7,
            sampling_ratio=2
        )
        
        # Create Faster R-CNN with custom settings for high recall
        model = FasterRCNN(
            backbone,
            num_classes=num_classes,
            rpn_anchor_generator=anchor_generator,
            box_roi_pool=roi_pooler,
            # HIGH RECALL SETTINGS
            rpn_pre_nms_top_n_train=3000,      # More proposals (default: 2000)
            rpn_post_nms_top_n_train=3000,     # Keep more proposals
            rpn_pre_nms_top_n_test=3000,
            rpn_post_nms_top_n_test=3000,
            rpn_nms_thresh=0.7,                 # Less aggressive NMS
            rpn_fg_iou_thresh=0.5,              # Lower threshold for positives
            rpn_bg_iou_thresh=0.3,              # More conservative background
            box_score_thresh=0.05,              # VERY LOW threshold for recall
            box_nms_thresh=0.3,                 # Keep overlapping boxes
            box_detections_per_img=300,         # More detections per image
        )
    
    elif backbone_type == 'resnet18':
        # Lightweight ResNet18 alternative
        from torchvision.models.detection.backbone_utils import resnet_fpn_backbone
        backbone = resnet_fpn_backbone('resnet18', pretrained=True)
        
        roi_pooler = torchvision.ops.MultiScaleRoIAlign(
            featmap_names=['0', '1', '2', '3'],
            output_size=7,
            sampling_ratio=2
        )
        
        model = FasterRCNN(
            backbone,
            num_classes=num_classes,
            rpn_anchor_generator=anchor_generator,
            box_roi_pool=roi_pooler,
            rpn_pre_nms_top_n_train=3000,
            rpn_post_nms_top_n_train=3000,
            rpn_pre_nms_top_n_test=3000,
            rpn_post_nms_top_n_test=3000,
            rpn_nms_thresh=0.7,
            rpn_fg_iou_thresh=0.5,
            rpn_bg_iou_thresh=0.3,
            box_score_thresh=0.05,
            box_nms_thresh=0.3,
            box_detections_per_img=300,
        )
    
    return model


def get_transforms(train=False):
    """Data augmentation for training"""
    transforms = []
    transforms.append(T.ToTensor())
    
    if train:
        # Augmentations to improve generalization and recall
        transforms.append(T.RandomHorizontalFlip(0.5))
        transforms.append(T.RandomVerticalFlip(0.5))
        # Color jitter for robustness
        transforms.append(T.ColorJitter(brightness=0.2, contrast=0.2))
    
    return T.Compose(transforms)


def collate_fn(batch):
    """Custom collate function for batching"""
    return tuple(zip(*batch))


def split_dataset(data_dir, image_type, split_ratio=0.8):
    """Split data into train and validation sets"""
    train_dir = os.path.join(data_dir, 'train')
    val_dir = os.path.join(data_dir, 'val')
    
    # Check if already split
    if os.path.exists(train_dir) and os.path.exists(val_dir):
        print("Dataset already split. Using existing split.")
        return train_dir, val_dir
    
    os.makedirs(train_dir, exist_ok=True)
    os.makedirs(val_dir, exist_ok=True)
    
    # Find all images
    img_exts = ['.jpg', '.png', '.bmp']
    all_files = []
    
    for folder in ['EV', 'BV', 'TV']:
        folder_path = os.path.join(data_dir, folder)
        if os.path.exists(folder_path):
            for f in os.listdir(folder_path):
                if any(f.lower().endswith(ext) for ext in img_exts):
                    if image_type.lower() in f.lower():
                        img_path = os.path.join(folder_path, f)
                        xml_path = os.path.splitext(img_path)[0] + '.xml'
                        if os.path.exists(xml_path):
                            all_files.append((img_path, xml_path))
    
    # Shuffle and split
    np.random.seed(42)
    np.random.shuffle(all_files)
    split_idx = int(len(all_files) * split_ratio)
    
    train_files = all_files[:split_idx]
    val_files = all_files[split_idx:]
    
    print(f"Splitting {len(all_files)} files: {len(train_files)} train, {len(val_files)} val")
    
    # Copy files
    for img_path, xml_path in tqdm(train_files, desc="Copying train files"):
        shutil.copy(img_path, train_dir)
        shutil.copy(xml_path, train_dir)
    
    for img_path, xml_path in tqdm(val_files, desc="Copying val files"):
        shutil.copy(img_path, val_dir)
        shutil.copy(xml_path, val_dir)
    
    return train_dir, val_dir


def train_one_epoch(model, optimizer, data_loader, device, epoch):
    """Train for one epoch"""
    model.train()
    
    # Warmup learning rate in first epoch
    lr_scheduler = None
    if epoch == 0:
        warmup_factor = 1.0 / 1000
        warmup_iters = min(1000, len(data_loader) - 1)
        lr_scheduler = torch.optim.lr_scheduler.LinearLR(
            optimizer, start_factor=warmup_factor, total_iters=warmup_iters
        )
    
    total_loss = 0
    loss_components = defaultdict(float)
    
    pbar = tqdm(data_loader, desc=f'Epoch {epoch}')
    for images, targets in pbar:
        images = [img.to(device) for img in images]
        targets = [{k: v.to(device) for k, v in t.items()} for t in targets]
        
        # Forward pass
        loss_dict = model(images, targets)
        losses = sum(loss for loss in loss_dict.values())
        
        # Check for NaN
        if not math.isfinite(losses.item()):
            print(f"Loss is {losses.item()}, stopping training")
            sys.exit(1)
        
        # Backward pass
        optimizer.zero_grad()
        losses.backward()
        optimizer.step()
        
        if lr_scheduler is not None:
            lr_scheduler.step()
        
        # Track losses
        total_loss += losses.item()
        for k, v in loss_dict.items():
            loss_components[k] += v.item()
        
        pbar.set_postfix({'loss': f'{losses.item():.4f}'})
    
    avg_loss = total_loss / len(data_loader)
    return avg_loss, loss_components


@torch.no_grad()
def evaluate(model, data_loader, device):
    """Evaluate model and compute recall/precision"""
    model.eval()
    
    all_predictions = []
    all_targets = []
    
    for images, targets in tqdm(data_loader, desc='Evaluating'):
        images = [img.to(device) for img in images]
        outputs = model(images)
        
        all_predictions.extend(outputs)
        all_targets.extend(targets)
    
    # Compute metrics at different thresholds
    thresholds = [0.05, 0.1, 0.2, 0.3, 0.5]
    metrics = {}
    
    for thresh in thresholds:
        tp, fp, fn = 0, 0, 0
        
        for pred, target in zip(all_predictions, all_targets):
            pred_boxes = pred['boxes'][pred['scores'] > thresh].cpu()
            target_boxes = target['boxes']
            
            if len(target_boxes) == 0:
                fp += len(pred_boxes)
                continue
            
            if len(pred_boxes) == 0:
                fn += len(target_boxes)
                continue
            
            # Compute IoU matrix
            ious = torchvision.ops.box_iou(pred_boxes, target_boxes)
            
            # Match predictions to targets
            matched_targets = set()
            for i in range(len(pred_boxes)):
                if ious[i].max() > 0.5:  # IoU threshold
                    matched_targets.add(ious[i].argmax().item())
                    tp += 1
                else:
                    fp += 1
            
            fn += len(target_boxes) - len(matched_targets)
        
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        
        metrics[f'thresh_{thresh}'] = {
            'recall': recall,
            'precision': precision,
            'f1': f1,
            'tp': tp,
            'fp': fp,
            'fn': fn
        }
    
    return metrics


def train_model(data_dir, image_type, output_dir, num_epochs=20, batch_size=4, 
                backbone='mobilenet', device_id=0):
    """Main training function"""
    
    print(f"\n{'='*60}")
    print(f"HIGH-RECALL DEFECT DETECTION TRAINING")
    print(f"{'='*60}")
    print(f"Image Type: {image_type}")
    print(f"Backbone: {backbone}")
    print(f"Epochs: {num_epochs}")
    print(f"Batch Size: {batch_size}")
    print(f"{'='*60}\n")
    
    # Setup device
    device = torch.device(f'cuda:{device_id}' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}\n")
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Split dataset
    train_dir, val_dir = split_dataset(data_dir, image_type)
    
    # Create datasets
    train_dataset = PhotomaskDataset(train_dir, get_transforms(train=True), image_type)
    val_dataset = PhotomaskDataset(val_dir, get_transforms(train=False), image_type)
    
    # Create data loaders
    train_loader = DataLoader(
        train_dataset, 
        batch_size=batch_size, 
        shuffle=True, 
        num_workers=4,
        collate_fn=collate_fn,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset, 
        batch_size=batch_size, 
        shuffle=False, 
        num_workers=4,
        collate_fn=collate_fn,
        pin_memory=True
    )
    
    # Create model
    model = get_high_recall_model(num_classes=2, backbone_type=backbone)
    model.to(device)
    
    # Optimizer with higher learning rate for faster training
    params = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.SGD(params, lr=0.01, momentum=0.9, weight_decay=0.0005)
    
    # Learning rate scheduler
    lr_scheduler = torch.optim.lr_scheduler.MultiStepLR(
        optimizer, milestones=[10, 15], gamma=0.1
    )
    
    # Training loop
    best_recall = 0
    best_f1 = 0
    training_history = []
    
    for epoch in range(num_epochs):
        # Train
        avg_loss, loss_components = train_one_epoch(
            model, optimizer, train_loader, device, epoch
        )
        
        # Evaluate
        metrics = evaluate(model, val_loader, device)
        
        # Update learning rate
        lr_scheduler.step()
        
        # Log results
        print(f"\nEpoch {epoch} Results:")
        print(f"  Average Loss: {avg_loss:.4f}")
        print(f"  Metrics at different thresholds:")
        for thresh_name, m in metrics.items():
            print(f"    {thresh_name}: Recall={m['recall']:.3f}, Precision={m['precision']:.3f}, F1={m['f1']:.3f}")
        
        # Save best model based on recall at threshold 0.05
        current_recall = metrics['thresh_0.05']['recall']
        current_f1 = metrics['thresh_0.05']['f1']
        
        if current_recall > best_recall:
            best_recall = current_recall
            torch.save(model.state_dict(), os.path.join(output_dir, 'best_recall_model.pt'))
            print(f"  ✓ New best recall: {best_recall:.3f}")
        
        if current_f1 > best_f1:
            best_f1 = current_f1
            torch.save(model.state_dict(), os.path.join(output_dir, 'best_f1_model.pt'))
            print(f"  ✓ New best F1: {best_f1:.3f}")
        
        # Save latest model
        torch.save(model.state_dict(), os.path.join(output_dir, 'latest_model.pt'))
        
        # Save training history
        training_history.append({
            'epoch': epoch,
            'loss': avg_loss,
            'metrics': metrics
        })
        
        with open(os.path.join(output_dir, 'training_history.json'), 'w') as f:
            json.dump(training_history, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"Training Complete!")
    print(f"Best Recall: {best_recall:.3f}")
    print(f"Best F1: {best_f1:.3f}")
    print(f"{'='*60}\n")
    
    return model


def export_to_onnx(model_path, output_path, image_size=(640, 640), backbone='mobilenet'):
    """Export trained model to ONNX format"""
    
    print(f"\nExporting model to ONNX...")
    
    # Load model
    device = torch.device('cpu')
    model = get_high_recall_model(num_classes=2, backbone_type=backbone)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.eval()
    
    # Create dummy input
    dummy_input = torch.randn(1, 3, image_size[1], image_size[0])
    
    # Export
    torch.onnx.export(
        model,
        dummy_input,
        output_path,
        export_params=True,
        opset_version=11,
        do_constant_folding=True,
        input_names=['input'],
        output_names=['boxes', 'labels', 'scores'],
        dynamic_axes={
            'input': {0: 'batch_size'},
            'boxes': {0: 'num_detections'},
            'labels': {0: 'num_detections'},
            'scores': {0: 'num_detections'}
        }
    )
    
    print(f"✓ Model exported to: {output_path}")


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Train high-recall defect detector')
    parser.add_argument('--data_dir', type=str, required=True, 
                       help='Path to d-Photomask-merlin directory')
    parser.add_argument('--image_type', type=str, required=True, choices=['EV', 'BV', 'TV'],
                       help='Image type to train on')
    parser.add_argument('--output_dir', type=str, default='./results',
                       help='Output directory for models and logs')
    parser.add_argument('--epochs', type=int, default=20,
                       help='Number of training epochs')
    parser.add_argument('--batch_size', type=int, default=4,
                       help='Batch size')
    parser.add_argument('--backbone', type=str, default='mobilenet', 
                       choices=['mobilenet', 'resnet18'],
                       help='Backbone architecture')
    parser.add_argument('--device', type=int, default=0,
                       help='CUDA device ID')
    parser.add_argument('--export_onnx', action='store_true',
                       help='Export to ONNX after training')
    
    args = parser.parse_args()
    
    # Train model
    model = train_model(
        data_dir=args.data_dir,
        image_type=args.image_type,
        output_dir=args.output_dir,
        num_epochs=args.epochs,
        batch_size=args.batch_size,
        backbone=args.backbone,
        device_id=args.device
    )
    
    # Export to ONNX if requested
    if args.export_onnx:
        export_to_onnx(
            model_path=os.path.join(args.output_dir, 'best_recall_model.pt'),
            output_path=os.path.join(args.output_dir, 'best_model.onnx'),
            backbone=args.backbone
        )
