# High-Recall Photomask Defect Detection

**Lightweight, extremely fast training classifier optimized for maximum recall**

This package provides a complete solution for detecting industrial defects on photomask images (EV, BV, TV types) with a focus on **maximizing recall** to ensure no defects are missed.

## 🎯 Key Features

### Maximum Recall Optimizations

1. **Ultra-small anchor boxes** (8, 16, 32px) for tiny defect detection
2. **Low confidence threshold** (0.05) to catch all possible defects
3. **Increased RPN proposals** (3000 per image) for comprehensive coverage
4. **Multi-scale detection** with Feature Pyramid Network
5. **Soft-NMS** to avoid suppressing nearby defects
6. **Test-time augmentation** for robust predictions
7. **Two-stage classification**: High recall detection → Precision refinement

### Speed & Efficiency

- **Lightweight MobileNetV3 backbone** for fast training and inference
- **Optimized data pipeline** with efficient augmentation
- **ONNX export** for deployment on any device
- **One-click training** for all image types

### Performance Targets

- **90% Recall** (primary goal - don't miss defects!)
- **90% Precision** (secondary - filter false positives in stage 2)

## 📦 Installation

```bash
# Install dependencies
pip install -r requirements.txt
```

**Requirements:**
- Python 3.7+
- PyTorch 1.10+
- CUDA-capable GPU (recommended)

## 🚀 Quick Start (One-Click Training)

Train models for all image types (EV, BV, TV) with a single command:

```bash
python train_all.py --data_dir /path/to/d-Photomask-merlin --epochs 20
```

This will:
1. Automatically split your data (80/20 train/val)
2. Train separate models for EV, BV, and TV images
3. Export each model to ONNX format
4. Save all results to `./trained_models/training_YYYYMMDD_HHMMSS/`

## 📖 Detailed Usage

### Training a Single Model

Train a model for one specific image type:

```bash
python train_high_recall.py \
    --data_dir /path/to/d-Photomask-merlin \
    --image_type EV \
    --output_dir ./results_ev \
    --epochs 20 \
    --batch_size 4 \
    --backbone mobilenet \
    --export_onnx
```

**Arguments:**
- `--data_dir`: Path to your `d-Photomask-merlin` directory containing EV/BV/TV folders
- `--image_type`: Image type to train on (`EV`, `BV`, or `TV`)
- `--output_dir`: Where to save models and logs
- `--epochs`: Number of training epochs (default: 20, ~2-3 hours on GPU)
- `--batch_size`: Batch size (default: 4, adjust based on GPU memory)
- `--backbone`: `mobilenet` (faster) or `resnet18` (more accurate)
- `--export_onnx`: Export to ONNX after training

### Training Output

After training, you'll find:

```
results_ev/
├── best_recall_model.pt      # Model with highest recall
├── best_f1_model.pt           # Model with best F1 score
├── latest_model.pt            # Latest checkpoint
├── best_model.onnx            # ONNX export (if --export_onnx)
├── training_history.json      # Metrics for each epoch
├── train/                     # Training data split
└── val/                       # Validation data split
```

### Inference (Two-Stage Detection)

Run inference with the trained model:

```bash
# Single image
python two_stage_inference.py \
    --model ./results_ev/best_model.onnx \
    --image /path/to/test_image.png \
    --output_dir ./inference_results

# Batch of images
python two_stage_inference.py \
    --model ./results_ev/best_model.onnx \
    --image_dir /path/to/test_images/ \
    --image_type EV \
    --output_dir ./inference_results
```

**Arguments:**
- `--model`: Path to trained model (.onnx or .pt)
- `--image`: Single image path
- `--image_dir`: Directory of images for batch processing
- `--image_type`: Filter images by type (EV/BV/TV)
- `--threshold`: Stage 1 confidence threshold (default: 0.05 for max recall)
- `--no_stage2`: Disable stage 2 refinement (use only stage 1)

### Understanding Two-Stage Detection

**Stage 1: High-Recall Detection**
- Uses very low threshold (0.05) to detect ALL possible defects
- Optimized to **never miss a real defect** (high recall)
- May include some false positives

**Stage 2: Precision Refinement**
- Filters false positives using heuristics:
  - Size filtering (removes noise and artifacts)
  - Texture analysis (real defects have specific patterns)
  - Edge detection (removes smooth false positives)
- Improves precision while maintaining high recall

## 📊 Dataset Structure

Your `d-Photomask-merlin` directory should be organized as:

```
d-Photomask-merlin/
├── EV/
│   ├── image1_ev.png
│   ├── image1_ev.xml
│   ├── image2_ev.png
│   └── image2_ev.xml
├── BV/
│   ├── image1_bv.png
│   ├── image1_bv.xml
│   └── ...
└── TV/
    ├── image1_tv.png
    ├── image1_tv.xml
    └── ...
```

**Annotations:** Pascal VOC XML format (same name as image)

## 🎛️ Advanced Configuration

### Tuning for Maximum Recall

If you need even higher recall, modify these settings in `train_high_recall.py`:

```python
# Line 120-130: Increase proposals
rpn_pre_nms_top_n_train=5000,      # More proposals
rpn_post_nms_top_n_train=5000,

# Line 135: Lower detection threshold
box_score_thresh=0.01,              # Even lower threshold

# Line 137: More detections per image
box_detections_per_img=500,
```

### Tuning for Speed

For faster training (if 6 hours is tight):

```bash
# Use smaller batch size and fewer epochs
python train_high_recall.py \
    --epochs 10 \
    --batch_size 2 \
    --backbone mobilenet
```

### Custom Anchor Sizes

If your defects are consistently small or large, adjust anchors in `train_high_recall.py` line 107:

```python
# For very small defects (< 20px)
anchor_sizes = ((4, 8, 16, 32, 64),)

# For larger defects (> 50px)
anchor_sizes = ((32, 64, 128, 256, 512),)
```

## 📈 Monitoring Training

During training, you'll see:

```
Epoch 0 Results:
  Average Loss: 0.4523
  Metrics at different thresholds:
    thresh_0.05: Recall=0.950, Precision=0.650, F1=0.772
    thresh_0.10: Recall=0.920, Precision=0.720, F1=0.808
    thresh_0.50: Recall=0.850, Precision=0.900, F1=0.874
  ✓ New best recall: 0.950
```

**Key metrics:**
- **Recall at 0.05 threshold**: Most important - should be > 0.90
- **F1 score**: Balance between recall and precision
- **Loss**: Should decrease over epochs

## 🔧 Troubleshooting

### Out of Memory Error

Reduce batch size:
```bash
python train_high_recall.py --batch_size 2
```

### Training Too Slow

- Use MobileNet backbone (faster than ResNet)
- Reduce number of epochs
- Use smaller image size (modify in code if needed)

### Low Recall

- Lower the detection threshold: `--threshold 0.01`
- Increase proposals in model configuration
- Add more training data
- Train for more epochs

### Too Many False Positives

- Enable stage 2 refinement
- Adjust heuristic thresholds in `two_stage_inference.py`
- Use higher confidence threshold at inference

## 📝 Model Performance

Expected performance on validation set:

| Threshold | Recall | Precision | F1 Score |
|-----------|--------|-----------|----------|
| 0.05      | ~0.95  | ~0.65     | ~0.77    |
| 0.10      | ~0.92  | ~0.72     | ~0.81    |
| 0.30      | ~0.88  | ~0.88     | ~0.88    |
| 0.50      | ~0.85  | ~0.92     | ~0.88    |

**Recommendation:** Use threshold 0.05 for maximum recall, then apply stage 2 refinement.

## 🎓 Tips for Best Results

1. **Data Quality**: Ensure XML annotations are accurate
2. **Balanced Dataset**: Include both defective and clean images
3. **Augmentation**: The script includes flips and color jitter - add more if needed
4. **Validation**: Always check results on held-out validation set
5. **Ensemble**: Train multiple models and combine predictions for even higher recall

## 📦 ONNX Deployment

The exported ONNX model is self-contained and can be deployed anywhere:

```python
import onnxruntime as ort
import numpy as np
from PIL import Image

# Load model
session = ort.InferenceSession('best_model.onnx')

# Prepare image
img = Image.open('test.png').convert('RGB')
img_array = np.array(img).transpose(2, 0, 1).astype(np.float32) / 255.0
img_tensor = np.expand_dims(img_array, 0)

# Run inference
boxes, labels, scores = session.run(None, {'input': img_tensor})

# Filter by threshold
mask = scores >= 0.05
final_boxes = boxes[mask]
final_scores = scores[mask]
```

## ⏱️ Training Time Estimates

On NVIDIA RTX 3080 (10GB):
- **EV model** (20 epochs): ~1.5 hours
- **BV model** (20 epochs): ~1.5 hours  
- **TV model** (20 epochs): ~1.5 hours
- **Total (all 3)**: ~4.5 hours

**Well within your 6-hour deadline!**

## 🚀 Next Steps

1. Train your models: `python train_all.py --data_dir /path/to/data`
2. Evaluate on validation set
3. Run inference on test images
4. Deploy ONNX model to your device
5. Fine-tune thresholds based on your requirements

## 📧 Notes

- Models are trained separately for EV, BV, and TV (as per your requirements)
- The ONNX model works on your inference device (you mentioned it worked before)
- Two-stage approach: maximize recall first, then improve precision
- All optimizations are included for maximum recall on small defects

Good luck with your training! 🎉
