"""
One-Click Training Launcher
Trains models for EV, BV, and TV image types automatically
"""

import os
import sys
import subprocess
import argparse
from datetime import datetime


def train_single_model(data_dir, image_type, base_output_dir, epochs, batch_size, backbone, device):
    """Train a single model for one image type"""
    
    output_dir = os.path.join(base_output_dir, f"{image_type}_model")
    os.makedirs(output_dir, exist_ok=True)
    
    print(f"\n{'='*70}")
    print(f"TRAINING {image_type} MODEL")
    print(f"{'='*70}\n")
    
    cmd = [
        sys.executable,
        'train_high_recall.py',
        '--data_dir', data_dir,
        '--image_type', image_type,
        '--output_dir', output_dir,
        '--epochs', str(epochs),
        '--batch_size', str(batch_size),
        '--backbone', backbone,
        '--device', str(device),
        '--export_onnx'
    ]
    
    try:
        subprocess.run(cmd, check=True)
        print(f"\n✓ {image_type} model training completed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n✗ {image_type} model training failed!")
        return False


def main():
    parser = argparse.ArgumentParser(description='One-click training for all image types')
    parser.add_argument('--data_dir', type=str, required=True,
                       help='Path to d-Photomask-merlin directory')
    parser.add_argument('--output_dir', type=str, default='./trained_models',
                       help='Base output directory for all models')
    parser.add_argument('--image_types', type=str, nargs='+', 
                       default=['EV', 'BV', 'TV'],
                       help='Image types to train (default: EV BV TV)')
    parser.add_argument('--epochs', type=int, default=20,
                       help='Number of training epochs (default: 20)')
    parser.add_argument('--batch_size', type=int, default=4,
                       help='Batch size (default: 4)')
    parser.add_argument('--backbone', type=str, default='mobilenet',
                       choices=['mobilenet', 'resnet18'],
                       help='Backbone architecture (default: mobilenet)')
    parser.add_argument('--device', type=int, default=0,
                       help='CUDA device ID (default: 0)')
    
    args = parser.parse_args()
    
    # Create timestamped output directory
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_dir = os.path.join(args.output_dir, f"training_{timestamp}")
    os.makedirs(output_dir, exist_ok=True)
    
    print(f"\n{'='*70}")
    print(f"ONE-CLICK TRAINING LAUNCHER")
    print(f"{'='*70}")
    print(f"Data Directory: {args.data_dir}")
    print(f"Output Directory: {output_dir}")
    print(f"Image Types: {', '.join(args.image_types)}")
    print(f"Epochs: {args.epochs}")
    print(f"Batch Size: {args.batch_size}")
    print(f"Backbone: {args.backbone}")
    print(f"Device: cuda:{args.device}")
    print(f"{'='*70}\n")
    
    # Train models for each image type
    results = {}
    
    for image_type in args.image_types:
        success = train_single_model(
            data_dir=args.data_dir,
            image_type=image_type,
            base_output_dir=output_dir,
            epochs=args.epochs,
            batch_size=args.batch_size,
            backbone=args.backbone,
            device=args.device
        )
        results[image_type] = success
    
    # Print summary
    print(f"\n{'='*70}")
    print(f"TRAINING SUMMARY")
    print(f"{'='*70}")
    
    for image_type, success in results.items():
        status = "✓ SUCCESS" if success else "✗ FAILED"
        print(f"{image_type}: {status}")
    
    print(f"\nAll models saved to: {output_dir}")
    print(f"{'='*70}\n")
    
    # Check if all succeeded
    if all(results.values()):
        print("🎉 All models trained successfully!")
        return 0
    else:
        print("⚠️  Some models failed to train. Check logs above.")
        return 1


if __name__ == '__main__':
    sys.exit(main())
