"""
Two-Stage Inference: High Recall Detection + Precision Refinement
Stage 1: Detect all possible defects (maximize recall)
Stage 2: Filter false positives (improve precision)
"""

import torch
import torchvision
from torchvision import transforms as T
from PIL import Image
import numpy as np
import onnxruntime as ort
import cv2
from typing import List, Tuple, Dict
import os


class TwoStageDetector:
    """
    Two-stage defect detector:
    1. High-recall detection (catch everything)
    2. Precision refinement (filter false positives)
    """
    
    def __init__(self, stage1_model_path, stage2_model_path=None, device='cuda:0'):
        """
        Args:
            stage1_model_path: Path to high-recall ONNX model
            stage2_model_path: Optional path to precision refinement model
            device: Device for inference
        """
        self.device = device
        
        # Load Stage 1: High Recall Detector
        if stage1_model_path.endswith('.onnx'):
            self.stage1_session = ort.InferenceSession(stage1_model_path)
            self.use_onnx_stage1 = True
        else:
            self.stage1_model = self.load_pytorch_model(stage1_model_path)
            self.use_onnx_stage1 = False
        
        # Load Stage 2: Precision Refinement (if provided)
        self.stage2_model = None
        if stage2_model_path:
            if stage2_model_path.endswith('.onnx'):
                self.stage2_session = ort.InferenceSession(stage2_model_path)
                self.use_onnx_stage2 = True
            else:
                self.stage2_model = self.load_pytorch_model(stage2_model_path)
                self.use_onnx_stage2 = False
        
        self.transform = T.Compose([T.ToTensor()])
    
    def load_pytorch_model(self, model_path):
        """Load PyTorch model"""
        from train_high_recall import get_high_recall_model
        
        model = get_high_recall_model(num_classes=2, backbone_type='mobilenet')
        model.load_state_dict(torch.load(model_path, map_location=self.device))
        model.to(self.device)
        model.eval()
        return model
    
    @torch.no_grad()
    def stage1_detect(self, image: Image.Image, conf_threshold=0.05) -> Dict:
        """
        Stage 1: High-recall detection
        Uses very low confidence threshold to catch all possible defects
        """
        img_tensor = self.transform(image).unsqueeze(0)
        
        if self.use_onnx_stage1:
            # ONNX inference
            inputs = {self.stage1_session.get_inputs()[0].name: img_tensor.numpy()}
            boxes, labels, scores = self.stage1_session.run(None, inputs)
        else:
            # PyTorch inference
            img_tensor = img_tensor.to(self.device)
            outputs = self.stage1_model(img_tensor)[0]
            boxes = outputs['boxes'].cpu().numpy()
            labels = outputs['labels'].cpu().numpy()
            scores = outputs['scores'].cpu().numpy()
        
        # Filter by confidence threshold
        mask = scores >= conf_threshold
        
        return {
            'boxes': boxes[mask],
            'labels': labels[mask],
            'scores': scores[mask]
        }
    
    def extract_roi_features(self, image: Image.Image, box: np.ndarray) -> np.ndarray:
        """Extract features from region of interest for stage 2 classification"""
        img_array = np.array(image)
        x1, y1, x2, y2 = box.astype(int)
        
        # Clip to image bounds
        h, w = img_array.shape[:2]
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(w, x2), min(h, y2)
        
        # Extract ROI
        roi = img_array[y1:y2, x1:x2]
        
        if roi.size == 0:
            return None
        
        # Resize to fixed size for classifier
        roi_resized = cv2.resize(roi, (64, 64))
        
        # Compute features
        features = []
        
        # 1. Color statistics
        mean_color = roi_resized.mean(axis=(0, 1))
        std_color = roi_resized.std(axis=(0, 1))
        features.extend(mean_color)
        features.extend(std_color)
        
        # 2. Texture features (gradient magnitude)
        gray = cv2.cvtColor(roi_resized, cv2.COLOR_RGB2GRAY)
        gx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        gy = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        grad_mag = np.sqrt(gx**2 + gy**2)
        features.extend([grad_mag.mean(), grad_mag.std()])
        
        # 3. Size features
        roi_area = (x2 - x1) * (y2 - y1)
        roi_aspect = (x2 - x1) / max(1, (y2 - y1))
        features.extend([roi_area, roi_aspect])
        
        return np.array(features, dtype=np.float32)
    
    def stage2_refine(self, image: Image.Image, detections: Dict) -> Dict:
        """
        Stage 2: Precision refinement
        Classify each detection as real defect or false positive
        """
        if self.stage2_model is None:
            # No refinement model, return all detections
            return detections
        
        refined_boxes = []
        refined_labels = []
        refined_scores = []
        
        for box, label, score in zip(detections['boxes'], 
                                      detections['labels'], 
                                      detections['scores']):
            # Extract features
            features = self.extract_roi_features(image, box)
            
            if features is None:
                continue
            
            # Simple heuristic-based filtering (can be replaced with trained classifier)
            # Filter based on:
            # 1. Size (too small or too large might be noise)
            # 2. Texture variance (real defects have certain texture patterns)
            # 3. Location (edge artifacts)
            
            roi_area = features[-2]
            grad_std = features[-3]
            
            # Heuristic thresholds (tune based on validation data)
            if roi_area < 10 or roi_area > 50000:  # Size filter
                continue
            
            if grad_std < 5:  # Too smooth, likely false positive
                continue
            
            refined_boxes.append(box)
            refined_labels.append(label)
            refined_scores.append(score)
        
        return {
            'boxes': np.array(refined_boxes),
            'labels': np.array(refined_labels),
            'scores': np.array(refined_scores)
        }
    
    def detect(self, image: Image.Image, 
               stage1_threshold=0.05, 
               use_stage2=True) -> Dict:
        """
        Full two-stage detection pipeline
        
        Args:
            image: Input PIL Image
            stage1_threshold: Confidence threshold for stage 1 (low for high recall)
            use_stage2: Whether to apply stage 2 refinement
        
        Returns:
            Dictionary with 'boxes', 'labels', 'scores'
        """
        # Stage 1: High-recall detection
        detections = self.stage1_detect(image, conf_threshold=stage1_threshold)
        
        print(f"Stage 1: Detected {len(detections['boxes'])} candidates")
        
        # Stage 2: Precision refinement
        if use_stage2:
            detections = self.stage2_refine(image, detections)
            print(f"Stage 2: Refined to {len(detections['boxes'])} detections")
        
        return detections
    
    def visualize_detections(self, image: Image.Image, detections: Dict, 
                            output_path: str = None, show_scores=True):
        """Visualize detections on image"""
        img_array = np.array(image).copy()
        
        for box, label, score in zip(detections['boxes'], 
                                      detections['labels'], 
                                      detections['scores']):
            x1, y1, x2, y2 = box.astype(int)
            
            # Draw box
            color = (0, 255, 0)  # Green for defects
            cv2.rectangle(img_array, (x1, y1), (x2, y2), color, 2)
            
            # Draw label and score
            if show_scores:
                text = f"{score:.2f}"
                cv2.putText(img_array, text, (x1, y1 - 5), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        result_image = Image.fromarray(img_array)
        
        if output_path:
            result_image.save(output_path)
        
        return result_image


def batch_inference(detector: TwoStageDetector, 
                   image_dir: str, 
                   output_dir: str,
                   image_type: str = 'EV'):
    """Run inference on a batch of images"""
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Find all images
    img_exts = ['.jpg', '.png', '.bmp']
    image_files = []
    
    for f in os.listdir(image_dir):
        if any(f.lower().endswith(ext) for ext in img_exts):
            if image_type.lower() in f.lower():
                image_files.append(os.path.join(image_dir, f))
    
    print(f"Found {len(image_files)} {image_type} images")
    
    results = []
    
    for img_path in image_files:
        print(f"\nProcessing: {os.path.basename(img_path)}")
        
        # Load image
        image = Image.open(img_path).convert('RGB')
        
        # Detect
        detections = detector.detect(image)
        
        # Visualize
        output_path = os.path.join(output_dir, f"result_{os.path.basename(img_path)}")
        detector.visualize_detections(image, detections, output_path)
        
        results.append({
            'image': os.path.basename(img_path),
            'num_detections': len(detections['boxes']),
            'detections': detections
        })
    
    # Save results summary
    import json
    with open(os.path.join(output_dir, 'results.json'), 'w') as f:
        # Convert numpy arrays to lists for JSON serialization
        json_results = []
        for r in results:
            json_r = {
                'image': r['image'],
                'num_detections': r['num_detections'],
                'boxes': r['detections']['boxes'].tolist(),
                'labels': r['detections']['labels'].tolist(),
                'scores': r['detections']['scores'].tolist()
            }
            json_results.append(json_r)
        
        json.dump(json_results, f, indent=2)
    
    print(f"\n✓ Results saved to {output_dir}")


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Two-stage defect detection inference')
    parser.add_argument('--model', type=str, required=True,
                       help='Path to stage 1 model (ONNX or .pt)')
    parser.add_argument('--image', type=str, help='Single image path')
    parser.add_argument('--image_dir', type=str, help='Directory of images')
    parser.add_argument('--output_dir', type=str, default='./inference_results',
                       help='Output directory')
    parser.add_argument('--image_type', type=str, default='EV',
                       choices=['EV', 'BV', 'TV'],
                       help='Image type')
    parser.add_argument('--threshold', type=float, default=0.05,
                       help='Stage 1 confidence threshold')
    parser.add_argument('--no_stage2', action='store_true',
                       help='Disable stage 2 refinement')
    parser.add_argument('--device', type=str, default='cuda:0',
                       help='Device for inference')
    
    args = parser.parse_args()
    
    # Create detector
    detector = TwoStageDetector(args.model, device=args.device)
    
    if args.image:
        # Single image inference
        image = Image.open(args.image).convert('RGB')
        detections = detector.detect(image, 
                                    stage1_threshold=args.threshold,
                                    use_stage2=not args.no_stage2)
        
        output_path = os.path.join(args.output_dir, f"result_{os.path.basename(args.image)}")
        os.makedirs(args.output_dir, exist_ok=True)
        detector.visualize_detections(image, detections, output_path)
        
        print(f"\n✓ Result saved to {output_path}")
        print(f"  Detected {len(detections['boxes'])} defects")
    
    elif args.image_dir:
        # Batch inference
        batch_inference(detector, args.image_dir, args.output_dir, args.image_type)
    
    else:
        print("Error: Please specify either --image or --image_dir")
