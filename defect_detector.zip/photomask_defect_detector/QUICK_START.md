# Quick Start Guide - 5 Minutes to Training

## ⚡ Fastest Way to Start

### 1. Install Dependencies (1 minute)
```bash
pip install -r requirements.txt
```

### 2. One-Click Training (4.5 hours)
```bash
python train_all.py --data_dir /path/to/d-Photomask-merlin --epochs 20
```

**That's it!** This will train all three models (EV, BV, TV) and export to ONNX.

---

## 📋 Command Reference

### Train Single Model
```bash
# EV model
python train_high_recall.py --data_dir /path/to/data --image_type EV --export_onnx

# BV model  
python train_high_recall.py --data_dir /path/to/data --image_type BV --export_onnx

# TV model
python train_high_recall.py --data_dir /path/to/data --image_type TV --export_onnx
```

### Run Inference
```bash
# Single image
python two_stage_inference.py --model results/best_model.onnx --image test.png

# Batch
python two_stage_inference.py --model results/best_model.onnx --image_dir /path/to/images --image_type EV
```

---

## 🎯 Key Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `--epochs` | 20 | Training epochs (~1.5h per model) |
| `--batch_size` | 4 | Batch size (reduce if OOM) |
| `--backbone` | mobilenet | Use `resnet18` for more accuracy |
| `--threshold` | 0.05 | Detection threshold (lower = higher recall) |

---

## 📊 Expected Results

After training, you'll get:
- ✅ **Recall**: ~95% at threshold 0.05
- ✅ **Precision**: ~65% (improves to ~85% with stage 2)
- ✅ **Training time**: ~1.5 hours per model
- ✅ **ONNX model**: Ready for deployment

---

## 🔥 Maximum Recall Settings

For absolute maximum recall (catch EVERYTHING):

```bash
python train_high_recall.py \
    --data_dir /path/to/data \
    --image_type EV \
    --epochs 25 \
    --export_onnx
```

Then at inference:
```bash
python two_stage_inference.py \
    --model best_model.onnx \
    --image test.png \
    --threshold 0.01 \
    --no_stage2
```

---

## ⚠️ Troubleshooting

**Out of memory?**
```bash
python train_high_recall.py --batch_size 2
```

**Too slow?**
```bash
python train_high_recall.py --epochs 10 --backbone mobilenet
```

**Need higher recall?**
- Lower `--threshold` to 0.01
- Train for more epochs
- Disable stage 2 refinement (`--no_stage2`)

---

## 📁 Output Structure

```
trained_models/
└── training_20250114_120000/
    ├── EV_model/
    │   ├── best_recall_model.pt
    │   ├── best_model.onnx ← Use this!
    │   └── training_history.json
    ├── BV_model/
    │   └── ...
    └── TV_model/
        └── ...
```

---

## 🎓 Pro Tips

1. **Start with one model** to test your setup
2. **Monitor GPU usage** with `nvidia-smi`
3. **Check validation metrics** after each epoch
4. **Use stage 2 refinement** to reduce false positives
5. **Ensemble multiple models** for even better results

---

## ⏱️ Timeline

- **Install**: 1 min
- **EV training**: 1.5 hours
- **BV training**: 1.5 hours
- **TV training**: 1.5 hours
- **Total**: ~4.5 hours (well under 6 hours!)

---

**Ready? Let's go!** 🚀

```bash
python train_all.py --data_dir /path/to/d-Photomask-merlin
```
