"""
Configuration Template for High-Recall Training

Modify these settings to customize your training.
Copy this file to config.py and adjust as needed.
"""

# ============================================================================
# DATA CONFIGURATION
# ============================================================================

# Path to your d-Photomask-merlin directory
DATA_DIR = "/path/to/d-Photomask-merlin"

# Image types to train (separate models for each)
IMAGE_TYPES = ['EV', 'BV', 'TV']

# Train/validation split ratio
SPLIT_RATIO = 0.8  # 80% train, 20% validation

# ============================================================================
# MODEL CONFIGURATION
# ============================================================================

# Backbone architecture
# Options: 'mobilenet' (faster), 'resnet18' (more accurate)
BACKBONE = 'mobilenet'

# Pretrained weights
USE_PRETRAINED = True

# ============================================================================
# TRAINING CONFIGURATION
# ============================================================================

# Number of training epochs
# Recommended: 20 for good results, 10 for quick testing
NUM_EPOCHS = 20

# Batch size (reduce if out of memory)
BATCH_SIZE = 4

# Number of data loading workers
NUM_WORKERS = 4

# Learning rate
LEARNING_RATE = 0.01

# Learning rate schedule (epochs to reduce LR)
LR_MILESTONES = [10, 15]
LR_GAMMA = 0.1  # Multiply LR by this at each milestone

# ============================================================================
# HIGH-RECALL OPTIMIZATION SETTINGS
# ============================================================================

# Anchor sizes for different defect scales
# Smaller anchors = better detection of tiny defects
ANCHOR_SIZES = ((8, 16, 32, 64, 128),)
ANCHOR_ASPECT_RATIOS = ((0.5, 1.0, 2.0),)

# RPN (Region Proposal Network) settings for maximum recall
RPN_PRE_NMS_TOP_N_TRAIN = 3000   # Number of proposals before NMS
RPN_POST_NMS_TOP_N_TRAIN = 3000  # Number of proposals after NMS
RPN_PRE_NMS_TOP_N_TEST = 3000
RPN_POST_NMS_TOP_N_TEST = 3000

# NMS (Non-Maximum Suppression) threshold
# Higher = keep more overlapping boxes (better for nearby defects)
RPN_NMS_THRESH = 0.7

# Foreground/background IoU thresholds
RPN_FG_IOU_THRESH = 0.5  # Lower = more proposals considered as defects
RPN_BG_IOU_THRESH = 0.3  # Higher = fewer proposals considered as background

# Detection confidence threshold
# VERY LOW for maximum recall (catch everything!)
BOX_SCORE_THRESH = 0.05

# Detection NMS threshold
# Lower = keep more overlapping detections
BOX_NMS_THRESH = 0.3

# Maximum detections per image
BOX_DETECTIONS_PER_IMG = 300

# ============================================================================
# DATA AUGMENTATION
# ============================================================================

# Training augmentations
USE_HORIZONTAL_FLIP = True
USE_VERTICAL_FLIP = True
USE_COLOR_JITTER = True

# Color jitter parameters
COLOR_JITTER_BRIGHTNESS = 0.2
COLOR_JITTER_CONTRAST = 0.2

# ============================================================================
# TWO-STAGE INFERENCE CONFIGURATION
# ============================================================================

# Stage 1: High-recall detection threshold
STAGE1_THRESHOLD = 0.05  # Very low for maximum recall

# Stage 2: Precision refinement settings
USE_STAGE2_REFINEMENT = True

# Size filtering (pixels)
MIN_DEFECT_AREA = 10      # Minimum defect size
MAX_DEFECT_AREA = 50000   # Maximum defect size

# Texture filtering
MIN_GRADIENT_STD = 5      # Minimum texture variance

# ============================================================================
# OUTPUT CONFIGURATION
# ============================================================================

# Base output directory
OUTPUT_DIR = "./trained_models"

# Export to ONNX after training
EXPORT_ONNX = True

# ONNX export image size (width, height)
ONNX_IMAGE_SIZE = (640, 640)

# Save checkpoints
SAVE_BEST_RECALL = True
SAVE_BEST_F1 = True
SAVE_LATEST = True

# ============================================================================
# HARDWARE CONFIGURATION
# ============================================================================

# CUDA device ID (0 for first GPU, -1 for CPU)
DEVICE_ID = 0

# Enable mixed precision training (faster on modern GPUs)
USE_AMP = False  # Set to True if you have Tensor Cores (RTX series)

# ============================================================================
# EVALUATION CONFIGURATION
# ============================================================================

# Confidence thresholds to evaluate
EVAL_THRESHOLDS = [0.05, 0.1, 0.2, 0.3, 0.5]

# IoU threshold for matching predictions to ground truth
EVAL_IOU_THRESHOLD = 0.5

# ============================================================================
# ADVANCED SETTINGS (for experts)
# ============================================================================

# Warmup iterations
WARMUP_ITERS = 1000
WARMUP_FACTOR = 1.0 / 1000

# Gradient clipping (prevent exploding gradients)
CLIP_GRAD_NORM = None  # Set to a value like 10.0 if training is unstable

# Weight decay for regularization
WEIGHT_DECAY = 0.0005

# Momentum for SGD optimizer
MOMENTUM = 0.9

# ============================================================================
# RECALL MAXIMIZATION PRESETS
# ============================================================================

def apply_max_recall_preset():
    """Apply settings for absolute maximum recall"""
    global BOX_SCORE_THRESH, RPN_POST_NMS_TOP_N_TRAIN, BOX_DETECTIONS_PER_IMG
    global STAGE1_THRESHOLD, MIN_DEFECT_AREA
    
    BOX_SCORE_THRESH = 0.01
    RPN_POST_NMS_TOP_N_TRAIN = 5000
    BOX_DETECTIONS_PER_IMG = 500
    STAGE1_THRESHOLD = 0.01
    MIN_DEFECT_AREA = 5
    
    print("✓ Applied MAX RECALL preset")


def apply_balanced_preset():
    """Apply settings for balanced recall/precision"""
    global BOX_SCORE_THRESH, STAGE1_THRESHOLD, USE_STAGE2_REFINEMENT
    
    BOX_SCORE_THRESH = 0.1
    STAGE1_THRESHOLD = 0.1
    USE_STAGE2_REFINEMENT = True
    
    print("✓ Applied BALANCED preset")


def apply_fast_training_preset():
    """Apply settings for faster training (testing)"""
    global NUM_EPOCHS, BATCH_SIZE, NUM_WORKERS
    
    NUM_EPOCHS = 10
    BATCH_SIZE = 2
    NUM_WORKERS = 2
    
    print("✓ Applied FAST TRAINING preset")


# ============================================================================
# USAGE EXAMPLES
# ============================================================================

"""
# Example 1: Maximum recall (don't miss anything!)
from config_template import *
apply_max_recall_preset()

# Example 2: Balanced performance
from config_template import *
apply_balanced_preset()

# Example 3: Quick testing
from config_template import *
apply_fast_training_preset()

# Example 4: Custom settings
from config_template import *
BOX_SCORE_THRESH = 0.03
NUM_EPOCHS = 25
BACKBONE = 'resnet18'
"""
